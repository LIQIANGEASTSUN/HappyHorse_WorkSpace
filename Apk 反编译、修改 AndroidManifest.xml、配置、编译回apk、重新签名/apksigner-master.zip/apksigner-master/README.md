# ApkSigner

Apk 反编译、修改 AndroidManifest.xml、配置、编译回apk、重新签名