local PoolWarmProcessor = {}

function PoolWarmProcessor.Start(onFinish, onProgress)
    WaitExtension.SetTimeout(function()
        -- 这里完成资源池初始化
        Runtime.InvokeCbk(onFinish)
    end, 0.2)
end


return PoolWarmProcessor