local LoadingPanelProxy = class()

function LoadingPanelProxy:ctor()

end

function LoadingPanelProxy:init()

end

return LoadingPanelProxy
