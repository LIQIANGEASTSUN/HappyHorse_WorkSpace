LoadingPanelNotificationEnum =
{
	Click_btn_Confirm = "LoginPanelNotificationEnum_Click_btn_Confirm",
	UPDATE_LOADING_PROCESS = "UPDATE_LOADING_PROCESS",
	--ShowGameStartButton = "ShowGameStartButton",
    ShowGameButtonOnly = "ShowGameButtonOnly",
    --SHOW_OR_HIDE_PROGRESS = "LoginPanelNotificationEnum_SHOW_OR_HIDE_PROGRESS",
	Click_btn_facebook = "LoginPanelNotificationEnum_Click_btn_facebook",
	Click_btn_apple = "LoginPanelNotificationEnum_Click_btn_apple",
	Click_btn_FAQ = "LoginPanelNotificationEnum_Click_btn_FAQ",
	SDKAUTOLOGIN = "LoginPanelNotificationEnum_SDKAUTOLOGIN",
	LOGIN_RESULT_SUC = "LoginPanelNotificationEnum_LOGIN_RESULT_SUC",

	--new
	ShowTitleCartoon = "ShowTitleCartoon",
	ShowLoadingView = "ShowLoadingView",
	HideAll = "HideAll",
}
