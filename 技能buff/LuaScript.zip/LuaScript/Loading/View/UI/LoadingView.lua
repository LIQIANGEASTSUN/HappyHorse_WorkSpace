--insertRequire

---@class LoadingView
local LoadingView = class()

function LoadingView:ctor()
    self.resource = nil
    self.proxy = nil
    --insertCtor
    self.btn_Confirm = nil
    self.onClick_btn_Confirm = nil

    self.resource = GameObject.Find("Canvas/LoginPanel")
    self.isAnima = false
end

function LoadingView:setArguments(args)
end

function LoadingView:setProxy(proxy)
    self.proxy = proxy
    --setProxy
end

--------------Open LoginPanel 的逻辑 ------------
--@params 控制gitTips的显隐
function LoadingView:ShowGiftTips(isShow)
    self.gitTips:SetActive(isShow)
end

--@params 控制ChannelPanel/btn_panel的显隐
function LoadingView:ShowBtnPanel(isShow)
end

function LoadingView:bindView()
    self.sliderBg = find_component(self.resource, "sliderBg")
    self.scb_LoadingProgress = find_component(self.sliderBg, "slider", Image)

    self.loadingCanvas = GameObject.Find("LoadingCanvas")

    self.bundleVersionText = self.resource:FindGameObject("BundleVersion"):GetComponent(typeof(Text))
    self.bundleVersionText.text = RuntimeContext.BUNDLE_VERSION

    self.tips = find_component(self.sliderBg, "Tips", Text)
    self.tips.text = Runtime.Translate("LoadingScene.LoadingView.Tips." .. math.random(1, 6))
    if BCore.IsOpen("SpecialCheck") then
        self.tips:FindGameObject("HealthAdvice"):SetActive(true)
    end
    local cgCanvas = GameObject.Find("CGCanvas")

    self.cgCanvasGroup = cgCanvas:GetComponent(typeof(CanvasGroup))
    self.cgCanvasGroup.alpha = 0
    AppServices.CGPlayer:Init(cgCanvas)
    AppServices.CGPlayer:SetSkipCallback(function()
        --App:Log(SDK_EVENT.CGSkip, {})
    end)
end


function LoadingView:PlayCG(finishCallback)
    ---视频播放完毕或销毁回调
    local function onFinish()
        self:DestroyCG()
        Runtime.InvokeCbk(finishCallback)
    end
    ---播放视频至白屏阶段
    -- local function onScreenFlash()
    --     -- Runtime.InvokeCbk(onFlash)
    -- end
    ---视频开始播放回调
    local function onStart()
        GameUtil.DoFade(self.cgCanvasGroup, 1, 0.5)
    end


    local cgPlayer = AppServices.CGPlayer
    cgPlayer:SetFinishCallback(onFinish)
    cgPlayer:SetStartCallback(onStart)
    -- cgPlayer:SetFlashCallback(onScreenFlash)
    cgPlayer:Play()
end

function LoadingView:DestroyCG()
    -- CSDestroy(self.CGPlayer)
    -- CSDestroy(self.cgCanvasGroup.gameObject)
    AppServices.CGPlayer:Destory()
    -- self.skipButton = nil
    self.cgCanvasGroup = nil
end


function LoadingView:setProgress(val)
    -- val = math.max(0.07, val)

    local function updateCallback(value)
        self.scb_LoadingProgress.fillAmount = value
    end

    local function completeCallback()
        if self.floatSmoothTweener ~= nil then
            self.floatSmoothTweener:Kill()
            self.floatSmoothTweener = nil
        end
    end

    completeCallback()
    self.floatSmoothTweener = LuaHelper.FloatSmooth(self.scb_LoadingProgress.fillAmount, val, 0.3, updateCallback, completeCallback)
end

--隐藏进度条UI
function LoadingView:ShowTitleCartoon()
    self.sliderBg:SetActive(false)
end

return LoadingView
