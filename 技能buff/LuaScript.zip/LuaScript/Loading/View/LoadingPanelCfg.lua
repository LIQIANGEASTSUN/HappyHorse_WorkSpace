local LoadingPanelCfg = {
	panelName = "LoadingPanel",
	classPath = "Loading.View.UI.LoadingView",
	mediatorPath = "Loading.View.LoadingPanelMediator",
}

return LoadingPanelCfg
