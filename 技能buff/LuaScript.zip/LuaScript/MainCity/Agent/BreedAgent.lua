local BreedUnit = require "Cleaner.Unit.BreedUnit"
---@type NormalAgent
local NormalAgent = require("MainCity.Agent.NormalAgent")
local BreedAgent = class(NormalAgent, "BreedAgent")

local StateChangedHandles = {
    ---@param agent BreedAgent
    [CleanState.clearing] = function(agent)
        return agent:SetState(CleanState.cleared)
    end,
    [CleanState.cleared] = function(agent)
        agent:InitRender(
            function(result)
                agent:SetClickable(true)
            end
        )

        local x, z = agent:GetMin()
        local sx, sz = agent:GetSize()
        --后触发格子状态
        ---@type MapManager
        local map = App.scene.mapManager
        return map:SetBlockState(x, sx, z, sz, CleanState.cleared)
    end
}

-- 装扮建筑 Agent
function BreedAgent:ctor(id, data)
    self.id = id -- 构造出的唯一ID
    self.data = data
end

function BreedAgent:OnStateChanged(...)
    local state = self:GetState()
    local handler = StateChangedHandles[state]
    if handler then
        return handler(self)
    end
end

function BreedAgent:InitRender(callback)
    NormalAgent.InitRender(self, callback)
    self.render:AddInstantiateListener(
        function(result)
            self:RenderInstantiateCallBack(result)
        end
    )
end

function BreedAgent:RenderInstantiateCallBack(result)
    if not result then
        return
    end
    self.BreedUnit = BreedUnit.new(self)
    self:AddUnit(self.BreedUnit)
    -- self.BreedUnit:Init()
end

-- 处理点击
function BreedAgent:ProcessClick()
    local callback = function()
        local state = self:GetState()
        if state == CleanState.cleared then
            local a = AppServices.BreedManager:GetBreedOnlyID()
            if a then
                local t = AppServices.BreedManager:GetBreedsIsFinish()
                if t then
                    AppServices.NetBuildingManager:SendPetBreedReward(a)
                else
                    PanelManager.showPanel(GlobalPanelEnum.BreedDoingPanel)
                end
            else
                PanelManager.showPanel(GlobalPanelEnum.BreedPanel)
            end
        end
    end
    AppServices.BreedManager:OnShowBreedPanel(self:GetId(), callback)
end

function BreedAgent:SetState(state)
    if self.data:SetState(state) then
        return self:HandleStateChanged()
    end
end

function BreedAgent:Destroy(...)
    -- body
end

return BreedAgent
