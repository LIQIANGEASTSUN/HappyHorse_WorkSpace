---@type OnHookBuildUnit
local OnHookBuildUnit = require "Cleaner.Unit.OnHookBuildUnit"
---@type NormalAgent
local NormalAgent = require("MainCity.Agent.NormalAgent")

---@class OnHookBuildAgent:NormalAgent
local OnHookBuildAgent = class(NormalAgent, "OnHookBuildAgent")

local StateChangedHandles = {
    ---@param agent OnHookBuildAgent
    [CleanState.cleared] = function(agent)
        agent:InitRender(
            function(result)
                agent:SetClickable(true)
            end
        )

        local x, z = agent:GetMin()
        local sx, sz = agent:GetSize()
        --后触发格子状态
        ---@type MapManager
        local map = App.scene.mapManager
        return map:SetBlockState(x, sx, z, sz, CleanState.cleared)
    end
}

-- 挂机建筑 Agent
function OnHookBuildAgent:ctor(id, data)
    self.id = id -- 构造出的唯一ID
    self.data = data
end

function OnHookBuildAgent:OnStateChanged(...)
    local state = self:GetState()
    local handler = StateChangedHandles[state]
    if handler then
        return handler(self)
    end
end

function OnHookBuildAgent:InitRender(callback)
    NormalAgent.InitRender(self, callback)
    self.render:AddInstantiateListener(
        function(result)
            self:RenderInstantiateCallBack(result)
        end
    )
end

-- 通过宠物的类型，返回宠物是否绑定挂机建筑 ID
function OnHookBuildAgent:GetBuildIDByPetType(_petTyp)
    return self.onHookBuildUnit:GetBuildIDByPetType(_petTyp)
end

function OnHookBuildAgent:RenderInstantiateCallBack(result)
    if not result then
        return
    end

    -- local production = AppServices.User:GetProduction(self:GetId())
    -- SceneServices.DecorationFactory:InitWithResponse(self:GetId(), production)
    -- self:NotifyProduction(true)

    self.onHookBuildUnit = OnHookBuildUnit.new(self)
    self:AddUnit(self.onHookBuildUnit)
    self.onHookBuildUnit:Init()
    MessageDispatcher:SendMessage(MessageType.BUILDONHOOKMESSAGE)
end

-- 处理点击
function OnHookBuildAgent:ProcessClick()
    local state = self:GetState()
    if state == CleanState.cleared then
        console.jf("....测试挂机建筑被点击效果....")
        local region = self:GetRegion()
        if region and region:IsLinked() then
            return self.onHookBuildUnit:OnClick()
        end

        local message = Runtime.Translate("tip_islandBuildingLock")
        local position = self:GetAnchorPosition()

        AppServices.SceneTextTip:Show(message, position)
    end
end

function OnHookBuildAgent:SetState(state)
    if self.data:SetState(state) then
        return self:HandleStateChanged()
    end
end

-- 挂机建筑移动结束
function OnHookBuildAgent:OnMoved(...)
    console.jf("....挂机建筑移动结束....")
    MessageDispatcher:SendMessage(MessageType.BUILDONHOOKMOVEINGMESSAGE, self.id)
end

function OnHookBuildAgent:Destroy(...)
    -- body
end

return OnHookBuildAgent
