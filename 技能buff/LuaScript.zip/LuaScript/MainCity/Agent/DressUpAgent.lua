local DressUpUnit = require "Cleaner.Unit.DressUpUnit"
---@type NormalAgent
local NormalAgent = require("MainCity.Agent.NormalAgent")
local DressUpAgent = class(NormalAgent, "DressUpAgent")

local StateChangedHandles = {
    ---@param agent DressUpAgent
    [CleanState.clearing] = function(agent)
        return agent:SetState(CleanState.cleared)
    end,
    [CleanState.cleared] = function(agent)
        agent:InitRender(
            function(result)
                agent:SetClickable(true)
            end
        )

        local x, z = agent:GetMin()
        local sx, sz = agent:GetSize()
        --后触发格子状态
        ---@type MapManager
        local map = App.scene.mapManager
        return map:SetBlockState(x, sx, z, sz, CleanState.cleared)
    end
}

-- 装扮建筑 Agent
function DressUpAgent:ctor(id, data)
    self.id = id -- 构造出的唯一ID
    self.data = data
end

function DressUpAgent:OnStateChanged(...)
    local state = self:GetState()
    local handler = StateChangedHandles[state]
    if handler then
        return handler(self)
    end
end

function DressUpAgent:InitRender(callback)
    NormalAgent.InitRender(self, callback)
    self.render:AddInstantiateListener(
        function(result)
            self:RenderInstantiateCallBack(result)
        end
    )
end

function DressUpAgent:RenderInstantiateCallBack(result)
    if not result then
        return
    end
    self.dressUpUnit = DressUpUnit.new(self)
    self:AddUnit(self.dressUpUnit)
    -- self.dressUpUnit:Init()
end

-- 处理点击
function DressUpAgent:ProcessClick()
    local state = self:GetState()
    if state == CleanState.cleared then
        MessageDispatcher:SendMessage(MessageType.UnitTipsClick, self.dressUpUnit.instanceId)
    end
end

function DressUpAgent:SetState(state)
    if self.data:SetState(state) then
        return self:HandleStateChanged()
    end
end

function DressUpAgent:Destroy(...)
    -- body
end

return DressUpAgent
