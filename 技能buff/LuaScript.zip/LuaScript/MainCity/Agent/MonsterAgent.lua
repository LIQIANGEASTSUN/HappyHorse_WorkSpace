---@type SceneTemplateTool
local SceneTemplateTool = require "Fsm.Ship.SceneTemplateTool"

---@type SudokuScrewCross
local SudokuScrewCross = require "Cleaner.PathFinding.Search.SudokuScrewCross"

---@type NormalAgent
local NormalAgent = require("MainCity.Agent.NormalAgent")

---@class MonsterAgent:BaseAgent 怪物生成器
local MonsterAgent = class(NormalAgent, "MonsterAgent")

local StateChangedHandles = {
    ---@param agent BaseAgent
    [CleanState.prepare] = function(agent)
        --因为没有处理逻辑,这个函数理论上可以不要
    end,
    ---@param agent NormalAgent
    [CleanState.clearing] = function(agent)
        if not agent:BlockGrid() then
            return agent:SetState(CleanState.cleared)
        end
    end,
    ---@param agent NormalAgent
    [CleanState.cleared] = function(agent)
        local x, z = agent:GetMin()
        local sx, sz = agent:GetSize()

        if AppServices.SceneDataManager.current:IsRemoveBuild(agent.id) then
            agent:Destroy()
        else
            agent:InitRender(
                function(result)
                    agent:SetClickable(true)
                end
            )
        end

        --后触发格子状态
        ---@type MapManager
        local map = App.scene.mapManager
        return map:SetBlockState(x, sx, z, sz, CleanState.cleared)
    end
}

-- 探索船 Agent
function MonsterAgent:ctor(id, data)
    ---@type MonsterAgentData
    self.data = data
    self.isRenderCallBack = false
end

---@private
---触发显示更新/格子状态更新
function MonsterAgent:OnStateChanged()
    local state = self:GetState()
    local handler = StateChangedHandles[state]
    if handler then
        return handler(self)
    end
end

function MonsterAgent:InitRender(callback)
    if not self.render then
        local MonsterRender = require "MainCity.Render.MonsterRender"
        local assetName = self:GetAssetName()
        self.render = MonsterRender.new(assetName)
    end

    self.render:SetPrune(self.prune)
    self.render:Init(self.data, callback)
        self.render:AddInstantiateListener(
        function(result)
            self:RenderInstantiateCallBack(result)
        end
    )
end

function MonsterAgent:RenderInstantiateCallBack(result)
    if not result then
        return
    end

    if self.isRenderCallBack then
        return
    end
    self.isRenderCallBack = true

    self:SpawnMonster()
    self:RegisterEvent()
end

-- 处理点击
function MonsterAgent:ProcessClick()
end

function MonsterAgent:SpawnMonster()
    if not self.data then
        return
    end

    local sceneId = App.scene:GetCurrentSceneId()
    local type = SceneTemplateTool:GetType(sceneId)
    if type == SceneTemplateType.Homeland then
        return
    end

    local waitExtensionId = self.data:GetWaitExtensionId()
    if waitExtensionId then
        WaitExtension.CancelTimeout(waitExtensionId)
        self.data:SetWaitExtensionId(nil)
    end

    if self.data:IsCreating() then
        return
    end

    local monsterId = self.data.mapData.monsterId
    self.data:SetCreateEntityId(-1)

    local configId = tostring(monsterId)
    local monsterConfig = AppServices.Meta:Category("MonsterTemplate")[tostring(configId)]
    local isBossAgent = (monsterConfig.isBoss == 1)
    self.data:SetIsBossAgent(isBossAgent)

    -- 重新创建怪物，此时不能被吸尘器吸了
    self.data:SetCreating(true)
    AppServices.EntityManager:CreateEntity(configId, EntityType.Monster, function(entity)
        self:CreateEntitySuccess(entity)
    end)
end

function MonsterAgent:CreateEntitySuccess(entity)
    if not self.alive then
        return
    end

    self.data:SetCreating(false)
    self.data:SetCreateEntityId(entity.entityId)
    entity:SetAgentId(self.id)

    local _, position = self:MonsterSpawnPosition()
    entity:Init(position)
    local maxHp = entity:GetMaxHp()
    entity:SetHp(maxHp)

    local region = self:GetRegion()
    if region then
        local regionId = region:GetId()
        entity:SetRegionId(regionId)
    end
end

-- 查找一个可行走的位置，生成怪物用
function MonsterAgent:MonsterSpawnPosition()
    local originPos = self:GetWorldPosition()
    local find = false
    local petSpawnPos = Vector2(originPos.x, originPos.z)
    SudokuScrewCross:Search( petSpawnPos, 0, 5, function(position)
        local enablePass = AppServices.IslandPathManager:EnablePass(position.x, position.y)
        if enablePass then
            petSpawnPos = Vector3(position.x, 0, position.y)
            find = true
            return false
        end
        return true
    end)

    if not find then
        petSpawnPos = originPos
    end

    return find, petSpawnPos
end

function MonsterAgent:IsSameRegion(reigion1, region2)
    if not reigion1 or not region2 then
        return false
    end

    return reigion1:GetId() == region2:GetId()
end

-- 怪物被吸
function MonsterAgent:MonsterBeSuck(entityId)
    local createEntityId = self.data:GetCreateEntityId()
    if not createEntityId or createEntityId ~= entityId then
        return
    end

    local isBossAgent = self.data:GetIsBossAgent()
    if isBossAgent then
        self:Destroy()
    else
        self:DelaySpawnMonster(entityId)
    end

    if self:MonsterCorpseNotrefresh() then
        AppServices.NetBuildingManager:SendRemoveBuilding(self.id)
    end
end

function MonsterAgent:EntityDeathAndDestroy(entityId)
    --console.error("EntityDeathAndDestroy")
    self:DelaySpawnMonster(entityId)
end

function MonsterAgent:MonsterDeath(entityId, sn)
    local createEntityId = self.data:GetCreateEntityId()
    if not createEntityId or createEntityId ~= entityId then
        return
    end

    local isBossAgent = self.data:GetIsBossAgent()
    if isBossAgent or self:IslandProgressAgent() and not self:MonsterCorpseNotrefresh() then
        self:Destroy()
        AppServices.NetBuildingManager:SendRemoveBuilding(self.id)
    end
end

function MonsterAgent:DelaySpawnMonster(entityId)
    local createEntityId = self.data:GetCreateEntityId()
    if not createEntityId or createEntityId ~= entityId then
        return
    end

    local monsterId = self.data.mapData.monsterId
    local monsterConfig = AppServices.Meta:Category("MonsterTemplate")[tostring(monsterId)]

    -- 间隔一定时间，再创建一个怪物
    local refreshCd = monsterConfig.refreshTime
    if refreshCd > 1 then
        local waitExtensionId = WaitExtension.InvokeRepeating(function() self:SpawnMonster() end, 0, refreshCd)
        self.data:SetWaitExtensionId(waitExtensionId)
    end
end

function MonsterAgent:IslandProgressAgent()
    local sceneId = App.scene:GetCurrentSceneId()
    local islandConfig = SceneTemplateTool:GetData(sceneId)
    local monsterId = islandConfig.monsterId

    local result = false
    for _, id in pairs(monsterId) do
        if tonumber(id) == tonumber(self.id) then
            result = true
            break
        end
    end

    return result
end

function MonsterAgent:MonsterCorpseNotrefresh()
    if not self.monsterCorpseNotrefresh then
        local data = AppServices.Meta:GetConfigMetaValue("monsterCorpseNotrefresh")
        if data then
            data = table.deserialize(data)
        end

        self.monsterCorpseNotrefresh = {}
        for _, id in pairs(data) do
            self.monsterCorpseNotrefresh[tostring(id)] = true
        end
    end

    return self.monsterCorpseNotrefresh[self.id]
end

function MonsterAgent:GetCreateEntityId()
    return self.data:GetCreateEntityId()
end

-- 连接到家园，删除怪物出生点，删除怪物
function MonsterAgent:OnRegionLinked()
    -- AppServices.NetBuildingManager:SendRemoveBuilding(self.id)
    local createEntityId = self.data:GetCreateEntityId()

    --console.error("MonsterAgent:OnRegionLinked:"..createEntityId)
    if createEntityId and createEntityId > 0 then
        AppServices.EntityManager:RemoveEntity(createEntityId)
    end

    NormalAgent.OnRegionLinked(self)
end

function MonsterAgent:RegisterEvent()
    MessageDispatcher:AddMessageListener(MessageType.MonsterBeSuck, self.MonsterBeSuck, self)
    MessageDispatcher:AddMessageListener(MessageType.EntityDeathAndDestroy, self.EntityDeathAndDestroy, self)
    MessageDispatcher:AddMessageListener(MessageType.EntityDeath, self.MonsterDeath, self)
end

function MonsterAgent:UnRegisterEvent()
    MessageDispatcher:RemoveMessageListener(MessageType.MonsterBeSuck, self.MonsterBeSuck, self)
    MessageDispatcher:RemoveMessageListener(MessageType.EntityDeathAndDestroy, self.EntityDeathAndDestroy, self)
    MessageDispatcher:RemoveMessageListener(MessageType.EntityDeath, self.MonsterDeath, self)
end

function MonsterAgent:Destroy()
    local waitExtensionId = self.data:GetWaitExtensionId()
    NormalAgent.Destroy(self)
    self:UnRegisterEvent()

    if waitExtensionId then
        WaitExtension.CancelTimeout(waitExtensionId)
    end
end

return MonsterAgent