local FightUnitAgent = require "Cleaner.Unit.FightUnitAgent"

---@type NormalAgent
local NormalAgent = require("MainCity.Agent.NormalAgent")

---@class RecoveryPetAgent:NormalAgent 探索船
local RecoveryPetAgent = class(NormalAgent, "RecoveryPetAgent")

local StateChangedHandles = {
    ---@param agent BaseAgent
    [CleanState.prepare] = function(agent)
        --因为没有处理逻辑,这个函数理论上可以不要
    end,
    ---@param agent NormalAgent
    [CleanState.clearing] = function(agent)
        if not agent:BlockGrid() then
            return agent:SetState(CleanState.cleared)
        end
    end,
    ---@param agent NormalAgent
    [CleanState.cleared] = function(agent)
        local x, z = agent:GetMin()
        local sx, sz = agent:GetSize()

        if AppServices.SceneDataManager.current:IsRemoveBuild(agent.id) then
            agent:Destroy()
        else
            agent:InitRender(
                function(result)
                    agent:SetClickable(true)
                end
            )
        end

        --后触发格子状态
        ---@type MapManager
        local map = App.scene.mapManager
        return map:SetBlockState(x, sx, z, sz, CleanState.cleared)
    end
}

-- 探索船 Agent
function RecoveryPetAgent:ctor(id, data)
    self.data = data
    self.init = false
end

---@private
---触发显示更新/格子状态更新
function RecoveryPetAgent:OnStateChanged()
    local state = self:GetState()
    local handler = StateChangedHandles[state]
    if handler then
        return handler(self)
    end
end

function RecoveryPetAgent:InitRender(callback)
    NormalAgent.InitRender(self, callback)
    self.render:AddInstantiateListener(
        function(result)
            self:RenderInstantiateCallBack(result)
    end)
end

function RecoveryPetAgent:RenderInstantiateCallBack(result)
    if not result then
        return
    end

    if not self.init then
        self.init = true
        self:CreateFightUnit()
        self:CreateBuff()
    end
end

function RecoveryPetAgent:CreateFightUnit()
    local fightUnit = FightUnitAgent.new(self)
    fightUnit:SetCamp(CampType.Blue)
    self:AddUnit(fightUnit)
end

function RecoveryPetAgent:CreateBuff()
    local buffId = self.data.meta.buff

    ---@type FightUnitBase
    local fightUnit = self:GetUnit(UnitType.FightUnit)
    fightUnit:AddBuff(buffId)
end

function RecoveryPetAgent:Destroy()
    NormalAgent.Destroy(self)
end

return RecoveryPetAgent