---@type NormalAgent
local NormalAgent = require("MainCity.Agent.NormalAgent")
---@type FightUnitBase
local FightUnitBase = require "Cleaner.Unit.FightUnitBase"
---@type PetNestEarnings
local PetNestEarnings = require("Cleaner.PetNest.PetNestEarnings")
---@type PetNestConstant
local PetNestConstant = require("Game.System.PetNest.PetNestConstant")
---@type BuildUpLevelUnit
local BuildUpLevelUnit = require("Cleaner.Unit.BuildUpLevelUnit")
---@type AttributeInfo
local AttributeInfo = require "Cleaner.Fight.Attribute.AttributeInfo"

---@class PetNestAgent:NormalAgent
---@field petNestEarnings PetNestEarnings
local PetNestAgent = class(NormalAgent, "PetNestAgent")

local StateChangedHandles = {
    ---@param agent PetNestAgent
    [CleanState.cleared] = function(agent)
        agent:InitRender(function(result)
                agent:SetClickable(true)
        end)
        local x, z = agent:GetMin()
        local sx, sz = agent:GetSize()
        ---@type MapManager
        local map = App.scene.mapManager
        return map:SetBlockState(x, sx, z, sz, CleanState.cleared)
    end
}

function PetNestAgent:ctor(id, data)
    self.id = id
    self.data = data
    self:CreateAttribute()
end
function PetNestAgent:Destroy(...)
    if self.petNestEarnings then
        self.petNestEarnings:Release()
    end
end

function PetNestAgent:InitRender(callback)
    NormalAgent.InitRender(self, callback)
    self.render:AddInstantiateListener(
        function(result)
            self:RenderInstantiateCallBack(result)
        end
    )
end
function PetNestAgent:RenderInstantiateCallBack(result)
    if not result then
        return
    end
    self:CreateBuildUpLevelUnit()
    self:CreateFightUnit()
    self:AddBuffs()
    self:InitPetNestEarnings()
    MessageDispatcher:SendMessage(MessageType.PetGoToNest, self.id)
end

function PetNestAgent:CreateAttribute()
    self:AddAttribute(AttributeInfo.Type.BreedTime, 0)
    self:AddAttribute(AttributeInfo.Type.PetNestEarnings, 0)
    self:AddAttribute(AttributeInfo.Type.PetNestEarningsTimeUpLimit, 0)
end

--region state
function PetNestAgent:SetState(state)
    if self.data:SetState(state) then
        return self:HandleStateChanged()
    end
end
function PetNestAgent:OnStateChanged(...)
    local state = self:GetState()
    local handler = StateChangedHandles[state]
    if handler then
        return handler(self)
    end
end
--endregion

function PetNestAgent:ProcessClick()
    local state = self:GetState()
    if state == CleanState.cleared then
        local agentId = self:GetId()
        AppServices.PetNestManager:ShowUIPetNestPanel(agentId)
    end
end

--region level
---@overload
---重写Agent等级，栖息地等级可能为0，即未解锁
function PetNestAgent:GetLevel()
    local data = self:GetData()
    if data and data.mapData and data.mapData.level then
        return data.mapData.level
    end
    return 0
end
function PetNestAgent:SetLevel(level)
    NormalAgent.SetLevel(self, level)
    self:AddBuffs()
    local agentId = self:GetId()
    AppServices.PetNestManager:AddBuffsForNestPetAttribute(agentId)
    AppServices.SceneDataManager.current:SetPetNestLevel(agentId, level)
end
--endregion

--region PetNestEarnings
function PetNestAgent:InitPetNestEarnings()
    self.petNestEarnings = PetNestEarnings.new(self)
    self.petNestEarnings:Init()
end
---@return PetNestEarnings
function PetNestAgent:GetPetNestEarnings()
    return self.petNestEarnings
end
--endregion

--region buff
function PetNestAgent:CreateFightUnit()
    local fightUnit = FightUnitBase.new(self)
    fightUnit:SetCamp(CampType.Blue)
    self:AddUnit(fightUnit)
end
function PetNestAgent:AddBuffs()
    local curLevel = self:GetLevel()
    if curLevel <= 0 then
        return
    end
    ---@type FightUnitBase
    local fightUnit = self:GetUnit(UnitType.FightUnit)
    local buffManager = fightUnit:GetBuffManager()
    for i = 1, curLevel do
        local cfgv = AppServices.PetNestManager:GetBuildingLevelTemplateBySnBuildingAndLevel(self.data:GetTemplateId(), i)
        local buffId = cfgv.buff or 0
        local target = cfgv.target or 0
        if target == PetNestConstant.BuffTargetType.Nest then
            if buffId > 0 and (not buffManager:GetBuffWithBuffId(buffId)) then
                fightUnit:AddBuff(buffId)
            end
        elseif target == PetNestConstant.BuffTargetType.Pet then --此时宠物实体还没创建出来
        else
            console.hxp("### invalid target.") --@DEL
        end
    end
end
--endregion


function PetNestAgent:CreateBuildUpLevelUnit()
    ---@type BuildUpLevelUnit
    local unit = BuildUpLevelUnit.new(self)
    self:AddUnit(unit)
    unit:SetAnchorOffset(Vector3(-1.5, 2, 1))
end

return PetNestAgent
