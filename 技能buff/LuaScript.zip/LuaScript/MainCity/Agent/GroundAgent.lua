local NormalAgent = require("MainCity.Agent.NormalAgent")
---@class GroundAgent:NormalAgent 可消除障碍物
local GroundAgent = class(NormalAgent, "GroundAgent")

local StateChangedHandles = {
    ---@param agent GroundAgent
    [CleanState.locked] = function(agent)
        -- local x, z = agent:GetMin()
        -- local region = App.scene.mapManager:GetRegionByGrid(x, z)
        -- if region and region:IsLinked() then
        --     return agent:SetState(CleanState.cleared)
        -- end
    end,
    ---@param agent GroundAgent
    [CleanState.prepare] = function(agent)
        -- local x, z = agent:GetMin()
        -- local region = App.scene.mapManager:GetRegionByGrid(x, z)
        -- if region and region:IsLinked() then
        --     return agent:SetState(CleanState.cleared)
        -- end

        local function setModelTransform()
            local go = agent:GetGameObject()
            local sx, sz = agent:GetSize()
            local center = agent:GetCenterPostion()
            go:SetPosition(center)
            go:SetLocalScale(sx, 1, sz)
        end
        local modelName = "airWall"
        if agent.render then
            agent.render:SetModelName(modelName)
        else
            agent:SetAssetName(modelName)
            agent:InitRender(
                function(result)
                    agent:SetClickable(true)

                    if result then
                        local go = agent:GetGameObject()
                        go.name = "prepare"
                        setModelTransform()
                    end
                end
            )
        end
    end,
    ---@param agent GroundAgent
    [CleanState.clearing] = function(agent)
        -- local x, z = agent:GetMin()
        -- local region = App.scene.mapManager:GetRegionByGrid(x, z)
        -- if region and region:IsLinked() then
        --     return agent:SetState(CleanState.cleared)
        -- end

        local function setModelTransform()
            local go = agent:GetGameObject()
            if Runtime.CSNull(go) then
                return
            end

            local sx, sz = agent:GetSize()
            local center = agent:GetCenterPostion()
            go:SetPosition(center)
            go:SetLocalScale(sx, 1, sz)
        end
        local modelName = "airWall"
        if agent.render then
            agent.render:SetModelName(modelName)
        else
            agent:SetAssetName(modelName)
        end
        agent:InitRender(
            function(result)
                agent:SetClickable(true)
                local go = agent:GetGameObject()
                go.name = agent:GetId()
                setModelTransform()
                agent:ShowTip()
            end
        )
    end,
    ---@param agent GroundAgent
    [CleanState.cleared] = function(agent)
        agent:DestroyTip()
        if agent.render then
            agent.render:OnDestroy()
            agent.render = nil
        end
        agent:SetAssetName(nil)
        local isInit = not App.scene.objectManager:IsAllAgentInitFinish()
        agent:InitRender(
            function(result)
                agent:SetClickable(true)
                agent:OnClearedEvent(isInit)
            end
        )
        local x, z = agent:GetMin()
        local sx, sz = agent:GetSize()
        --后触发格子状态
        ---@type MapManager
        local map = App.scene.mapManager

        return map:SetBlockState(x, sx, z, sz, CleanState.cleared)
    end
}

---@private
---触发显示更新/格子状态更新
function GroundAgent:OnStateChanged()
    local state = self:GetState()
    local handler = StateChangedHandles[state]
    if handler then
        return handler(self)
    end
end

function GroundAgent:InitState()
    --留空就行
end

function GroundAgent:BlockBuilding()
    return false
end

function GroundAgent:GetCenterPostion()
    local x, z = self:GetMin()
    local sx, sz = self:GetSize()
    local min = App.scene.mapManager:ToWorld(x, z)
    local max = App.scene.mapManager:ToWorld(x + sx - 1, z + sz - 1)
    local center = (min + max) / 2
    return center
end

function GroundAgent:ShowTip()
    if not self.alive then
        return
    end
    if Runtime.CSValid(self.tipGo) then
        self.tipGo:SetActive(true)
        return
    end
    local assetPath = "Prefab/UI/BindingTip/GroundConsume.prefab"
    App.commonAssetsManager:LoadAssets(
        {assetPath},
        function()
            if not self.alive then
                return
            end
            self.tipGo = BResource.InstantiateFromAssetName(assetPath)
            self.tipGo:SetParent(App.scene.worldCanvas)
            self.tipGo:SetLocalScale(1, 1, 1)
            local position = self:GetWorldPosition()
            position = Vector3(position.x, 0.1, position.z)
            self.tipGo:SetPosition(position)
            self.tipText = find_component(self.tipGo, "Text", Text)
            -- self.tipIcon = find_component(self.tipGo, "icon", Image)
            self.tipSlider = self.tipGo:GetComponent(typeof(Slider))
            self:OnConsume(0)
        end
    )
end
function GroundAgent:DestroyTip()
    Runtime.CSDestroy(self.tipGo)
    self.tipGo = nil
    self.tipText = nil
    self.tipSlider = nil
    -- self.tipIcon = nil
    App.mapGuideManager:OnGuideFinishEvent(GuideEvent.FillLand)
end

---@param payed number 单次填充消耗
function GroundAgent:OnConsume(payed)
    if Runtime.CSValid(self.tipGo) then
        local id, cost, total = self:GetCurrentCost()
        cost = cost - payed
        self.tipText.text = cost
        self.tipSlider.value = 1 - cost / total
        self.data:AddCleanCosted(id, payed)
        if cost <= 0 then
            self:Clean()
        end
    end
end

function GroundAgent:OnRegionLinked()
    --所在探索岛连接到家园后, 自动变更状态(防止岛上出现不可修补漏洞)
    self:SetState(CleanState.cleared)
end

function GroundAgent:CanEdit()
    return false
end

function GroundAgent:Suckable()
    if self.alive then
        return self:GetState() == CleanState.clearing
    end
end

function GroundAgent:InitExtraData(extra)
    self.data:InitExtraData(extra)
end

return GroundAgent
