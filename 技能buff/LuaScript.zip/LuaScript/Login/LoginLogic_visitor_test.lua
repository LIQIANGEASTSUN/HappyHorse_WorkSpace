--- 不同渠道配置不同的LoginLogic_visitor_test，默认针对fb渠道，包括了游客，fb和ios三种登陆模式
---@class LoginLogic_visitor_test : LoginBase
local LoginLogic_visitor_test = {}

function LoginLogic_visitor_test:CheckBind()
    return true
end

--准备开始登陆,组装登陆参数
function LoginLogic_visitor_test:LoginStart(callback)
    local loginParam = {}

    loginParam.channelId = "0"
    loginParam.userIdentity = RuntimeContext.CACHES.TEST_ACCOUNT
    loginParam.token = ""
    loginParam.deviceId = RuntimeContext.DEVICE_ID
    loginParam.version = RuntimeContext.BUNDLE_VERSION

    local deviceInfo = DcDelegates.Legacy:GetDeviceInfo()
    loginParam.type = 0 --int32；用户类型 0:普通 1:GM
    loginParam.osType = CONST.RULES.GetOsType() --int32；系统类型 0:android 1:ios 2:win
    loginParam.idfa = deviceInfo.userid or "" --安卓用户为uuid，ios用户为idfa，统一用字段idfa表示
    loginParam.idfv = deviceInfo.idfv or "" --idfv
    loginParam.deviceCountry = deviceInfo.devicecountry or "00" --设备国家（如：en_US 没有写00）
    loginParam.timeZone = TimeUtil.GetLocalTimeZone() --int32；时区

    Runtime.InvokeCbk(callback, loginParam)
end

return LoginLogic_visitor_test
