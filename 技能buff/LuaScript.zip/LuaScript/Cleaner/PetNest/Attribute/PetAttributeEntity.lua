---@type AttributeManager
local AttributeManager =  require "Cleaner.Fight.Attribute.AttributeManager"

---@type AttributeInfo
local AttributeInfo = require "Cleaner.Fight.Attribute.AttributeInfo"

---@type FightUnitEntity
local FightUnitEntity = require "Cleaner.Unit.FightUnitEntity"

---@class PetAttributeEntity
local PetAttributeEntity = class(nil, "PetAttributeEntity")

function PetAttributeEntity:ctor(sn)
    self.sn = sn

    self.petConfig = AppServices.Meta:Category("PetTemplate")[tostring(sn)]

    ---@type FightUnitEntity
    self.fightUnit = nil

    self:CreateFightUnit()

    self:AddAttribute(AttributeInfo.Type.BreedTime, 1500)
    self:AddAttribute(AttributeInfo.Type.MaxHp, 0)
    self:AddAttribute(AttributeInfo.Type.Attack, 0)
    self:AddAttribute(AttributeInfo.Type.Shield, 0)
end

function PetAttributeEntity:CreateFightUnit()
    self.fightUnit = FightUnitEntity.new(self)
    self.fightUnit:SetCamp(CampType.Blue)
    self.fightUnit:SetOnlyLogic(true)
end

function PetAttributeEntity:AddAttribute(type, value)
    if not self.attributeManager then
        self.attributeManager = AttributeManager.new(self)
    end
    self.attributeManager:AddAttribute(type, value)
end

function PetAttributeEntity:GetAttribute(type)
    if self.attributeManager then
        return self.attributeManager:GetAttribute(type)
    end
    return nil
end

function PetAttributeEntity:RemoveAttribute(type)
    if self.attributeManager then
        self.attributeManager:RemoveAttribute(type)
    end
end

function PetAttributeEntity:GetAttributeManager()
    return self.attributeManager
end

-- buffId
function PetAttributeEntity:AddBuff(buffId, skillId)
    ---@type FightUnitBase
    self.fightUnit:AddBuff(buffId, skillId)
end

function PetAttributeEntity:ClearBuff()
    ---@type FightUnitBase
    local fightUnit = self:GetUnit(UnitType.FightUnit)
    fightUnit:ClearBuff()
end

function PetAttributeEntity:GetMaxHp()
    local hp = self.petConfig.hp
    return self:CalculateAttribute(AttributeInfo.Type.MaxHp, hp)
end

function PetAttributeEntity:GetMaxAttack()
    local skillData = AppServices.Meta:Category("SkillTemplate")[tostring(self.petConfig.skillId)]
    local damage = skillData.attackPower
    return self:CalculateAttribute(AttributeInfo.Type.Attack, damage)
end

function PetAttributeEntity:CalculateAttribute(type, originValue)
    ---@type AttributeBase
    local attributeBase = self:GetAttribute(type)
    attributeBase:Init(originValue)
    attributeBase:CalculateValue()
    local value = attributeBase:GetValue()
    return value
end

function PetAttributeEntity:IsAlive()
    return true
end

function PetAttributeEntity:Release()

end

return PetAttributeEntity