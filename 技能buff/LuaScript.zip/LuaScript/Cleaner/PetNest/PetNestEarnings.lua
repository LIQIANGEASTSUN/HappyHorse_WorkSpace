---@type PetTemplateTool
local PetTemplateTool = require "Cleaner.Entity.Pet.PetTemplateTool"

---@type AttributeInfo
local AttributeInfo = require "Cleaner.Fight.Attribute.AttributeInfo"

---@class PetNestEarnings
---@field agent PetNestAgent
local PetNestEarnings = class(nil, "PetNestEarnings")

function PetNestEarnings:ctor(agent)
    self.agent = agent
    self.agentId = self.agent:GetId()
    self.sn = self.agent:GetTemplateId()
end

function PetNestEarnings:Init()
    self:RegisterEvent()
    self:StartTimer()
end

function PetNestEarnings:Refresh()
    local level = self.agent:GetLevel()
    if level <= 0 then
        return
    end

    self.buildLevelConfig = self:BuildLevelConfig()
    local result, production = self:GatherInfo()
    if not result then
        return
    end

    local tipsData = {
        agentId = self.agent:GetId(),
        production = production,
    }

    local unitId = self:GetUnitId()
    AppServices.UnitTipsManager:ShowTips(unitId, TipsType.UnitPetNestProduction, tipsData)
end

function PetNestEarnings:GetUnitId()
    if not self.unitId then
        local commonUnit = self.agent:GetCommonUnit()
        self.unitId = commonUnit:GetInstanceId()
    end
    return self.unitId
end

function PetNestEarnings:GatherInfo()
    local production = {}
    local result, minutes = self:GetEarningsTime()
    if not result then
        return result, production
    end

    production = self:EarningsPerMinute()

    local countResult = false
    for itemId, count in pairs(production) do
        production[itemId] = math.floor(count * minutes)
        if production[itemId] > 0 then
            countResult = true
        end
    end

    return (result and countResult), production
end

function PetNestEarnings:EarningsPerMinute()
    local production = {}
    local list = AppServices.EntityManager:GetEntityWithType(EntityType.PetHL)
    for _, entity in pairs(list) do
        self:PetProductionPerMinute(entity, production)
    end

    ---@type AttributeBase
    local attributeBase = self.agent:GetAttribute(AttributeInfo.Type.PetNestEarnings)
    if not attributeBase then
        return production
    end

    for itemId, count in pairs(production) do
        attributeBase:Init(count)
        attributeBase:CalculateValue()
        production[itemId] = attributeBase:GetValue()
    end
    return production
end

function PetNestEarnings:GetEarningsTime()
    if not self.buildLevelConfig then
        return false, 0
    end

    local time = AppServices.SceneDataManager.current:GetHungTime(self.agentId)
    local second = TimeUtil.ServerTime() - time
    local minutes = math.floor(second / 60)

    local productItemTimeLimit = self.buildLevelConfig.productItemTimeLimit
    ---@type AttributeBase
    local attributeBase = self.agent:GetAttribute(AttributeInfo.Type.PetNestEarningsTimeUpLimit)
    if not attributeBase then
        return false, minutes
    end

    attributeBase:Init(productItemTimeLimit)
    attributeBase:CalculateValue()
    local value = attributeBase:GetValue()

    return true, math.min(value, minutes)
end

function PetNestEarnings:PetProductionPerMinute(entity, production)
    local habitatSn = entity.data:GetHabitatSn()
    if self.sn ~= habitatSn then
        return
    end

    local type = entity.data:GetType()
    local pet = AppServices.User:GetPetWithType(type)
    local level = pet.level

    local sn = PetTemplateTool:Getkey(type, level)
    local config = PetTemplateTool:GetData(sn)
    local times = math.floor(1 / config.productTime)

    for _, data in pairs(config.productItem) do
        local itemId = data[1]
        local count = data[2] * times
        if not production[itemId] then
            production[itemId] = 0
        end
        production[itemId] = production[itemId] + count
    end
end

function PetNestEarnings:BuildLevelConfig()
    local level = self.agent:GetLevel()
    local sn = AppServices.BuildingLevelTemplateTool:GetKey(self.sn, level)
    local config = AppServices.Meta:Category("BuildingLevelTemplate")[tostring(sn)]
    return config
end

function PetNestEarnings:StartTimer()
    self.timerId = WaitExtension.InvokeRepeating(
        function()
            self:Refresh()
        end,
        1,
        10
    )
end

---@param agentId number 栖息地agentId
function PetNestEarnings:TakeHomeReward(agentId)
    if agentId ~= self.agent:GetId() then
        return
    end
    local result, production = self:GatherInfo()
    if not result then
        return
    end

    local initPos = self.agent:GetAnchorPosition()
    for itemId, count in pairs(production) do
        self:FlyAnmation(itemId, count, initPos)
        local msg = string.format("+%d", count)
        AppServices.SceneTextTip:Show( msg, initPos)
        console.hxp("### TakeHomeReward:", itemId, count) --@DEL
    end
end

function PetNestEarnings:FlyAnmation(itemId, count, initPos)
    local flyCall = function()
        local radius = 1.3
        local rad = math.random(360)
        local offset = Vector3(math.cos(rad), 0, math.sin(rad)) * radius
        local flyPos = initPos + offset
        local itemInfo = {
            itemId = itemId,
            pos = flyPos,
            initPos = initPos,
            sizeDelta = Vector2(80, 80),
        }
        AppServices.FlyAnimation.Create3DItemWithFly(itemInfo)
    end

    count = math.min(count, 10)
    local sequence = DOTween.Sequence()
    for _ = 1, count do
        sequence:AppendCallback(flyCall)
        sequence:AppendInterval(0.05)
    end
    sequence:Play()
end

function PetNestEarnings:RegisterEvent()
    MessageDispatcher:AddMessageListener(MessageType.PetNestTakeHomeReward, self.TakeHomeReward, self)
end

function PetNestEarnings:UnRegisterEvent()
    MessageDispatcher:RemoveMessageListener(MessageType.PetNestTakeHomeReward, self.TakeHomeReward, self)
end

function PetNestEarnings:Release()
    if self.timerId then
        WaitExtension.CancelTimeout(self.timerId)
    end
    self:UnRegisterEvent()
end


return PetNestEarnings