---@class BehaviorTreeInfo
local BehaviorTreeInfo = {}

--- 节点类型
BehaviorTreeInfo.NODE_TYPE = {
    --- 选择节点 SelectNode
    SELECT = 0,

    --- 顺序节点 SequenceNode
    SEQUENCE = 1,

    --- 随机节点 RandomNode
    RANDOM = 2,

    --- 随机顺序节点 RandomSequeuece
    RANDOM_SEQUEUECE = 3,

    --- 随机权重节点 RandomPriority
    RANDOM_PRIORITY = 4,

    --- 并行节点 ParallelNode
    PARALLEL = 5,

    --- 并行选择节点 ParalleSelect
    PARALLEL_SELECT = 6,

    --- 并行所有节点 ParalleAll
    PARALLEL_ALL = 7,

    --- If 判断并行节点 IfJudgeParallel
    IF_JUDEG_PARALLEL = 8,

    --- If 判断顺序节点 IfJudgeSequence
    IF_JUDEG_SEQUENCE = 9,

    --- 修饰节点：取反 DecoratorInverter
    DECORATOR_INVERTER = 100,

    --- 修饰节点：重复 DecoratorRepeat
    DECORATOR_REPEAT = 101,

    --- 修饰节点：永远返回 Fail DecoratorReturnFail
    DECORATOR_RETURN_FAIL = 102,

    --- 修饰节点：永远返回 Success DecoratorReturnSuccess
    DECORATOR_RETURN_SUCCESS = 103,

    --- 修饰节点：知道返回 Fail DecoratorUntilFail
    DECORATOR_UNTIL_FAIL = 104,

    --- 修饰节点：知道返回 Success DecoratorUntilSuccess
    DECORATOR_UNTIL_SUCCESS = 105,

    --- 条件节点 Condition
    CONDITION = 200,

    --- 行为节点 Action
    ACTION = 300,

    --- 子树节点 SubTreeNode
    SUB_TREE = 1000,
}

--- 节点状态
BehaviorTreeInfo.NODE_STATUS = {
    --- 准备阶段 Ready Status
    READY = 0,

    --- 运行中阶段 Running Status
    RUNNING = 1,
}

--- 子树类型 Subtree type
BehaviorTreeInfo.SUB_TREE_TYPE = {
    --- 可编辑子节点子树 CommonChildNodesCanBeEdited
    NORMAL = 0,

    --- 读取配置文件子树 ConfigReadConfigFile
    CONFIG = 1,
}

--- If 判断节点，子节点类型 If node type
BehaviorTreeInfo.NodeIfJudgeEnum = {
    --- 判断条件的节点 IfJudgmentNode
    IF = 0,

    --- 可执行的子节点 ExecuteNode
    ACTION = 1,
}

--- 节点执行结果 node execution result
BehaviorTreeInfo.ResultType = {
    --- 执行失败 Fail
    Fail        = 0,

    --- 执行成功 Success
    Success = 1,

    --- 执行中 Running
    Running = 2,
}

--- 参数类型
BehaviorTreeInfo.ParameterType = {
    --- Float
    Float = 0,

    --- Int
    Int = 2,

    --- Bool
    Bool = 5,

    --- String
    String = 10,
}

--- 参数大小比较
BehaviorTreeInfo.ParameterCompare = {
    --- 无效
    INVALID = 0,

    --- Greater 大于
    GREATER = 0x01,

    --- Less
    LESS = 0x02,

    --- Equal
    EQUALS = 0x04,

    --- NotEqual
    NOT_EQUAL = 0x08,

    --- GreaterOrEqual
    GREATER_EQUALS = 0x10,

    --- LessOrEqual
    LESS_EQUAL = 0x100,
}

BehaviorTreeInfo.NodeConfigs = {
    --- 修饰节点
    ["NodeDecoratorInverter"] = "Cleaner.BehaviorTree.Node.Composite.Decorator.NodeDecoratorInverter",
    ["NodeDecoratorRepeat"] = "Cleaner.BehaviorTree.Node.Composite.Decorator.NodeDecoratorRepeat",
    ["NodeDecoratorReturnFail"] = "Cleaner.BehaviorTree.Node.Composite.Decorator.NodeDecoratorReturnFail",
    ["NodeDecoratorReturnSuccess"] = "Cleaner.BehaviorTree.Node.Composite.Decorator.NodeDecoratorReturnSuccess",
    ["NodeDecoratorUntilFail"] = "Cleaner.BehaviorTree.Node.Composite.Decorator.NodeDecoratorUntilFail",
    ["NodeDecoratorUntilSuccess"] = "Cleaner.BehaviorTree.Node.Composite.Decorator.NodeDecoratorUntilSuccess",

    --- 组合节点
    ["NodeIfJudgeParallel"] = "Cleaner.BehaviorTree.Node.Composite.NodeIfJudgeParallel",
    ["NodeIfJudgeSequence"] = "Cleaner.BehaviorTree.Node.Composite.NodeIfJudgeSequence",
    ["NodeParallel"] = "Cleaner.BehaviorTree.Node.Composite.NodeParallel",
    ["NodeParallelAll"] = "Cleaner.BehaviorTree.Node.Composite.NodeParallelAll",
    ["NodeParallelSelect"] = "Cleaner.BehaviorTree.Node.Composite.NodeParallelSelect",
    ["NodeRandom"] = "Cleaner.BehaviorTree.Node.Composite.NodeRandom",
    ["NodeRandomPriority"] = "Cleaner.BehaviorTree.Node.Composite.NodeRandomPriority",
    ["NodeRandomSelect"] = "Cleaner.BehaviorTree.Node.Composite.NodeRandomSelect",
    ["NodeRandomSequence"] ="Cleaner.BehaviorTree.Node.Composite.NodeRandomSequence",
    ["NodeSelect"] = "Cleaner.BehaviorTree.Node.Composite.NodeSelect",
    ["NodeSequence"] = "Cleaner.BehaviorTree.Node.Composite.NodeSequence",

    --- 通用条件节点
    ["NodeConditionCustom"] = "Cleaner.BehaviorTree.Node.Leaf.NodeConditionCustom",

    --- 子树节点
    ["NodeSubTree"] = "Cleaner.BehaviorTree.Node.SubTree.NodeSubTree",
}

return BehaviorTreeInfo