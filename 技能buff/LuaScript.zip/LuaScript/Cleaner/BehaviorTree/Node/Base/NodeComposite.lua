---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type NodeBase
local NodeBase = require "Cleaner.BehaviorTree.Node.Base.NodeBase"

---@class NodeComposite:NodeBase
local NodeComposite = class(NodeBase, "NodeComposite")

-- NODE_TYPE nodeType
function NodeComposite:ctor()
    ---@type List<NodeBase>
    self.nodeChildList = {}
end

--- add child node
-- NodeBase node
function NodeComposite:AddNode(node)
    local count = #self.nodeChildList
    node.NodeIndex = count
    table.insert(self.nodeChildList, node)
end

--- get all child nodes
-----  List<NodeBase>
function NodeComposite:GetChilds()
    return self.nodeChildList
end

function NodeComposite:ClearChild()
    self.nodeChildList = {}
end

-- ResultType
function NodeComposite:Execute()
    return BehaviorTreeInfo.ResultType.Fail
end

return NodeComposite