---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type NodeParameter
local NodeParameter = require "Cleaner.BehaviorTree.Graphic.Data.NodeParameter"

---@type NodeBase
local NodeBase = require "Cleaner.BehaviorTree.Node.Base.NodeBase"

---@class NodeLeaf:NodeBase
---@field owner BaseEntity
local NodeLeaf = class(NodeBase, "NodeLeaf")

-- NODE_TYPE nodeType
function NodeLeaf:ctor()
    ---@type List<NodeParameter>
    self.parameterList = {}
    self.owner = nil
end

function NodeLeaf:SetOwner(owner)
    self.owner = owner
end

--- ResultType
function NodeLeaf:Execute()
    return BehaviorTreeInfo.ResultType.Fail
end

--- List<NodeParameter> parameterList
function NodeLeaf:SetParameters(parameterList)
    for _, parameter in pairs(parameterList) do
        local cloneParameter = NodeParameter.new()
        cloneParameter:CloneFrom(parameter)
        table.insert(self.parameterList, cloneParameter)
    end
end

return NodeLeaf