---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type NodeIfJudge
local NodeIfJudge = require "Cleaner.BehaviorTree.Node.Composite.NodeIfJudge"

---@class NodeIfJudgeParallel:NodeIfJudge
local NodeIfJudgeParallel = class(NodeIfJudge, "NodeIfJudgeParallel")

function NodeIfJudgeParallel:ctor()
    self:SetNodeType(BehaviorTreeInfo.NODE_TYPE.IF_JUDEG_PARALLEL)
end

--- NodeDescript.GetDescript(NODE_TYPE)
function NodeIfJudgeParallel:Execute()
    if #self.nodeChildList <= 0 then
        return BehaviorTreeInfo.ResultType.Fail
    end

    local resultType = BehaviorTreeInfo.ResultType.Fail
    -- The first node is the conditional node
    ---@type NodeBase
    local ifNode = self.nodeChildList[1]
    resultType = self:ExecuteNode(ifNode, true)
    if (resultType == BehaviorTreeInfo.ResultType.Running) then
        return BehaviorTreeInfo.ResultType.Fail
    end

    ---@type NodeBase
    local nodeBase = self:GetBaseNode(resultType)
    if (nil ~= nodeBase) then
        if ((nil ~= self.lastRunningNode) and (self.lastRunningNode.NodeId ~= nodeBase.NodeId)) then
            self.lastRunningNode:Postposition(BehaviorTreeInfo.ResultType.Fail)
            self.lastRunningNode = nil
        end
        resultType = self:ExecuteNode(nodeBase, false)
    else
        resultType = self.defaultResult
    end

    return resultType
end

return NodeIfJudgeParallel