---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type NodeDecorator
local NodeDecorator = require "Cleaner.BehaviorTree.Node.Composite.NodeDecorator"

---@class NodeDecoratorReturnConst:NodeDecorator
local NodeDecoratorReturnConst = class(NodeDecorator, "NodeDecoratorReturnConst")

function NodeDecoratorReturnConst:ctor()
    self.runningNodeMap = {}
end

function NodeDecoratorReturnConst:OnEnter()
    NodeDecorator.OnEnter(self)
    self.runningNodeMap = {}
end

--- ResultType
function NodeDecoratorReturnConst:Execute()
    local resultType = BehaviorTreeInfo.ResultType.Fail
    for i = 1, #self.nodeChildList do
        ---@type NodeBase
        local nodeBase = self.nodeChildList[i]
        nodeBase:Preposition()
        resultType = nodeBase:Execute()
        nodeBase:Postposition(resultType)

        if (resultType == BehaviorTreeInfo.ResultType.Running) then
            self.runningNodeMap[i] = true
        end
    end

    --NodeNotify.NotifyExecute(EntityId, NodeId, (int)ResultType.Fail, Time.realtimeSinceStartup);
    return self.constResult
end

function NodeDecoratorReturnConst:OnExit()
    NodeDecorator.OnExit(self)

    for i = 1, #self.nodeChildList do
        if self.runningNodeMap[i] then
            ---@type NodeBase
            local nodeBase = self.nodeChildList[i]
            nodeBase:Postposition(BehaviorTreeInfo.ResultType.Fail)
        end
    end
end

function NodeDecoratorReturnConst:SetConstResult( resultType)
    self.constResult = resultType
end

return NodeDecoratorReturnConst