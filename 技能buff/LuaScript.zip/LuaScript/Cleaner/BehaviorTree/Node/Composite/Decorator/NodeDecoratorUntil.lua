---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type NodeDecorator
local NodeDecorator = require "Cleaner.BehaviorTree.Node.Composite.NodeDecorator"

---@class NodeDecoratorUntil:NodeDecorator
local NodeDecoratorUntil = class(NodeDecorator, "NodeDecoratorUntil")

function NodeDecoratorUntil:ctor()
    self.runningNodeMap = {}
    self.desiredResult = BehaviorTreeInfo.ResultType.Fail
end

function NodeDecoratorUntil:OnEnter()
    NodeDecorator.OnEnter(self)
    self.runningNodeMap = {}
end

--- ResultType
function NodeDecoratorUntil:Execute()
    NodeDecorator.Execute(self)
    local resultType = BehaviorTreeInfo.ResultType.Fail
    for i = 1, #self.nodeChildList do
        ---@type NodeBase
        local nodeBase = self.nodeChildList[i]
        nodeBase:Preposition()
        resultType = nodeBase:Execute()
        nodeBase:Postposition(resultType)

        if (resultType == BehaviorTreeInfo.ResultType.Running) then
            self.runningNodeMap[i] = true
        end

        if (resultType == self.desiredResult) then
            return BehaviorTreeInfo.ResultType.Success
        end
    end

    --NodeNotify.NotifyExecute(EntityId, NodeId, (int)ResultType.Running, Time.realtimeSinceStartup);
    return BehaviorTreeInfo.ResultType.Running
end

function NodeDecoratorUntil:OnExit()
    NodeDecorator.OnExit(self)

    for i = 1, #self.nodeChildList do
        if self.runningNodeMap[i] then
            ---@type NodeBase
            local nodeBase = self.nodeChildList[i]
            nodeBase:Postposition(BehaviorTreeInfo.ResultType.Fail)
        end
    end
end

function NodeDecoratorUntil:SetDesiredResult( resultType)
    self.desiredResult = resultType
end

return NodeDecoratorUntil