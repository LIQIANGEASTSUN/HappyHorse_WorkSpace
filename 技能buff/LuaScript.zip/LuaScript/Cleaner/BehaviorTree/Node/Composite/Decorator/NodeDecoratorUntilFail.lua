---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type NodeDecoratorUntil
local NodeDecoratorUntil = require "Cleaner.BehaviorTree.Node.Composite.Decorator.NodeDecoratorUntil"

---@class NodeDecoratorUntilFail:NodeDecoratorUntil
local NodeDecoratorUntilFail = class(NodeDecoratorUntil, "NodeDecoratorUntilFail")

function NodeDecoratorUntilFail:ctor()
    self:SetNodeType(BehaviorTreeInfo.NODE_TYPE.DECORATOR_UNTIL_FAIL)
    self:SetDesiredResult(BehaviorTreeInfo.ResultType.Fail)
end

return NodeDecoratorUntilFail