---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type NodeDecoratorReturnConst
local NodeDecoratorReturnConst = require "Cleaner.BehaviorTree.Node.Composite.Decorator.NodeDecoratorReturnConst"

---@class NodeDecoratorReturnSuccess
local NodeDecoratorReturnSuccess = class(NodeDecoratorReturnConst, "NodeDecoratorReturnSuccess")

function NodeDecoratorReturnSuccess:ctor()
    self:SetNodeType(BehaviorTreeInfo.NODE_TYPE.DECORATOR_RETURN_SUCCESS)
    self.SetConstResult(BehaviorTreeInfo.ResultType.Success)
end

return NodeDecoratorReturnSuccess