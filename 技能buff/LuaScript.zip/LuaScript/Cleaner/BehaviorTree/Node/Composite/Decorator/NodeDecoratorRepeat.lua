---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type NodeDecorator
local NodeDecorator = require "Cleaner.BehaviorTree.Node.Composite.NodeDecorator"

---@class NodeDecoratorRepeat:NodeDecorator
local NodeDecoratorRepeat = class(NodeDecorator, "NodeDecoratorRepeat")

function NodeDecoratorRepeat:ctor()
    self.runningNodeMap = {}
    self.repeatCount = 0
    self.executeCount = 0
    self:SetNodeType(BehaviorTreeInfo.NODE_TYPE.DECORATOR_REPEAT)
end

function NodeDecoratorRepeat:OnEnter()
    NodeDecorator.OnEnter(self)
    self.runningNodeMap = {}
    self:ReStart()
end

--- ResultType
function NodeDecoratorRepeat:Execute()
    self.executeCount = self.executeCount + 1

    ---@type ResultType
    local resultType = BehaviorTreeInfo.ResultType.Fail
    for i = 1, #self.nodeChildList do
        ---@type NodeBase
        local nodeBase = self.nodeChildList[i]

        nodeBase:Preposition()
        resultType = nodeBase:Execute()
        nodeBase:Postposition(resultType)

        if (resultType == BehaviorTreeInfo.ResultType.Running) then
            self.runningNodeMap[i] = true
        end
    end

    if (self.repeatCount == -1 or self.executeCount < self.repeatCount) then
        resultType = BehaviorTreeInfo.ResultType.Running
    else
        resultType = BehaviorTreeInfo.ResultType.Success
    end

    --NodeNotify.NotifyExecute(EntityId, NodeId, (int)resultType, Time.realtimeSinceStartup);
    return resultType
end

function NodeDecoratorRepeat:OnExit()
    NodeDecorator.OnExit(self)
    self:ReStart()

    for i = 1, #self.nodeChildList do
        if self.runningNodeMap[i] then
            ---@type NodeBase
            local nodeBase = self.nodeChildList[i]
            nodeBase:Postposition(BehaviorTreeInfo.ResultType.Fail)
        end
    end
end

function NodeDecoratorRepeat:ReStart()
    self.executeCount = 0
end

function NodeDecoratorRepeat:SetRepeatCount( value)
    self.repeatCount = value
end

return NodeDecoratorRepeat