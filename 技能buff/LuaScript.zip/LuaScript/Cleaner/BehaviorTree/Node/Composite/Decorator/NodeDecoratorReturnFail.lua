---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type NodeDecoratorReturnConst
local NodeDecoratorReturnConst = require "Cleaner.BehaviorTree.Node.Composite.Decorator.NodeDecoratorReturnConst"

---@class NodeDecoratorReturnFail:NodeDecoratorReturnConst
local NodeDecoratorReturnFail = class(NodeDecoratorReturnConst, "NodeDecoratorReturnFail")

function NodeDecoratorReturnFail:ctor()
    self:SetNodeType(BehaviorTreeInfo.NODE_TYPE.DECORATOR_RETURN_FAIL)
    self.SetConstResult(BehaviorTreeInfo.ResultType.Fail)
end

return NodeDecoratorReturnFail