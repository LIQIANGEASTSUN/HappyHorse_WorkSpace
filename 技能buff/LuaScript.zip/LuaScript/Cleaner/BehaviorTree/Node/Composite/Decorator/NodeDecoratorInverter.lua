---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type NodeDecorator
local NodeDecorator = require "Cleaner.BehaviorTree.Node.Composite.NodeDecorator"

---@class NodeDecoratorInverter:NodeDecorator
local NodeDecoratorInverter = class(NodeDecorator, "NodeDecoratorInverter")

function NodeDecoratorInverter:ctor()
    self.runningNodeMap = {}
    self:SetNodeType(BehaviorTreeInfo.NODE_TYPE.DECORATOR_INVERTER)
end

function NodeDecoratorInverter:OnEnter()
    NodeDecorator.OnEnter(self)
    self.runningNodeMap = {}
end

--- ResultType
function NodeDecoratorInverter:Execute()
    local resultType = BehaviorTreeInfo.ResultType.Fail
    for i = 1, #self.nodeChildList do
        ---@type NodeBase
        local nodeBase = self.nodeChildList[i]

        nodeBase:Preposition()
        resultType = nodeBase:Execute()
        nodeBase:Postposition(resultType)

        if (resultType == BehaviorTreeInfo.ResultType.Running) then
            self.runningNodeMap[i] = true
        end
    end

    if (resultType == BehaviorTreeInfo.ResultType.Fail) then
        return BehaviorTreeInfo.ResultType.Success
    elseif (resultType == BehaviorTreeInfo.ResultType.Success) then
        return BehaviorTreeInfo.ResultType.Fail
    end

    --NodeNotify.NotifyExecute(EntityId, NodeId, (int)resultType, Time.realtimeSinceStartup);
    return resultType
end

function NodeDecoratorInverter:OnExit()
    NodeDecorator.OnExit(self)

    for i = 1, #self.nodeChildList do
        if self.runningNodeMap[i] then
            ---@type NodeBase
            local nodeBase = self.nodeChildList[i]
            nodeBase:Postposition(BehaviorTreeInfo.ResultType.Fail)
        end
    end
end

return NodeDecoratorInverter