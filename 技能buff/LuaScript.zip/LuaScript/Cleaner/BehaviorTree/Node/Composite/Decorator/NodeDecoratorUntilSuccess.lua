---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type NodeDecoratorUntil
local NodeDecoratorUntil = require "Cleaner.BehaviorTree.Node.Composite.Decorator.NodeDecoratorUntil"

---@class NodeDecoratorUntilSuccess:NodeDecoratorUntil
local NodeDecoratorUntilSuccess = class(NodeDecoratorUntil, "NodeDecoratorUntilSuccess")

function NodeDecoratorUntilSuccess:ctor()
    self:SetNodeType(BehaviorTreeInfo.NODE_TYPE.DECORATOR_UNTIL_SUCCESS)
    self:SetDesiredResult(BehaviorTreeInfo.ResultType.Success)
end

return NodeDecoratorUntilSuccess