---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type NodeRandom
local NodeRandom = require "Cleaner.BehaviorTree.Node.Composite.NodeRandom"

---@class NodeRandomSequence:NodeRandom
local NodeRandomSequence = class(NodeRandom, "NodeRandomSequence")

function NodeRandomSequence:ctor()
    self:SetNodeType(BehaviorTreeInfo.NODE_TYPE.RANDOM_SEQUEUECE)
    ---@type NodeBase
    self.lastRunningNode = nil
end

function NodeRandomSequence:OnEnter()
    NodeRandom.OnEnter(self)
end

function NodeRandomSequence:Execute()
    local index = -1
    if (self.lastRunningNode ~= nil) then
        index = self.lastRunningNode.NodeIndex + 1
    end
    self.lastRunningNode = nil

    local resultType = BehaviorTreeInfo.ResultType.Fail
    for i = 1, #self.nodeChildList do
        if (index < 0) then
            index = self:GetRandom()
        end

        ---@type NodeBase
        local nodeBase = self.nodeChildList[index]
        index = -1

        nodeBase:Preposition()
        resultType = nodeBase:Execute()
        nodeBase:Postposition(resultType)

        if (resultType == BehaviorTreeInfo.ResultType.Fail) then
            break
        elseif (resultType == BehaviorTreeInfo.ResultType.Success) then

        elseif (resultType == BehaviorTreeInfo.ResultType.Running) then
            self.lastRunningNode = nodeBase
            break
        end
    end

    --NodeNotify.NotifyExecute(EntityId, NodeId, (int)resultType, Time.realtimeSinceStartup);
    return resultType
end

function NodeRandomSequence:OnExit()
    NodeRandom.OnExit(self)

    if (nil ~= self.lastRunningNode) then
        self.lastRunningNode:Postposition(BehaviorTreeInfo.ResultType.Fail)
        self.lastRunningNode = nil
    end
end

return NodeRandomSequence