---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type NodeRandom
local NodeRandom = require "Cleaner.BehaviorTree.Node.Composite.NodeRandom"

---@class NodeRandomPriority:NodeRandom
local NodeRandomPriority = class(NodeRandom, "NodeRandomPriority")

function NodeRandomPriority:ctor()
    self:SetNodeType(BehaviorTreeInfo.NODE_TYPE.RANDOM_PRIORITY)
    ---@type NodeBase
    self.lastRunningNode = nil
    self.totalPriotity = 0
end

function NodeRandomPriority:OnEnter()
    NodeRandom.OnEnter(self)
    self.lastRunningNode = nil
end

function NodeRandomPriority:Execute()
    NodeRandom.Execute(self)
    local index = -1
    if (self.lastRunningNode ~= nil) then
        index = self.lastRunningNode.NodeIndex + 1
    end
    self.lastRunningNode = nil

    local resultType = BehaviorTreeInfo.ResultType.Fail
    for i = 1, #self.nodeChildList do
        if (index < 0) then
            index = self:GetRandom()
        end
        ---@type NodeBase
        local nodeBase = self.nodeChildList[index]
        index = -1

        nodeBase:Preposition()
        resultType = nodeBase:Execute()
        nodeBase:Postposition(resultType)

        if (resultType == BehaviorTreeInfo.ResultType.Fail) then

        elseif (resultType == BehaviorTreeInfo.ResultType.Success) then
            break
        elseif (resultType == BehaviorTreeInfo.ResultType.Running) then
            self.lastRunningNode = nodeBase
            break
        end
    end

    --NodeNotify.NotifyExecute(EntityId, NodeId, (int)resultType, Time.realtimeSinceStartup)
    return resultType
end

function NodeRandomPriority:OnExit()
    NodeRandom.OnExit(self)

    if (nil ~= self.lastRunningNode) then
        self.lastRunningNode:Postposition(BehaviorTreeInfo.ResultType.Fail)
        self.lastRunningNode = nil
    end
end

function NodeRandomPriority:GetRandom()
    self.behaviorRandom:Check()

    self.totalPriotity = 0
    local remainderCount = self.behaviorRandom:RemainderCount()
    for i = 1, remainderCount do
        local index = self.behaviorRandom:GetRemainder(i)
        self.totalPriotity = self.totalPriotity + self.nodeChildList[index].Priority
    end

    local randomValue = math.random(1, self.totalPriotity)
    local priority = 0

    local result = 0
    remainderCount = self.behaviorRandom:RemainderCount()
    for i = 1, remainderCount do
        local index = self.behaviorRandom:GetRemainder(i)
        priority = priority + self.nodeChildList[index].Priority
        if (priority >= randomValue) then
            result = index
            self.behaviorRandom:Remove(index)
            break
        end
    end

    return result
end

return NodeRandomPriority