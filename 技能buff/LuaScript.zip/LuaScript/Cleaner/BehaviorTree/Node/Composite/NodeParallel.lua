---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type NodeComposite
local NodeComposite = require "Cleaner.BehaviorTree.Node.Base.NodeComposite"

---@class NodeParallel:NodeComposite
local NodeParallel = class(NodeComposite, "NodeParallel")

function NodeParallel:ctor()
    self:SetNodeType(BehaviorTreeInfo.NODE_TYPE.PARALLEL)
end

function NodeParallel:OnEnter()
    if not self.runningNodeMap then
        self.runningNodeMap = {}
        for i = 1, #self.nodeChildList do
            self.runningNodeMap[i] = false
        end
    end
end

--- NodeDescript.GetDescript(NODE_TYPE)
function NodeParallel:Execute()
    NodeComposite.Execute(self)
    local resultType = BehaviorTreeInfo.ResultType.Fail

    local successCount = 0
    for i = 1, #self.nodeChildList do
        ---@type NodeBase
        local nodeBase = self.nodeChildList[i]

        nodeBase:Preposition()
        resultType = nodeBase:Execute()
        nodeBase:Postposition(resultType)

        if (resultType == BehaviorTreeInfo.ResultType.Fail) then
            break
        end

        if (resultType == BehaviorTreeInfo.ResultType.Success) then
            successCount = successCount + 1
        elseif resultType == BehaviorTreeInfo.ResultType.Running then
            self.runningNodeMap[i] = true
        end
    end

    if (resultType ~= BehaviorTreeInfo.ResultType.Fail) then
        if (successCount >= #self.nodeChildList) then
            resultType = BehaviorTreeInfo.ResultType.Success
        else
            resultType = BehaviorTreeInfo.ResultType.Running
        end
    end

    --NodeNotify.NotifyExecute(EntityId, NodeId, (int)resultType, Time.realtimeSinceStartup);
    return resultType;
end

function NodeParallel:OnExit()
    NodeComposite.OnExit(self)
    for index, value in pairs(self.runningNodeMap) do
        if value then
            ---@type NodeBase
            local nodeBase = self.nodeChildList[index]
            nodeBase:Postposition(BehaviorTreeInfo.ResultType.Fail)
            self.runningNodeMap[index] = false
        end
    end
end

return NodeParallel