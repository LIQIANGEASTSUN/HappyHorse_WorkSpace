---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type IfJudgeData
local IfJudgeData = require "Cleaner.BehaviorTree.Graphic.Data.IfJudgeData"

---@type NodeComposite
local NodeComposite = require "Cleaner.BehaviorTree.Node.Base.NodeComposite"

---@class NodeIfJudge:NodeComposite
local NodeIfJudge = class(NodeComposite, "NodeIfJudge")

function NodeIfJudge:ctor()
    ---@type NodeBase
    self.lastRunningNode = nil
    ---@type List<IfJudgeData>
    self.ifJudgeDataList = {}
    ---@type ResultType
    self.defaultResult = BehaviorTreeInfo.ResultType.Fail
end

function NodeIfJudge:OnEnter()
    NodeComposite.OnEnter(self)
end

--- NodeDescript.GetDescript(NODE_TYPE)
function NodeIfJudge:Execute()
    return BehaviorTreeInfo.ResultType.Fail
end

function NodeIfJudge:OnExit()
    NodeComposite.OnExit(self)

    if (nil ~= self.lastRunningNode) then
        self.lastRunningNode:Postposition(BehaviorTreeInfo.ResultType.Fail)
        self.lastRunningNode = nil
    end
end

-- NodeBase nodeBase, bool isFirstNode
function NodeIfJudge:ExecuteNode( nodeBase, isFirstNode)
    local resultType = BehaviorTreeInfo.ResultType.Fail
    if (nil ~= nodeBase) then
        nodeBase:Preposition()
        resultType = nodeBase:Execute()
        nodeBase:Postposition(resultType)
    end

    if ((not isFirstNode) and (resultType == BehaviorTreeInfo.ResultType.Running)) then
        self.lastRunningNode = nodeBase
    end

    --NodeNotify.NotifyExecute(EntityId, NodeId, (int)resultType, Time.realtimeSinceStartup);
    return resultType
end

function NodeIfJudge:SetDefaultResult(defaultResult)
    self.defaultResult  = defaultResult
end

-- List<IfJudgeData> ifJudgeDataList
function NodeIfJudge:SetData(ifJudgeDataList)
    for _, data in pairs(ifJudgeDataList) do
        local ifJudgeData = IfJudgeData.new()
        ifJudgeData:CloneFrom(data)
        table.insert(self.ifJudgeDataList, ifJudgeData)
    end
end

-- IfJudgeData    int nodeId
function NodeIfJudge:GetData( nodeId)
    for i = 1, #self.ifJudgeDataList do
        ---@type IfJudgeData
        local data =  self.ifJudgeDataList[i]
        if (data.nodeId == nodeId) then
            return data
        end
    end
    return nil
end

-- ResultType resultType
function NodeIfJudge:GetBaseNode( resultType)
    for i = 1, #self.nodeChildList do
        ---@type NodeBase
        local node = self.nodeChildList[i]
        ---@type IfJudgeData
        local judgeData = self:GetData(node.NodeId)
        if (judgeData.ifJudegType == BehaviorTreeInfo.NodeIfJudgeEnum.ACTION) then
            if (judgeData.ifResult == resultType) then
                return node
            end
        end
    end

    return nil
end

return NodeIfJudge