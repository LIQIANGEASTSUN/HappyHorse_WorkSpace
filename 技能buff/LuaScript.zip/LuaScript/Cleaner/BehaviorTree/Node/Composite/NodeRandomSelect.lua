---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type NodeRandom
local NodeRandom = require "Cleaner.BehaviorTree.Node.Composite.NodeRandom"

---@class NodeRandomSelect:NodeRandom
local NodeRandomSelect = class(NodeRandom, "NodeRandomSelect")

function NodeRandomSelect:ctor()
    self:SetNodeType(BehaviorTreeInfo.NODE_TYPE.RANDOM)
    ---@type NodeBase
    self.lastRunningNode = nil
end

function NodeRandomSelect:OnEnter()
    NodeRandom.OnEnter(self)
end

function NodeRandomSelect:Execute()
    NodeRandom.Execute(self)

    local index = -1
    if (self.lastRunningNode ~= nil) then
        index = self.lastRunningNode.NodeIndex
    end
    self.lastRunningNode = nil

    local resultType = BehaviorTreeInfo.ResultType.Fail
    for i = 1, #self.nodeChildList do
        if (index < 0) then
            index = self:GetRandom()
        end
        ---@type NodeBase
        local nodeBase = self.nodeChildList[index]
        index = -1

        nodeBase:Preposition()
        resultType = nodeBase:Execute()
        nodeBase:Postposition(resultType)

        if (resultType == BehaviorTreeInfo.ResultType.Fail) then

        elseif (resultType == BehaviorTreeInfo.ResultType.Success) then
            break
        elseif (resultType == BehaviorTreeInfo.ResultType.Running) then
            self.lastRunningNode = nodeBase
            break
        end
    end

    --NodeNotify.NotifyExecute(EntityId, NodeId, (int)resultType, Time.realtimeSinceStartup);
    return resultType
end

function NodeRandomSelect:OnExit()
    NodeRandom.OnExit(self)
    if (nil ~= self.lastRunningNode) then
        self.lastRunningNode:Postposition(BehaviorTreeInfo.ResultType.Fail)
        self.lastRunningNode = nil
    end
end

return NodeRandomSelect