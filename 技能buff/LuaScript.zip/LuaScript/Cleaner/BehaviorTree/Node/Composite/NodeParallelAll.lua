---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type NodeComposite
local NodeComposite = require "Cleaner.BehaviorTree.Node.Base.NodeComposite"

---@class NodeParallelAll:NodeComposite
local NodeParallelAll = class(NodeComposite, "NodeParallelAll")

function NodeParallelAll:ctor()
    self:SetNodeType(BehaviorTreeInfo.NODE_TYPE.PARALLEL_ALL)
end

function NodeParallelAll:OnEnter()
    NodeComposite.OnEnter(self)
    if not self.runningNodeMap then
        self.runningNodeMap = {}
        for i = 1, #self.nodeChildList do
            self.runningNodeMap[i] = false
        end
    end
end

--- NodeDescript.GetDescript(NODE_TYPE)
function NodeParallelAll:Execute()
    NodeComposite.Execute(self)
    local resultType = BehaviorTreeInfo.ResultType.Fail

    local successCount = 0
    local failCount = 0
    for i = 1, #self.nodeChildList do
        ---@type NodeBase
        local nodeBase = self.nodeChildList[i]

        nodeBase:Preposition()
        resultType = nodeBase:Execute()
        nodeBase:Postposition(resultType)

        if (resultType == BehaviorTreeInfo.ResultType.Fail) then
            failCount = failCount + 1
        elseif (resultType == BehaviorTreeInfo.ResultType.Success) then
            successCount = successCount + 1
        elseif (resultType == BehaviorTreeInfo.ResultType.Running) then
            self.runningNodeMap[i] = true
        end
    end

    if (successCount >= #self.nodeChildList) then
        resultType = BehaviorTreeInfo.ResultType.Success
    elseif (failCount >= #self.nodeChildList) then
        resultType = BehaviorTreeInfo.ResultType.Fail
    else
        resultType = BehaviorTreeInfo.ResultType.Running
    end

    --NodeNotify.NotifyExecute(EntityId, NodeId, (int)resultType, Time.realtimeSinceStartup);
    return resultType
end

function NodeParallelAll:OnExit()
    NodeComposite.OnExit(self)
    for index, value in pairs(self.runningNodeMap) do
        if value then
            ---@type NodeBase
            local nodeBase = self.nodeChildList[index]
            nodeBase:Postposition(BehaviorTreeInfo.ResultType.Fail)
            self.runningNodeMap[index] = false
        end
    end
end

return NodeParallelAll