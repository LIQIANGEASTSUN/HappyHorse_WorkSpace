---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type NodeIfJudge
local NodeIfJudge = require "Cleaner.BehaviorTree.Node.Composite.NodeIfJudge"

---@class NodeIfJudgeSequence:NodeIfJudge
local NodeIfJudgeSequence = class(NodeIfJudge, "NodeIfJudgeSequence")

function NodeIfJudgeSequence:ctor()
    self:SetNodeType(BehaviorTreeInfo.NODE_TYPE.IF_JUDEG_SEQUENCE)
end

--- NodeDescript.GetDescript(NODE_TYPE)
function NodeIfJudgeSequence:Execute()
    if (#self.nodeChildList <= 0) then
        return BehaviorTreeInfo.ResultType.Fail
    end

    local resultType = BehaviorTreeInfo.ResultType.Fail

    if (nil ~= self.lastRunningNode) then
        resultType = self.lastRunningNode:Execute()
    else
        -- The first node is the conditional node
        ---@type NodeBase
        local ifNode = self.nodeChildList[1]
        resultType = self:ExecuteNode(ifNode, true)
        if (resultType == BehaviorTreeInfo.ResultType.Running) then
            return BehaviorTreeInfo.ResultType.Fail
        end
        ---@type NodeBase
        local nodeBase = self:GetBaseNode(resultType)
        if (nil ~= nodeBase) then
            resultType = self:ExecuteNode(nodeBase, false)
        else
            resultType = self.defaultResult
        end
    end

    return resultType
end

return NodeIfJudgeSequence