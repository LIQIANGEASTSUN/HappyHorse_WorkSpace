---@type NodeComposite
local NodeComposite = require "Cleaner.BehaviorTree.Node.Base.NodeComposite"

---@type BehaviorRandom
local BehaviorRandom = require "Cleaner.BehaviorTree.Tool.BehaviorRandom"

---@class NodeRandom
local NodeRandom = class(NodeComposite, "NodeRandom")

function NodeRandom:ctor()
    self.behaviorRandom = BehaviorRandom.new(#self.nodeChildList)
end

function NodeRandom:OnEnter()
    NodeComposite.OnEnter(self)
    self.behaviorRandom:Init()
end

function NodeRandom:OnExit()
    NodeComposite.OnExit(self)
end

function NodeRandom:GetRandom()
    return self.behaviorRandom.GetRandom()
end

return NodeRandom