---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type NodeComposite
local NodeComposite = require "Cleaner.BehaviorTree.Node.Base.NodeComposite"

---@class NodeParallelSelect:NodeComposite
local NodeParallelSelect = class(NodeComposite, "NodeParallelSelect")

function NodeParallelSelect:ctor()
    self:SetNodeType(BehaviorTreeInfo.NODE_TYPE.PARALLEL_SELECT)
end

function NodeParallelSelect:OnEnter()
    NodeComposite.OnEnter(self)
    if not self.runningNodeMap then
        self.runningNodeMap = {}
        for i = 1, #self.nodeChildList do
            self.runningNodeMap[i] = false
        end
    end
end

--- NodeDescript.GetDescript(NODE_TYPE)
function NodeParallelSelect:Execute()
    NodeComposite.Execute(self)
    local resultType = BehaviorTreeInfo.ResultType.Fail
    local failCount = 0
    for i = 1, #self.nodeChildList do
        ---@type NodeBase
        local nodeBase = self.nodeChildList[i]

        nodeBase:Preposition()
        resultType = nodeBase:Execute()
        nodeBase:Postposition(resultType)

        if (resultType == BehaviorTreeInfo.ResultType.Success) then
            break
        end

        if (resultType == BehaviorTreeInfo.ResultType.Running) then
            self.runningNodeMap[i] = true
        elseif (resultType == BehaviorTreeInfo.ResultType.Fail) then
            failCount = failCount + 1
        end
    end

    if (resultType ~= BehaviorTreeInfo.ResultType.Success) then
        if #self.runningNodeMap > 0 then
            resultType = BehaviorTreeInfo.ResultType.Running
        else
            resultType = BehaviorTreeInfo.ResultType.Fail
        end
    end

    --NodeNotify.NotifyExecute(EntityId, NodeId, (int)resultType, Time.realtimeSinceStartup)
    return resultType
end

function NodeParallelSelect:OnExit()
    NodeComposite.OnExit(self)
    for index, value in pairs(self.runningNodeMap) do
        if value then
            ---@type NodeBase
            local nodeBase = self.nodeChildList[index]
            nodeBase:Postposition(BehaviorTreeInfo.ResultType.Fail)
            self.runningNodeMap[index] = false
        end
    end
end

return NodeParallelSelect