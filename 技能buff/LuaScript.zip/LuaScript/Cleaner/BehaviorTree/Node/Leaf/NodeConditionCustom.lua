---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type NodeCondition
local NodeCondition = require "Cleaner.BehaviorTree.Node.Leaf.NodeCondition"

---@class NodeConditionCustom:NodeCondition
local NodeConditionCustom = class(NodeCondition, "NodeCondition")

function NodeConditionCustom:ctor()

end

function NodeConditionCustom:OnEnter()
    NodeCondition.OnEnter(self)
end

--- condition node need to implement this method
-- ResultType
function NodeConditionCustom:Condition()
    -- Compares configured condition parameters
    local result = self.iconditionCheck:Condition(self.conditionParameter)
    local resultType = result and BehaviorTreeInfo.ResultType.Success or BehaviorTreeInfo.ResultType.Fail
    return resultType
end

return NodeConditionCustom