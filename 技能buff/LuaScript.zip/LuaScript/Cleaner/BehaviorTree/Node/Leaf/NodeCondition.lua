---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type ConditionParameter
local ConditionParameter = require "Cleaner.BehaviorTree.Graphic.Condition.ConditionParameter"

---@type ConditionGroup
local ConditionGroup = require "Cleaner.BehaviorTree.Graphic.Data.ConditionGroup"

---@type NodeLeaf
local NodeLeaf = require "Cleaner.BehaviorTree.Node.Base.NodeLeaf"

---@class NodeCondition:NodeLeaf
local NodeCondition = class(NodeLeaf, "NodeCondition")

function NodeCondition:ctor()
    ---@type List<ConditionGroup>
    self.conditionGroupList = {}
    ---@type ConditionParameter
    self.conditionParameter = ConditionParameter.new()
    ---@type ConditionCheck
    self.iconditionCheck = nil
    self:SetNodeType(BehaviorTreeInfo.NODE_TYPE.CONDITION)
end

function NodeCondition:OnEnter()
    NodeLeaf.OnEnter(self)
    self.conditionParameter:Init(self.conditionGroupList, self.parameterList)
end

--- ResultType
function NodeCondition:Execute()
    local resultType = self:Condition()
    --NodeNotify.NotifyExecute(EntityId, NodeId, (int)resultType, Time.realtimeSinceStartup);
    return resultType;
end

-- IConditionCheck iConditionCheck
function NodeCondition:SetConditionCheck(iConditionCheck)
    self.iconditionCheck = iConditionCheck
end

-- List<ConditionGroup> conditionGroupList
function NodeCondition:SetConditionGroup(conditionGroupList)
    for _, conditionGroup in pairs(conditionGroupList) do
        local cloneConditionGroup = ConditionGroup.new()
        cloneConditionGroup:CloneFrom(conditionGroup)
        table.insert(self.conditionGroupList, cloneConditionGroup)
    end
end

--- condition node need to implement this method
-- ResultType
function NodeCondition:Condition()
    return BehaviorTreeInfo.ResultType.Fail
end

return NodeCondition