---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type NodeLeaf
local NodeLeaf = require "Cleaner.BehaviorTree.Node.Base.NodeLeaf"

---@class NodeAction:NodeLeaf
local NodeAction = class(NodeLeaf, "NodeAction")

function NodeAction:ctor()
    --- List<NodeParameter>
    self:SetNodeType(BehaviorTreeInfo.NODE_TYPE.ACTION)
end

--- ResultType
function NodeAction:Execute()
    local resultType = BehaviorTreeInfo.ResultType.Fail
    resultType = self:DoAction()
    --NodeNotify.NotifyExecute(EntityId, NodeId, (int)resultType, Time.realtimeSinceStartup);
    return resultType
end

--- action node need to implement this method
--- ResultType
function NodeAction:DoAction()

end

return NodeAction