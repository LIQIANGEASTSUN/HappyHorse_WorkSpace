---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type NodeComposite
local NodeComposite = require "Cleaner.BehaviorTree.Node.Base.NodeComposite"

---@class NodeSubTree:NodeComposite
local NodeSubTree = class(NodeComposite, "NodeSubTree")

function NodeSubTree:ctor()
    self:SetNodeType(BehaviorTreeInfo.NODE_TYPE.SUB_TREE)

    ---@type NodeBase
    self.lastRunningNode = nil
end

function NodeSubTree:OnEnter()
    NodeComposite.OnEnter(self)
end

--- ResultType
function NodeSubTree:Execute()
    local resultType = BehaviorTreeInfo.ResultType.Fail
    if #self.nodeChildList <= 0 then
        return BehaviorTreeInfo.ResultType.Fail
    end

    --- NodeBase
    local nodeBase = self.nodeChildList[1]
    nodeBase:Preposition()
    resultType = nodeBase:Execute()
    nodeBase:Postposition(resultType)

    if (resultType == BehaviorTreeInfo.ResultType.Running) then
        self.lastRunningNode = nodeBase
    end

    --NodeNotify.NotifyExecute(EntityId, NodeId, (int)resultType, Time.realtimeSinceStartup);
    return resultType
end

function NodeSubTree:OnExit()
    NodeComposite.OnExit(self)
    if (nil ~= self.lastRunningNode) then
        self.lastRunningNode:Postposition(BehaviorTreeInfo.ResultType.Fail)
        self.lastRunningNode = nil
    end
end

return NodeSubTree