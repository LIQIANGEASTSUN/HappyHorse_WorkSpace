---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@class IfJudgeData
local IfJudgeData = class(nil, "IfJudgeData")

function IfJudgeData:ctor()
    self.nodeId = 0
    self.ifJudegType = BehaviorTreeInfo.NodeIfJudgeEnum.IF
    self.ifResult = BehaviorTreeInfo.ResultType.Fail
end

function IfJudgeData:Clone()
    ---@type IfJudgeData
    local ifJudgeData = IfJudgeData.new()
    ifJudgeData.CloneFrom(self)
    return ifJudgeData
end

function IfJudgeData:CloneFrom(data)
    self.nodeId = data.nodeId
    self.ifJudegType = data.ifJudegType
    self.ifResult = data.ifResult
end

return IfJudgeData