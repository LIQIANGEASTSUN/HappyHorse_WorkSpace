---@class ConditionGroup
local ConditionGroup = class(nil, "ConditionGroup")

function ConditionGroup:ctor()
    self.index = 0
    -- List<string> parameterList
    self.parameterNameList = {}
end

--- ConditionGroup Clone()
function ConditionGroup:Clone()
    ---@type ConditionGroup
    local group = ConditionGroup.new()
    group.index = self.index

    for _, parameterName in pairs(self.parameterNameList) do
        table.insert(group.parameterNameList, parameterName)
    end

    return group
end

function ConditionGroup:CloneFrom(conditionGroupData)
    self.index = conditionGroupData.index
    for _, parameterName in pairs(conditionGroupData.parameterList) do
        table.insert(self.parameterNameList, parameterName)
    end
end

return ConditionGroup