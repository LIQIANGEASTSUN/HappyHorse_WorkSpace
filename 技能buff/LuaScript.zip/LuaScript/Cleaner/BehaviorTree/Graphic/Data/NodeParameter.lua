---@class NodeParameter
local NodeParameter = class(nil, "NodeParameter")

function NodeParameter:ctor()
    self.parameterType = 0
    self.parameterName = ""
    self.CNName = ""
    self.index = 0
    self.floatValue = 0
    self.intValue = 0
    self.boolValue = false
    self.stringValue = ""
    self.compare = 0
end

function NodeParameter:Clone()
    ---@type NodeParameter
    local newParameter = NodeParameter.new()
    newParameter.CloneFrom(self)
    return newParameter
end

-- NodeParameter parameter
function NodeParameter:CloneFrom( parameterData)
    self.parameterType = parameterData.parameterType
    self.parameterName = parameterData.parameterName
    self.CNName = parameterData.CNName
    self.index = parameterData.index
    self.floatValue = parameterData.floatValue
    self.intValue = parameterData.intValue
    self.boolValue = parameterData.boolValue
    self.stringValue = parameterData.stringValue
    self.compare = parameterData.compare
end

return NodeParameter