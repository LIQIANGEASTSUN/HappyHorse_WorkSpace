---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

local Bit = require "Utils.bitOp"

---@class ParameterCompareTool
local ParameterCompareTool = {}

-- ParameterCompare Compare(NodeParameter self, NodeParameter parameter)
function ParameterCompareTool:Compare(selfParameter, parameter)
    ---@type ParameterCompare
    local result = BehaviorTreeInfo.ParameterCompare.NOT_EQUAL
    if (selfParameter.parameterType ~= parameter.parameterType) then
       --Debug.LogError("parameter Type not Equal:" + parameter.parameterName + "    " + parameter.parameterType + "    " + selfParameter.parameterType);
        return result
    end

    if (selfParameter.parameterType == BehaviorTreeInfo.ParameterType.Float) then
        result = self:CompareFloat(selfParameter.floatValue, parameter.floatValue)
    elseif (selfParameter.parameterType == BehaviorTreeInfo.ParameterType.Int) then
            result = self:CompareLong(selfParameter.intValue, parameter.intValue)
    elseif (selfParameter.parameterType == BehaviorTreeInfo.ParameterType.Bool) then
        result = self:CompareBool(selfParameter.boolValue, parameter.boolValue);
    elseif (selfParameter.parameterType == BehaviorTreeInfo.ParameterType.String) then
        result = self:CompareString(selfParameter.stringValue, parameter.stringValue);
    end

    return result
end

-- ParameterCompare CompareFloat(float floatValue1, float floatValue2)
function ParameterCompareTool:CompareFloat( floatValue1, floatValue2)
    ---@type ParameterCompare
    local BehaviorCompare = BehaviorTreeInfo.ParameterCompare.INVALID
    if (floatValue1 > floatValue2) then
        BehaviorCompare = Bit.Or(BehaviorCompare, BehaviorTreeInfo.ParameterCompare.GREATER)
    elseif (floatValue1 < floatValue2) then
        BehaviorCompare = Bit.Or(BehaviorCompare, BehaviorTreeInfo.ParameterCompare.LESS)
    end

    return BehaviorCompare
end

-- ParameterCompare CompareLong(long longValue1, long longValue2)
function ParameterCompareTool:CompareLong( longValue1, longValue2)
    ---@type ParameterCompare
    local behaviorCompare = BehaviorTreeInfo.ParameterCompare.INVALID
    if (longValue1 > longValue2) then
        behaviorCompare = Bit.Or(behaviorCompare, BehaviorTreeInfo.ParameterCompare.GREATER)
        behaviorCompare = Bit.Or(behaviorCompare, BehaviorTreeInfo.ParameterCompare.NOT_EQUAL)
    elseif (longValue1 < longValue2) then
        behaviorCompare = Bit.Or(behaviorCompare, BehaviorTreeInfo.ParameterCompare.LESS)
        behaviorCompare = Bit.Or(behaviorCompare, BehaviorTreeInfo.ParameterCompare.NOT_EQUAL)
    else
        behaviorCompare = Bit.Or(behaviorCompare, BehaviorTreeInfo.ParameterCompare.EQUALS)
    end

    if (longValue1 >= longValue2) then
        behaviorCompare = Bit.Or(behaviorCompare, BehaviorTreeInfo.ParameterCompare.GREATER_EQUALS)
    end

    if (longValue1 <= longValue2) then
        behaviorCompare = Bit.Or(behaviorCompare, BehaviorTreeInfo.ParameterCompare.LESS_EQUAL)
    end

    return behaviorCompare
end

--- ParameterCompare CompareBool(bool boolValue1, bool boolValue2)
function ParameterCompareTool:CompareBool( boolValue1, boolValue2)
    ---@type ParameterCompare
    if (boolValue1 == boolValue2) then
        return BehaviorTreeInfo.ParameterCompare.EQUALS
    end
    return BehaviorTreeInfo.ParameterCompare.NOT_EQUAL
end

--- ParameterCompare CompareString(string stringValue1, string stringValue2)
function ParameterCompareTool:CompareString( stringValue1, stringValue2)
    if stringValue1 == stringValue2 then
        return BehaviorTreeInfo.ParameterCompare.EQUALS
    end
    return BehaviorTreeInfo.ParameterCompare.NOT_EQUAL
end

return ParameterCompareTool