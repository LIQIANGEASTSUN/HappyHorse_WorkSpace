---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type NodeParameter
local NodeParameter = require "Cleaner.BehaviorTree.Graphic.Data.NodeParameter"

local Bit = require "Utils.bitOp"

---@type ParameterCompareTool
local ParameterCompareTool = require "Cleaner.BehaviorTree.Graphic.ParameterCompareTool"

---@class ConditionCheck
local ConditionCheck = class(nil, "ConditionCheck")

function ConditionCheck:ctor()
    ---@type Dictionary<string, NodeParameter>
    self.environmentParameterDic = {}
end

-- Set the value of the environment variable of type bool
-- string parameterName, bool boolValue
function ConditionCheck:SetBoolParameter( parameterName, boolValue)
    ---@type NodeParameter
    local parameter = self:GetNodeParametere(parameterName)
    if (nil == parameter) then
        parameter = self:CreateParameter(parameterName, BehaviorTreeInfo.ParameterType.Bool)
        self.environmentParameterDic[parameterName] = parameter
    end
    parameter.boolValue = boolValue
end

--- Set the value of the environment variable of type float
--- string parameterName, float floatValue
function ConditionCheck:SetFloatParameter( parameterName, floatValue)
    ---@type NodeParameter
    local parameter = self:GetNodeParametere(parameterName);
    if (nil == parameter) then
        parameter = self:CreateParameter(parameterName, BehaviorTreeInfo.ParameterType.Float)
        self.environmentParameterDic[parameterName] = parameter
    end
    parameter.floatValue = floatValue
end

--- Set the value of the environment variable of type int
--- string parameterName, int intValue
function ConditionCheck:SetIntParameter( parameterName, intValue)
    ---@type NodeParameter
    local parameter = self:GetNodeParametere(parameterName)
    if (nil == parameter) then
        parameter = self:CreateParameter(parameterName, BehaviorTreeInfo.ParameterType.Int)
        self.environmentParameterDic[parameterName] = parameter
    end
    parameter.intValue = intValue
end

-- Set the value of the environment variable of type string
-- string parameterName, string stringValue
function ConditionCheck:SetStringParameter( parameterName, stringValue)
    ---@type NodeParameter
    local parameter = self:GetNodeParametere(parameterName)
    if (nil == parameter) then
        parameter = self:CreateParameter(parameterName, BehaviorTreeInfo.ParameterType.String)
        self.environmentParameterDic[parameterName] = parameter
    end
    parameter.stringValue = stringValue
end

-- string parameterName, int type
function ConditionCheck:CreateParameter( parameterName, type)
    ---@type NodeParameter
    local nodeParameter = NodeParameter.new()
    nodeParameter.parameterName = parameterName
    nodeParameter.parameterType = type
    return nodeParameter
end

-- Add environment variables
-- NodeParameter parameter
function ConditionCheck:AddParameter(parameter)
    ---@type NodeParameter
    local cache = self:GetNodeParametere(parameter.parameterName)
    if (nil == cache) then
        self.environmentParameterDic[parameter.parameterName] = parameter
    end
end

-- Get the environment variable based on the parameter name
-- string parameterName
function ConditionCheck:GetNodeParametere( parameterName)
    ---@type NodeParameter
    local parameter = self.environmentParameterDic[parameterName]
    return parameter
end

--Get the value of the environment variable based on the parameter name
-- string parameterName, ref float value
function ConditionCheck:GetFloatParameterValue( parameterName)
    ---@type NodeParameter
    local parameter = self:GetNodeParametere(parameterName)
    if (nil ~= parameter) then
        return true, parameter.floatValue
    end
    return false, 0
end

--- Get the value of the environment variable based on the parameter name
--- string parameterName, ref int value
function ConditionCheck:GetIntParameterValue( parameterName)
    ---@type NodeParameter
    local parameter = self:GetNodeParametere(parameterName)
    if (nil ~= parameter) then
        return true, parameter.intValue
    end
    return false, 0
end

-- Get the value of the environment variable based on the parameter name
-- string parameterName, ref bool value
function ConditionCheck:GetBoolParameterValue( parameterName)
    ---@type NodeParameter
    local parameter = self:GetNodeParametere(parameterName)
    if (nil ~= parameter) then
        return true, parameter.boolValue
    end
    return false, false
end

--- Get the value of the environment variable based on the parameter name
--- string parameterName, ref string value
function ConditionCheck:GetStringParameterValue( parameterName)
    ---@type NodeParameter
    local parameter = self:GetNodeParametere(parameterName)
    if (nil ~= parameter) then
        return true, parameter.stringValue
    end
    return false, ""
end

-- NodeParameter parameter
function ConditionCheck:ConditionNodeParameter( parameter)
    ---@type NodeParameter
    local environmentParameter = self.environmentParameterDic[parameter.parameterName]
    if (not environmentParameter) then
        return false
    end

    if (environmentParameter.parameterType ~= parameter.parameterType) then
        return false
    end

    ---@type ParameterCompare
    local compare = ParameterCompareTool:Compare(environmentParameter, parameter)
    local value = Bit.And(parameter.compare, compare)
    return value > 0
end

--- List<NodeParameter> parameterList
function ConditionCheck:ConditionAllAnd(parameterList)
    local result = true
    for i = 1, #parameterList do
        ---@type NodeParameter
        local temp = parameterList[i]
        local value = self:ConditionNodeParameter(temp)
        if (not value) then
            result = false
            break
        end
    end

    return result
end

-- ConditionParameter conditionParameter
function ConditionCheck:Condition( conditionParameter)
    local result = true
    ---@type List<ConditionGroupParameter>
    local groupList = conditionParameter:GetGroupList()
    for i = 1, #groupList do
        ---@type ConditionGroupParameter
        local groupParameter = groupList[i]
        result = true

        for  j = 1, #groupParameter.parameterList do
            ---@type NodeParameter
            local parameter = groupParameter.parameterList[j]
            local value = self:ConditionNodeParameter(parameter)
            if (not value) then
                result = false
                break
            end
        end

        if (result) then
            break
        end
    end

    return result
end

function ConditionCheck:GetAllParameter()
    ---@type List<NodeParameter>
    local parameterList = {}
    for _, parameter in pairs(self.environmentParameterDic) do
        table.insert(parameterList, parameter)
    end

    return parameterList;
end

return ConditionCheck