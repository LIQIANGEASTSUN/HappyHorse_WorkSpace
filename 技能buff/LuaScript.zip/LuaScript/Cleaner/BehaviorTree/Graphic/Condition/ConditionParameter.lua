---@type ConditionGroupParameter
local ConditionGroupParameter = require "Cleaner.BehaviorTree.Graphic.Condition.ConditionGroupParameter"

---@class ConditionParameter
local ConditionParameter = class(nil, "ConditionParameter")

function ConditionParameter:ctor()
    self.init = false
    ---@type List<ConditionGroupParameter>
    self.groupList = {}
end

-- List<ConditionGroup> conditionGroupList, List<NodeParameter> parameterList
function ConditionParameter:Init(conditionGroupList, parameterList)
    if (self.init) then
        return
    end
    self.init = true

    for i = 1, #conditionGroupList do
        ---@type ConditionGroup
        local conditionGroup = conditionGroupList[i]
        ---@type ConditionGroupParameter
        local group = self:GetParameter(conditionGroup, parameterList)
        table.insert(self.groupList, group)
    end
end

-- ConditionGroupParameter GetParameter(ConditionGroup conditionGroup, List<NodeParameter> parameterList)
function ConditionParameter:GetParameter( conditionGroup, parameterList)
    ---@type ConditionGroupParameter
    local group = ConditionGroupParameter.new()
    for i = 1, #conditionGroup.parameterNameList do
        local parameter = conditionGroup.parameterNameList[i]
        for j = 1, #parameterList do
            if (parameter == parameterList[j].parameterName) then
                table.insert(group.parameterList, parameterList[j])
            end
        end
    end

    return group
end

-- List<ConditionGroupParameter> GetGroupList()
function ConditionParameter:GetGroupList()
    return self.groupList
end

return ConditionParameter