
---@type ConditionGroupParameter
local ConditionGroupParameter = class(nil, "ConditionGroupParameter")

function ConditionGroupParameter:ctor()
    ---@type List<NodeParameter>
    self.parameterList = {}
end

-- NodeParameter parameter
function ConditionGroupParameter:AddParameter( parameter)
    table.insert(self.parameterList, parameter)
end

return ConditionGroupParameter