---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"
local NODE_TYPE = BehaviorTreeInfo.NODE_TYPE

---@class BTActionOwnerTool
local BTActionOwnerTool = {}

function BTActionOwnerTool.NodeSetOwner(owner, rootNode)
    if not rootNode then
        return
    end

    local queue = {}
    table.insert(queue, rootNode)
    while #queue > 0 do
        ---@type NodeBase
        local node = queue[1]
        table.remove(queue, 1)
        if node.SetOwner then
            node:SetOwner(owner)
        end

        local nodeType = node:NodeType()
        local isLeaf = (nodeType == NODE_TYPE.ACTION) or (nodeType == NODE_TYPE.CONDITION)
        if (not isLeaf) and node.GetChilds then
            local childs = node:GetChilds()
            for _, child in pairs(childs) do
                table.insert(queue, child)
            end
        end
    end
end

return BTActionOwnerTool