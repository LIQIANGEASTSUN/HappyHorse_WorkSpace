---@class BehaviorRandom
local BehaviorRandom = class(nil, "BehaviorRandom")

function BehaviorRandom:ctor(count)
    self.count = count
    self.randomCount = 0
    self.idArr = {}
    self:Init()
end

function BehaviorRandom:Init()
    self.randomCount = 0
    for i = 1, self.count do
        table.insert(self.idArr, i)
    end
end

function BehaviorRandom:Check()
    if (self.randomCount < 0 or self.randomCount >= #self.idArr) then
        self:Init()
    end
end

function BehaviorRandom:GetRandom()
    if (self.count <= 0) then
        return 0
    end

    if (self.randomCount >= #self.idArr) then
        self:Init()
    end

    local index = math.random(1, 10000)
    index = index % (#self.idArr - self.randomCount)
    local value = self.idArr[index]
    self:Remove(index)
    return value
end

function BehaviorRandom:RemainderCount()
    local count = #self.idArr
    local remainder = count - self.randomCount
    return remainder
end

function BehaviorRandom:GetRemainder(index)
    return self.idArr[index]
end

function BehaviorRandom:Remove(index)
    if (index < 1 or index > #self.idArr) then
        return
    end

    if (self.randomCount < 0 or self.randomCount > #self.idArr) then
        return
    end

    local count = #self.idArr
    self.idArr[index] = self.idArr[count - self.randomCount]
    self.randomCount = self.randomCount + 1
end

return BehaviorRandom