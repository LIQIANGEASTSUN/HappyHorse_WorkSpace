---@type ConditionCheck
local ConditionCheck = require "Cleaner.BehaviorTree.Graphic.Condition.ConditionCheck"

---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type BehaviorAnalysis
local BehaviorAnalysis = require "Cleaner.BehaviorTree.Analysis.BehaviorAnalysis"

-- ---@type BTActionOwnerTool
-- local BTActionOwnerTool = require "Cleaner.BehaviorTree.Tool.BTActionOwnerTool"

---@class BehaviorTreeEntity
local BehaviorTreeEntity = class(nil, "BehaviorTreeEntity")

local currentDebugEntityId = 0
function BehaviorTreeEntity:ctor(configName, owner)
    self.entityId = 0

    ---@type ConditionCheck
    self.iconditionCheck = ConditionCheck.new()

    ---@type NodeBase
    self.rootNode = BehaviorAnalysis:GetInstance():Analysis(configName, self.iconditionCheck, owner)
    if (nil ~= self.rootNode) then
        self.entityId = self.rootNode.EntityId
        --BTActionOwnerTool.NodeSetOwner(owner, self.rootNode)
    end
end

function BehaviorTreeEntity:ConditionCheck()
    return self.iconditionCheck
end

---@type NodeBase
function BehaviorTreeEntity:RootNode()
    return self.rootNode
end

function BehaviorTreeEntity:EntityId()
    return self.entityId
end

function BehaviorTreeEntity:Execute()
    if (nil ~= self.rootNode) then
        self.rootNode:Preposition()
        local resultType = self.rootNode:Execute()
        self.rootNode:Postposition(resultType)
    end
end

function BehaviorTreeEntity:Clear()
    self:Exit()
end

function BehaviorTreeEntity:Exit()
    if (nil ~= self.rootNode) then
        self.rootNode:Postposition(BehaviorTreeInfo.ResultType.Fail)
    end
end

function BehaviorTreeEntity:Release()
    self:Exit()

    self.rootNode = nil
    self.iconditionCheck = nil
end

function BehaviorTreeEntity:SetCurrentDebugEntityId(entityId)
    currentDebugEntityId = entityId
    --NodeNotify:SetCurrentEndityId(entityIdntityId)
end

function BehaviorTreeEntity:GetCurrentDebugEntityId()
    return currentDebugEntityId
end

function BehaviorTreeEntity:SetBoolParameter( parameterName, boolValue)
    self.iconditionCheck:SetBoolParameter(parameterName, boolValue)
end

function BehaviorTreeEntity:SetFloatParameter( parameterName, floatValue)
    self.iconditionCheck:SetFloatParameter(parameterName, floatValue)
end

function BehaviorTreeEntity:SetIntParameter( parameterName, intValue)
    self.iconditionCheck:SetIntParameter(parameterName, intValue)
end

function BehaviorTreeEntity:SetStringParameter( parameterName, stringValue)
    self.iconditionCheck:SetStringParameter(parameterName, stringValue)
end

function BehaviorTreeEntity:GetFloatParameterValue( parameterName)
    return self.iconditionCheck:GetFloatParameterValue(parameterName)
end

function BehaviorTreeEntity:GetIntParameterValue( parameterName)
    return self.iconditionCheck:GetIntParameterValue(parameterName)
end

function BehaviorTreeEntity:GetBoolParameterValue( parameterName)
    return self.iconditionCheck:GetBoolParameterValue(parameterName)
end

function BehaviorTreeEntity:GetStringParameterValue( parameterName)
    return self.iconditionCheck:GetStringParameterValue(parameterName)
end

return BehaviorTreeEntity