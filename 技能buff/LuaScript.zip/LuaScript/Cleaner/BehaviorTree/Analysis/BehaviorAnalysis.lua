---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"
local NODE_TYPE = BehaviorTreeInfo.NODE_TYPE

---@type ConfigLoad
local ConfigLoad = require "Cleaner.BehaviorTree.Analysis.ConfigLoad"

---@type NodeParameter
local NodeParameter = require "Cleaner.BehaviorTree.Graphic.Data.NodeParameter"

---@type BehaviorAnalysis
local BehaviorAnalysis = class(nil, "BehaviorAnalysis")

local instance = nil
---@return BehaviorAnalysis
function BehaviorAnalysis:GetInstance()
    if not instance then
        instance = BehaviorAnalysis.new()
    end
    return instance
end

function BehaviorAnalysis:ctor()
    self.entityId = 0
end

-- NodeBase Analysis(string configName, IConditionCheck iConditionCheck)
function BehaviorAnalysis:Analysis( configName, iConditionCheck, owner)
    local entityId = self:NewEntityId()
    ---@type NodeBase
    local rootNode = self:AnalysisTree(entityId, configName, iConditionCheck, owner)
    return rootNode
end

-- NodeBase AnalysisTree(int entityId, BehaviorTreeData btData, IConditionCheck iConditionCheck)
function BehaviorAnalysis:AnalysisTree( entityId, configName, iConditionCheck, owner)
    ---@type NodeBase
    local rootNode = nil
    local btData = self:LoadConfig(configName)
    if (nil == btData or btData.rootNodeId < 0) then
        --ProDebug.Logger.LogError("数据无效");
        return rootNode
    end

    self:SetParameter(iConditionCheck, btData)
    rootNode = self:AnalysisNode(entityId, btData, btData.rootNodeId, iConditionCheck, owner)
    return rootNode
end

-- NodeBase AnalysisNode(int entityId, BehaviorTreeData btData, int nodeId, IConditionCheck iConditionCheck)
function BehaviorAnalysis:AnalysisNode( entityId, btData, nodeId, iConditionCheck, owner)
    --@type NodeValue
    local nodeValue = btData.nodeDic[nodeId]
    if not nodeValue then
        return nil
    end

    ---@type NodeBase
    local nodeBase = self:CreateNode(nodeValue, iConditionCheck, owner)
    nodeBase.NodeId = nodeValue.id
    nodeBase.EntityId = entityId
    nodeBase.Priority = nodeValue.priority

    if (nodeValue.NodeType == NODE_TYPE.SUB_TREE and nodeValue.subTreeType == BehaviorTreeInfo.SUB_TREE_TYPE.CONFIG) then
        ---@type BehaviorTreeData
        local subTreeData = self:LoadConfig(nodeValue.subTreeConfig)
        if (nil ~= subTreeData) then
            ---@type NodeBase
            local subTreeNode = self:AnalysisTree(entityId, subTreeData, iConditionCheck);
            ---@type NodeComposite
            local composite = nodeBase
            composite:AddNode(subTreeNode)
        end
    end

    if (not self:IsLeafNode(nodeValue.NodeType)) then
        ---@type NodeComposite
        local composite = nodeBase
        for i = 1, #nodeValue.childNodeList do
            local childNodeId = nodeValue.childNodeList[i]
            ---@type NodeBase
            local childNode = self:AnalysisNode(entityId, btData, childNodeId, iConditionCheck, owner)
            if (nil ~= childNode) then
                composite:AddNode(childNode)
            end
        end
    end

    return nodeBase
end

function BehaviorAnalysis:IsLeafNode( type)
    return (type == NODE_TYPE.ACTION) or (type == NODE_TYPE.CONDITION);
end

--- AbstractNode CreateNode(NodeValue nodeValue, IConditionCheck iConditionCheck)
function BehaviorAnalysis:CreateNode( nodeValue, iConditionCheck, owner)
    ---@type NodeBase
    local nodeAlias = self:GetNodePath(nodeValue)
    local nodeBase = nodeAlias.new()
    if (nodeValue.NodeType == NODE_TYPE.CONDITION) then -- 条件节点
        ---@type NodeCondition
        local condition = nodeBase
        condition:SetParameters(nodeValue.parameterList)
        condition:SetConditionGroup(nodeValue.conditionGroupList)
        condition:SetConditionCheck(iConditionCheck)
        if condition.SetOwner then
            condition:SetOwner(owner)
        end
    elseif (nodeValue.NodeType == NODE_TYPE.ACTION) then
        ---@type NodeAction
        local action = nodeBase
        action:SetParameters(nodeValue.parameterList)
        if action.SetOwner then
            action:SetOwner(owner)
        end
    elseif (nodeValue.NodeType == NODE_TYPE.IF_JUDEG_PARALLEL or nodeValue.NodeType == NODE_TYPE.IF_JUDEG_SEQUENCE) then
        ---@type NodeIfJudge
        local ifJudge =nodeBase
        ifJudge:SetData(nodeValue.ifJudgeDataList)
        ifJudge:SetDefaultResult(nodeValue.defaultResult)
    elseif (nodeValue.NodeType == NODE_TYPE.DECORATOR_REPEAT) then
        ---@type NodeDecoratorRepeat
        local nodeDecoratorRepeat = nodeBase
        nodeDecoratorRepeat:SetRepeatCount(nodeValue.repeatTimes)
    end

    return nodeBase
end

-- (IConditionCheck iConditionCheck, BehaviorTreeData btData
---@param iConditionCheck ConditionCheck
function BehaviorAnalysis:SetParameter( iConditionCheck, btData)
    for _, parameter in pairs(btData.parameterList) do
        local cloneParameter = NodeParameter.new()
        cloneParameter:CloneFrom(parameter)
        iConditionCheck:AddParameter(cloneParameter)
    end
end

function BehaviorAnalysis:NewEntityId()
    self.entityId = self.entityId + 1
    return self.entityId
end

function BehaviorAnalysis:LoadConfig(configName)
    return ConfigLoad.FileConfigs[configName]
end

function BehaviorAnalysis:GetNodePath(nodeValue)
    local name = nodeValue.luaConfig
    if not name or name == "" then
        name = nodeValue.identificationName
    end
    return ConfigLoad.NodeConfigs[name]
end

return BehaviorAnalysis