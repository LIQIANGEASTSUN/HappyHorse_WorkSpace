---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type BTCustomConfig
local BTCustomConfig = require "Cleaner.AIConfig.BTCustomConfig"

---@class ConfigLoad
local ConfigLoad = {
}

ConfigLoad.FileConfigs = setmetatable(
    {
        configMap = { }
    },
    {
        __index = function(t, k)
            local config = t.configMap[k]
            if not config then
                local path = "Configs.BT."..k
                config = include(path)
                config.nodeDic = {}
                for _, node in pairs(config.nodeList) do
                    config.nodeDic[node.id] = node
                end
            end

            rawset(t, k, config)
            return config
        end
    }
)

ConfigLoad.GetNodePath = function(name)
    local path = BehaviorTreeInfo.NodeConfigs[name]
    if not path then
        path = BTCustomConfig.NodeConfigs[name]
    end

    return path
end

ConfigLoad.NodeConfigs = setmetatable(
    { },
    {
        __index = function(t, k)
            local path = ConfigLoad.GetNodePath(k)
            local v = require(path)
            rawset(t, k, v)
            return v
        end
    }
)

return ConfigLoad