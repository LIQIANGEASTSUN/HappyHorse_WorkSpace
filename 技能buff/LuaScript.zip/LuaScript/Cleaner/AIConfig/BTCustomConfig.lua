---@class BTCustomConfig
local BTCustomConfig = {}

BTCustomConfig.NodeConfigs = {
    ["PetHLActionHook"] = "Cleaner.AIConfig.PetHL.PetHLActionHook",
    ["PetHLActionHookToIdle"] = "Cleaner.AIConfig.PetHL.PetHLActionHookToIdle",
    ["PetHLActionIdle"] = "Cleaner.AIConfig.PetHL.PetHLActionIdle",
    ["PetHLActionPatrol"] = "Cleaner.AIConfig.PetHL.PetHLActionPatrol",
    ["PetHLActionToHook"] = "Cleaner.AIConfig.PetHL.PetHLActionToHook",

    ["PetHLActionGoToNest"] = "Cleaner.AIConfig.PetHL.PetHLActionGoToNest",
    ["PetHLActionNestIdle"] = "Cleaner.AIConfig.PetHL.PetHLActionNestIdle",
    ["PetHLActionNestWander"] = "Cleaner.AIConfig.PetHL.PetHLActionNestWander",
    ["PetHLConditionNestBuilt"] = "Cleaner.AIConfig.PetHL.PetHLConditionNestBuilt",
    --- 探索岛宠物
    ["PetActionAttack"] = "Cleaner.AIConfig.PetIsland.PetActionAttack",
    ["PetActionDeath"] = "Cleaner.AIConfig.PetIsland.PetActionDeath",
    ["PetActionFollowPlayer"] = "Cleaner.AIConfig.PetIsland.PetActionFollowPlayer",
    ["PetActionIdle"] = "Cleaner.AIConfig.PetIsland.PetActionIdle",
    ["PetActionPursuit"] = "Cleaner.AIConfig.PetIsland.PetActionPursuit",
    --- 探索岛怪物
    ["MonsterActionAttack"] = "Cleaner.AIConfig.MonsterIsland.MonsterActionAttack",
    ["MonsterActionDeath"] = "Cleaner.AIConfig.MonsterIsland.MonsterActionDeath",
    ["MonsterActionIdle"] = "Cleaner.AIConfig.MonsterIsland.MonsterActionIdle",
    ["MonsterActionPatrol"] = "Cleaner.AIConfig.MonsterIsland.MonsterActionPatrol",
    ["MonsterActionPursuit"] = "Cleaner.AIConfig.MonsterIsland.MonsterActionPursuit",
    ["MonsterConditionIdle"] = "Cleaner.AIConfig.MonsterIsland.MonsterConditionIdle",

    --- 技能
    ["SkillActionPhaseInitial"] = "Cleaner.Fight.Skill.SkillAction.SkillActionPhaseInitial",
    ["SkillActionPhaseStandby"] = "Cleaner.Fight.Skill.SkillAction.SkillActionPhaseStandby",
    ["SkillActionPhaseFire"] = "Cleaner.Fight.Skill.SkillAction.SkillActionPhaseFire",
    ["SkillActionPhaseEnd"] = "Cleaner.Fight.Skill.SkillAction.SkillActionPhaseEnd",
}

return BTCustomConfig