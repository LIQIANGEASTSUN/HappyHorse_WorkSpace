---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type BTConstant
local BTConstant = require "Cleaner.AIConfig.BTConstant"

---@type NodeAction
local NodeAction = require "Cleaner.BehaviorTree.Node.Leaf.NodeAction"

-- 家园宠物行为：移动到挂机点
---@class PetHLActionToHook:NodeAction
local PetHLActionToHook = class(NodeAction, "PetHLActionToHook")

function PetHLActionToHook:ctor()

end

function PetHLActionToHook:OnEnter()
    NodeAction.OnEnter(self)
    --console.error("PetHLActionToHook:OnEnter:")
    ---@type PetEntity
    self.entity = self.owner
    ---@type BehaviorTreeEntity
    self.behaviorTree = self.owner:BehaviorTreeEntity()

    self.owner:PlayAnimation(EntityAnimationName.run)
    self:ResetDestination()
end

function PetHLActionToHook:DoAction()
    local arrive = self:Move()
    if arrive then
        self.behaviorTree:SetBoolParameter(BTConstant.InHookPlace, true)
        return BehaviorTreeInfo.ResultType.Success
    end

    return BehaviorTreeInfo.ResultType.Running
end

function PetHLActionToHook:OnExit()
    NodeAction.OnExit(self)
end

function PetHLActionToHook:ResetDestination()
    local resultPos = self:GetHookMount()
    self.entity.unitMove:ChangeDestination(resultPos)
    local findPath = self.entity.unitMove:FindPath()

    local entityPos = self.entity:GetPosition()
    local distance = Vector3.Distance(entityPos, resultPos)
    if distance >= 10 or not findPath then
        local hookCenter = self:GetHookCenter()
        self.entity:SetPosition(hookCenter)
        self.behaviorTree:SetBoolParameter(BTConstant.InHookPlace, true)
    end
end

function PetHLActionToHook:Move()
    local arrive = self.entity.unitMove:OnTick()
    return arrive
end

return PetHLActionToHook