---@type BTConstant
local BTConstant = require "Cleaner.AIConfig.BTConstant"
---@type PetHLStateInfo
local PetHLStateInfo = require "Cleaner.AIConfig.PetHL.PetHLStateInfo"

---@class PetHLNestTool
---@field entity PetHLEntity
---@field posNestCenter Vector3 栖息地中心点
local PetHLNestTool = class(nil, "PetHLNestTool")

---@param entity PetHLEntity
function PetHLNestTool:ctor(entity)
    self.entity = entity
    self.behaviorTree = entity:BehaviorTreeEntity()
    local agent = self:FindPetNestAgent()
    self.agent = agent
    if not agent then
        return
    end
    self.posRandom = Vector3.zero
    self.rotRandom = Vector3.right
    self:SetNestCenter(self:CalcNestCenter())
    self:SetWanderRadius(self:CalcNestPatrolRadius())
    self:PetGoToNest(agent:GetId())
    self:RegisterEvent()
end

function PetHLNestTool:SetNestCenter(posNestCenter)
    self.posNestCenter = posNestCenter
end
function PetHLNestTool:GetNestCenter()
    return self.posNestCenter or Vector3.zero
end

function PetHLNestTool:SetWanderRadius(wanderRadius)
    self.wanderRadius = wanderRadius
end
function PetHLNestTool:GetWanderRadius()
    return self.wanderRadius or 1
end

function PetHLNestTool:FindPetNestAgent()
    ---@type PetHLEntityData
    local data = self.entity.data
    local sn = data:GetHabitatSn()
    local agent = App.scene.objectManager:GetAgentByTemplateId(sn)
    return agent
end
function PetHLNestTool:GetPetNestAgent()
    return self.agent
end

---@return Vector3, Vector3 左下角，右上角；世界坐标
function PetHLNestTool:GetNestCorner()
    local minX, minZ = self.agent:GetMin()
    local sizeX, sizeZ = self.agent:GetSize()
    local minPos = App.scene.mapManager:ToWorld(minX, minZ)
    local maxPos = App.scene.mapManager:ToWorld(minX + sizeX - 1, minZ + sizeZ - 1)
    return minPos, maxPos
end
---计算栖息地中心点
---@param agent BaseAgent
function PetHLNestTool:CalcNestCenter()
    local minPos, maxPos = self:GetNestCorner()
    local center = (minPos + maxPos) * 0.5
    return center
end
function PetHLNestTool:CalcNestPatrolRadius()
    local minPos, maxPos = self:GetNestCorner()
    local patrolRadius = ((maxPos.x - minPos.x) * 0.5) - 0.35
    return patrolRadius
end
function PetHLNestTool:CalcRandomPos() --随机位置
    local minPos, maxPos = self:GetNestCorner()
    self.posRandom.x = Random.Range(minPos.x, maxPos.x)
    self.posRandom.z = Random.Range(minPos.z, maxPos.z)
    return self.posRandom
end
function PetHLNestTool:CalcRandomRot() --随机方向
    self.rotRandom = Quaternion.AngleAxis(Random.Range(0, 360), Vector3.up) * Vector3.right
    return self.rotRandom
end

---@param agentId string
function PetHLNestTool:PetGoToNest(agentId)
    if self.agent then
        if agentId ~= self.agent:GetId() then
            return
        end
        local pos = self:CalcRandomPos()
        self.entity:SetPosition(pos)
        local rot = self:CalcRandomRot()
        self.entity:SetForward(rot)
        self.behaviorTree:SetBoolParameter(BTConstant.NestIsExist, true)
        self.behaviorTree:SetIntParameter(BTConstant.DoFunction, PetHLStateInfo.StateType.NestIdle)
    end
end

---@return boolean 栖息地是否存在
function PetHLNestTool:IsNestExist()
    if self.agent then
        return true
    end
end
---@return boolean 是否已建造栖息地
function PetHLNestTool:HasNestBuilt()
    if self.agent then
        local built = self.agent:GetLevel() > 0
        return built
    end
end

function PetHLNestTool:RegisterEvent()
    MessageDispatcher:AddMessageListener(MessageType.PetGoToNest, self.PetGoToNest, self)
end
function PetHLNestTool:UnRegisterEvent()
    MessageDispatcher:RemoveMessageListener(MessageType.PetGoToNest, self.PetGoToNest, self)
end
function PetHLNestTool:Release()
    self:UnRegisterEvent()
end

return PetHLNestTool