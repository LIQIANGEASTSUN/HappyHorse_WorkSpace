--[[
    家园宠物行为：瞬移进巢穴
]]
---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"
---@type NodeAction
local NodeAction = require "Cleaner.BehaviorTree.Node.Leaf.NodeAction"
---@type BTConstant
local BTConstant = require "Cleaner.AIConfig.BTConstant"
---@type PetHLStateInfo
local PetHLStateInfo = require "Cleaner.AIConfig.PetHL.PetHLStateInfo"

---@class PetHLActionGoToNest:NodeAction
---@field owner PetHLEntity
local PetHLActionGoToNest = class(NodeAction, "PetHLActionGoToNest")

function PetHLActionGoToNest:ctor()
end

function PetHLActionGoToNest:OnEnter()
    NodeAction.OnEnter(self)
    self.behaviorTree = self.owner:BehaviorTreeEntity()
end

function PetHLActionGoToNest:DoAction()
    self:Teleport()
    self.behaviorTree:SetBoolParameter(BTConstant.InNest, true)
    return BehaviorTreeInfo.ResultType.Success
end

function PetHLActionGoToNest:OnExit()
    NodeAction.OnExit(self)
    self.behaviorTree:SetIntParameter(BTConstant.DoFunction, PetHLStateInfo.StateType.NestIdle)
end

function PetHLActionGoToNest:Teleport()
    local tool = self.owner.petHLNestTool
    if not tool then
        return
    end
    local pos = tool:GetNestCenter()
    self.owner:SetPosition(pos)
end

return PetHLActionGoToNest