---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type BTConstant
local BTConstant = require "Cleaner.AIConfig.BTConstant"

---@type PetHLStateInfo
local PetHLStateInfo = require "Cleaner.AIConfig.PetHL.PetHLStateInfo"

---@type NodeAction
local NodeAction = require "Cleaner.BehaviorTree.Node.Leaf.NodeAction"

-- 家园宠物行为：溜达
---@class PetHLActionPatrol:NodeAction
local PetHLActionPatrol = class(NodeAction, "PetHLActionPatrol")

function PetHLActionPatrol:ctor()

end

function PetHLActionPatrol:OnEnter()
    NodeAction.OnEnter(self)
    --console.error("PetHLActionPatrol:OnEnter:")
    ---@type PetEntity
    self.entity = self.owner
    ---@type BehaviorTreeEntity
    self.behaviorTree = self.owner:BehaviorTreeEntity()
    self.patrolTime = Time.realtimeSinceStartup +  Random.Range(10, 20)

    self.owner:PlayAnimation(EntityAnimationName.run)
    self:ResetDestination()
end

function PetHLActionPatrol:DoAction()
    --console.error("PetHLActionPatrol:DoAction")
    if Time.realtimeSinceStartup <= self.patrolTime then
        local arrive = self:Move()
        if arrive then
            self:ResetDestination()
        end
        return BehaviorTreeInfo.ResultType.Running
    end

    self.behaviorTree:SetIntParameter(BTConstant.DoFunction, PetHLStateInfo.StateType.Idle)
    return BehaviorTreeInfo.ResultType.Success
end

function PetHLActionPatrol:OnExit()
    NodeAction.OnExit(self)
end

function PetHLActionPatrol:ResetDestination()
    local pos = self.entity:GetPosition()
    local result, position =  self.entity.unitMove:RandomPosition(pos)
    if result then
        self.entity.unitMove:ChangeDestination(position)
    end
end

function PetHLActionPatrol:Move()
    self.patrolTime = self.patrolTime - Time.deltaTime
    local arrive = self.entity.unitMove:OnTick()
    return arrive
end

return PetHLActionPatrol