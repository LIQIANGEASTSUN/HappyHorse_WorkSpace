--[[
    栖息地中宠物idle
]]
---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"
---@type NodeAction
local NodeAction = require "Cleaner.BehaviorTree.Node.Leaf.NodeAction"
---@type BTConstant
local BTConstant = require "Cleaner.AIConfig.BTConstant"
---@type PetHLStateInfo
local PetHLStateInfo = require "Cleaner.AIConfig.PetHL.PetHLStateInfo"

---@class PetHLActionNestIdle:NodeAction
---@field owner PetHLEntity
---@field timeIdle number Idle时长（s）
local PetHLActionNestIdle = class(NodeAction, "PetHLActionNestIdle")

function PetHLActionNestIdle:ctor()
end

function PetHLActionNestIdle:OnEnter()
    NodeAction.OnEnter(self)
    self.behaviorTree = self.owner:BehaviorTreeEntity()
    self.owner:PlayAnimation(EntityAnimationName.idle)
    self.timeIdle = Time.realtimeSinceStartup + Random.Range(1, 10)
end

function PetHLActionNestIdle:DoAction()
    if Time.realtimeSinceStartup <= self.timeIdle then
        return BehaviorTreeInfo.ResultType.Running
    end
    self.behaviorTree:SetIntParameter(BTConstant.DoFunction, PetHLStateInfo.StateType.NestWander)
    return BehaviorTreeInfo.ResultType.Success
end

function PetHLActionNestIdle:OnExit()
    NodeAction.OnExit(self)
end

return PetHLActionNestIdle