---@class PetHLStateInfo
local PetHLStateInfo = { }

--- 己方怪物
PetHLStateInfo.StateType = {
    --- 休闲
    Idle = 1,
    --- 巡逻
    Patrol = 2,
    --- 去挂机建筑
    ToHook = 3,
    --- 挂机
    Hook = 4,
    --- 挂机到休闲
    HookToIdle = 5,
    NestIdle = 6, --栖息地Idle
    NestWander = 7, --栖息地漫游
}

return PetHLStateInfo