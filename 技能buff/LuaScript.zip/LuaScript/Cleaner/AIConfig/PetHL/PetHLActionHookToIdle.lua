---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type PetHLStateInfo
local PetHLStateInfo = require "Cleaner.AIConfig.PetHL.PetHLStateInfo"

---@type BTConstant
local BTConstant = require "Cleaner.AIConfig.BTConstant"

---@type NodeAction
local NodeAction = require "Cleaner.BehaviorTree.Node.Leaf.NodeAction"

-- 家园宠物行为：挂机到休闲
---@class PetHLActionHookToIdle:NodeAction
local PetHLActionHookToIdle = class(NodeAction, "PetHLActionHookToIdle")

function PetHLActionHookToIdle:ctor()

end

function PetHLActionHookToIdle:OnEnter()
    NodeAction.OnEnter(self)
    --console.error("PetHLActionHookToIdle:OnEnter:")
    ---@type PetEntity
    self.entity = self.owner
    ---@type BehaviorTreeEntity
    self.behaviorTree = self.entity:BehaviorTreeEntity()

    self.behaviorTree:PlayAnimation(EntityAnimationName.run)
    local moveType = AppServices.UnitMoveManager.MoveType.Freedom
    self.entity:ChangeMoveTool(moveType)
    self.entity.unitMove:SetSpeed(1)
    self:ResetDestination()
end

function PetHLActionHookToIdle:DoAction()
    local arrive = self:Move()
    if arrive then
        self.behaviorTree:SetBoolParameter(BTConstant.InHookPlace, false)
        self.behaviorTree:SetIntParameter(BTConstant.DoFunction, PetHLStateInfo.StateType.Idle)
        return BehaviorTreeInfo.ResultType.Success
    end

    return BehaviorTreeInfo.ResultType.Running
end

function PetHLActionHookToIdle:OnExit()
    NodeAction.OnExit(self)
    local moveType = AppServices.UnitMoveManager.MoveType.FindPathAlgorithm
    self.entity:ChangeMoveTool(moveType)
end

function PetHLActionHookToIdle:ResetDestination()
    local resultPos = self.entity.petHLHookTool:GetHookMount()
    self.entity.unitMove:ChangeDestination(resultPos)
end

function PetHLActionHookToIdle:Move()
    local arrive = self.entity.unitMove:OnTick()
    return arrive
end

return PetHLActionHookToIdle