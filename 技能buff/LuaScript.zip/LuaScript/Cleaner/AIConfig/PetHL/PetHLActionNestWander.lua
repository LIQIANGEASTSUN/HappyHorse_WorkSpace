--[[
    栖息地中宠物漫游
]]
---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"
---@type NodeAction
local NodeAction = require "Cleaner.BehaviorTree.Node.Leaf.NodeAction"
---@type BTConstant
local BTConstant = require "Cleaner.AIConfig.BTConstant"
---@type PetHLStateInfo
local PetHLStateInfo = require "Cleaner.AIConfig.PetHL.PetHLStateInfo"

---@class PetHLActionNestWander:NodeAction
---@field owner PetHLEntity
local PetHLActionNestWander = class(NodeAction, "PetHLActionNestWander")

function PetHLActionNestWander:ctor()
end

function PetHLActionNestWander:OnEnter()
    NodeAction.OnEnter(self)
    self.behaviorTree = self.owner:BehaviorTreeEntity()
    self.owner:PlayAnimation(EntityAnimationName.run)
    self.owner:ChangeMoveTool(AppServices.UnitMoveManager.MoveType.Freedom) --切换到自由移动
    self.owner.unitMove:SetSpeed(1) --设置速度
    self:ResetDestination()
end

function PetHLActionNestWander:DoAction()
    local arrive = self:Move()
    if arrive then
        self.behaviorTree:SetIntParameter(BTConstant.DoFunction, PetHLStateInfo.StateType.NestIdle)
        return BehaviorTreeInfo.ResultType.Success
    end
    return BehaviorTreeInfo.ResultType.Running
end

function PetHLActionNestWander:OnExit()
    NodeAction.OnExit(self)
    self.owner:ChangeMoveTool(AppServices.UnitMoveManager.MoveType.FindPathAlgorithm) --切换到寻路
end

--设置漫游目的地
function PetHLActionNestWander:ResetDestination()
    local tool = self.owner.petHLNestTool
    if not tool then
        return
    end
    local center = tool:GetNestCenter()
    local radius = tool:GetWanderRadius()
    self.owner.unitMove:SetPatrolRadius(radius)
    local result, position = self.owner.unitMove:RandomPosition(center)
    if result then
        self.owner.unitMove:ChangeDestination(position)
    end
end
--移动
function PetHLActionNestWander:Move()
    local arrive = self.owner.unitMove:OnTick()
    return arrive
end

return PetHLActionNestWander