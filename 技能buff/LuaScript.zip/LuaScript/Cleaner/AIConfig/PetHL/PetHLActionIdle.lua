---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type BTConstant
local BTConstant = require "Cleaner.AIConfig.BTConstant"

---@type PetHLStateInfo
local PetHLStateInfo = require "Cleaner.AIConfig.PetHL.PetHLStateInfo"

---@type NodeAction
local NodeAction = require "Cleaner.BehaviorTree.Node.Leaf.NodeAction"

-- 家园宠物行为：休闲
---@class PetHLActionIdle:NodeAction
local PetHLActionIdle = class(NodeAction, "PetHLActionIdle")

function PetHLActionIdle:ctor()

end

function PetHLActionIdle:OnEnter()
    NodeAction.OnEnter(self)
    --console.error("PetHLActionIdle:OnEnter:")
    ---@type BehaviorTreeEntity
    self.behaviorTree = self.owner:BehaviorTreeEntity()

    self.owner:PlayAnimation(EntityAnimationName.idle)
    self.idleTime = Time.realtimeSinceStartup + Random.Range(3, 5)
end

function PetHLActionIdle:DoAction()
    if Time.realtimeSinceStartup <= self.idleTime then
        return BehaviorTreeInfo.ResultType.Running
    end

    self.behaviorTree:SetIntParameter(BTConstant.DoFunction, PetHLStateInfo.StateType.Patrol)
    return BehaviorTreeInfo.ResultType.Success
end

function PetHLActionIdle:OnExit()
    NodeAction.OnExit(self)
end

return PetHLActionIdle