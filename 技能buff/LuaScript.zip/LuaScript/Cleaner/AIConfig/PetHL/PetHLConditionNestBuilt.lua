---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"
---@type NodeCondition
local NodeCondition = require "Cleaner.BehaviorTree.Node.Leaf.NodeCondition"

---@class PetHLConditionNestBuilt:NodeCondition
---@field entity PetHLEntity
local PetHLConditionNestBuilt = class(NodeCondition, "PetHLConditionNestBuilt")

function PetHLConditionNestBuilt:ctor()
end

function PetHLConditionNestBuilt:OnEnter()
    NodeCondition.OnEnter(self)
    self.entity = self.owner
end

function PetHLConditionNestBuilt:Condition()
    NodeCondition.Condition(self)
    if self:HasNestBuilt() then
        return BehaviorTreeInfo.ResultType.Success
    end
    return BehaviorTreeInfo.ResultType.Fail
end

function PetHLConditionNestBuilt:OnExit()
    NodeCondition.OnExit(self)
end

function PetHLConditionNestBuilt:HasNestBuilt()
    local tool = self.entity.petHLNestTool
    if not tool then
        return
    end
    local boo = tool:HasNestBuilt()
    return boo
end

return PetHLConditionNestBuilt