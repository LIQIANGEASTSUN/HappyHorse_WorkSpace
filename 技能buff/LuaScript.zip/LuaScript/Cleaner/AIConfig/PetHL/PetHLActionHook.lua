---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type NodeAction
local NodeAction = require "Cleaner.BehaviorTree.Node.Leaf.NodeAction"

-- 家园宠物行为：挂机
---@class PetHLActionHook:NodeAction
local PetHLActionHook = class(NodeAction, "PetHLActionHook")

function PetHLActionHook:ctor()

end

function PetHLActionHook:OnEnter()
    NodeAction.OnEnter(self)
    --console.error("PetHLActionHook:OnEnter:")
    ---@type PetHLEntity
    self.entity = self.owner
    self.owner:PlayAnimation(EntityAnimationName.run)
    self.entity:ChangeMoveTool(AppServices.UnitMoveManager.MoveType.Freedom)
    self.entity.unitMove:SetSpeed(1)
    self:ResetDestination()

    local agent = self.entity.petHLHookTool:GetHookAgent()
    if agent then
        local sn = agent:GetTemplateId()
        MessageDispatcher:SendMessage(MessageType.PetHLArriveingHook, sn)
    end
end

function PetHLActionHook:DoAction()
    local arrive = self:Move()
    if arrive then
        self:ResetDestination()
    end
    return BehaviorTreeInfo.ResultType.Running
end

function PetHLActionHook:OnExit()
    NodeAction.OnExit(self)
    local moveType = AppServices.UnitMoveManager.MoveType.FindPathAlgorithm
    self.entity:ChangeMoveTool(moveType)
end

function PetHLActionHook:ResetDestination()
    local center = self.entity.petHLHookTool:GetHookCenter()
    local patrolRadius = self.entity:GetPatrolRadius()

    self.entity.unitMove:SetPatrolRadius(patrolRadius)
    local result, position = self.entity.unitMove:RandomPosition(center)
    if result then
        self.entity.unitMove:ChangeDestination(position)
    end
end

function PetHLActionHook:Move()
    local arrive = self.entity.unitMove:OnTick()
    return arrive
end

return PetHLActionHook