---@type SudokuScrewCross
local SudokuScrewCross = require "Cleaner.PathFinding.Search.SudokuScrewCross"

---@type PetHLStateInfo
local PetHLStateInfo = require "Cleaner.AIConfig.PetHL.PetHLStateInfo"

---@type BTConstant
local BTConstant = require "Cleaner.AIConfig.BTConstant"

---@PetHLHookTool
local PetHLHookTool = class(nil, "PetHLHookTool")

function PetHLHookTool:ctor(entity)
    self.entity = entity
    ---@type BehaviorTreeEntity
    self.behaviorTree = entity:BehaviorTreeEntity()

    self.hookPosition = Vector3(0, 0, 0)
    self.hookCenter = Vector3(0, 0, 0)

    self:ReceiveHookMonster()
    self:RegisterEvent()
end

function PetHLHookTool:SetHookMount(position)
    self.hookPosition = position
end

function PetHLHookTool:GetHookMount()
    return self.hookPosition
end

function PetHLHookTool:SetHookCenter(hookCenter)
    self.hookCenter = hookCenter
end

function PetHLHookTool:GetHookCenter()
    return self.hookCenter
end

function PetHLHookTool:GetHookAgent()
    local petType = self.entity.data:GetType()
    local agent = App.scene.objectManager:GetPetBindOnHookBuildByPetTyp(petType)
    if agent then
        local position = self:HookAgentMount(agent)
        self:SetHookMount(position)

        local center, patrolRadius = self:HookCenter(agent)
        self:SetHookCenter(center)
        self.entity.data:SetPatrolRadius(patrolRadius)
    end
    return agent
end

-- 挂机建筑锚点：宠物挂机先走到这个位置，宠物脱离挂机也需要先走到这个位置
function PetHLHookTool:HookAgentMount(agent)
    if not agent then
        return self:GetPosition()
    end

    local minX, minZ = agent:GetMin()
    local map = App.scene.mapManager
    local position = map:ToWorld(minX, minZ)

    local entityPos = self:GetPosition()
    local resultPos = entityPos
     local originPos = Vector2(position.x, position.z)
     SudokuScrewCross:Search(originPos, 0, 5, function(position)
         local enablePass = AppServices.IslandPathManager:EnablePass(position.x, position.y)
         if enablePass then
            resultPos = Vector3(position.x, 0, position.y)
             return false
         end
         return true
     end)

    return resultPos
end

function PetHLHookTool:HookCenter(agent)
    if not agent then
        return self:GetPosition(), 1
    end
    local minX, minZ = agent:GetMin()
    local sizeX, sizeZ = agent:GetSize()

    local map = App.scene.mapManager
    local minPos = map:ToWorld(minX, minZ)
    local maxPos = map:ToWorld(minX + sizeX - 1, minZ + sizeZ - 1)

    local center = (minPos + maxPos) * 0.5
    local patrolRadius = ((maxPos.x - minPos.x) * 0.5) - 0.35
    return center, patrolRadius
end

function PetHLHookTool:ReceiveHookMonster()
    local agent = self:GetHookAgent()
    local inHooking = (agent ~= nil)
    self.behaviorTree:SetBoolParameter(BTConstant.InHooking, inHooking)

    local doFunction = (agent ~= nil) and -1 or PetHLStateInfo.StateType.Idle
    self.behaviorTree:SetIntParameter(BTConstant.DoFunction, doFunction)
end

function PetHLHookTool:ReceiveHookFinish()
    self:ReceiveHookMonster()
end

function PetHLHookTool:HookMoveing(agentId)
    local agent = self:GetHookAgent()
    if not agent or (agentId ~= agent:GetId()) then
        return
    end

    local result, value = self.behaviorTree:GetBoolParameterValue(BTConstant.InHookPlace)
    local minX, minZ = agent:GetMin()
    local sizeX, sizeZ = agent:GetSize()

    local map = App.scene.mapManager
    local minPos = map:ToWorld(minX, minZ)
    local maxPos = map:ToWorld(minX + sizeX, minZ + sizeZ)

    local position = self:GetPosition()
    local greatherMin = (position.x >= minPos.x) and (position.z >= minPos.z)
    local lessMax = (position.x <= maxPos.x) and (position.z <= maxPos.z)
    local inHookPlace = greatherMin and lessMax

    if result and inHookPlace ~= value then
        self.behaviorTree:SetBoolParameter(BTConstant.InHookPlace, inHookPlace)
    end
end

function PetHLHookTool:RegisterEvent()
    MessageDispatcher:AddMessageListener(MessageType.BUILDONHOOKMESSAGE, self.ReceiveHookMonster, self)
    MessageDispatcher:AddMessageListener(MessageType.BUILDONHOOKFINISHMESSAGE, self.ReceiveHookFinish, self)
    MessageDispatcher:AddMessageListener(MessageType.BUILDONHOOKMOVEINGMESSAGE, self.HookMoveing, self)
end

function PetHLHookTool:UnRegisterEvent()
    MessageDispatcher:RemoveMessageListener(MessageType.BUILDONHOOKMESSAGE, self.ReceiveHookMonster, self)
    MessageDispatcher:RemoveMessageListener(MessageType.BUILDONHOOKFINISHMESSAGE, self.ReceiveHookFinish, self)
    MessageDispatcher:RemoveMessageListener(MessageType.BUILDONHOOKMOVEINGMESSAGE, self.HookMoveing, self)
end

function PetHLHookTool:Release()
    self:UnRegisterEvent()
end

return PetHLHookTool