---@type PetFollowPlayer
local PetFollowPlayer = require "Cleaner.Entity.Pet.PetFollowPlayer"

---@type BTConstant
local BTConstant = require "Cleaner.AIConfig.BTConstant"

---@class PetActionTool
local PetActionTool = class(nil, "PetActionTool")

function PetActionTool:ctor(owner)
    ---@type PetEntity
    self.entity = owner
end

function PetActionTool:Init()
    ---@type FightUnitEntity
    local fightUnit = self.entity:GetUnit(UnitType.FightUnit)
    ---@type FightSearchOpposed
    self.searchOpposed = fightUnit:SearchOpposed()

    ---@type BehaviorTreeEntity
    self.behaviorTree = self.entity:BehaviorTreeEntity()
    self.behaviorTree:SetFloatParameter(BTConstant.DistancePlayer, 100)
    self.behaviorTree:SetBoolParameter(BTConstant.HasTarget, false)
    self.behaviorTree:SetBoolParameter(BTConstant.TargetInAttackDistance, false)
end

function PetActionTool:CalculateFollowPos()
    local result, destination = PetFollowPlayer:GetFollowPos(self.entity)
    if not result then
        return result, destination
    end

    local playerPos = PetFollowPlayer:GetPlayerPos()
    local entityPos = self.entity:GetPosition()
    local distancePlayer = Vector3.Distance(playerPos, entityPos)
    self.behaviorTree:SetFloatParameter(BTConstant.DistancePlayer, distancePlayer)
    --console.error("DistancePlayer:"..distancePlayer)

    return result, destination
end

function PetActionTool:ResetFollowPos()
    local result, destination = PetFollowPlayer:GetFollowPos(self.entity)
    if result then
        self.entity.unitMove:ChangeDestination(destination)
    end
end

function PetActionTool:SearchAttackTarget()
    -- 搜索到能攻击的对象
    ---@type TargetSearchResult
    local result = self.searchOpposed:SearchWithPlayer()

    local hasTarget = result:IsTargetValid()
    self.behaviorTree:SetBoolParameter(BTConstant.HasTarget, hasTarget)

    local targetInAttackDistance = result:TargetInAttackDistance()
    self.behaviorTree:SetBoolParameter(BTConstant.TargetInAttackDistance, targetInAttackDistance)

    return result
end

return PetActionTool