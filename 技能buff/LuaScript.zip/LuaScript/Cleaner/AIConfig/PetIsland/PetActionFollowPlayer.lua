---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type BTConstant
local BTConstant = require "Cleaner.AIConfig.BTConstant"

---@type NodeAction
local NodeAction = require "Cleaner.BehaviorTree.Node.Leaf.NodeAction"

-- 探索岛宠物行为：跟随Player
---@class PetActionFollowPlayer:NodeAction
local PetActionFollowPlayer = class(NodeAction, "PetActionFollowPlayer")

function PetActionFollowPlayer:ctor()
    self.refresTime = 0
    self.REFRESH_INTERVAL = 1
end

function PetActionFollowPlayer:SetOwner(owner)
    NodeAction.SetOwner(self, owner)
    ---@type PetEntity
    self.entity = self.owner
    ---@type FightUnitBase
    self.fightUnit = self.entity:GetUnit(UnitType.FightUnit)
    ---@type PetActionTool
    self.petActionTool = self.entity.petActionTool
end

function PetActionFollowPlayer:OnEnter()
    NodeAction.OnEnter(self)
    --console.error("PetActionFollowPlayer:OnEnter:"..Time.realtimeSinceStartup)
    ---@type BehaviorTreeEntity
    self.behaviorTree = self.owner:BehaviorTreeEntity()

    self.entity:PlayAnimation(EntityAnimationName.run)
    self.petActionTool:ResetFollowPos()
end

function PetActionFollowPlayer:DoAction()
    local arrive = self.entity.unitMove:OnTick()
    self:Refresh(arrive)
    return BehaviorTreeInfo.ResultType.Running
end

function PetActionFollowPlayer:OnExit()
    NodeAction.OnExit(self)
    self.entity.unitMove:Stop()
    --console.error("PetActionFollowPlayer:OnExit:"..Time.realtimeSinceStartup)
end

function PetActionFollowPlayer:Refresh(force)
    if not force and Time.realtimeSinceStartup < self.refresTime then
        return
    end

    self.refresTime = Time.realtimeSinceStartup + self.REFRESH_INTERVAL
    self.petActionTool:CalculateFollowPos()
    self.petActionTool:SearchAttackTarget()

    local _, distancePlayer = self.behaviorTree:GetFloatParameterValue(BTConstant.DistancePlayer)
    if force or distancePlayer > 3 then
        self.petActionTool:ResetFollowPos()
    end
end

return PetActionFollowPlayer