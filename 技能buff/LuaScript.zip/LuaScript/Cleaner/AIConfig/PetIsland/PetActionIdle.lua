---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type NodeAction
local NodeAction = require "Cleaner.BehaviorTree.Node.Leaf.NodeAction"

-- 探索岛宠物行为：休闲
---@class PetActionIdle:NodeAction
local PetActionIdle = class(NodeAction, "PetActionIdle")

function PetActionIdle:ctor()
    self.refresTime = 0
    self.REFRESH_INTERVAL = 1
end

function PetActionIdle:SetOwner(owner)
    NodeAction.SetOwner(self, owner)
    ---@type PetEntity
    self.entity = self.owner
    ---@type FightUnitBase
    self.fightUnit = self.entity:GetUnit(UnitType.FightUnit)
    ---@type PetActionTool
    self.petActionTool = self.entity.petActionTool
end

function PetActionIdle:OnEnter()
    NodeAction.OnEnter(self)
    --console.error("PetActionIdle:OnEnter:"..Time.realtimeSinceStartup)
    self.entity:PlayAnimation(EntityAnimationName.idle)
end

function PetActionIdle:DoAction()
    self:Refresh()
    return BehaviorTreeInfo.ResultType.Running
end

function PetActionIdle:OnExit()
    NodeAction.OnExit(self)
    --console.error("PetActionIdle:OnExit:"..Time.realtimeSinceStartup)
end

function PetActionIdle:Refresh()
    if Time.realtimeSinceStartup < self.refresTime then
        return
    end

    self.refresTime = Time.realtimeSinceStartup + self.REFRESH_INTERVAL
    self.petActionTool:CalculateFollowPos()
    self.petActionTool:SearchAttackTarget()
end

return PetActionIdle