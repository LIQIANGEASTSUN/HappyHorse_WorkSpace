---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type NodeAction
local NodeAction = require "Cleaner.BehaviorTree.Node.Leaf.NodeAction"

-- 探索岛宠物行为：死亡
---@class PetActionDeath:NodeAction
local PetActionDeath = class(NodeAction, "PetActionDeath")

function PetActionDeath:ctor()

end

function PetActionDeath:SetOwner(owner)
    NodeAction.SetOwner(self, owner)
    ---@type PetEntity
    self.entity = self.owner
    ---@type FightUnitBase
    self.fightUnit = self.entity:GetUnit(UnitType.FightUnit)
end

function PetActionDeath:OnEnter()
    NodeAction.OnEnter(self)
    --console.error("PetActionDeath:OnEnter:"..Time.realtimeSinceStartup)
    self.isHide = false
    self.hideTime = Time.realtimeSinceStartup + 2
    MessageDispatcher:SendMessage(MessageType.EntityDeath, self.entity.entityId, self.entity:GetSn())

    self.fightUnit:NotifyHp(0, TipsType.UnitPetHpTips, false)

    local position = self.entity:GetAnchorPosition()
    local config = self.entity.data:GetMeta()
    self.deathEffectEntity = AppServices.EffectManager:Play(config.deadEffect, position)

    self.entity:SetDeath()
    self.entity:PlayAnimation(EntityAnimationName.die)
end

function PetActionDeath:DoAction()
    if Time.realtimeSinceStartup >= self.hideTime then
        self:DeathHide()
    end

    return BehaviorTreeInfo.ResultType.Running
end

function PetActionDeath:OnExit()
    NodeAction.OnExit(self)
    --console.error("PetActionDeath:OnExit:"..Time.realtimeSinceStartup)
    self:RemoveEffect()
end

function PetActionDeath:DeathHide()
    if self.isHide then
        return
    end
    self.isHide = true
    self.entity:SetVisible(false)
    self:RemoveEffect()
    local fightUnit = self.entity:GetUnit(UnitType.FightUnit)
    local instanceId = fightUnit:GetInstanceId()
    AppServices.UnitTipsManager:RemoveTipsAll(instanceId)
end

function PetActionDeath:RemoveEffect()
    if self.deathEffectEntity then
        local instanceId = self.deathEffectEntity:GetInstanceId()
        AppServices.EffectManager:RemoveEffect(instanceId)
        self.deathEffectEntity = nil
    end
end

return PetActionDeath