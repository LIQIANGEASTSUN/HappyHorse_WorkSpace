---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type NodeAction
local NodeAction = require "Cleaner.BehaviorTree.Node.Leaf.NodeAction"

-- 探索岛宠物行为：追踪
---@class PetActionPursuit:NodeAction
local PetActionPursuit = class(NodeAction, "PetActionPursuit")

function PetActionPursuit:ctor()
    self.refresTime = 0
    self.REFRESH_INTERVAL = 1
end

function PetActionPursuit:SetOwner(owner)
    NodeAction.SetOwner(self, owner)
    ---@type PetEntity
    self.entity = self.owner
    ---@type FightUnitBase
    self.fightUnit = self.entity:GetUnit(UnitType.FightUnit)
    ---@type PetActionTool
    self.petActionTool = self.entity.petActionTool
end

function PetActionPursuit:OnEnter()
    NodeAction.OnEnter(self)
    --console.error("PetActionPursuit:OnEnter:"..Time.realtimeSinceStartup)
    self.entity:PlayAnimation(EntityAnimationName.run)
    self:Refresh(true)
end

function PetActionPursuit:DoAction()
    local arrive = self.entity.unitMove:OnTick()
    self:Refresh(arrive)
    return BehaviorTreeInfo.ResultType.Running
end

function PetActionPursuit:OnExit()
    NodeAction.OnExit(self)
    self.entity.unitMove:Stop()
    --console.error("PetActionPursuit:OnExit:"..Time.realtimeSinceStartup)
end

function PetActionPursuit:Refresh(force)
    if not force and  Time.realtimeSinceStartup < self.refresTime then
        return BehaviorTreeInfo.ResultType.Running
    end
    self.refresTime = Time.realtimeSinceStartup + self.REFRESH_INTERVAL

    self.petActionTool:CalculateFollowPos()
    ---@type TargetSearchResult
    local result = self.petActionTool:SearchAttackTarget()
    if not result:TargetInAttackDistance() then
        local destination =  result:NearestAttackPosition()
        self.entity.unitMove:ChangeDestination(destination)
    end
end

return PetActionPursuit