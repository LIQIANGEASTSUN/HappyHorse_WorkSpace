
---@class BTConstant
local BTConstant= {

    --- 功能/执行功能 Int
    DoFunction = "DoFunction",

    InHooking = "InHooking", --- 家园宠物/是否在挂机中 Bool
    InHookPlace = "InHookPlace", --- 家园宠物/在挂机建筑位置 Bool

    --region nest
    NestIsExist = "NestIsExist", --家园宠物/宠物栖息地是否存在 Bool
    NestHasBuild = "NestHasBuild", --- 家园宠物/栖息地是否已建好 Bool
    InNest = "InNest", --- 家园宠物/是否在栖息地中 Bool
    --endregion

    --- 宠物/与玩家距离 Float
    DistancePlayer = "DistancePlayer",

    --- 宠物/有攻击目标 Bool
    HasTarget = "HasTarget",

    --- 宠物/技能有效
    ValidSkill = "ValidSkill",

    --- 宠物/目标在攻击范围内
    TargetInAttackDistance = "TargetInAttackDistance",

    --- 宠物/血量
    PetHp = "PetHp",

    --- 宠物/路径有效
    ValidPath = "ValidPath",

    --- 技能/入口
    SkillEntry = "SkillEntry",

    --- 技能/初始阶段结束
    SkillInitFinish = "SkillInitFinish",

    --- 技能/待机阶段结束
    SkillStandbyFinish = "SkillStandbyFinish",

    --- 技能/释放阶段结束
    SkillFireFinish = "SkillFireFinish",

    --- 技能/收尾阶段结束
    SkillEndFinish = "SkillEndFinish",

    --- 技能/转换到状态
    SkillToState = "SkillToState",
}

return BTConstant