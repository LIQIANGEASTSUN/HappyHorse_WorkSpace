---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type NodeAction
local NodeAction = require "Cleaner.BehaviorTree.Node.Leaf.NodeAction"

-- 探索岛宠物行为：攻击
---@class MonsterActionAttack:NodeAction
local MonsterActionAttack = class(NodeAction, "MonsterActionAttack")

function MonsterActionAttack:ctor()
    self.refresTime = 0
    self.REFRESH_INTERVAL = 1
end

function MonsterActionAttack:SetOwner(owner)
    NodeAction.SetOwner(self, owner)
    ---@type MonsterEntity
    self.entity = self.owner
    ---@type FightUnitBase
    self.fightUnit = self.entity:GetUnit(UnitType.FightUnit)
    ---@type MonsterActionTool
    self.monsterActionTool = self.entity.monsterActionTool
end

function MonsterActionAttack:OnEnter()
    NodeAction.OnEnter(self)
    --console.error("MonsterActionAttack:OnEnter:")
    self.fightUnit:NotifyHp(0, TipsType.UnitMonsterHpTips, true)
end

function MonsterActionAttack:DoAction()
    local resultType = self:Refresh()
    return resultType
end

function MonsterActionAttack:OnExit()
    NodeAction.OnExit(self)
    --console.error("MonsterActionAttack:OnExit:")
    self.fightUnit:NotifyHp( 0, TipsType.UnitMonsterHpTips, false)
end

function MonsterActionAttack:Refresh()
    if Time.realtimeSinceStartup < self.refresTime then
        return BehaviorTreeInfo.ResultType.Running
    end
    self.refresTime = Time.realtimeSinceStartup + self.REFRESH_INTERVAL

    ---@type TargetSearchResult
    local result = self.monsterActionTool:SearchAttackTarget()
    if not result:IsTargetAndSkillValid() then
        return BehaviorTreeInfo.ResultType.Fail
    end

    if not result:TargetInAttackDistance() then
        return BehaviorTreeInfo.ResultType.Fail
    end

    -- 有攻击目标，且在攻击范围内，攻击
    local _, normalized = result:OffsetPosition()
    self.entity:SetForward(normalized)

    -- 释放技能 skill
    ---@type SkillController
    local skillController = self.fightUnit:SkillController()
    if skillController:EnableUse(result.skillId) then
        local targets = {result.other}
        skillController:Fire(result.skillId, targets)
    end

    return BehaviorTreeInfo.ResultType.Running
end

return MonsterActionAttack