---@type BTConstant
local BTConstant = require "Cleaner.AIConfig.BTConstant"

---@class MonsterActionTool
local MonsterActionTool = class(nil, "MonsterActionTool")

function MonsterActionTool:ctor(entity)
    ---@type MonsterEntity
    self.entity = entity
    local meta = self.entity.data.meta
    self.track = meta.track
end

function MonsterActionTool:Init()
    ---@type FightUnitEntity
    local fightUnit = self.entity:GetUnit(UnitType.FightUnit)
    ---@type FightSearchOpposed
    self.searchOpposed = fightUnit:SearchOpposed()

    ---@type BehaviorTreeEntity
    self.behaviorTree = self.entity:BehaviorTreeEntity()
    self.behaviorTree:SetBoolParameter(BTConstant.HasTarget, false)
    self.behaviorTree:SetBoolParameter(BTConstant.TargetInAttackDistance, false)
end

function MonsterActionTool:ResetPursuitPos()
    local result = self:SearchAttackTarget()
    if result:IsTargetAndSkillValid() then
        return
    end

    local destination =  result:NearestAttackPosition()

    local birthPos = self.entity:GetBornPos()
    local distance = Vector3.Distance(birthPos, destination)
    if distance > self.track then
        destination = birthPos + (destination - birthPos).normalized * self.track
    end
    self.entity.unitMove:ChangeDestination(destination)
end

function MonsterActionTool:SearchAttackTarget()
    -- 搜索到能攻击的对象
    ---@type TargetSearchResult
    local result = self.searchOpposed:SearchWithFightUnit()

    local hasTarget = result:IsTargetValid()
    self.behaviorTree:SetBoolParameter(BTConstant.HasTarget, hasTarget)

    --console.error("hasTarget:"..tostring(hasTarget))
    local targetInAttackDistance = result:TargetInAttackDistance()
    self.behaviorTree:SetBoolParameter(BTConstant.TargetInAttackDistance, targetInAttackDistance)

    return result
end

return MonsterActionTool