---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type NodeAction
local NodeAction = require "Cleaner.BehaviorTree.Node.Leaf.NodeAction"

-- 探索岛宠物行为：追踪
---@class MonsterActionPursuit:NodeAction
local MonsterActionPursuit = class(NodeAction, "MonsterActionPursuit")

function MonsterActionPursuit:ctor()
    self.refresTime = 0
    self.REFRESH_INTERVAL = 1
end

function MonsterActionPursuit:SetOwner(owner)
    NodeAction.SetOwner(self, owner)
    ---@type MonsterEntity
    self.entity = self.owner
    ---@type MonsterActionTool
    self.monsterActionTool = self.entity.monsterActionTool
end

function MonsterActionPursuit:OnEnter()
    NodeAction.OnEnter(self)
    --console.error("MonsterActionPursuit:OnEnter:")
    --self.entity:ChangeMoveTool(AppServices.UnitMoveManager.MoveType.Freedom)
    self.entity:PlayAnimation(EntityAnimationName.run)
    self.monsterActionTool:ResetPursuitPos()
end

function MonsterActionPursuit:DoAction()
    --console.error("MonsterActionPursuit:DoAction:")
    local arrive = self.entity.unitMove:OnTick()
    self:Refresh(arrive)
    return BehaviorTreeInfo.ResultType.Running
end

function MonsterActionPursuit:OnExit()
    NodeAction.OnExit(self)
    self.entity.unitMove:Stop()
    --console.error("MonsterActionPursuit:OnExit:")
end

function MonsterActionPursuit:Refresh(force)
    if not force and Time.realtimeSinceStartup < self.refresTime then
        return BehaviorTreeInfo.ResultType.Running
    end
    self.refresTime = Time.realtimeSinceStartup + self.REFRESH_INTERVAL

    self.monsterActionTool:ResetPursuitPos()
end

return MonsterActionPursuit