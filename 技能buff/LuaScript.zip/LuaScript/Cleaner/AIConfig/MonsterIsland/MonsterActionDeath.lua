---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type NodeAction
local NodeAction = require "Cleaner.BehaviorTree.Node.Leaf.NodeAction"

-- 探索岛宠物行为：死亡
---@class MonsterActionDeath:NodeAction
local MonsterActionDeath = class(NodeAction, "MonsterActionDeath")

function MonsterActionDeath:ctor()
    self.refresTime = 0
    self.REFRESH_INTERVAL = 1
end

function MonsterActionDeath:SetOwner(owner)
    NodeAction.SetOwner(self, owner)
    ---@type MonsterEntity
    self.entity = self.owner
    ---@type FightUnitBase
    self.fightUnit = self.entity:GetUnit(UnitType.FightUnit)
end

function MonsterActionDeath:OnEnter()
    NodeAction.OnEnter(self)
    --console.error("MonsterActionDeath:OnEnter:")
    local sn = self.entity:GetSn()
    self.entityId = self.entity.entityId
    self.isDestroy = false

    self.config = self.entity.data:GetMeta()
    self.deathDestroyTime = Time.realtimeSinceStartup + self.config.deadDestroyTime
    MessageDispatcher:SendMessage(MessageType.EntityDeath, self.entityId, sn)

    local agentId = self.entity:GetAgentId()
    if self.config.isBoss == 1 then
        AppServices.User:SetKillMonster(tostring(agentId))
    end
    MessageDispatcher:SendMessage(MessageType.OnKillMonster, agentId, tonumber(sn), 1)

    if self.entity:IsSendKillBoss() then
        AppServices.NetPetManager:SendKillBoss(agentId)
    end

    self.fightUnit:NotifyHp(0, TipsType.UnitMonsterHpTips, false)
    local position = self.entity:GetPosition() + Vector3(0, 1, 0)
    self.deathEffectEntity = AppServices.EffectManager:Play(self.config.deadEffect, position)

    self.entity:PlayAnimation(EntityAnimationName.die)
    self.entity:SetDeath()
    self:RegisterEvent()
end

function MonsterActionDeath:DoAction()
    self:CheckDestroy()
    return BehaviorTreeInfo.ResultType.Running
end

function MonsterActionDeath:OnExit()
    NodeAction.OnExit(self)
    --console.error("MonsterActionDeath:OnExit:")
    if self.deathEffectEntity then
        local instanceId = self.deathEffectEntity:GetInstanceId()
        AppServices.EffectManager:RemoveEffect(instanceId)
    end
    self.fightUnit:NotifyHp(0, TipsType.UnitMonsterHpTips, false)
    self:UnRegisterEvent()
end

function MonsterActionDeath:CheckDestroy()
    if not self:IsDestroyDeath() or self.isDestroy then
        return
    end

    if Time.realtimeSinceStartup < self.deathDestroyTime then
        return
    end

    self.isDestroy = true
    local sn = self.entity:GetSn()
    MessageDispatcher:SendMessage(MessageType.EntityDeathAndDestroy, self.entityId, sn)
    self:NotifyRemove()
end

function MonsterActionDeath:IsDestroyDeath()
    return self.config.deadDestroyTime > 0
end

function MonsterActionDeath:NotifyRemove()
    AppServices.EffectManager:RemoveEffect(self.entityId)
    AppServices.EntityManager:RemoveEntity(self.entityId)
end

function MonsterActionDeath:LeaveIsland(islandId)
    if not self.entityId then
        return
    end
    local entity = AppServices.EntityManager:GetEntity(self.entityId)
    self.entityId = nil
    if not entity then
        return
    end

    local regionId = self.entity:GetRegionId()
    if regionId ~= islandId then
        return
    end
    if not self:IsDestroyDeath() or self.isDestroy then
        return
    end

    self.isDestroy = true
    local sn = self.entity:GetSn()
    MessageDispatcher:SendMessage(MessageType.EntityDeathAndDestroy, self.entityId, sn)
    self:NotifyRemove()
end

function MonsterActionDeath:RegisterEvent()
    MessageDispatcher:AddMessageListener(MessageType.LeaveIsLand, self.LeaveIsland, self)
end

function MonsterActionDeath:UnRegisterEvent()
    MessageDispatcher:RemoveMessageListener(MessageType.LeaveIsLand, self.LeaveIsland, self)
end

return MonsterActionDeath