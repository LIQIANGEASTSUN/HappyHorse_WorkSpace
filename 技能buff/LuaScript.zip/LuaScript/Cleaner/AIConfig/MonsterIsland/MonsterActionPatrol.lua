---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type NodeAction
local NodeAction = require "Cleaner.BehaviorTree.Node.Leaf.NodeAction"

-- 探索岛宠物行为：巡逻
---@class MonsterActionPatrol:NodeAction
local MonsterActionPatrol = class(NodeAction, "MonsterActionPatrol")

function MonsterActionPatrol:ctor()
    self.refresTime = 0
    self.REFRESH_INTERVAL = 1
end

function MonsterActionPatrol:SetOwner(owner)
    NodeAction.SetOwner(self, owner)
    ---@type MonsterEntity
    self.entity = self.owner
    ---@type MonsterActionTool
    self.monsterActionTool = self.entity.monsterActionTool
    self.patrolPositionList = {}
end

function MonsterActionPatrol:OnEnter()
    NodeAction.OnEnter(self)
    --console.error("MonsterActionPatrol:OnEnter:")
    self.entity:PlayAnimation(EntityAnimationName.run)

    local moveType = AppServices.UnitMoveManager.MoveType.Freedom
    self.entity:ChangeMoveTool(moveType)
    self:ResetDestination()
end

function MonsterActionPatrol:DoAction()
    --console.error("MonsterActionPatrol:DoAction:")
    local arrive = self.entity.unitMove:OnTick()
    if arrive then
        self:ResetDestination()
    end

    self:Refresh()

    return BehaviorTreeInfo.ResultType.Running
end

function MonsterActionPatrol:OnExit()
    NodeAction.OnExit(self)
    --console.error("MonsterActionPatrol:OnExit:")
    local moveType = AppServices.UnitMoveManager.MoveType.FindPathAlgorithm
    self.entity:ChangeMoveTool(moveType)
    self.entity.unitMove:Stop()
end

function MonsterActionPatrol:ResetDestination()
    if #self.patrolPositionList <= 0 then
        local pos = self.entity:GetBornPos()
        local patrolRaduis = self.entity.data:GetPatrol()
        self:RandomEnablePointInRadius(pos, patrolRaduis)
    end

    if #self.patrolPositionList <= 0 then
        local position = self.entity:GetPosition()
        self.entity.unitMove:ChangeDestination(position)
        return
    end

    local random = math.random(1, 100)
    local index = (random % #self.patrolPositionList) + 1
    local position = self.patrolPositionList[index]
    self.entity.unitMove:ChangeDestination(position)
end

function MonsterActionPatrol:Refresh()
    if Time.realtimeSinceStartup < self.refresTime then
        return
    end
    self.refresTime = Time.realtimeSinceStartup + self.REFRESH_INTERVAL

    self.monsterActionTool:SearchAttackTarget()
end

function MonsterActionPatrol:RandomEnablePointInRadius(pos, radius)
    for angle = 0, 360, 75 do
        local rad = math.rad(angle)
        local x = math.sin(rad) * radius
        local z = math.cos(rad) * radius
        local dir = Vector3(x, 0, z)
        local destination = pos + dir
        local enablePass = AppServices.IslandPathManager:EnablePass(destination.x, destination.z)
        if enablePass then
            table.insert(self.patrolPositionList, destination)
        end
    end
end

return MonsterActionPatrol