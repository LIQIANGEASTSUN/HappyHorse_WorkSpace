---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type NodeAction
local NodeAction = require "Cleaner.BehaviorTree.Node.Leaf.NodeAction"

-- 探索岛宠物行为：休闲
---@class MonsterActionIdle:NodeAction
local MonsterActionIdle = class(NodeAction, "MonsterActionIdle")

function MonsterActionIdle:ctor()
    self.refresTime = 0
    self.REFRESH_INTERVAL = 1
end

function MonsterActionIdle:SetOwner(owner)
    NodeAction.SetOwner(self, owner)
    ---@type MonsterEntity
    self.entity = self.owner
    ---@type MonsterActionTool
    self.monsterActionTool = self.entity.monsterActionTool
end

function MonsterActionIdle:OnEnter()
    NodeAction.OnEnter(self)
    --console.error("MonsterActionIdle:OnEnter:")
    self.entity:PlayAnimation(EntityAnimationName.idle)
end

function MonsterActionIdle:DoAction()
    --console.error("MonsterActionIdle:DoAction:")
    self:Refresh()
    return BehaviorTreeInfo.ResultType.Running
end

function MonsterActionIdle:OnExit()
    NodeAction.OnExit(self)
    --console.error("MonsterActionIdle:OnExit:")
end

function MonsterActionIdle:Refresh()
    if Time.realtimeSinceStartup < self.refresTime then
        return BehaviorTreeInfo.ResultType.Running
    end
    self.refresTime = Time.realtimeSinceStartup + self.REFRESH_INTERVAL

    self.monsterActionTool:SearchAttackTarget()
    return BehaviorTreeInfo.ResultType.Running
end

return MonsterActionIdle