---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type NodeCondition
local NodeCondition = require "Cleaner.BehaviorTree.Node.Leaf.NodeCondition"

-- 探索岛宠物行为：死亡
---@class MonsterConditionIdle:NodeCondition
local MonsterConditionIdle = class(NodeCondition, "MonsterConditionIdle")

local MonsterDoFunction = {
    IDLE = 0,
    PATROL = 1,
    Max = 2,
}

function MonsterConditionIdle:ctor()
    self.refresTime = 0
    self.REFRESH_INTERVAL = 1

    self.doFunction = MonsterDoFunction.IDLE
    self:SetDurationTime()
end

function MonsterConditionIdle:SetOwner(owner)
    NodeCondition.SetOwner(self, owner)
    ---@type MonsterEntity
    self.entity = self.owner
    ---@type MonsterActionTool
    self.monsterActionTool = self.entity.monsterActionTool
end

function MonsterConditionIdle:OnEnter()
    NodeCondition.OnEnter(self)
    --console.error("PetActionIdle:OnEnter:")
end

function MonsterConditionIdle:Condition()
    NodeCondition.Condition(self)
    --console.error("PetActionIdle:DoAction:")
    if Time.realtimeSinceStartup > self.durationTime then
        self:ChangeDoFunction()
    end

    if self.doFunction == MonsterDoFunction.IDLE then
        return BehaviorTreeInfo.ResultType.Success
    end
    return BehaviorTreeInfo.ResultType.Fail
end

function MonsterConditionIdle:OnExit()
    NodeCondition.OnExit(self)
    --console.error("PetActionIdle:OnExit:")
end

function MonsterConditionIdle:SetDurationTime()
    if self.doFunction == MonsterDoFunction.IDLE then
        self.durationTime = Time.realtimeSinceStartup + Random.Range(3, 5)
    else
        self.durationTime = Time.realtimeSinceStartup + Random.Range(8, 10)
    end
end

function MonsterConditionIdle:ChangeDoFunction()
    self.doFunction = self.doFunction + 1
    self.doFunction = self.doFunction % MonsterDoFunction.Max
    self:SetDurationTime()
end

return MonsterConditionIdle