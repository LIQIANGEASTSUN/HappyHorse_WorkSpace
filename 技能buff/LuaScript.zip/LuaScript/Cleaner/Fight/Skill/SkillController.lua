---@type SkillInfo
local SkillInfo = require "Cleaner.Fight.Skill.Base.SkillInfo"

---@class SkillController
local SkillController = class(nil, "SkillController")

function SkillController:ctor(fightUnit)
    ---@type Dictionary<int, SkillBase>
    self.skills = {}
    self.fightUnit = fightUnit
    self.TICK_INTERVAL = 0.3
    self.tickTime = 0
end

function SkillController:SetTickInterval(interval)
    self.TICK_INTERVAL = interval
end

function SkillController:AddSkill(skillId)
    local type = SkillInfo.SkillType.General
    local skillAlias = SkillInfo.Skills[type]
    local skillInstance = skillAlias.new(skillId, self.fightUnit)
    self.skills[skillId] = skillInstance
end

function SkillController:AddSkills(skillIds)
    for _, skillId in pairs(skillIds) do
        self:AddSkill(skillId)
    end
end

function SkillController:ClearSkill()
    for _, skill in pairs(self.skills) do
        skill:Clear()
    end
    self.skills = {}
end

function SkillController:GetSkill(skillId)
    return self.skills[skillId]
end

function SkillController:GetAllSkill()
    return self.skills
end

function SkillController:GetAllSkillID()
    local list = {}
    for _, skill in pairs(self.skills) do
        local skillId = skill:GetSkillId()
        table.insert(list, skillId)
    end
    return list
end

function SkillController:IsValidCampRelation(other)
    local list = {}
    for _, skill in pairs(self.skills) do
        local result = skill:IsValidCampRelation(other)
        if result then
            local skillId = skill:GetSkillId()
            table.insert(list, skillId)
        end
    end
    return list
end

function SkillController:EnableUse(skillId)
    local skill = self:GetSkill(skillId)
    return skill:EnableUse()
end

function SkillController:OnTick()
    if Time.realtimeSinceStartup < self.tickTime then
        return
    end
    self.tickTime = Time.realtimeSinceStartup + self.TICK_INTERVAL

    for _, skill in pairs(self.skills) do
        skill:OnTick()
    end
end

function SkillController:Fire(skillId, targets)
    local skill = self:GetSkill(skillId)
    skill:Fire(targets)
end

function SkillController:FireNoTarget(skillId)
    local skill = self:GetSkill(skillId)
    skill:FireNoTarget()
end

return SkillController