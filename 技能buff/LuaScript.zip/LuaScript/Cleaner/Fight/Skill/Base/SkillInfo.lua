---@class SkillInfo
local SkillInfo = {}

-- 技能类型
SkillInfo.SkillType = {
    -- 普通攻击
    General = 1,
}

SkillInfo.StateType = {
    -- 起手阶段
    INITIAL_PHASE = 0,
    -- 待机(循环)阶段
    STANDBY_PHASE = 1,
    -- 释放阶段
    FIRE_PHASE    = 2,
    --- 结束收尾阶段
    END_PHASE     = 3,
    -- 无效值
    NONE          = 4,
}

-- 技能事件类型
SkillInfo.SkillEventType = {
    --- 特效事件
    EFFECT = 0,
    --- 动作事件
    ANIMATION = 1,
    --- 音效事件
    AUDIO = 2,
    --- 更换武器事件
    CHANGE_WEAPON = 3,
    --- 触发伤害事件
    DAMAGE = 4,
    --- 弹道事件
    TRAJECTORY = 20,
    --- Hold 事件
    HOLD = 30,
    --- 循环事件
    LOOP = 31,
    --- 阶段结束
    PHASE_END = 32,
}

-- 技能 Hold 类型
SkillInfo.SkillHoldType = {
    --- 切掉当前阶段
    Abort_PHASE = 0,

    --- 可以终止当前技能
    Abort_SKILL = 10,
}


--- 技能事件刪除类型
SkillInfo.SkillEventRemoveType = {
    -- 特效时间结束删除
    TIME_END = 1,

    -- 技能切换阶段删除
    SKILL_PHASE_CHANGE = 2,

    -- 特定阶段删除
    SKILL_PHASE_CHANGE_SPECIFI = 4,

    -- 技能蓄力蓄满
    SKILL_FOCO_FULL = 8,
}

-- 技能配置
SkillInfo.Skills = setmetatable(
    {
        _register = {
            [SkillInfo.SkillType.General] = "Cleaner.Fight.Skill.SkillGeneral",
        }
    },
    {
        __index = function(t, k)
            local path = t._register[k]
            local v = require(path)
            rawset(t, k, v)
            return v
        end
    }
)

-- 事件配置
SkillInfo.EventAlias = setmetatable(
    {
        _register = {
            [SkillInfo.SkillEventType.EFFECT] = "Cleaner.Fight.Skill.SkillEvent.SkillEventEffect",
            [SkillInfo.SkillEventType.ANIMATION] = "Cleaner.Fight.Skill.SkillEvent.SkillEventAnimation",
            [SkillInfo.SkillEventType.AUDIO] = "Cleaner.Fight.Skill.SkillEvent.SkillEventAudio",
            [SkillInfo.SkillEventType.CHANGE_WEAPON] = "Cleaner.Fight.Skill.SkillEvent.SkillEventChangeWeapon",
            [SkillInfo.SkillEventType.DAMAGE] = "Cleaner.Fight.Skill.SkillEvent.SkillEventDamage",
            [SkillInfo.SkillEventType.TRAJECTORY] = "Cleaner.Fight.Skill.SkillEvent.SkillEventTrajectory",
            [SkillInfo.SkillEventType.HOLD] = "Cleaner.Fight.Skill.SkillEvent.SkillEventHold",
            [SkillInfo.SkillEventType.LOOP] = "Cleaner.Fight.Skill.SkillEvent.SkillEventLoop",
            [SkillInfo.SkillEventType.PHASE_END] = "Cleaner.Fight.Skill.SkillEvent.SkillEventPhaseEnd",
        }
    },
    {
        __index = function(t, k)
            local path = t._register[k]
            local v = require(path)
            rawset(t, k, v)
            return v
        end
    }
)

return SkillInfo