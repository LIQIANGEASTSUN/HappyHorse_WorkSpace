---@type BehaviorTreeEntity
local BehaviorTreeEntity = require "Cleaner.BehaviorTree.BehaviorTreeEntity"

---@type BTConstant
local BTConstant = require "Cleaner.AIConfig.BTConstant"

---@class SkillBase
local SkillBase = class(nil, "SkillBase")

function SkillBase:ctor(skillId, fightUnit)
    self.skillId = skillId
    self.fightUnit = fightUnit

    ---@type BehaviorTreeEntity
    self.behaviorTree = nil

    local config = AppServices.Meta:Category("SkillTemplate")
    self.meta = config[tostring(self.skillId)]

    -- 技能攻击阵营关系
    self.campRelation = self.meta.camp
    -- 正在使用中
    self.activate = false
    -- 记录每次攻击时的时间
    self.fireTime = 0

    self.targetSprites = {}

    self:CreateState()
end

function SkillBase:GetSkillId()
    return self.skillId
end

function SkillBase:GetAttackPower()
    return self.meta.attackPower
end

function SkillBase:GetAttackDistance()
    return self.meta.attackDistance
end

function SkillBase:GetCD()
    return self.meta.attackCd
end

function SkillBase:AttackAnimation()
    return self.meta.attackAni
end

function SkillBase:AttackEffect()
    return self.meta.AttackEffect
end

function SkillBase:IsCollDown()
    local cd = self:GetCD()
    return (Time.realtimeSinceStartup - self.fireTime) < cd
end

function SkillBase:IsValidCampRelation(other)
    local selfCamp = self.fightUnit:GetCamp()
    local otherCamp = other:GetCamp()
    local isSelf = self.fightUnit:GetInstanceId() == other:GetInstanceId()
    return CampType.IsValidCampRelation(self.campRelation, selfCamp, otherCamp, isSelf)
end

function SkillBase:IsActivate()
    return self.activate
end

function SkillBase:EnableUse()
    -- CD 中
    if self:IsCollDown() then
        return false
    end

    -- 正在使用中
    if self:IsActivate() then
        return false
    end

    return true
end

function SkillBase:CreateState()
    local skillConfig = require("Configs.Skill.skill_10001")
    local skillInfoData = skillConfig.SkillInfoList[1]
    self:AnalyzeSkillEvent(skillInfoData)

    self.behaviorTree = BehaviorTreeEntity.new("skill_general", self)
end

function SkillBase:AnalyzeSkillEvent(skillInfoData)
    self.skillEventMap = {[0] = {}, [1] = {}, [2] = {}, [3] = {}}
    for _, eventData in pairs(skillInfoData.CustomEventList) do
        local phaseType = eventData.SkillPhaseType
        table.insert(self.skillEventMap[phaseType], eventData)
    end
end

function SkillBase:GetEventData(phaseType)
    local eventDatas = self.skillEventMap[phaseType]
    return eventDatas
end

function SkillBase:GetBtEntity()
    return self.behaviorTree
end

function SkillBase:GetTargets()
    return self.targetSprites
end

function SkillBase:GetFightUnit()
    return self.fightUnit
end

function SkillBase:Fire(targetSprites)
    self.targetSprites = targetSprites
    self.fireTime = Time.realtimeSinceStartup
    self.activate = true

    self.behaviorTree:SetBoolParameter(BTConstant.SkillEntry, true)
end

function SkillBase:FireNoTarget()
    local skillId = self:GetSkillId()
    local skillMap = {[skillId] = true}
    local fightSearchOpposed = self.fightUnit:SearchOpposed()

    local targetResult = fightSearchOpposed:SearchWithFightUnit(skillMap)
    if targetResult:IsTargetAndSkillValid() and targetResult:TargetInAttackDistance() then
        local targets = { targetResult.other }
        self:Fire(targets)
    end
end

function SkillBase:Damage()
    AppServices.DamageController:Damage(self, self.fightUnit, self.targetSprites)
end

function SkillBase:OnTick()
    if self.behaviorTree then
        self.behaviorTree:Execute()
    end
end

function SkillBase:SkillEnd()
    self.activate = false
    if self.behaviorTree then
        self.behaviorTree:Exit()
    end

    --- 临时处理
    self.behaviorTree:SetBoolParameter(BTConstant.SkillEntry, false)
    self.behaviorTree:SetBoolParameter(BTConstant.SkillInitFinish, false)
    self.behaviorTree:SetBoolParameter(BTConstant.SkillStandbyFinish, false)
    self.behaviorTree:SetBoolParameter(BTConstant.SkillFireFinish, false)
    self.behaviorTree:SetBoolParameter(BTConstant.SkillEndFinish, false)
end

function SkillBase:Clear()

end

return SkillBase