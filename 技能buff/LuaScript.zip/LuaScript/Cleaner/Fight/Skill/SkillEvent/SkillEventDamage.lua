
---@type SkillEventBase
local SkillEventBase = require "Cleaner.Fight.Skill.SkillEvent.SkillEventBase"

---@class SkillEventDamage
local SkillEventDamage = class(SkillEventBase, "SkillEventDamage")

-- 技能触发伤害事件
-- 后续需要完善：碰撞检测(圆、矩形、扇形) 或 不需要碰撞检测，直接伤害被攻击对象
function SkillEventDamage:ctor(skill, skillState, eventData)

end

function SkillEventDamage:OnTick(time)
    SkillEventBase.OnTick(self, time)
end

function SkillEventDamage:Trigger()
    SkillEventBase.Trigger(self)
    self.skill:Damage()
end

function SkillEventDamage:Reset()
    SkillEventBase.Reset(self)
end

return SkillEventDamage