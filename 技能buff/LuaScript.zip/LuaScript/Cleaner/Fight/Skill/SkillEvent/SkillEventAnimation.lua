
---@type SkillEventBase
local SkillEventBase = require "Cleaner.Fight.Skill.SkillEvent.SkillEventBase"

---@class SkillEventAnimation
local SkillEventAnimation = class(SkillEventBase, "SkillEventAnimation")

-- 技能播放动画事件
function SkillEventAnimation:ctor(skill, skillState, eventData)

end

function SkillEventAnimation:OnTick(time)
    SkillEventBase.OnTick(self, time)
end

function SkillEventAnimation:Trigger()
    SkillEventBase.Trigger(self)

    local animationName = self.eventData.FileName
    local fightUnit = self.skill:GetFightUnit()
    fightUnit:PlayAnimation(animationName, 0.1)
end

function SkillEventAnimation:Reset()
    SkillEventBase.Reset(self)
end

return SkillEventAnimation