---@type SkillEventBase
local SkillEventBase = require "Cleaner.Fight.Skill.SkillEvent.SkillEventBase"

---@class SkillEventPhaseEnd
local SkillEventPhaseEnd = class(SkillEventBase, "SkillEventPhaseEnd")

-- 技能阶段结束事件
function SkillEventPhaseEnd:ctor(skill, skillState, eventData)

end

function SkillEventPhaseEnd:OnTick(time)
    SkillEventBase.OnTick(self, time)
end

function SkillEventPhaseEnd:Trigger()
    SkillEventBase.Trigger(self)

    self.skillState:SetPhaseEnd()
end

function SkillEventPhaseEnd:Reset()
    SkillEventBase.Reset(self)
    self.loopTimes = 0
end

return SkillEventPhaseEnd