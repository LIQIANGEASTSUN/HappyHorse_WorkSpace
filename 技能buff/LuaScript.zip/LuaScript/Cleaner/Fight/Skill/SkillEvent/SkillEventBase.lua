
---@class SkillEventBase
local SkillEventBase = class(nil, "SkillEventBase")

function SkillEventBase:ctor(skill, skillState, eventData)
    self.skill = skill
    self.skillState = skillState
    self.eventData = eventData
    self.trigger = false
end

function SkillEventBase:OnTick(time)
    if not self.trigger and time >= self.eventData.EventBase.Start then
        self:Trigger()
    end
end

function SkillEventBase:Trigger()
    self.trigger = true
end

function SkillEventBase:ChangePhase(phaseType)

end

function SkillEventBase:Reset()
    self.trigger = false
end

return SkillEventBase