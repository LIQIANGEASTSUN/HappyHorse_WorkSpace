
---@type SkillEventBase
local SkillEventBase = require "Cleaner.Fight.Skill.SkillEvent.SkillEventBase"

---@class SkillEventChangeWeapon
local SkillEventChangeWeapon = class(SkillEventBase, "SkillEventChangeWeapon")

-- 技能替换武器事件
function SkillEventChangeWeapon:ctor(skill, skillState, eventData)

end

function SkillEventChangeWeapon:OnTick(time)
    SkillEventBase.OnTick(self, time)
end

function SkillEventChangeWeapon:Reset()
    SkillEventBase.Reset(self)
end

return SkillEventChangeWeapon