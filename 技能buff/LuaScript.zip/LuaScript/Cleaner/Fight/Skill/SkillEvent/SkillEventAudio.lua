
---@type SkillEventBase
local SkillEventBase = require "Cleaner.Fight.Skill.SkillEvent.SkillEventBase"

---@class SkillEventAudio
local SkillEventAudio = class(SkillEventBase, "SkillEventAudio")

-- 技能播放音效事件
function SkillEventAudio:ctor(skill, skillState, eventData)

end

function SkillEventAudio:OnTick(time)
    SkillEventBase.OnTick(self, time)
end

function SkillEventAudio:Reset()
    SkillEventBase.Reset(self)
end

return SkillEventAudio