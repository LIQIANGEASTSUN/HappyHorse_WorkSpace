---@type SkillEventBase
local SkillEventBase = require "Cleaner.Fight.Skill.SkillEvent.SkillEventBase"

---@class SkillEventLoop
local SkillEventLoop = class(SkillEventBase, "SkillEventLoop")

-- 技能循环事件
function SkillEventLoop:ctor(skill, skillState, eventData)
    self.loopTimes = 0
end

function SkillEventLoop:OnTick(time)
    SkillEventBase.OnTick(self, time)
end

function SkillEventLoop:Trigger()
    SkillEventBase.Trigger(self)

    if self.loopTimes < self.eventData.LoopTimes then
        self.skillState:LoopRestar()
    end
end

function SkillEventLoop:Reset()
    SkillEventBase.Reset(self)
    self.loopTimes = 0
end

return SkillEventLoop