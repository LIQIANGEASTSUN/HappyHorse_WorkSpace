---@type SkillEventBase
local SkillEventBase = require "Cleaner.Fight.Skill.SkillEvent.SkillEventBase"

---@class SkillEventTrajectory
local SkillEventTrajectory = class(SkillEventBase, "SkillEventTrajectory")

-- 技能释放弹道事件
function SkillEventTrajectory:ctor(skill, skillState, eventData)

end

function SkillEventTrajectory:OnTick(time)
    SkillEventBase.OnTick(self, time)
end

function SkillEventTrajectory:Reset()
    SkillEventBase.Reset(self)
    self.loopTimes = 0
end

return SkillEventTrajectory