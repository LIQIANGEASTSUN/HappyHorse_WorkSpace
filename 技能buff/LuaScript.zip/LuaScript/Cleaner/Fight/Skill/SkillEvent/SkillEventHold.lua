---@type SkillInfo
local SkillInfo = require "Cleaner.Fight.Skill.Base.SkillInfo"

---@type SkillEventBase
local SkillEventBase = require "Cleaner.Fight.Skill.SkillEvent.SkillEventBase"

---@class SkillEventHold
local SkillEventHold = class(SkillEventBase, "SkillEventHold")

-- 技能Hold事件
function SkillEventHold:ctor(skill, skillState, eventData)

end

function SkillEventHold:OnTick(time)
    SkillEventBase.OnTick(self, time)
end

function SkillEventHold:Trigger()
    SkillEventBase.Trigger(self)

    if self.eventData.HoldType == SkillInfo.SkillHoldType.Abort_PHASE then
        self.skillState:SetPhaseEnd()
    elseif self.eventData.HoldType == SkillInfo.SkillHoldType.Abort_SKILL then
        self.skillState:SetSkillEnd()
    end
end

function SkillEventHold:Reset()
    SkillEventBase.Reset(self)
end

return SkillEventHold