---@type SkillInfo
local SkillInfo = require "Cleaner.Fight.Skill.Base.SkillInfo"

---@type SkillEventBase
local SkillEventBase = require "Cleaner.Fight.Skill.SkillEvent.SkillEventBase"

---@class SkillEventEffect
local SkillEventEffect = class(SkillEventBase, "SkillEventEffect")

-- 技能播放特效事件
function SkillEventEffect:ctor(skill, skillState, eventData)

end

function SkillEventEffect:OnTick(time)
    SkillEventBase.OnTick(self, time)

    self:TimeRemove()
end

function SkillEventEffect:Reset()
    SkillEventBase.Reset(self)
    --console.error("SkillEventEffect Reset:"..Time.realtimeSinceStartup.."   "..tostring(self.trigger))
end

function SkillEventEffect:Trigger()
    SkillEventBase.Trigger(self)

    local effectName = self.eventData.FileName
    --console.error("SkillEventEffect:"..Time.realtimeSinceStartup.."   "..effectName)

    local targetUnit = self.skill:GetTargets()
    if not targetUnit or #targetUnit<= 0 then
        local fightUnit = self.skill:GetFightUnit()
        self:PlayTargetEffect(fightUnit, effectName)
        return
    end

    for _, other in pairs(targetUnit) do
        self:PlayTargetEffect(other, effectName)
    end
end

function SkillEventEffect:ChangePhase(phaseType)
    SkillEventBase.ChangePhase(self, phaseType)
    self:ChangePhaseRemove(phaseType)
end

function SkillEventEffect:TimeRemove(time)
    if not self.trigger then
        return
    end
    if self.eventData.RemoveType ~= SkillInfo.SkillEventRemoveType.TIME_END then
        return
    end

    if time < self.eventData.Start + self.eventData.EventLength then
        return
    end

    self:RemoveEffect()
end

function SkillEventEffect:ChangePhaseRemove(phaseType)
    if self.eventData.RemoveType == SkillInfo.SkillEventRemoveType.SKILL_PHASE_CHANGE then
        self:RemoveEffect()
        return
    end

    if self.eventData.RemoveType ~= SkillInfo.SkillEventRemoveType.SKILL_PHASE_CHANGE_SPECIFI then
        return
    end

    if phaseType ~= self.eventData.RemovePhase then
        return
    end
    self:RemoveEffect()
end

function SkillEventEffect:PlayTargetEffect(unit, effectName)
    local position = unit:GetPosition()
    position = position + Vector3(0, 0.8, 0)
    self.effectEntity = AppServices.EffectManager:Play(effectName, position)
end

function SkillEventEffect:RemoveEffect()
    if not self.effectEntity then
        return
    end
    local instanceId = self.effectEntity:GetInstanceId()
    AppServices.EffectManager:RemoveEffect(instanceId)
    self.effectEntity = nil
end

return SkillEventEffect