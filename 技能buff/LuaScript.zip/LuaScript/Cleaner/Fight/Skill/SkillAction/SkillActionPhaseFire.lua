---@type SkillActionPhaseBase
local SkillActionPhaseBase = require "Cleaner.Fight.Skill.SkillAction.SkillActionPhaseBase"

---@type SkillInfo
local SkillInfo = require "Cleaner.Fight.Skill.Base.SkillInfo"

---@type BTConstant
local BTConstant = require "Cleaner.AIConfig.BTConstant"

---@type SkillActionPhaseFire
local SkillActionPhaseFire = class(SkillActionPhaseBase, "SkillActionPhaseFire")

function SkillActionPhaseFire:ctor()
    self.stateType = SkillInfo.StateType.FIRE_PHASE
end

function SkillActionPhaseFire:OnEnter()
    SkillActionPhaseBase.OnEnter(self)
end

function SkillActionPhaseFire:DoAction()
    return SkillActionPhaseBase.DoAction(self)
end

function SkillActionPhaseFire:OnExit()
    SkillActionPhaseBase.OnExit(self)
end

function SkillActionPhaseFire:SetPhaseEnd()
    SkillActionPhaseBase.SetSkillEnd(self)
    self.btEntity:SetBoolParameter(BTConstant.SkillFireFinish, true)
end

function SkillActionPhaseFire:SetSkillEnd()
    SkillActionPhaseBase.SetSkillEnd(self)
    self.btEntity:SetBoolParameter(BTConstant.SkillFireFinish, true)
end

return SkillActionPhaseFire