---@type SkillActionPhaseBase
local SkillActionPhaseBase = require "Cleaner.Fight.Skill.SkillAction.SkillActionPhaseBase"

---@type SkillInfo
local SkillInfo = require "Cleaner.Fight.Skill.Base.SkillInfo"

---@type BTConstant
local BTConstant = require "Cleaner.AIConfig.BTConstant"

---@type SkillActionPhaseStandby
local SkillActionPhaseStandby = class(SkillActionPhaseBase, "SkillActionPhaseStandby")

function SkillActionPhaseStandby:ctor()
    self.stateType = SkillInfo.StateType.STANDBY_PHASE
end

function SkillActionPhaseStandby:OnEnter()
    SkillActionPhaseBase.OnEnter(self)
end

function SkillActionPhaseStandby:DoAction()
    return SkillActionPhaseBase.DoAction(self)
end

function SkillActionPhaseStandby:OnExit()
    SkillActionPhaseBase.OnExit(self)
end

function SkillActionPhaseStandby:SetPhaseEnd()
    SkillActionPhaseBase.SetSkillEnd(self)
    self.btEntity:SetBoolParameter(BTConstant.SkillStandbyFinish, true)
end

function SkillActionPhaseStandby:SetSkillEnd()
    SkillActionPhaseBase.SetSkillEnd(self)
    self.btEntity:SetBoolParameter(BTConstant.SkillStandbyFinish, true)
end

return SkillActionPhaseStandby