---@type BehaviorTreeInfo
local BehaviorTreeInfo = require "Cleaner.BehaviorTree.BehaviorTreeInfo"

---@type SkillInfo
local SkillInfo = require "Cleaner.Fight.Skill.Base.SkillInfo"

---@type NodeAction
local NodeAction = require "Cleaner.BehaviorTree.Node.Leaf.NodeAction"

-- 技能阶段：基类
---@class SkillActionPhaseBase:SkillActionPhaseBase
local SkillActionPhaseBase = class(NodeAction, "SkillActionPhaseBase")

function SkillActionPhaseBase:ctor()
    self.eventList = {}
    self.enterTime = 0
    self.stateType = SkillInfo.StateType.NONE
    self.phaseFinish = false
end

function SkillActionPhaseBase:SetOwner(owner)
    NodeAction.SetOwner(self, owner)
    ---@type SkillBase
    self.skill = owner

    local eventDatas = self.skill:GetEventData(self.stateType)
    self:SetEvent(eventDatas)
end

function SkillActionPhaseBase:OnEnter()
    NodeAction.OnEnter(self)
    ---@type BehaviorTreeEntity
    self.btEntity = self.skill:GetBtEntity()
    self.enterTime = Time.realtimeSinceStartup
    self.phaseFinish = false
end

function SkillActionPhaseBase:DoAction()
    local time = Time.realtimeSinceStartup - self.enterTime
    time = time * 1000
    for _, event in pairs(self.eventList) do
        event:OnTick(time)
    end

    if self.phaseFinish then
        return BehaviorTreeInfo.ResultType.Success
    end

    return BehaviorTreeInfo.ResultType.Running
end

function SkillActionPhaseBase:OnExit()
    NodeAction.OnExit(self)
    self:Reset()
end

function SkillActionPhaseBase:SetEvent(eventDatas)
    for _, event in pairs(eventDatas) do
        local eventType = event.EventBase.EventType
        local eventAlias =  SkillInfo.EventAlias[eventType]
        local eventInstance = eventAlias.new(self.skill, self, event)
        table.insert(self.eventList, eventInstance)
    end
end

function SkillActionPhaseBase:Reset()
    self.currentEventIndex = 1
    for _, event in pairs(self.eventList) do
        event:Reset()
    end

    self.toOtherState = -1
end

function SkillActionPhaseBase:LoopRestar()
    --console.error("SkillStateBase:LoopRestar:"..Time.realtimeSinceStartup)
    self:Reset()
    self.enterTime = Time.realtimeSinceStartup
end

function SkillActionPhaseBase:SetPhaseEnd()
    self.phaseFinish = true
end

function SkillActionPhaseBase:SetSkillEnd()
    self.phaseFinish = true
end

return SkillActionPhaseBase