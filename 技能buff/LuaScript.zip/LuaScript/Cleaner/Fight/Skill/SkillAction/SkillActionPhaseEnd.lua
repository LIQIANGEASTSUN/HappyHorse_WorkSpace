---@type SkillActionPhaseBase
local SkillActionPhaseBase = require "Cleaner.Fight.Skill.SkillAction.SkillActionPhaseBase"

---@type SkillInfo
local SkillInfo = require "Cleaner.Fight.Skill.Base.SkillInfo"

---@type BTConstant
local BTConstant = require "Cleaner.AIConfig.BTConstant"

---@type SkillActionPhaseEnd
local SkillActionPhaseEnd = class(SkillActionPhaseBase, "SkillActionPhaseEnd")

function SkillActionPhaseEnd:ctor()
    self.stateType = SkillInfo.StateType.END_PHASE
end

function SkillActionPhaseEnd:OnEnter()
    SkillActionPhaseBase.OnEnter(self)
end

function SkillActionPhaseEnd:DoAction()
    return SkillActionPhaseBase.DoAction(self)
end

function SkillActionPhaseEnd:OnExit()
    SkillActionPhaseBase.OnExit(self)
    self.skill:SkillEnd()
end

function SkillActionPhaseEnd:SetPhaseEnd()
    SkillActionPhaseBase.SetSkillEnd(self)
    self.btEntity:SetBoolParameter(BTConstant.SkillEndFinish, true)
end

function SkillActionPhaseEnd:SetSkillEnd()
    SkillActionPhaseBase.SetSkillEnd(self)
    self.btEntity:SetBoolParameter(BTConstant.SkillEndFinish, true)
end

return SkillActionPhaseEnd