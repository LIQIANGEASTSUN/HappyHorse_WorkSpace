---@type SkillActionPhaseBase
local SkillActionPhaseBase = require "Cleaner.Fight.Skill.SkillAction.SkillActionPhaseBase"

---@type SkillInfo
local SkillInfo = require "Cleaner.Fight.Skill.Base.SkillInfo"

---@type BTConstant
local BTConstant = require "Cleaner.AIConfig.BTConstant"

---@type SkillActionPhaseInitial
local SkillActionPhaseInitial = class(SkillActionPhaseBase, "SkillActionPhaseInitial")

function SkillActionPhaseInitial:ctor()
    self.stateType = SkillInfo.StateType.INITIAL_PHASE
end

function SkillActionPhaseInitial:OnEnter()
    SkillActionPhaseBase.OnEnter(self)
    self.btEntity:SetBoolParameter(BTConstant.SkillEntry, false)
end

function SkillActionPhaseInitial:DoAction()
    return SkillActionPhaseBase.DoAction(self)
end

function SkillActionPhaseInitial:OnExit()
    SkillActionPhaseBase.OnExit(self)
end

function SkillActionPhaseInitial:SetPhaseEnd()
    SkillActionPhaseBase.SetSkillEnd(self)
    self.btEntity:SetBoolParameter(BTConstant.SkillInitFinish, true)
end

function SkillActionPhaseInitial:SetSkillEnd()
    SkillActionPhaseBase.SetSkillEnd(self)
    self.btEntity:SetBoolParameter(BTConstant.SkillInitFinish, true)
end

return SkillActionPhaseInitial