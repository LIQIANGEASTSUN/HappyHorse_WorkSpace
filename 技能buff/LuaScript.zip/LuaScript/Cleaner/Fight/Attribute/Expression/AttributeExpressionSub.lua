--- 属性表达式:减
---@class AttributeExpressionSub
local AttributeExpressionSub = {}

function AttributeExpressionSub:Interpreter(attributeBase, value)
    local originValue = attributeBase:GetValue()
    local result = originValue - value
    attributeBase:SetValue(result)
end

return AttributeExpressionSub