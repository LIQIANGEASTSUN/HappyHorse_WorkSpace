--- 属性表达式:加
---@class AttributeExpressionPlus
local AttributeExpressionPlus = {}

function AttributeExpressionPlus:Interpreter(attributeBase, value)
    local originValue = attributeBase:GetValue()
    local result = originValue + value
    attributeBase:SetValue(result)
end

return AttributeExpressionPlus