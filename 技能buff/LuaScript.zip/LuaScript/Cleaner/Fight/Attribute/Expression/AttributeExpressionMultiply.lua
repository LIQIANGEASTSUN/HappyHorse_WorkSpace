--- 属性表达式:乘
---@class AttributeExpressionMultiply
local AttributeExpressionMultiply = {}

function AttributeExpressionMultiply:Interpreter(attributeBase, value)
    local originValue = attributeBase:GetValue()
    local result = originValue * value
    attributeBase:SetValue(result)
end

return AttributeExpressionMultiply