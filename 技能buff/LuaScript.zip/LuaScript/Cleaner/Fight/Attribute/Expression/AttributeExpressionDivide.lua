--- 属性表达式:除
---@class AttributeExpressionDivide
local AttributeExpressionDivide = {}

function AttributeExpressionDivide:Interpreter(attributeBase, value)
    local originValue = attributeBase:GetValue()
    local result = originValue / value
    attributeBase:SetValue(result)
end

return AttributeExpressionDivide