---@type AttributeInfo
local AttributeInfo = require "Cleaner.Fight.Attribute.AttributeInfo"

---@class AttributeBase
local AttributeBase = class(nil, "AttributeBase")

function AttributeBase:ctor(owner, attributeType)
    self.owner = owner
    self.attributeType = attributeType

    --- 原始属性值
    self.originValue = 0
    --- 属性修改后的值
    self.value = 0
    self.expressionList = {}
end

function AttributeBase:Init(value)
    self.originValue = value
    self.value = value
end

function AttributeBase:GetType()
    return self.attributeType
end

function AttributeBase:GetValue()
    return self.value
end

function AttributeBase:SetValue(value)
    self.value = value
end

function AttributeBase:AddPlus(sourceKey, value)
    self:AddItem(sourceKey, value, AttributeInfo.ExpressionType.Plus)
end

function AttributeBase:AddSub(sourceKey, value)
    self:AddItem(sourceKey,  value, AttributeInfo.ExpressionType.Sub)
end

function AttributeBase:AddMultiply(sourceKey, value)
    self:AddItem(sourceKey, value, AttributeInfo.ExpressionType.Multiply)
end

function AttributeBase:AddDivide(sourceKey, value)
    self:AddItem(sourceKey, value, AttributeInfo.ExpressionType.Divide)
end

function AttributeBase:AddItem(sourceKey, value, expressionType)
    local item = {
        sourceKey = sourceKey,
        value = value,
        expressionType = expressionType,
    }

    table.insert(self.expressionList, item)
    self:CalculateValue()
end

function AttributeBase:RemoveItem(sourceKey)
    local remove = false
    for i = #self.expressionList, 1, -1 do
        local item = self.expressionList[i]
        if item.sourceKey == sourceKey then
            table.remove(self.expressionList, i)
            remove = true
        end
    end

    if remove then
        self:CalculateValue()
    end
end

-- 计算公式
function AttributeBase:CalculateValue()
    --- 因为从当前值逆向运算，不一定能得到正确的解锁，每次计算，将 value 复制为原始值开始计算
    self:SetValue(self.originValue)

    for _, item in ipairs(self.expressionList) do
        local expression = AttributeInfo.Expressions[item.expressionType]
        expression:Interpreter(self, item.value)
    end

    return self:GetValue()
end

function AttributeBase:Remove()
    self.expressionList = {}
end

return AttributeBase