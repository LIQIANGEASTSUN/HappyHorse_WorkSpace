---@type AttributeBase
local AttributeBase = require "Cleaner.Fight.Attribute.Entity.AttributeBase"

-- 属性修改：护盾属性修改
-- 被攻击时削减对方的攻击力,目前没有区分:魔法护盾、物理护盾
---@class AttributeShield
local AttributeShield = class(AttributeBase, "AttributeShield")

function AttributeShield:ctor()
    --- 免除伤害次数
    self.absolveDamage = 0
end

-- 计算公式
function AttributeShield:CalculateValue()
    if self.absolveDamage > 0 then
        self.absolveDamage = self.absolveDamage - 1
        return 0
    end
    return AttributeBase.CalculateValue(self)
end

return AttributeShield