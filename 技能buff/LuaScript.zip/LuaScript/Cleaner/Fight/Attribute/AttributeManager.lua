---@type AttributeInfo
local AttributeInfo = require "Cleaner.Fight.Attribute.AttributeInfo"

---@class AttributeManager
---@field attributeMap table<AttributeInfo.Type, AttributeBase>
local AttributeManager = class(nil, "AttributeManager")

function AttributeManager:ctor(owner)
    ---@type FightUnitBase
    self.owner = owner

    self.attributeMap = {}
end

function AttributeManager:Init()
end

function AttributeManager:GetAttribute(type)
    return self.attributeMap[type]
end

function AttributeManager:AddAttribute(type, value)
    local attributeAlias = AttributeInfo.AttributeTypes[type]
    local attribute = self:GetAttribute()
    if not attribute then
        attribute = attributeAlias.new(self.owner, type)
        self.attributeMap[type] = attribute
    end
    attribute:Init(value)
end

function AttributeManager:RemoveAttribute(type)
    local attribute = self:GetAttribute(type)
    if attribute then
        attribute:Remove()
    end
    self.attributeMap[type] = nil
end

return AttributeManager