-- FightUnitBase 各种属性
-- 移动速度、攻击距离、搜索距离、攻击力等

---@class AttributeInfo
local AttributeInfo = {}

AttributeInfo.Type = {
    --- 无效值
    None = -1,
    --- 移动速度
    MoveSpeed = 1,
    --- 攻击力
    Attack = 2,
    --- 搜索距离
    SearchDistance = 3,
    --- 护盾属性
    Shield = 4,
    --- 最大血量
    MaxHp = 5,
    --- 栖息地每分钟收益
    PetNestEarnings = 6,
    --- 栖息地收益上限时间
    PetNestEarningsTimeUpLimit = 7,
    --- 繁育时间
    BreedTime= 8,
}

--- 属性计算表达式
AttributeInfo.ExpressionType = {
    --- 加
    Plus = 1,
    --- 减
    Sub = 2,
    --- 乘
    Multiply = 3,
    --- 除
    Divide = 4,
}

AttributeInfo.AttributeTypes = setmetatable(
    {
        _register = {
            [AttributeInfo.Type.Shield] = "AttributeShield",
        }
    },
    {
        __index = function(t, k)
            local alias = t._register[k]
            if not alias then
                alias = "AttributeBase"
            end
            local path = "Cleaner.Fight.Attribute.Entity."..alias
            local v = require(path)
            rawset(t, k, v)
            return v
        end
    }
)

AttributeInfo.Expressions = setmetatable(
    {
        _register = {
            [AttributeInfo.ExpressionType.Plus] = "AttributeExpressionPlus",
            [AttributeInfo.ExpressionType.Sub] = "AttributeExpressionSub",
            [AttributeInfo.ExpressionType.Multiply] = "AttributeExpressionMultiply",
            [AttributeInfo.ExpressionType.Divide] = "AttributeExpressionDivide",
        }
    },
    {
        __index = function(t, k)
            local alias = t._register[k]
            local path = "Cleaner.Fight.Attribute.Expression."..alias
            local v = require(path)
            rawset(t, k, v)
            return v
        end
    }
)

return AttributeInfo