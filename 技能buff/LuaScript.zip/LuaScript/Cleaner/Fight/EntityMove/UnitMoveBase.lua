---@class UnitMoveBase
local UnitMoveBase = class(nil, "UnitMoveBase")
-- 设置目标点，令角色移动到目标点
function UnitMoveBase:ctor(entity)
    ---@type BaseEntity
    self.entity = entity
    self.moveDir = Vector3(0, 0, 0)
    self.destination = Vector3(0, 0, 0)
    self.patrolRadius = 1.5
    self.entityMove = self.entity.entityMove
    self.pathList = {}
    self.hasPath = false
    self.useRvo2 = self.entityMove:GetUseRVO2()
end

function UnitMoveBase:SetSpeed(speed)
    self.speed = speed * 0.8
end

function UnitMoveBase:ChangeDestination(destination)
    self.destination = destination
    self.hasPath = false
    self.entityMove:SetSpeed(self.speed)
    self.entityMove:SetMove(true)
end

function UnitMoveBase:OnTick(dt)
    if not self.hasPath then
        self:Stop()
        return self.hasPath
    end

    local arrive = false
    if self.useRvo2 then
        arrive = self.entityMove:ArriveDestination()
    else
        arrive = self.entityMove:Move(self.entity.dt)
    end
    if arrive then
        table.remove(self.pathList, 1)
        local value, movePos = self:GetMovePos()
        if value then
            self.entityMove:SetDestination(movePos)
            self:ResetForward()
        else
            self:Stop()
        end
    end

    return arrive
end

function UnitMoveBase:GetMovePos()
    return  #self.pathList > 0, self.pathList[1]
end

function UnitMoveBase:ResetForward()
    if #self.pathList <= 0 then
        return
    end
    local entityPos = self.entity:GetPosition()
    local forward = self.pathList[1] - entityPos
    if math.abs(forward.x) >= 0.3 or math.abs(forward.z) >= 0.3 then
        self.entity:SetForward(forward)
    end
end

function UnitMoveBase:RandomPosition(position)
    return false, position
end

function UnitMoveBase:SetPatrolRadius(radius)
    self.patrolRadius = radius
end

function UnitMoveBase:GetPatrolRadius()
    return self.patrolRadius
end

function UnitMoveBase:FindPath()
    return self.hasPath
end

function UnitMoveBase:EnableArriveThisFrame(position, destination, speed, time)
    local offsetX = (position.x - destination.x)
    local offsetZ = (position.z - destination.z)

    time = time and time or self.entity.dt
    local frameMoveDis = speed * time
    return (math.abs(offsetX) <= frameMoveDis and math.abs(offsetZ) <= frameMoveDis)
end

function UnitMoveBase:Stop()
    if self.entityMove then
        --self.entityMove:SetMove(false)
    end
end

return UnitMoveBase