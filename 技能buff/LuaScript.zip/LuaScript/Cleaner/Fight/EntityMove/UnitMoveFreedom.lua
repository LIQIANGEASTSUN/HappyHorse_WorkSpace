---@type UnitMoveBase
local UnitMoveBase = require "Cleaner.Fight.EntityMove.UnitMoveBase"

---@class UnitMoveFreedom:UnitMoveBase
local UnitMoveFreedom = class(UnitMoveBase, "UnitMoveFreedom")

-- 无寻路移动
function UnitMoveFreedom:ctor(entity)
end

function UnitMoveFreedom:ChangeDestination(destination)
    UnitMoveBase.ChangeDestination(self, destination)
    self.hasPath = true
    self.pathList = {destination}
    self:ResetForward()

    local _, movePos = self:GetMovePos()
    self.entityMove:SetDestination(movePos)
end

function UnitMoveFreedom:RandomPosition(position)
    local angle = Random.Range(0, 360)
    local rad = math.rad(angle)
    local x = math.sin(rad)
    local z = math.cos(rad)
    local dir = Vector3(x, 0, z)
    local dis = Random.Range(0, 100) * 0.01
    local destination = position + dir * self.patrolRadius * dis
    return true, destination
end

return UnitMoveFreedom