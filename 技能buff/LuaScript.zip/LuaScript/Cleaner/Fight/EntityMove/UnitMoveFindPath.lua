---@type PosIsOnWater
local PosIsOnWater = require "Cleaner.Fight.EntityMove.PosIsOnWater"

---@type UnitMoveBase
local UnitMoveBase = require "Cleaner.Fight.EntityMove.UnitMoveBase"

---@class UnitMoveFindPath:UnitMoveBase
local UnitMoveFindPath = class(UnitMoveBase, "UnitMoveFindPath")
-- 寻路移动
function UnitMoveFindPath:ctor(entity)
    self.pathGo = {}
end

function UnitMoveFindPath:ChangeDestination(destination)
    UnitMoveBase.ChangeDestination(self, destination)

    self.pathList = {}
    local startPos = self.entity:GetPosition()
    if Vector3.Distance(startPos, destination) <= 1 then
        table.insert(self.pathList, destination)
    else
        local list = AppServices.IslandPathManager:Search(Vector2(startPos.x, startPos.z), Vector2(destination.x, destination.z))
        for i = 2, #list do
            local addNode = false
            if i == #list then
                 addNode = true
            else
                local preNode = list[i - 1]
                local nextNode = list[i + 1]
                addNode = (preNode.x ~= nextNode.x) and (preNode.y ~= nextNode.y)
            end

            if addNode then
                local pos = list[i]
                local position = Vector3(pos.x, 0, pos.y)
                table.insert(self.pathList, position)
            end
        end
    end

    if #self.pathList <= 0 then
        self:NotFindPath()
    end

    self.hasPath = #self.pathList > 0
    self:ResetForward()
    local value, movePos = self:GetMovePos()
    if value then
        self.entityMove:SetDestination(movePos)
    end
end

function UnitMoveFindPath:NotFindPath()
    local entityPos = self.entity:GetPosition()
    if PosIsOnWater:IsOnWater(entityPos) then
        self.entity:SetPosition(self.destination)
        self.entityMove:setAgentPosition()
    end
end

function UnitMoveFindPath:RandomPosition(pos)
    local result, position = AppServices.IslandPathManager:RandomPath(pos.x, pos.z)
    return result, position
end

return UnitMoveFindPath