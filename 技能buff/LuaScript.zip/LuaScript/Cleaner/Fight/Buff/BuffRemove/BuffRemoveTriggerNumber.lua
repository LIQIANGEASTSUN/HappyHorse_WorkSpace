---@type BuffInfo
local BuffInfo = require "Cleaner.Fight.Buff.BuffInfo"

---@type BuffRemoveBase
local BuffRemoveBase = require "Cleaner.Fight.Buff.BuffRemove.Base.BuffRemoveBase"

---@class BuffRemoveTriggerNumber
local BuffRemoveTriggerNumber = class(BuffRemoveBase, "BuffRemoveTriggerNumber")

--- 移除类型:达到触发次数移除
function BuffRemoveTriggerNumber:ctor()
    self.removeType = BuffInfo.RemoveType.TriggerNumber

    self:Init()
end

function BuffRemoveTriggerNumber:Init()
    local buffConfig = self.buff:GetBuffConfig()
    self.triggerMax = buffConfig.removeValue
end

function BuffRemoveTriggerNumber:DoAction()
    local triggerNumaber = self.buff.triggerNumber
    if self.triggerMax > triggerNumaber then
        return
    end

    self.buff:BuffNeedRemove()
end

return BuffRemoveTriggerNumber