---@class BuffInfo
local BuffInfo = {}

--- Buff 类型
BuffInfo.BuffType = {
    --- 效果类
    --- 无效值
    None = -1,
    --- 恢复血量固定值
    RecoverHpValue = 1,
    --- 恢复血量百分比
    RecoverHpPercent = 2,
    --- 物理伤害增加值
    PhysicsDamageAddValue = 3,
    --- 物理伤害增加百分比
    PhysicsDamageAddPercent = 4,
    --- 属性克制物理伤害倍数
    RestraintPhysicsHarmMultiple = 5,

    --- 移动速度增加值
    --MoveSpeedAddValue = 6,
    --- 净化(移除所有有害buff)
    --Purify = 7,

    --- 栖息地每分钟收益增加值
    PetNestEarningsPlus = 6,
    --- 栖息地动物血量增加值
    EntityHpAddValue = 7,
    --- 栖息地动物攻击增加值
    EntityDamageAddValue = 8,
    --- 栖息地动物繁育时间减少值
    PetNestEntityBreedTimeSubValue = 9,
    --- 栖息地收益上限时间增加值
    PetNestEarningsTimeUpLimitAddValue = 10,
    --- 栖息地每分钟收益增加百分比
    PetNestEarningsAddPercent = 11,



    --- 状态类
    --- 眩晕
    Dizziness = 10000,
    --- 沉默
    Silence = 10001,
    --- 无敌
    Unbeatable = 10002,
    --- 霸体
    SuperArmor = 10003,
    --- 免疫
    Immune = 10004,
}

--- 触发类型
BuffInfo.TriggerType = {
    --- 无效值
    None = -1,
    --- 按时间间隔
    TimeInterval = 1,
    --- owner主动攻击时
    Hit = 2,
    --- owner被攻击时
    BeHit = 3,
    --- owner死亡前触发
    DeathBefore = 4,
    --- owner死亡后触发
    DeathAfter = 5,
    --- 添加buff时触发
    Apply = 6,
    --- 移除buff时触发
    Remove = 7,
}

-- --- 触发后生效类型
-- BuffInfo.EffectiveType = {
--     --- 无效值
--     None = -1,
--     --- 永久生效
--     Always = 1,
--     --- 生效一次
--     Once = 2,
-- }

--- 移除类型
BuffInfo.RemoveType = {
    --- 无效值
    None = -1,
    --- 时间结束
    TimeEnd = 1,
    --- 触发次数
    TriggerNumber = 2,
}

--- buff 有益/有害类型
BuffInfo.AdvantageType = {
    --- 有利的
    Helpful = 1,
    --- 有害
    Harmful = 2,
}

--- 优先级类型
BuffInfo.PriorityType = {
    --- 覆盖
    Overlay = 1,
    --- 叠加
    Superposition = 2,
}

--- Buff 配置
BuffInfo.Buffs = setmetatable(
    {
        _register = {
            --- 效果
            [BuffInfo.BuffType.RecoverHpValue] = "Cleaner.Fight.Buff.BuffEntity.BuffEffect.BuffEffectRecoverHpValue",
            [BuffInfo.BuffType.RecoverHpPercent] = "Cleaner.Fight.Buff.BuffEntity.BuffEffect.BuffEffectRecoverHpPercent",
            [BuffInfo.BuffType.RestraintPhysicsHarmMultiple] = "Cleaner.Fight.Buff.BuffEntity.BuffEffect.BuffEffectRestraintPhysicsHarmMultiple",
            --[BuffInfo.BuffType.MoveSpeedAddValue] = "Cleaner.Fight.Buff.BuffEntity.BuffEffect.BuffEffectMoveSpeedAddValue",
            --[BuffInfo.BuffType.Purify] = "Cleaner.Fight.Buff.BuffEntity.BuffEffect.BuffEffectPurify",
            [BuffInfo.BuffType.PetNestEarningsPlus] = "Cleaner.Fight.Buff.BuffEntity.BuffEffect.BuffEffectEarningsAddValue",
            [BuffInfo.BuffType.EntityHpAddValue] = "Cleaner.Fight.Buff.BuffEntity.BuffEffect.BuffEffectEntityHpAddValue",
            [BuffInfo.BuffType.EntityDamageAddValue] = "Cleaner.Fight.Buff.BuffEntity.BuffEffect.BuffEffectEntityAttackAddValue",
            [BuffInfo.BuffType.PetNestEntityBreedTimeSubValue] = "Cleaner.Fight.Buff.BuffEntity.BuffEffect.BuffEffectBreedTimeSubValue",
            [BuffInfo.BuffType.PetNestEarningsTimeUpLimitAddValue] = "Cleaner.Fight.Buff.BuffEntity.BuffEffect.BuffEffectEarningsTimeUpLimitAddValue",
            [BuffInfo.BuffType.PetNestEarningsAddPercent] = "Cleaner.Fight.Buff.BuffEntity.BuffEffect.BuffEffectEarningsAddPercent",


            --- 状态
            [BuffInfo.BuffType.SuperArmor] = "Cleaner.Fight.Buff.BuffEntity.BuffStatus.BuffStateSuperArmor",
            [BuffInfo.BuffType.Immune] = "Cleaner.Fight.Buff.BuffEntity.BuffStatus.BuffStateImmune",
            [BuffInfo.BuffType.Unbeatable] = "Cleaner.Fight.Buff.BuffEntity.BuffStatus.BuffStateUnbeatable",
        }
    },
    {
        __index = function(t, k)
            local path = t._register[k]
            local v = require(path)
            rawset(t, k, v)
            return v
        end
    }
)

BuffInfo.BuffTriggers = setmetatable(
    {
        _register = {
            [BuffInfo.TriggerType.TimeInterval] = "Cleaner.Fight.Buff.BuffTrigger.BuffTriggerTimeInterval",
        }
    },
    {
        __index = function(t, k)
            local path = t._register[k]
            if not path then
                path = "Cleaner.Fight.Buff.BuffTrigger.Base.BuffTriggerBase"
            end
            local v = require(path)
            rawset(t, k, v)
            return v
        end
    }
)

BuffInfo.BuffRemoves = setmetatable(
    {
        _register = {
            [BuffInfo.RemoveType.TimeEnd] = "Cleaner.Fight.Buff.BuffRemove.BuffRemoveTimeEnd",
            [BuffInfo.RemoveType.TriggerNumber] = "Cleaner.Fight.Buff.BuffRemove.BuffRemoveTriggerNumber"
        }
    },
    {
        __index = function(t, k)
            local path = t._register[k]
            local v = require(path)
            rawset(t, k, v)
            return v
        end
    }
)

return BuffInfo