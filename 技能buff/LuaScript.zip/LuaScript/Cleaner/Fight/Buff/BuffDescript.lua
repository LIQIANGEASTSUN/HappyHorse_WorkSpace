---@type BuffInfo
local BuffInfo = require "Cleaner.Fight.Buff.BuffInfo"

---@class BuffDescript
local BuffDescript = {}

function BuffDescript:Descript(buffId)
    local buffConfig = AppServices.Meta:Category("BuffTemplate")[tostring(buffId)]
    local buffAlias = BuffInfo.Buffs[buffConfig.buffType]
    return buffAlias:Description(buffConfig)
end

return BuffDescript