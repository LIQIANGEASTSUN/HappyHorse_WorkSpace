---@class BuffTriggerBase
local BuffTriggerBase = class(nil, "BuffTriggerBase")

-- Buff 生效/执行 基类

function BuffTriggerBase:ctor(buff, triggerType)
    self.buff = buff
    ---@type BuffInfo.TriggerType
    self.triggerType = triggerType
end

function BuffTriggerBase:GetTriggerType()
    return self.triggerType
end

function BuffTriggerBase:Trigger(type)
    if type ~= self.triggerType then
        return false
    end

    return true
end

return BuffTriggerBase