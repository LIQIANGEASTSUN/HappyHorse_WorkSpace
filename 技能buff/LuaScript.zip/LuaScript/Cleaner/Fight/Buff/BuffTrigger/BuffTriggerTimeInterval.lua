---@type BuffTriggerBase
local BuffTriggerBase = require "Cleaner.Fight.Buff.BuffTrigger.Base.BuffTriggerBase"

---@class BuffTriggerTimeInterval
local BuffTriggerTimeInterval = class(BuffTriggerBase, "BuffTriggerTimeInterval")

-- 触发类型：时间间隔触发
function BuffTriggerTimeInterval:ctor()
    --- 上一次触发时间
    self.triggerTime = -1
    --- 执行次数
    self.executeNumber = 0

    self:Init()
end

function BuffTriggerTimeInterval:Init()
    local buffConfig = self.buff:GetBuffConfig()
    local dotValue = buffConfig.dotValue
    self.excuteInZeroTime = dotValue[1]
    self.interval = dotValue[2]
end

function BuffTriggerTimeInterval:Trigger(type)
    if type ~= self.triggerType then
        return false
    end

    local execute = (self.excuteInZeroTime == 1) and (self.executeNumber <= 0)
    local value = (Time.realtimeSinceStartup - self.triggerTime) >= self.interval
    if value or execute then
        self.triggerTime = Time.realtimeSinceStartup
        self.executeNumber = self.executeNumber + 1
    end

    return value
end

function BuffTriggerTimeInterval:LateUpdate()

end

return BuffTriggerTimeInterval