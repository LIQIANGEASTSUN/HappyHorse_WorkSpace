---@type BuffBase
local BuffBase= require "Cleaner.Fight.Buff.BuffEntity.Base.BuffBase"

---@class BuffEffectBase:BuffBase
local BuffEffectBase = class(BuffBase, "BuffEffectBase")

-- Buff 效果基类
function BuffEffectBase:ctor()

end

return BuffEffectBase