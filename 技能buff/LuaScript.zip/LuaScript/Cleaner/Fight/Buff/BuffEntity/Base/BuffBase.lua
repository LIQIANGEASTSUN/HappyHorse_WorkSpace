---@type BuffInfo
local BuffInfo = require "Cleaner.Fight.Buff.BuffInfo"

---@class BuffBase
local BuffBase = class(nil, "BuffBase")

-- Buff 基类
function BuffBase:ctor(buffType, instanceId, buffManager, buffId, casterData)
    self.buffType = buffType
    self.instanceId = instanceId
    ---@type BuffManager
    self.buffManager = buffManager
    self.buffId = buffId
    -- 是挂在谁身上的
    ---@type FightUnitBase
    self.owner = buffManager:GetOwner()

    -- 施加者
    ---@type FightUnitBase
    self.caster = casterData.caster
    -- 施加者 技能ID
    self.casterSkillId = casterData.casterSkillId
    -- 施加者 buffId
    self.casterBuffId = casterData.casterBuffId

    -- buff 层
    self.layer = 1
    self.attributeKey = string.format("BuffAttribute_%d_%d", self.instanceId, self.buffType)

    self.buffConfig = AppServices.Meta:Category("BuffTemplate")[self.buffId]

    if self.buffConfig.effectiveType then
        self.effectiveType = self.buffConfig.effectiveType
    end

    -- buff 生效触发器
    ---@type BuffTriggerBase
    self.triggerEntity = nil
    -- buff 移除逻辑
    ---@type BuffRemoveBase
    self.buffRemoveEntity = nil

    --- 触发次数
    self.triggerNumber = 0

    self.actionObjects = {}

    self:CreateTrigger()
    self:CreateRemoveEntity()
    self:PlayEffect()
end

function BuffBase:GetInstanceId()
    return self.instanceId
end

function BuffBase:GetBuffId()
    return self.buffId
end

function BuffBase:GetBuffConfig()
    return self.buffConfig
end

function BuffBase:GetBuffAdvantage()
    return self.buffConfig.advantage
end

function BuffBase:GetLayer()
    return self.layer
end

function BuffBase:EnableAddBuff(buffId)
    return true
end

-- buff 叠加层时触发方法
function BuffBase:AddLayer(value)
    self.layer = self.layer + value
end

-- buff 添加时触发方法
function BuffBase:Applay()
    self:Trigger(BuffInfo.TriggerType.Apply)
end

-- buff 移除时触发方法
function BuffBase:Remove()
    self:Trigger(BuffInfo.TriggerType.Remove)
end

-- Trigger -------------------------------------
function BuffBase:CreateTrigger()
    local triggerType = self.buffConfig.triggerCondition
    local triggerAlias = BuffInfo.BuffTriggers[triggerType]
    self.triggerEntity = triggerAlias.new(self, triggerType)
    if triggerType ~= self.triggerEntity:GetTriggerType() then
        console.error("buff trigger config error") ---@Del
    end
end

function BuffBase:CreateRemoveEntity()
    local removeType = self.buffConfig.removeType
    local removeAlias = BuffInfo.BuffRemoves[removeType]
    self.buffRemoveEntity = removeAlias.new(self)
end

function BuffBase:Trigger(type, data)
    if not self.triggerEntity or type ~= self.triggerEntity:GetTriggerType() then
        return false
    end

    local result = self.triggerEntity:Trigger(type)
    if result then
        self.triggerNumber = self.triggerNumber + 1
        self:DoAction(data)
    end

    return result
end

-- 执行
function BuffBase:DoAction(data)
    self.buffRemoveEntity:DoAction()
end

function BuffBase:Update()
    self:Trigger(BuffInfo.TriggerType.TimeInterval)
    self.buffRemoveEntity:Update()
end

function BuffBase:BuffNeedRemove()
    self.buffManager:Remove()
end

function BuffBase:PlayEffect()
    if self.owner:GetOnlyLogic() then
        return
    end
    local effectName = self.buffConfig.effect

    local position = self.owner:GetPosition()
    position = position + Vector3(0, 0.1, 0)

    AppServices.EffectManager:Play(effectName, position)
end

function BuffBase:SearchCampAttackType(distance)
    distance = distance or 0.1
    local campRelation = self.buffConfig.camp
    if campRelation == CampType.CampRelation.Self then
        return {self.owner}
    end

    local searchOpposed = self.owner:SearchOpposed()
    local results = searchOpposed:SearchCamp(campRelation, distance)
    return results
end

function BuffBase:GetAttribute(attributeType)
    local attributeManager = self.owner:GetAttributeManager()
    local attributeBase = attributeManager:GetAttribute(attributeType)
    return attributeBase
end

--- 记录 buff 作用的对象
function BuffBase:SetActionObjects(objects)
    if not objects then
        return
    end
    for _, obj in pairs(objects) do
        table.insert(self.actionObjects, obj)
    end
end

--- buff 作用结束，将操作的属性撤销
function BuffBase:ClearActionObjects(attributeType)
    for _, obj in pairs(self.actionObjects) do
        local attributeBase = obj:GetAttribute(attributeType)
        attributeBase:RemoveItem(self.attributeKey)
    end
    self.actionObjects = {}
end

function BuffBase:Description(buffConfig)
    return ""
end

return BuffBase