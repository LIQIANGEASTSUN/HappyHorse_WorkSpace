---@type BuffBase
local BuffBase= require "Cleaner.Fight.Buff.BuffEntity.Base.BuffBase"

---@class BuffEffectBase:BuffBase
local BuffStateBase = class(BuffBase, "BuffStateBase")

-- Buff 状态基类
function BuffStateBase:ctor()

end

return BuffStateBase