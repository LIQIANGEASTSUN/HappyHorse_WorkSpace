---@type AttributeInfo
local AttributeInfo = require "Cleaner.Fight.Attribute.AttributeInfo"

---@type BuffEffectBase
local BuffEffectBase = require "Cleaner.Fight.Buff.BuffEntity.Base.BuffEffectBase"

-- buff 效果：栖息地动物繁育时间减少值
---@class BuffEffectBreedTimeSubValue:BuffEffectBase
local BuffEffectBreedTimeSubValue = class(BuffEffectBase, "BuffEffectBreedTimeSubValue")

function BuffEffectBreedTimeSubValue:ctor()
end

-- buff 移除触发方法
function BuffEffectBreedTimeSubValue:Remove()
    BuffEffectBase.Remove(self)

    self:ClearActionObjects(AttributeInfo.Type.BreedTime)
end

-- 执行
function BuffEffectBreedTimeSubValue:DoAction(data)
    BuffEffectBase.DoAction(self)

    local results = self:SearchCampAttackType(self.buffConfig.range)
    local addValue = self.buffConfig.buffValue[1]
    for _, other in pairs(results) do
        if other:IsAlive() then
            ---@type AttributeBase
            local attributeBase = other:GetAttribute(AttributeInfo.Type.BreedTime)
            attributeBase:AddSub(self.attributeKey, addValue)
        end
    end

    self:SetActionObjects(results)
end

function BuffEffectBreedTimeSubValue:Description(buffConfig)
    --- 栖息地内动物繁育时间缩短{time}
    local value = buffConfig.buffValue[1]
    return Runtime.Translate("ui_habitat_attribute_5", {time = tostring(value)})
end

return BuffEffectBreedTimeSubValue