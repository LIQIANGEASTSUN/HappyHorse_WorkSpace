---@type AttributeInfo
local AttributeInfo = require "Cleaner.Fight.Attribute.AttributeInfo"

---@type BuffEffectBase
local BuffEffectBase = require "Cleaner.Fight.Buff.BuffEntity.Base.BuffEffectBase"

-- buff 效果：栖息地每分钟收益增加值
---@class BuffEffectEarningsAddValue:BuffEffectBase
local BuffEffectEarningsAddValue = class(BuffEffectBase, "BuffEffectEarningsAddValue")

function BuffEffectEarningsAddValue:ctor()
end

-- buff 移除触发方法
function BuffEffectEarningsAddValue:Remove()
    BuffEffectBase.Remove(self)

    self:ClearActionObjects(AttributeInfo.Type.PetNestEarnings)
end

-- 执行
function BuffEffectEarningsAddValue:DoAction(data)
    BuffEffectBase.DoAction(self)

    local results = self:SearchCampAttackType(self.buffConfig.range)
    local addValue = self.buffConfig.buffValue[1]
    for _, other in pairs(results) do
        if other:IsAlive() then
            local attributeBase = other:GetAttribute(AttributeInfo.Type.PetNestEarnings)
            attributeBase:AddPlus(self.attributeKey, addValue)
        end
    end

    self:SetActionObjects(results)
end

function BuffEffectEarningsAddValue:Update()
    BuffEffectBase.Update(self)
end

function BuffEffectEarningsAddValue:Description(buffConfig)
    -- ○ui_habitat_attribute_2 栖息地每分钟收益+{num}
    local value = buffConfig.buffValue[1]
    return Runtime.Translate("ui_habitat_attribute_2", {num = tostring(value)})
end

return BuffEffectEarningsAddValue