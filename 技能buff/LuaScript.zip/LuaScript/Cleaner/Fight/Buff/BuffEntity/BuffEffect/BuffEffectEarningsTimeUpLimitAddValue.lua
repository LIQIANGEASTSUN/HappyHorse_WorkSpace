---@type AttributeInfo
local AttributeInfo = require "Cleaner.Fight.Attribute.AttributeInfo"

---@type BuffEffectBase
local BuffEffectBase = require "Cleaner.Fight.Buff.BuffEntity.Base.BuffEffectBase"

-- buff 效果：栖息地收益上限时间增加值
---@class BuffEffectEarningsTimeUpLimitAddValue:BuffEffectBase
local BuffEffectEarningsTimeUpLimitAddValue = class(BuffEffectBase, "BuffEffectEarningsTimeUpLimitAddValue")

function BuffEffectEarningsTimeUpLimitAddValue:ctor()
end

-- buff 移除触发方法
function BuffEffectEarningsTimeUpLimitAddValue:Remove()
    BuffEffectBase.Remove(self)

    self:ClearActionObjects(AttributeInfo.Type.PetNestEarningsTimeUpLimit)
end

-- 执行
function BuffEffectEarningsTimeUpLimitAddValue:DoAction(data)
    BuffEffectBase.DoAction(self)

    local results = self:SearchCampAttackType(self.buffConfig.range)
    local addValue = self.buffConfig.buffValue[1]
    for _, other in pairs(results) do
        if other:IsAlive() then
            local attributeBase = other:GetAttribute(AttributeInfo.Type.PetNestEarningsTimeUpLimit)
            attributeBase:AddPlus(self.attributeKey, addValue)
        end
    end

    self:SetActionObjects(results)
end

function BuffEffectEarningsTimeUpLimitAddValue:Update()
    BuffEffectBase.Update(self)
end

function BuffEffectEarningsTimeUpLimitAddValue:Description(buffConfig)
    --○ui_habitat_attribute_6 栖息地收益上限时间+{time}
    local value = buffConfig.buffValue[1]
    return Runtime.Translate("ui_habitat_attribute_6", {time = tostring(value)})
end

return BuffEffectEarningsTimeUpLimitAddValue