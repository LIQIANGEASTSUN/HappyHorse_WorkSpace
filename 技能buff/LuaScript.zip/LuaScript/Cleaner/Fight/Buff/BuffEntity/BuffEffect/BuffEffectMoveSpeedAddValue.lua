---@type AttributeInfo
local AttributeInfo = require "Cleaner.Fight.Attribute.AttributeInfo"

---@type BuffEffectBase
local BuffEffectBase = require "Cleaner.Fight.Buff.BuffEntity.Base.BuffEffectBase"

-- buff 效果：移动速度增加值
---@class BuffEffectMoveSpeedAddValue:BuffEffectBase
local BuffEffectMoveSpeedAddValue = class(BuffEffectBase, "BuffEffectMoveSpeedAddValue")

function BuffEffectMoveSpeedAddValue:ctor()
    -- 还没有配置，临时值
    self.modifySpeed = 10
end

-- buff 移除触发方法
function BuffEffectMoveSpeedAddValue:Remove()
    BuffEffectBase.Remove(self)

    self:ClearActionObjects(AttributeInfo.Type.MoveSpeed)
end

-- 执行
function BuffEffectMoveSpeedAddValue:DoAction(data)
    BuffEffectBase.DoAction(self)

    -- 现在需要修改 移动速度属性了
    -- 对移动速度属性增加值 number 做修改
    -- 通过公式重新计算 移动熟读属性值

    local results = self:SearchCampAttackType(self.buffConfig.range)
    local addValue = self.buffConfig.buffValue[1]
    for _, other in pairs(results) do
        if other:IsAlive() then
            ---@type AttributeBase
            local attributeBase = other:GetAttribute(AttributeInfo.Type.MoveSpeed)
            attributeBase:AddPlus(self.attributeKey, addValue)
        end
    end

    self:SetActionObjects(results)
end

return BuffEffectMoveSpeedAddValue