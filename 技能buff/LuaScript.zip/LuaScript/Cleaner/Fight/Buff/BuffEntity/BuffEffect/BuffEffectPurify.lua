---@type BuffEffectBase
local BuffEffectBase = require "Cleaner.Fight.Buff.BuffEntity.Base.BuffEffectBase"

-- buff 效果：净化
---@class BuffEffectPurify:BuffEffectBase
local BuffEffectPurify = class(BuffEffectBase, "BuffEffectPurify")

function BuffEffectPurify:ctor()
end

-- 执行
function BuffEffectPurify:DoAction(data)
    BuffEffectBase.DoAction(self)

    self.buffManager:RemoveAllHarmfulBuff()
end

return BuffEffectPurify