---@type AttributeInfo
local AttributeInfo = require "Cleaner.Fight.Attribute.AttributeInfo"

---@type BuffEffectBase
local BuffEffectBase = require "Cleaner.Fight.Buff.BuffEntity.Base.BuffEffectBase"

-- buff 效果：栖息地动物血量增加值
---@class BuffEffectEntityHpAddValue:BuffEffectBase
local BuffEffectEntityHpAddValue = class(BuffEffectBase, "BuffEffectEntityHpAddValue")

function BuffEffectEntityHpAddValue:ctor()
end

-- buff 移除触发方法
function BuffEffectEntityHpAddValue:Remove()
    BuffEffectBase.Remove(self)

    self:ClearActionObjects(AttributeInfo.Type.MaxHp)
end

-- 执行
function BuffEffectEntityHpAddValue:DoAction(data)
    BuffEffectBase.DoAction(self)

    local results = self:SearchCampAttackType(self.buffConfig.range)
    local addValue = self.buffConfig.buffValue[1]
    for _, other in pairs(results) do
        if other:IsAlive() then
            ---@type AttributeBase
            local attributeBase = other:GetAttribute(AttributeInfo.Type.MaxHp)
            attributeBase:AddPlus(self.attributeKey, addValue)
        end
    end

    self:SetActionObjects(results)
end

function BuffEffectEntityHpAddValue:Update()
    BuffEffectBase.Update(self)
end

function BuffEffectEntityHpAddValue:Description(buffConfig)
    -- ○ui_habitat_attribute_3 栖息地内动物血量+{num}
    local value = buffConfig.buffValue[1]
    return Runtime.Translate("ui_habitat_attribute_3", {num = tostring(value)})
end

return BuffEffectEntityHpAddValue