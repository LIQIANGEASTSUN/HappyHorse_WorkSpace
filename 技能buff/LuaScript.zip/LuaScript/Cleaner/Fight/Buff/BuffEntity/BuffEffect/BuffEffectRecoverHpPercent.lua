---@type BuffEffectBase
local BuffEffectBase = require "Cleaner.Fight.Buff.BuffEntity.Base.BuffEffectBase"

-- buff 效果：恢复血量百分比
---@class BuffEffectRecoverHpPercent:BuffEffectBase
local BuffEffectRecoverHpPercent = class(BuffEffectBase, "BuffEffectRecoverHpPercent")

function BuffEffectRecoverHpPercent:ctor()
end

-- 执行
function BuffEffectRecoverHpPercent:DoAction(data)
    BuffEffectBase.DoAction(self)

    local results = self:SearchCampAttackType(self.buffConfig.range)
    local percent = self.buffConfig.buffValue[1]

    for _, other in pairs(results) do
        if other:IsAlive() then
            local recoverHp = percent * other:GetMaxHp()
            AppServices.DamageController:BuffRecoverHp(self.owner, self, recoverHp, other)
        end
    end
end

function BuffEffectRecoverHpPercent:Update()
    BuffEffectBase.Update(self)
end

return BuffEffectRecoverHpPercent