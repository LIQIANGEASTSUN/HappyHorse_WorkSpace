---@type AttributeInfo
local AttributeInfo = require "Cleaner.Fight.Attribute.AttributeInfo"

---@type BuffEffectBase
local BuffEffectBase = require "Cleaner.Fight.Buff.BuffEntity.Base.BuffEffectBase"

-- buff 效果：栖息地每分钟收益增加百分比
---@class BuffEffectEarningsAddPercent:BuffEffectBase
local BuffEffectEarningsAddPercent = class(BuffEffectBase, "BuffEffectEarningsAddPercent")

function BuffEffectEarningsAddPercent:ctor()
end

-- buff 移除触发方法
function BuffEffectEarningsAddPercent:Remove()
    BuffEffectBase.Remove(self)

    self:ClearActionObjects(AttributeInfo.Type.PetNestEarnings)
end

-- 执行
function BuffEffectEarningsAddPercent:DoAction(data)
    BuffEffectBase.DoAction(self)

    local results = self:SearchCampAttackType(self.buffConfig.range)
    local addValue = self.buffConfig.buffValue[1]
    local percent = addValue * 0.01 + 1
    for _, other in pairs(results) do
        if other:IsAlive() then
            ---@type AttributeBase
            local attributeBase = other:GetAttribute(AttributeInfo.Type.PetNestEarnings)
            attributeBase:AddMultiply(self.attributeKey, percent)
        end
    end

    self:SetActionObjects(results)
end

function BuffEffectEarningsAddPercent:Update()
    BuffEffectBase.Update(self)
end

function BuffEffectEarningsAddPercent:Description(buffConfig)
    -- ○ui_habitat_attribute_2 栖息地每分钟收益+{num}
    local value = string.format("%d%s", buffConfig.buffValue[1], "%")
    return Runtime.Translate("ui_habitat_attribute_2", {num = value})
end

return BuffEffectEarningsAddPercent