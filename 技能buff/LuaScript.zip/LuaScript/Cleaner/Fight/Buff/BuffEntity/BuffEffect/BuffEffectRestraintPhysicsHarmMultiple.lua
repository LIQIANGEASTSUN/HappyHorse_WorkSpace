---@type AttributeInfo
local AttributeInfo = require "Cleaner.Fight.Attribute.AttributeInfo"

---@type BuffEffectBase
local BuffEffectBase = require "Cleaner.Fight.Buff.BuffEntity.Base.BuffEffectBase"

-- buff 效果：物种克制物理伤害倍数
---@class BuffEffectRestraintPhysicsHarmMultiple:BuffEffectBase
local BuffEffectRestraintPhysicsHarmMultiple = class(BuffEffectBase, "BuffEffectRestraintPhysicsHarmMultiple")

function BuffEffectRestraintPhysicsHarmMultiple:ctor()
    self:Init()
end

function BuffEffectRestraintPhysicsHarmMultiple:Init()
    -- 克制属性
    self.restraintSpecies = self.buffConfig.buffValue[1]
    -- 伤害倍数
    self.selfharmMultiples = self.buffConfig.buffValue[2]
end

-- buff 移除触发方法
function BuffEffectRestraintPhysicsHarmMultiple:Remove()
    BuffEffectBase.Remove(self)

    -- 现在要移除 buff 了
    -- 如果这个buff 触发了，并且修改了 移动速度属性了
    -- 对移动速度属性增加值 number 做修改
    -- 通过公式重新计算 移动读属性值

    local attributeBase = self:GetAttribute(AttributeInfo.Type.Attack)
    attributeBase:RemoveItem(self.attributeKey)
end

-- 执行
function BuffEffectRestraintPhysicsHarmMultiple:DoAction(data)
    BuffEffectBase.DoAction(self, data)

    ---@type FightUnitBase
    local other = data.other
    if not data or not other or not other:IsAlive() then
        return
    end

    local campRelation = self.buffConfig.camp

    local selfCamp = self.owner:GetCamp()
    local otherCamp = other:GetCamp()
    local isSelf = self.owner:GetInstanceId() == other:GetInstanceId()
    -- buff 作用的阵营关系
    local value = CampType.IsValidCampRelation(campRelation, selfCamp, otherCamp, isSelf)
    if not value then
        return
    end

    -- 克制的属性
    local otherSpeciesType = other:GetSpeciesType()
    if not otherSpeciesType or self.restraintSpecies ~= otherSpeciesType then
        return
    end

    ---@type AttributeBase
    local attributeBase = self:GetAttribute(AttributeInfo.Type.Attack)
    if not attributeBase then
        return
    end
    attributeBase:AddMultiply(self.attributeKey, self.selfharmMultiples)
end

return BuffEffectRestraintPhysicsHarmMultiple