---@type AttributeInfo
local AttributeInfo = require "Cleaner.Fight.Attribute.AttributeInfo"

---@type BuffEffectBase
local BuffEffectBase = require "Cleaner.Fight.Buff.BuffEntity.Base.BuffEffectBase"

-- buff 效果：栖息地动物攻击增加值
---@class BuffEffectEntityAttackAddValue:BuffEffectBase
local BuffEffectEntityAttackAddValue = class(BuffEffectBase, "BuffEffectEntityAttackAddValue")

function BuffEffectEntityAttackAddValue:ctor()
end

-- buff 移除触发方法
function BuffEffectEntityAttackAddValue:Remove()
    BuffEffectBase.Remove(self)

    self:ClearActionObjects(AttributeInfo.Type.Attack)
end

-- 执行
function BuffEffectEntityAttackAddValue:DoAction(data)
    BuffEffectBase.DoAction(self)

    local results = self:SearchCampAttackType(self.buffConfig.range)
    local addValue = self.buffConfig.buffValue[1]
    for _, other in pairs(results) do
        if other:IsAlive() then
            local attributeBase = other:GetAttribute(AttributeInfo.Type.Attack)
            attributeBase:AddPlus(self.attributeKey, addValue)
        end
    end

    self:SetActionObjects(results)
end

function BuffEffectEntityAttackAddValue:Update()
    BuffEffectBase.Update(self)
end

function BuffEffectEntityAttackAddValue:Description(buffConfig)
    -- ○ui_habitat_attribute_4 栖息地内动物攻击+{num}
    local value = buffConfig.buffValue[1]
    return Runtime.Translate("ui_habitat_attribute_4", {num = tostring(value)})
end

return BuffEffectEntityAttackAddValue