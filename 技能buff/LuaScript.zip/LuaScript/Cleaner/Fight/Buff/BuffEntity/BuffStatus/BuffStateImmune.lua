---@type BuffInfo
local BuffInfo = require "Cleaner.Fight.Buff.BuffInfo"

---@type BuffStateBase
local BuffStateBase = require "Cleaner.Fight.Buff.BuffEntity.Base.BuffStateBase"

-- buff 状态：免疫
---@class BuffStateImmune
local BuffStateImmune = class(BuffStateBase, "BuffStateImmune")

function BuffStateImmune:ctor()
    self.buffType = BuffInfo.BuffType.SuperArmor

    self:Init()
end

function BuffStateImmune:Init()

end

function BuffStateImmune:EnableAddBuff(buffId)
    local buffConfig = AppServices.Meta:Category("BuffTemplate")[buffId]
    local advantage = buffConfig.advantage
    if advantage == BuffInfo.AdvantageType.Helpful then
        return true
    elseif advantage == BuffInfo.AdvantageType.Harmful then
        return false
    end
    return false
end

-- 执行
function BuffStateImmune:DoAction(data)
    BuffStateBase.DoAction(self, data)
end

return BuffStateImmune