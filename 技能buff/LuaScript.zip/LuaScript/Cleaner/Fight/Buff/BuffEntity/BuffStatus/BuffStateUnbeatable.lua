---@type AttributeInfo
local AttributeInfo = require "Cleaner.Fight.Attribute.AttributeInfo"

---@type BuffInfo
local BuffInfo = require "Cleaner.Fight.Buff.BuffInfo"

---@type BuffStateBase
local BuffStateBase = require "Cleaner.Fight.Buff.BuffEntity.Base.BuffStateBase"

-- buff 状态：无敌
---@class BuffStateUnbeatable
local BuffStateUnbeatable = class(BuffStateBase, "BuffStateUnbeatable")

function BuffStateUnbeatable:ctor()
    self.buffType = BuffInfo.BuffType.Unbeatable
end

function BuffStateUnbeatable:GetAttribute()
    local attributeManager = self.owner:GetAttributeManager()
    local attributeBase = attributeManager:GetAttribute(AttributeInfo.Type.Shield)
    return attributeBase
end

-- buff 移除触发方法
function BuffStateUnbeatable:Remove()
    BuffStateBase.Remove(self)
end

-- 执行
function BuffStateUnbeatable:DoAction(data)
    BuffStateBase.DoAction(self)

    local attributeBase = self:GetAttribute()
    attributeBase:SetDisableAttack()
end

return BuffStateUnbeatable