---@type BuffInfo
local BuffInfo = require "Cleaner.Fight.Buff.BuffInfo"

---@type BuffStateBase
local BuffStateBase = require "Cleaner.Fight.Buff.BuffEntity.Base.BuffStateBase"

-- buff 状态：霸体
---@class BuffStateSuperArmor
local BuffStateSuperArmor = class(BuffStateBase, "BuffStateSuperArmor")

function BuffStateSuperArmor:ctor()
    self.buffType = BuffInfo.BuffType.SuperArmor

    self:Init()
end

function BuffStateSuperArmor:Init()

end

-- 执行
function BuffStateSuperArmor:DoAction(data)
    BuffStateBase.DoAction(self, data)
end

return BuffStateSuperArmor