
---@type EffectEntity
local EffectEntity = require "Cleaner.Effect.EffectEntity"

---@type EffectInfo
local EffectInfo = require "Cleaner.Effect.EffectInfo"

---@type EffectManager
local EffectManager = {
    effectMap = {},
    instanceId = 0
}

-- 在世界坐标位置播放特效
function EffectManager:Play(effectName, position)
    local id = self:NewInstanceId()
    local data = {
        type = EffectInfo.WorldPosition,
        effectName = effectName,
        position = position
    }

    local effect = EffectEntity.new(id, data)
    self:AddEffect(effect)
    return effect
end

-- 按照 Transform 局部坐标播放特效
function EffectManager:PlayTargetLocal(effectName, targetTr, localPosition, follow)
    local id = self:NewInstanceId()

    local data = {
        type = EffectInfo.TargetLocal,
        effectName = effectName,
        targetTr = targetTr,
        localPosition = localPosition,
        follow = follow
    }

    local effect = EffectEntity.new(id, data)
    self:AddEffect(effect)
    return effect
end

-- 根据 Transfor 骨骼位置播放特效
function EffectManager:PlayTargetBone(effectName, targetTr, bone, follow)
    local id = self:NewInstanceId()

    local data = {
        type = EffectInfo.TargetBone,
        effectName = effectName,
        targetTr = targetTr,
        bone = bone,
        follow = follow
    }

    local effect = EffectEntity.new(id, data)
    self:AddEffect(effect)
    return effect
end

function EffectManager:AddEffect(effect)
    local instanceId = effect:GetInstanceId()
    self.effectMap[instanceId] = effect
end

function EffectManager:RemoveEffect(instanceId)
    local effect = self.effectMap[instanceId]
    if effect then
        effect:Destroy()
        self.effectMap[instanceId] = nil
    end
end

function EffectManager:RemoveAll()
    for _, effect in pairs(self.effectMap) do
        effect:Destroy()
    end
    self.effectMap = {}
end

function EffectManager:NewInstanceId()
    self.instanceId = self.instanceId + 1
    return self.instanceId
end

function EffectManager:Release()
    self:RemoveAll()
end

return EffectManager