---@class AutoJump
local AutoJump = {}

---跳转任务
function AutoJump.JumpTask(taskSn)
    AppServices.JumpTask.JumpByTaskSn(taskSn)
end

local _moveCameraDurationDefault = 0.5
---@param agent BaseAgent
function AutoJump.FocusAgent(agent, callback, moveCameraDuration)
    if not agent then
        return
    end
    local inIsland = AppServices.IslandManager:InIsland()
    if inIsland then
        AutoJump.FocusAgentIsland(agent, callback, moveCameraDuration)
    else
        AutoJump.FocusAgentHome(agent, callback, moveCameraDuration)
    end
end

function AutoJump.FocusAgentHome(agent, callback, moveCameraDuration)
    local pos = agent:GetAnchorPosition(true)
    MoveCameraLogic.Instance():MoveCameraToLook2(pos, moveCameraDuration or _moveCameraDurationDefault, nil, callback)
end

function AutoJump.FocusAgentIsland(agent, callback, moveCameraDuration)
    local pos = agent:GetAnchorPosition(true)
    local oldPos = MoveCameraLogic.Instance():GetCameraPosition()
    MessageDispatcher:SendMessage(MessageType.Camera_Follow_Player, false)
    local cbk = function()
        Util.BlockAll(1, 'AutoJump.FocusAgent')
        WaitExtension.SetTimeout(function()
            Util.BlockAll(0, 'AutoJump.FocusAgent')
            MoveCameraLogic.Instance():MoveCameraToLook2(oldPos, moveCameraDuration or _moveCameraDurationDefault, nil, function()
                MessageDispatcher:SendMessage(MessageType.Camera_Follow_Player, true)
                Runtime.InvokeCbk(callback)
            end)
        end, 1)
    end
    MoveCameraLogic.Instance():MoveCameraToLook2(pos, moveCameraDuration or 0.5, nil, cbk)
end

function AutoJump.FindFactoryByItemId(itemId)
    local cfgs = AppServices.Meta:Category("BuildingLevelTemplate")
    local agent = nil
    local buildTemplateId = -1
    for _, cfg in pairs(cfgs) do
        for _, item in ipairs(cfg.production) do
            if item[1] == itemId then
                agent = AutoJump.FindLinkHomeAgent(cfg.building)
                buildTemplateId = cfg.building
                local validState = agent:GetState() >= CleanState.clearing
                if agent and agent:IsInHomeland() and validState then
                    return agent, buildTemplateId
                end
            end
        end
    end

    return agent, buildTemplateId
end

function AutoJump.FindLinkHomeAgent(templeteId)
    local agent = App.scene.objectManager:GetAgentByTemplateId(templeteId)
    if not agent or agent:GetState() < CleanState.clearing then
        return nil
    end

    if not agent:IsInHomeland() then
        return nil
    end
    return agent
end

function AutoJump.JumpFoodFactoryByItemId(itemId)
    local agent, buildTemplateId = AutoJump.FindFactoryByItemId(itemId)
    if not agent then
        local cfg = AppServices.Meta:Category("BuildingLevelTemplate")[tostring(buildTemplateId)]
        if not cfg then
            local msg = string.format("配置错误:%d", itemId)
            AppServices.UITextTip:Show(msg)
            console.error("JumpFoodFactoryByItemId:"..msg)
            return
        end
        local buildingName = Runtime.Translate(cfg.name)
        local msg = Runtime.Translate("tip_itemGetway_noBuilding", {buildingName = buildingName})
        AppServices.UITextTip:Show(msg)
        return
    end

    local moveCallBack = function()
        PanelManager.closeAllPanels()
        local arguments = {id = agent:GetId(), sn = agent:GetTemplateId()}
        PanelManager.showPanel(GlobalPanelEnum.FoodFactoryPanel, arguments)
    end
    AutoJump.FocusAgent(agent, moveCallBack, 0.5)
end

function AutoJump.JumpFactoryByItemId(itemId)
    local agent = AutoJump.FindFactoryByItemId(itemId)
    if not agent then
        return
    end
    agent:ProcessClick()
end

function AutoJump.JumpDecorationFactory()
    local agent = App.scene.objectManager:GetAgentByType(AgentType.decoration_factory)
    if not agent or agent:GetState() < CleanState.clearing then
        return
    end

    local moveCallBack = function()
        agent:ProcessClick()
    end
    AutoJump.FocusAgent(agent, moveCallBack, 0.5)
end

function AutoJump.JumpRecycle()
    local agent = App.scene.objectManager:GetAgentByType(AgentType.recycle)
    if not agent or agent:GetState() < CleanState.clearing then
        return
    end
    agent:ProcessClick()
end

function AutoJump.JumpDock()
    -- local agent = App.scene.objectManager:GetAgentByType(AgentType.dock)
    -- if not agent or agent:GetState() < CleanState.clearing then
    --     return
    -- end
    -- agent:ProcessClick()
    PanelManager.showPanel(GlobalPanelEnum.ShipSailingPanel)
end

---@param shopType number 数字1 钻石商城, 2 付费商城
---@param panelEnum GlobalPanelEnum 打开商店界面的来源
---@param callback function 商店关闭后的回调
function AutoJump.JumpShop(shopType, panelEnum, callback, failCallBack, isShowAll, horizontalNormalizedPosition)
    local shopsName = {
        [1] = MoneyShopPage.Coin, --钻石商城
        [2] = MoneyShopPage.Diamond --付费商城
    }

    if not failCallBack then
        PanelManager.closeAllPanels()
    end

    local function showShopPanel()
        require("Game.Processors.RequestIAPProcessor").Start(function()
            PanelManager.showPanel(
                GlobalPanelEnum.ShopPanel,
                {
                    selectIndex = shopsName[shopType],
                    source = panelEnum and panelEnum.panelName,
                    afterShopCallback = callback,
                    isShowAll = isShowAll,
                    horizontalNormalizedPosition = horizontalNormalizedPosition
                },
                PanelCallbacks:Create(
                    function()
                        Runtime.InvokeCbk(callback)
                    end
                )
            )
		end)
    end

    --付费商店需判定是否打开
    if shopType == 2 then
        require("Game.Processors.RequestIAPProcessor").Start(
            function()
                showShopPanel()
            end,
            function()
                Runtime.InvokeCbk(failCallBack)
            end
        )
    else
        showShopPanel()
    end
end

function AutoJump.JumpLinkIsland()
    local inIsland, region_id = AppServices.IslandManager:InIsland()
    if not inIsland then
        AutoJump.JumpDock()
        return
    end

    local regionMgr = App.scene.mapManager and App.scene.mapManager.regionManager

    local region = regionMgr and regionMgr:FindRegion(region_id)
    if region then
        local agents = region:FindAllAgents()
        for _, agent in pairs(agents) do
            local agentType = agent:GetType()
            if (agentType == AgentType.ground or agentType == AgentType.linkHomeland_groud) and agent:Suckable() then
                return AutoJump.FocusAgent(agent)
            end
        end
    end
    local str = Runtime.Translate"tip_linkHome_bossNoDead"
    AppServices.UITextTip:Show(str)
end

function AutoJump.JumpGoIsland(islandId, str)
    local inIsland = AppServices.IslandManager:InIsland()
    if not inIsland then
        AutoJump.JumpDock()
        return
    end
    str = str or Runtime.Translate'tip_task_arriveIsland'
    AppServices.UITextTip:Show(str)
end

function AutoJump.JumpFactoryLevelUp(factorySn)
    local inIsland = AppServices.IslandManager:InIsland()
    if inIsland then
        local str = Runtime.Translate"tip_task_buildingLevel"
        AppServices.UITextTip:Show(str)
        return
    end
    local agent = App.scene.objectManager:GetAgentByTemplateId(factorySn)
    if agent then
        AutoJump.FocusAgent(agent, function()
            agent:ShowUpLevelPanel()
        end)
    end
end

---跳转宠物挂机任务
function AutoJump.JumpPetHLActionHook(buildingSn)
    local inIsland = AppServices.IslandManager:InIsland()
    local cfg = AppServices.Meta:GetBindingMeta(buildingSn)
    if inIsland then
        local str = Runtime.Translate("tip_task_ildeBuilding_island",
            {idleBuildingName = Runtime.Translate(cfg.name)})
        AppServices.UITextTip:Show(str)
        return
    end
    local agent = App.scene.objectManager:GetAgentByTemplateId(buildingSn)
    if agent and agent:CanBeSeen() and agent:IsInHomeland() then
        agent:ProcessClick()
    else
        local str = Runtime.Translate"tip_task_ildeBuilding_home"
        AppServices.UITextTip:Show(str)
    end
end

return AutoJump