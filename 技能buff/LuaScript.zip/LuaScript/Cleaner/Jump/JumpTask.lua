---@class JumpTask 跳转任务
local JumpTask = {}

JumpTask.JumpCondition = {
    [TaskEnum.LevelUp] = function()
        local str = Runtime.Translate("tip_task_roleLevel")
        AppServices.UITextTip:Show(str)
    end,
    [TaskEnum.GetPet] = function()
        local str = Runtime.Translate("tip_task_petType")
        AppServices.UITextTip:Show(str)
    end,
    [TaskEnum.HavePet] = function()
        local str = Runtime.Translate("tip_task_havePet")
        AppServices.UITextTip:Show(str)
    end,
    [TaskEnum.PetLevel] = function()
        PanelManager.showPanel(GlobalPanelEnum.PetIllustratedPanel)
    end,
    [TaskEnum.ProductItem] = function(cfg)
        local itemId = cfg.args and cfg.args[1]
        AppServices.Jump.JumpFactoryByItemId(itemId)
    end,
    [TaskEnum.ProductDecoration] = function()
        AppServices.Jump.JumpDecorationFactory()
    end,
    [TaskEnum.LinkIsland] = function()
        AppServices.Jump.JumpLinkIsland()
    end,
    [TaskEnum.RecycleItem] = function()
        AppServices.Jump.JumpRecycle()
    end,
    [TaskEnum.GetItem] = function()
        local str = Runtime.Translate('tip_task_collectItem')
        AppServices.UITextTip:Show(str)
    end,
    [TaskEnum.FindAgent] = function(cfg)
        --探索小岛即可发现{factoryName}
        local str = Runtime.Translate('tip_task_findBuilding')
        AppServices.UITextTip:Show(str)
    end,
    [TaskEnum.KillMonster] = function(cfg)
        --探索小岛即可发现{factoryName}
        local str = Runtime.Translate('tip_task_beatMonster')
        AppServices.UITextTip:Show(str)
    end,
    [TaskEnum.GoIsland] = function(cfg)
        AppServices.Jump.JumpGoIsland(cfg.args[1])
    end,
    [TaskEnum.IslandComplete] = function(cfg)
        AppServices.Jump.JumpGoIsland(cfg.args[1])
    end,
    [TaskEnum.BuildingLevelup] = function(cfg)
        AppServices.Jump.JumpFactoryLevelUp(cfg.args[1])
    end,
    [TaskEnum.VaccumUpgraded] = function(cfg)
        PanelManager.showPanel(GlobalPanelEnum.VaccumCleanerUpgradePanel)
    end,
    [TaskEnum.PetHLActionHook] = function(cfg)
        AppServices.Jump.JumpPetHLActionHook(cfg.args[1])
    end,
}

function JumpTask.JumpByTaskSn(taskSn)
    local cfg = AppServices.Task:GetConfigBySn(taskSn)
    local taskEnum = cfg.taskEnum
    return JumpTask.JumpCondition[taskEnum](cfg)
end

return JumpTask