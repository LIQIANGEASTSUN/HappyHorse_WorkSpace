--@type UnitBase
local UnitBase = require "Cleaner.Unit.Base.UnitBase"

--- Agent 通用没有特殊功能的 Unit
---@class AgentCommonUnit:UnitBase
local AgentCommonUnit = class(UnitBase, "AgentCommonUnit")

function AgentCommonUnit:ctor(agent)
    self.agent = agent
    -- agetn 唯一 id
    self.id = agent:GetId()
    self.data = agent:GetData()
    self:SetUseUpdate(true)
    self:SetUnitType(UnitType.AgentCommonUnit)
end

function AgentCommonUnit:GetPosition()
    local go = self.agent:GetGameObject()
    if Runtime.CSValid(go) then
        return go.transform.position
    end
    return Vector3(0, 0, 0)
end

function AgentCommonUnit:GetAnchorPosition(value)
    return self.agent:GetAnchorPosition(value)
end

function AgentCommonUnit:Update()
    UnitBase.Update(self)
end

function AgentCommonUnit:Remove()
    UnitBase.Remove(self)
end

function AgentCommonUnit:ShowTips(tipsType, data)
    UnitBase.ShowTips(self, tipsType, data)
end

function AgentCommonUnit:HideTips(tipsType)
    UnitBase.HideTips(self, tipsType)
end

function AgentCommonUnit:RemoveTipsAll()
    UnitBase.RemoveTipsAll(self)
end

function AgentCommonUnit:GetMark()
    local mark = string.format("AgentUnit_%s", tostring(self.id))
    return mark
end

return AgentCommonUnit