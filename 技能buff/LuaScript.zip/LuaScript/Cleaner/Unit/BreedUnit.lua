local AgentCommonUnit = require "Cleaner.Unit.AgentCommonUnit"

---@class BreedUnit:AgentCommonUnit
local BreedUnit = class(AgentCommonUnit, "BreedUnit")

function BreedUnit:ctor(agent)
    self.agent = agent
    self:SetUnitType(UnitType.BreedUnit)
    self:RegisgerEvent()
    self:InitState()
end

function BreedUnit:InitState()
    local id = AppServices.BreedManager:GetBreedAnimalID()
    if id then
        local t = AppServices.BreedManager:GetBreedsIsFinish()
        if t then
            self:OnChangeBreedState(ProductionStatus.Finish)
        else
            self:OnChangeBreedState(ProductionStatus.Doing)
        end
    end
end

-- 点击了 Tips
function BreedUnit:UnitTipsClick(unitId, tipsType)
    local callback = function()
        if self.instanceId ~= unitId then
            return
        end
        if self.breedState == ProductionStatus.None then
            -- DOTO 正常
            PanelManager.showPanel(GlobalPanelEnum.BreedPanel)
        elseif self.breedState == ProductionStatus.Doing then
            -- DOTO 繁育进行中
            PanelManager.showPanel(GlobalPanelEnum.BreedDoingPanel)
        elseif self.breedState == ProductionStatus.Finish then
            -- DOTO 领取界面
            local nid = AppServices.BreedManager:GetBreedOnlyID()
            if nid then
                AppServices.NetBuildingManager:SendPetBreedReward(nid)
            end
        end
    end
    AppServices.BreedManager:OnShowBreedPanel(self.agent:GetId(), callback)
end

function BreedUnit:Remove()
    AgentCommonUnit.Remove(self)
    self:UnRegisterEvent()
end

--  设置显示新图标
function BreedUnit:ShowNewTab()
    AppServices.UnitTipsManager:ShowTips(self.instanceId, TipsType.UnitBreedNewTips)
end

-- 繁育状态的切换
function BreedUnit:OnChangeBreedState(state)
    AppServices.UnitTipsManager:RemoveTips(self.instanceId, TipsType.UnitBreedNewTips)
    AppServices.UnitTipsManager:RemoveTips(self.instanceId, TipsType.UnitBreedFinishTips)
    AppServices.UnitTipsManager:RemoveTips(self.instanceId, TipsType.UnitBreedDoingTips)
    if self.breedState == state then
        return
    end
    self.breedState = state
    if state == ProductionStatus.None then
    elseif state == ProductionStatus.Doing then
        AppServices.UnitTipsManager:ShowTips(self.instanceId, TipsType.UnitBreedDoingTips)
    elseif state == ProductionStatus.Finish then
        AppServices.UnitTipsManager:ShowTips(self.instanceId, TipsType.UnitBreedFinishTips)
    end
end

function BreedUnit:RegisgerEvent()
    MessageDispatcher:AddMessageListener(MessageType.UnitTipsClick, self.UnitTipsClick, self)
    MessageDispatcher:AddMessageListener(MessageType.OnBreedUnLock, self.ShowNewTab, self)
    MessageDispatcher:AddMessageListener(MessageType.OnStartBreed, self.OnChangeBreedState, self)
end

function BreedUnit:UnRegisterEvent()
    MessageDispatcher:RemoveMessageListener(MessageType.UnitTipsClick, self.UnitTipsClick, self)
    MessageDispatcher:RemoveMessageListener(MessageType.OnBreedUnLock, self.ShowNewTab, self)
    MessageDispatcher:RemoveMessageListener(MessageType.OnStartBreed, self.OnChangeBreedState, self)
end

return BreedUnit
