local AgentCommonUnit = require "Cleaner.Unit.AgentCommonUnit"

---@class DressUpUnit:AgentCommonUnit
local DressUpUnit = class(AgentCommonUnit, "DressUpUnit")

function DressUpUnit:ctor(agent)
    self:SetUnitType(UnitType.DressUpUnit)
    self:RegisgerEvent()
end

-- 点击了 Tips
function DressUpUnit:UnitTipsClick(unitId, tipsType)
    if self.instanceId ~= unitId then
        return
    end
    PanelManager.showPanel(GlobalPanelEnum.DressUpPanel)
    AppServices.UnitTipsManager:HideTips(self.instanceId, TipsType.UnitDressNewTips)
end

function DressUpUnit:Remove()
    AgentCommonUnit.Remove(self)
    self:UnRegisterEvent()
end

--  设置显示新图标
function DressUpUnit:ShowNewTab()
    -- DOTO 显示new的tip
    AppServices.UnitTipsManager:ShowTips(self.instanceId, TipsType.UnitDressNewTips)
end

function DressUpUnit:RegisgerEvent()
    MessageDispatcher:AddMessageListener(MessageType.UnitTipsClick, self.UnitTipsClick, self)
end

function DressUpUnit:UnRegisterEvent()
    MessageDispatcher:RemoveMessageListener(MessageType.UnitTipsClick, self.UnitTipsClick, self)
end

return DressUpUnit
