local FightUnitBase = require "Cleaner.Unit.FightUnitBase"

---@class FightUnitAgent:FightUnitBase
local FightUnitAgent = class(FightUnitBase, "FightUnitAgent")

function FightUnitAgent:ctor(owner)
    ---@type BaseAgent
    self.agent = owner
    self.id = self.agent:GetId()
end

function FightUnitAgent:GetSn()
    return self.agent.data:GetTemplateId()
end

function FightUnitAgent:GetPosition()
    return self.agent:GetWorldPosition()
end

function FightUnitAgent:GetAnchorPosition(value)
    return self.agent:GetAnchorPosition(value)
end

function FightUnitAgent:GetTransform()
    return self.agent:GetGameObject().transform
end

function FightUnitAgent:EnableAttack()
    return self.enableAttack
end

function FightUnitAgent:GetMark()
    local mark = string.format("AgentUnit_%s", tostring(self.id))
    return mark
end

return FightUnitAgent