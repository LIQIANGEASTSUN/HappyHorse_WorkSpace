local AgentCommonUnit = require "Cleaner.Unit.AgentCommonUnit"

---@class BuildUpLevelUnit:AgentCommonUnit
local BuildUpLevelUnit = class(AgentCommonUnit, "BuildUpLevelUnit")

function BuildUpLevelUnit:ctor(agent)
    self:SetUnitType(UnitType.BuildUpLevelUnit)
    self:RegisgerEvent()
    self:SetUseUpdate(false)

    self.showArrow = false
    self.lastTime = -10
    self.INTERVAL_TIME = 10
end

-- 点击了 Tips
function BuildUpLevelUnit:UnitTipsClick(unitId, tipsType)
    if self.instanceId ~= unitId then
        return
    end

end

function BuildUpLevelUnit:Update()
    AgentCommonUnit.Update(self)
    self:CheckUp()
end

function BuildUpLevelUnit:CheckUp()
    if Time.realtimeSinceStartup - self.lastTime < self.INTERVAL_TIME then
        return
    end

    local level = self.agent.data:GetLevel()
    local sn = self.agent:GetTemplateId()
    local config = AppServices.BuildingLevelTemplateTool:GetConfig(sn, level)
    local result = AppServices.BuildingLevelTemplateTool:EnableUp(config)
    if result == UpgradeEnableType.Enable then
        AppServices.UnitTipsManager:ShowTips(self.instanceId, TipsType.UnitBuildingUpLevel)
    else
        AppServices.UnitTipsManager:RemoveTips(self.instanceId, TipsType.UnitBuildingUpLevel)
    end
end

function BuildUpLevelUnit:GetAnchorPosition(value)
    local anchorPos = AgentCommonUnit.GetAnchorPosition(self, value)
    local anchorOffset = self:GetAnchorOffset()
    return anchorPos + anchorOffset
end

function BuildUpLevelUnit:GetAnchorOffset()
    return self.anchorOffset or Vector3.zero
end
function BuildUpLevelUnit:SetAnchorOffset(anchorOffset)
    self.anchorOffset = anchorOffset
end

function BuildUpLevelUnit:Remove()
    AgentCommonUnit.Remove(self)
    self:UnRegisterEvent()
end

function BuildUpLevelUnit:RegisgerEvent()
    MessageDispatcher:AddMessageListener(MessageType.UnitTipsClick, self.UnitTipsClick, self)
end

function BuildUpLevelUnit:UnRegisterEvent()
    MessageDispatcher:RemoveMessageListener(MessageType.UnitTipsClick, self.UnitTipsClick, self)
end

return BuildUpLevelUnit