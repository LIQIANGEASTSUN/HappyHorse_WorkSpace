
---@class UnitBase
local UnitBase = class(nil, "UnitBase")

function UnitBase:ctor(owner)
    self.instanceId = -1
    self.unitType = UnitType.None
    self.useUpdate = false

    local instanceId = AppServices.UnitManager:NewInstanceId()
    self:SetInstanceId(instanceId)
end

function UnitBase:SetInstanceId(instanceId)
    self.instanceId = instanceId
end

function UnitBase:GetInstanceId()
    return self.instanceId
end

function UnitBase:SetUnitType(unitType)
    self.unitType = unitType
end

function UnitBase:GetUnitType()
    return self.unitType
end

function UnitBase:SetUseUpdate(value)
    self.useUpdate = value
end

function UnitBase:GetMark()
    local mark = string.format("Unit_%s", tostring(self.instanceId))
    return mark
end

function UnitBase:GetUseUpdate()
    return self.useUpdate
end

function UnitBase:GetPosition()
    return Vector3(0, 0, 0)
end

function UnitBase:GetAnchorPosition(value)
    return Vector3(0, 0, 0)
end

function UnitBase:IsAlive()
    return true
end

function UnitBase:Update()

end

function UnitBase:Remove()
    self:RemoveTipsAll()
end

function UnitBase:ShowTips(tipsType, data)
    AppServices.UnitTipsManager:ShowTips(self.instanceId, tipsType, data)
end

function UnitBase:HideTips(tipsType)
    AppServices.UnitTipsManager:HideTips(self.instanceId, tipsType)
end

function UnitBase:RemoveTipsAll()
    AppServices.UnitTipsManager:RemoveTipsAll(self.instanceId)
end

return UnitBase