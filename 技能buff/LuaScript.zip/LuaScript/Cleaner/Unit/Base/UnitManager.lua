---@type UnitManager
local UnitManager = {
    instanceId = 0,
    ---@type Dictionary<int, UnitBase> int:instanceId
    unitMap = {},
    ---@type Dictionary<int, List<UnitBase>> int:unitType
    unitTypeMap = {},
    -- 记录需要Update 的 Unit
    unitUpdateMap = {}
}

function UnitManager:Init()
    self:RegisterEvents()
end

function UnitManager:AddUnit(unitBase)
    if not unitBase then
        return
    end

    local instanceId = unitBase:GetInstanceId()
    self.unitMap[instanceId] = unitBase

    local unitType = unitBase:GetUnitType()
    local typeList = self.unitTypeMap[unitType]
    if not typeList then
        typeList = {}
        self.unitTypeMap[unitType] = typeList
    end
    typeList[instanceId] = unitBase

    if unitBase:GetUseUpdate() then
        self.unitUpdateMap[instanceId] = true
    end
end

function UnitManager:RemoveUnit(unitBase)
    if not unitBase then
        return
    end

    local instanceId = unitBase:GetInstanceId()
    local unitType =  unitBase:GetUnitType()
    unitBase:Remove()
    self.unitMap[instanceId] = nil
    local typeList = self.unitTypeMap[unitType]
    if typeList then
        typeList[instanceId] = nil
    end

    if self.unitUpdateMap[instanceId] then
        self.unitUpdateMap[instanceId] = nil
    end
end

function UnitManager:RemoveUnitWithId(instanceId)
    local unitBase = self:GetUnit(instanceId)
    self:RemoveUnit(unitBase)
end

function UnitManager:RmeoveAll()
    for _, unit in pairs(self.unitMap) do
        unit:Remove()
    end
    self.unitMap = {}
    self.unitTypeMap = {}
    self.unitUpdateMap = {}
end

function UnitManager:GetUnit(instanceId)
    return self.unitMap[instanceId]
end

function UnitManager:GetUnitWithType(unitType)
    local typeList = self.unitTypeMap[unitType]
    typeList = typeList or {}
    return typeList
end

function UnitManager:NewInstanceId()
    self.instanceId = self.instanceId + 1
    return self.instanceId
end

function UnitManager:Update()
    for unitId, _ in pairs(self.unitUpdateMap) do
        local unit = self:GetUnit(unitId)
        if unit then
            unit:Update()
        end
    end
end

function UnitManager:RegisterEvents()
end

function UnitManager:UnRegisterEvent()
end

function UnitManager:Release()
    self:UnRegisterEvent()
    self:RmeoveAll()
end

return UnitManager