---@type PetTemplateTool
local PetTemplateTool = require "Cleaner.Entity.Pet.PetTemplateTool"

---@type UnitBase
local UnitBase = require "Cleaner.Unit.Base.UnitBase"

---@class OnHookBuildUnit:UnitBase
local OnHookBuildUnit = class(UnitBase, "OnHookBuildUnit")

function OnHookBuildUnit:ctor(agent)
    self.agent = agent
    -- agetn 唯一 id
    self.id = agent:GetId()
    self.data = agent:GetData()
    self.bindPetID = nil
    self.level = self.data:GetLevel() or 1
    self.lastTime = 0
    self.petTemplateMeta = AppServices.Meta:Category("PetTemplate")
    self.key = AppServices.BuildingLevelTemplateTool:GetKey(self.data.meta.sn, self.level)
    self.buildingLevelTemplate = AppServices.Meta:Category("BuildingLevelTemplate")[tostring(self.key)]
    self:SetUseUpdate(true)
    self:SetUnitType(UnitType.OnHookBuildUnit)

    self:RegisgerEvent()
end

-- 构建结束之后先调用一次
function OnHookBuildUnit:Init()
    self:OnTickCheckState()
end

function OnHookBuildUnit:ShowNewBuildTip()
    console.jf("... 通知显示新图标的....")
    self:VisibleUnitNewBuildTips(true)
end

function OnHookBuildUnit:SetPetID(petID)
    self.bindPetID = petID
end

--  挂机建筑返回绑定的宠物ID
function OnHookBuildUnit:GetOnHookBindPetID()
    return self.bindPetID
end

-- 通过宠物的类型，返回宠物是否绑定挂机建筑
function OnHookBuildUnit:GetBuildByPetType(_petTyp)
    local retBuild = nil
    if self.bindPetID then
        local petInfo = AppServices.User:GetPet(self.bindPetID)
        local petKey = PetTemplateTool:Getkey(petInfo.type, petInfo.level)
        local strPetKey = tostring(petKey)
        local petTyp = self.petTemplateMeta[strPetKey].type
        if _petTyp == petTyp then
            retBuild = self.agent
        end
    end
    console.jf("...通过宠物的类型，返回宠物是否绑定挂机建筑 ID...", retBuild)
    return retBuild
end

-- function OnHookBuildUnit:ClickMoveCameraFinish()
--     -- local arguments = {id = self.id, sn = self.data.meta.sn}
--     -- PanelManager.showPanel(GlobalPanelEnum.DecorationFactoryPanel, arguments)
-- end

function OnHookBuildUnit:Update()
    if Time.realtimeSinceStartup - self.lastTime < 1 then
        return
    end
    self.lastTime = Time.realtimeSinceStartup
    self:OnTickCheckState()
end

function OnHookBuildUnit:VisibleUnitNewBuildTips(is)
    if is then
        AppServices.UnitTipsManager:ShowTips(self.instanceId, TipsType.UnitNewBuildTips)
        return
    end
    AppServices.UnitTipsManager:RemoveTips(self.instanceId, TipsType.UnitNewBuildTips)
end

-- 每秒检测 生产的状态
function OnHookBuildUnit:OnTickCheckState()
    local status = ProductionStatus.None
    self.id = self.agent:GetId()
    local data = AppServices.User:GetProduction(self.id)
    if data then
        if data.pets then
            self.bindPetID = data.pets[1]
        end
        status = AppServices.User:ProductionStatue(data)
    end
    if status == self.currentStatus then
        return
    end
    self.currentStatus = status
    if status == ProductionStatus.None then
        self:StateChangeToNone()
    elseif status == ProductionStatus.Doing then
        self:StateChangeToDoing()
    elseif status == ProductionStatus.Finish then
        self:StateChangeToFinish()
    end
end

-- 建筑生产数据
function OnHookBuildUnit:CreateProductionData()
    local level = self.data:GetLevel()
    local sn = self.data.meta.sn
    local data = AppServices.BuildingLevelTemplateTool:CreateProductionData(self.id, level, sn)
    return data
end

-- 开始生产
function OnHookBuildUnit:StartTakeProduction()
    console.jf("...挂机建筑...开始生产....self.id：", self.id)
    local data = AppServices.User:GetProduction(self.id)
    if not data then
        data = self:CreateProductionData()
    end
    data.status = ProductionStatus.Doing
    AppServices.User:SetProduction(data)
end

-- 建筑物被点击
function OnHookBuildUnit:OnClick()
    local localFunc = function()
        if self.currentStatus == ProductionStatus.None then
            self:NoneClick()
        elseif self.currentStatus == ProductionStatus.Doing then
            self:DoingClick()
        elseif self.currentStatus == ProductionStatus.Finish then
            self:FinishClick()
        end
    end

    self:PreventClick(localFunc)
end

function OnHookBuildUnit:PreventClick(func)
    if self.clicked then
        return
    end
    self.clicked = true
    func()
    WaitExtension.SetTimeout(
        function()
            self.clicked = false
        end,
        1.5
    )
end

-- 建筑Tip被点击
function OnHookBuildUnit:UnitTipsClick(unitId, tipsType)
    if self.instanceId ~= unitId then
        return
    end

    local localFunc = function()
        if tipsType == TipsType.UnitOnHookBuildProductDoingTips then
            self:DoingClick()
        elseif tipsType == TipsType.UnitOnHookBuildProductFinishTips then
            self:FinishClick()
        elseif tipsType == TipsType.UnitNewBuildTips then
            self:NoneClick()
        end
    end

    self:PreventClick(localFunc)
end

function OnHookBuildUnit:NoneClick()
    -- 建筑ID
    local nBuildID = self.data.mapData.tid
    self.id = self.agent:GetId()
    if not nBuildID then
        console.error("...OnHookBuildAgent data 中没有 mapData tid...")
    end

    PanelManager.showPanel(GlobalPanelEnum.OnHookBuildPanel, {id = self.id, buildID = nBuildID})
end
function OnHookBuildUnit:DoingClick()
    if self.canProductNumber <= 0 then
        AppServices.SceneTextTip:Show(
            Runtime.Translate("tip_building_lumber_production"),
            self.agent:GetAnchorPosition(true)
        )
        return
    end
    local productionData = self:GetProductionData()
    if productionData then
        local endTime = productionData.endTime - TimeUtil.ServerTime()
        if endTime > (self.buildingLevelTemplate.time * 0.1) then
            self:TryTake()
        end
    end
end

function OnHookBuildUnit:TryTake()
    local productionData = self:GetProductionData()
    local productItemNumLimit = self.buildingLevelTemplate.productItemNumLimit
    if productionData then
        productionData.take = productionData.take or 0
        if productionData.take < productItemNumLimit then
            self:ItemWithFly()
        end
        return
    end
end

function OnHookBuildUnit:FinishClick()
    self:TryTake()
end

-- 道具动画结束回调
function OnHookBuildUnit:flyItemCallback()
    local production = AppServices.User:GetProduction(self.id)
    production.take = production.take + self.canProductNumber
    if production.take > self.buildingLevelTemplate.productItemNumLimit then
        production.take = self.buildingLevelTemplate.productItemNumLimit
    end
    AppServices.NetBuildingManager:SendTakeHangProduction(self.id, production.take)
    console.jf("...领取挂机建筑物品...", "id", self.id, "canProductNumber", production.take, "发送接口：MsgMap.CSTakeHangProduction")
    MessageDispatcher:SendMessage(MessageType.BUILDONHOOKTAKEMESSAGE) -- 中途领取
    self:TakeProduction()
end

-- 收获飞道具动画
function OnHookBuildUnit:ItemWithFly()
    local initPos = self:GetAnchorPosition(true)
    local outItem = self:GetProductionData().outItem
    for _, item in pairs(outItem) do
        local itemInfo = {
            itemId = item.key,
            initPos = initPos,
            sizeDelta = Vector2(80, 80)
            -- onFinish = function()
            --     self:flyItemCallback()
            -- end
        }
        AppServices.FlyAnimation.CreateItemWithFly(itemInfo)
    end
    self:flyItemCallback()
end

function OnHookBuildUnit:StateChangeToNone()
    self.bindPetID = nil
    self.currentStatus = ProductionStatus.None
    self:VisibleUnitNewBuildTips(true)
    AppServices.UnitTipsManager:RemoveTips(self.instanceId, TipsType.UnitOnHookBuildProductDoingTips)
    AppServices.UnitTipsManager:RemoveTips(self.instanceId, TipsType.UnitOnHookBuildProductFinishTips)
end

function OnHookBuildUnit:StateChangeToDoing()
    self:VisibleUnitNewBuildTips(false)
    MessageDispatcher:SendMessage(MessageType.BUILDONHOOKMESSAGE)
    AppServices.UnitTipsManager:ShowTips(self.instanceId, TipsType.UnitOnHookBuildProductDoingTips, self.key)
end

function OnHookBuildUnit:StateChangeToFinish()
    self.bindPetID = nil
    local data = AppServices.User:GetProduction(self.id)
    if not data then
        self:CreateProductionData()
        return
    end
    AppServices.UnitTipsManager:RemoveTips(self.instanceId, TipsType.UnitOnHookBuildProductDoingTips)
    AppServices.UnitTipsManager:ShowTips(self.instanceId, TipsType.UnitOnHookBuildProductFinishTips, self.key)
    local productionData = self:GetProductionData()
    local residueTakeCount = self.buildingLevelTemplate.productItemNumLimit - (productionData.take or 0)
    self.canProductNumber = residueTakeCount
end

-- 领取挂机建筑send 之后判断时候挂机是否结束
function OnHookBuildUnit:TakeProduction()
    local data = self:GetProductionData()
    if not data then
        return
    end

    local takeCount = data.take or 0
    local productItemNumLimit = self.buildingLevelTemplate.productItemNumLimit

    -- 挂机建筑领取次数 == 总次数 时 完成
    if takeCount >= productItemNumLimit then
        AppServices.User:RemoveProduction(self.id)
        self:StateChangeToNone()
        self:SetPetID(nil)
        MessageDispatcher:SendMessage(MessageType.BUILDONHOOKFINISHMESSAGE)
    end
end

-- 获取对象的坐标
function OnHookBuildUnit:GetPosition()
    local go = self.agent:GetGameObject()
    if Runtime.CSValid(go) then
        return go.transform.position
    end
    return Vector3(0, 0, 0)
end

function OnHookBuildUnit:GetAnchorPosition(value)
    return self.agent:GetAnchorPosition(value)
end

-- 获取user生产数据
function OnHookBuildUnit:GetProductionData()
    return AppServices.User:GetProduction(self.id)
end

function OnHookBuildUnit:Remove()
    UnitBase.Remove(self)
    AppServices.UnitTipsManager:RemoveTipsAll(self.instanceId)
    self:UnRegisterEvent()
end

function OnHookBuildUnit:RegisgerEvent()
    MessageDispatcher:AddMessageListener(MessageType.UnitTipsClick, self.UnitTipsClick, self)
    MessageDispatcher:AddMessageListener(MessageType.BUILDONHOOKFINISHMESSAGE, self.TakeProduction, self)
end

function OnHookBuildUnit:UnRegisterEvent()
    MessageDispatcher:RemoveMessageListener(MessageType.UnitTipsClick, self.UnitTipsClick, self)
    MessageDispatcher:RemoveMessageListener(MessageType.BUILDONHOOKFINISHMESSAGE, self.TakeProduction, self)
end

-- 设置是否可以领取
function OnHookBuildUnit:SetIsTake(number)
    if number == self.canProductNumber then
        return
    end
    self.canProductNumber = number
end

-- 挂机的状态
function OnHookBuildUnit:GetOnHookProduceState()
    return self.currentStatus
end

return OnHookBuildUnit
