--@type FightUnitBase
local FightUnitBase = require "Cleaner.Unit.FightUnitBase"

---@class FightUnitEntity:FightUnitBase
local FightUnitEntity = class(FightUnitBase, "FightUnitEntity")

function FightUnitEntity:ctor(owner)
    ---@type BaseEntity
    self.entity = owner
end

function FightUnitEntity:GetPosition()
    return self.entity:GetPosition()
end

function FightUnitEntity:GetAnchorPosition()
    if not self.entity:IsAlive() then
        return Vector3(0, 0, 0)
    end
    return self.entity:GetAnchorPosition()
end

function FightUnitEntity:GetTransform()
    return self.entity:GetGameObject().transform
end

function FightUnitEntity:GetSn()
    return self.entity.data:GetSn()
end

function FightUnitEntity:GetEntityType()
    return self.entity:GetEntityType()
end

function FightUnitEntity:IsAlive()
    return self.entity:IsAlive()
end

function FightUnitEntity:PlayAnimation(animation)
    if animation and animation ~= "" then
        self.entity:PlayAnimation(animation)
    end
end

function FightUnitEntity:GetAnimationLength(animation)
    return self.entity:GetAnimationLength(animation)
end

function FightUnitEntity:Damage(damage)
    self.entity:Damage(damage)
    self:NotifyHp(damage * -1, self.damageHpTipsType, true)
end

-- 治疗
function FightUnitEntity:Cure(value)
    self.entity:Cure(value)
    self:NotifyHp(value, self.damageHpTipsType, true)
end

function FightUnitEntity:GetMaxHp()
    return self.entity:GetMaxHp()
end

function FightUnitEntity:GetHp()
    return self.entity:GetHp()
end

function FightUnitEntity:GetLevel()
    if not self.entity or not self.entity:IsAlive() then
        return 1
    end
    return self.entity.data.meta.level
end

function FightUnitEntity:GetSpeciesType()
    if not self.entity or not self.entity:IsAlive() then
        return nil
    end
    return self.entity.data:GetSpeciesType()
end

function FightUnitEntity:EnableAttack()
    if not self.enableAttack then
        return self.enableAttack
    end
    if not self:IsAlive() then
        return false
    end
    return true
end

function FightUnitEntity:GetSearchDistance()
    return self.entity:GetSearchDistance()
end

function FightUnitEntity:GetMark()
    local mark = string.format("EntityUnit_%s", tostring(self.entity.entityId))
    return mark
end

return FightUnitEntity