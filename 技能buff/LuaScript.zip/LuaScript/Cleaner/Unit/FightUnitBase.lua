---@type SkillController
local SkillController = require "Cleaner.Fight.Skill.SkillController"

---@type FightSearchOpposed
local FightSearchOpposed = require "Cleaner.Fight.SearchOpposed.FightSearchOpposed"

---@type SkillController
local BuffManager = require "Cleaner.Fight.Buff.BuffManager"

---@type UnitBase
local UnitBase = require "Cleaner.Unit.Base.UnitBase"

---@class FightUnitBase : UnitBase
---@field owner BaseEntity
local FightUnitBase = class(UnitBase, "FightUnitBase")

function FightUnitBase:ctor(owner)
    self.owner = owner
    ---@type SkillController
    self.skillController = nil

    ---@type FightSearchOpposed
    self.fightSearchOpposed  = nil

    ---@type BuffManager
    self.buffManager = nil

    self.damageHpTipsType = 1
    self.enableAttack = false

    self:SetUnitType(UnitType.FightUnit)
    self:SetUseUpdate(true)
    self:Init()
end

function FightUnitBase:Init()

end

function FightUnitBase:SetCamp(camp)
    self.camp = camp
end

function FightUnitBase:GetCamp()
    return self.camp
end

function FightUnitBase:GetSn()
    return "-1"
end

function FightUnitBase:SetDamageHpTipsType(hpType)
    self.damageHpTipsType = hpType
end

function FightUnitBase:AddAttribute(type, value)
    self.owner:AddAttribute(type, value)
end

function FightUnitBase:GetAttribute(type)
    ---@type AttributeManager
    local attributeManager = self:GetAttributeManager()
    return attributeManager:GetAttribute(type)
end

function FightUnitBase:GetAttributeManager()
    return self.owner:GetAttributeManager()
end

function FightUnitBase:AddSkill(skills)
    self:SkillController()
    self.skillController:AddSkills(skills)
end

function FightUnitBase:ClearSkill()
    if self.skillController then
        self.skillController:ClearSkill()
    end
end

function FightUnitBase:SkillController()
    if not self.skillController then
        self.skillController = SkillController.new(self)
    end
    return self.skillController
end

function FightUnitBase:SearchOpposed()
    if not self.fightSearchOpposed then
        self.fightSearchOpposed = FightSearchOpposed.new(self)
        local searchDistance = self:GetSearchDistance()
        self.fightSearchOpposed:SetSearchDistance(searchDistance)
    end
    return self.fightSearchOpposed
end

function FightUnitBase:GetBuffManager()
    if not self.buffManager then
        self.buffManager = BuffManager.new(self)
    end
    return self.buffManager
end

function FightUnitBase:AddBuff(buffId, skillId)
    local casterData= {
        caster = self,
        casterSkillId = skillId,
        casterBuffId = buffId
    }
    local buffManager = self:GetBuffManager()
    buffManager:AddBuff(buffId, casterData)
end

function FightUnitBase:ClearBuff()
    if self.buffManager then
        self.buffManager:ClearBuff()
    end
end

function FightUnitBase:GetPosition()
    return Vector3(0, 0, 0)
end

function FightUnitBase:GetTransform()
    return nil
end

function FightUnitBase:PlayAnimation(animation)

end

function FightUnitBase:GetAnimationLength(animation)
    return 1
end

-- 伤害
function FightUnitBase:Damage(damage)

end

-- 治疗
function FightUnitBase:Cure(value)

end

function FightUnitBase:GetMaxHp()
    return 1
end

function FightUnitBase:GetHp()
    return 1
end

function FightUnitBase:GetLevel()
    return 1
end

function FightUnitBase:GetSpeciesType()
    return -1
end

function FightUnitBase:GetSearchDistance()
    return 0
end

function FightUnitBase:EnableAttack()
    return self.enableAttack
end

function FightUnitBase:SetEnableAttack(value)
    self.enableAttack = value
end

function FightUnitBase:NotifyHp(changeValue, type, show)
    local data = {
        changeValue = changeValue,
    }

    local instanceId = self:GetInstanceId()
    if not self:IsAlive() then
        AppServices.UnitTipsManager:RemoveTipsAll(instanceId)
        return
    end

    if show then
        AppServices.UnitTipsManager:ShowTips(instanceId, type, data)
    else
        AppServices.UnitTipsManager:HideTips(instanceId, type)
    end
end

function FightUnitBase:SetOnlyLogic(value)
    self.onlyLogic = value
end

function FightUnitBase:GetOnlyLogic()
    return self.onlyLogic
end

function FightUnitBase:Update()
    if not self:IsAlive() then
        return
    end

    if self.skillController then
        self.skillController:OnTick()
    end

    if self.buffManager then
        self.buffManager:Update()
    end
end

function FightUnitBase:Remove()
    UnitBase.RemoveTipsAll(self)
end

return FightUnitBase