--- 九宫格螺旋交叉排序
---@class SudokuScrewCross
local SudokuScrewCross = {
    singleCount = 4,
    ---@type List<RectInt>
    searchSequenceRectList = {
       { offset = Vector2( 0,  1), dir = Vector2(1,  0) }, --* 1 */
       { offset = Vector2(-1,  0), dir = Vector2(0, -1) }, --* 2 */
       { offset = Vector2( 0, -1), dir = Vector2(1,  0) }, --* 3 */
       { offset = Vector2( 1,  0), dir = Vector2(0, -1) }, --* 4 */
       { offset = Vector2( 1,  1), dir = Vector2(0,  0) }, --* 5 */
       { offset = Vector2(-1,  1), dir = Vector2(0,  0) }, --* 6 */
       { offset = Vector2(-1, -1), dir = Vector2(0,  0) }, --* 7 */
       { offset = Vector2( 1, -1), dir = Vector2(0,  0) }, --* 8 */
    },
}

-- Vector2 originPos, Vector2 size, int ringMin, int ringMax, Func<Vector2, Vector2, bool> callBack
function SudokuScrewCross:Search( originPos, ringMin, ringMax, callBack)
    if ringMin <= 0 then
        local result = true
        if (nil ~= callBack) then
            result = callBack(originPos)
        end

        if not result then
            return result
        end

        ringMin = 1
    end

    for i = ringMin, ringMax do
        for j = 1, #self.searchSequenceRectList do
            local rectInt = self.searchSequenceRectList[j]
            local isSingleCount = (j >= (self.singleCount + 1))
            local result = self:Ring(originPos, rectInt, isSingleCount, i, callBack)
            if (not result) then
                return
            end
        end
    end
end

-- Vector2 originPos, Vector2 size, RectInt rectInt, bool singleCount, int ring, Func<Vector2, Vector2, bool> callBack
function SudokuScrewCross:Ring( originPos, rectInt, singleCount, ring, callBack)
    local offset = rectInt.offset * ring

    local result = true
    if (singleCount) then
        local position = originPos + offset + rectInt.dir
        if (nil ~= callBack) then
            result = callBack(position)
        end
        return result
    end

    local count = ring * 2 - 1
    local half = math.floor(count / 2)
    for i = 0, count - 1 do
        local position = originPos + offset + (i - half) * rectInt.dir
        if (nil ~= callBack) then
            result = callBack(position)
        end

        if (not result) then
            break
        end
    end

    return result
end

return SudokuScrewCross