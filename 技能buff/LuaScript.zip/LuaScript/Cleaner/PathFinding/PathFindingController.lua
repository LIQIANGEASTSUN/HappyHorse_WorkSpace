---@type FindPathInfo
local FindPathInfo = require "Cleaner.PathFinding.FindPathInfo"

---@class PathFindingController
local PathFindingController = class(nil, "PathFindingController")

function PathFindingController:ctor(algorithmType, mapType)
    -- 算法
    self.pathFind = nil

    self:InitMap(mapType)
    self:CreatePathFind(algorithmType)
end

function PathFindingController:CreatePathFind(algorithmType)
    local pathFindAlias = FindPathInfo.Algorithms[algorithmType]
    local pathFind = require(pathFindAlias)

    -- 初始化 算法，并将地图数据传递进去
    self.pathFind = pathFind.new(self.map)
end

function PathFindingController:InitMap(mapType)
    local mapAlias = FindPathInfo.Maps[mapType]
    local map = require(mapAlias)
    -- 地图
    self.map = map.new(mapType)
end

function PathFindingController:SetMapNodeHandle(handle)
    self.map:SetMapNodeHandle(handle)
end

-- Vector2 min, Vector2 max, float gridSize
function PathFindingController:CreateMap( min, max, gridSize)
    self.map:Create(min, max, gridSize)
end

-- Vector2 center, Vector2 size, int nodeType
function PathFindingController:SetAreaNodeType( center, size, nodeType)
    size = size * 0.5
    local min = center - size
    local max = center + size
    self.map:SetAreaNodeType(min, max, nodeType)
end

function PathFindingController:OpenArea(min, max)
    self.map:OpenArea(min, max)
end

function PathFindingController:GetNode(x, y)
    local node = self.map:PositionToNode(x, y)
    return node
end

-- return List<Vector2>  -- float startX, float startY, float endX, float endY
function PathFindingController:Search( startX, startY, endX, endY)
    local list = {}
    -- 获取开始位置、终点位置
    ---@type Vector2
    local from = Vector2(startX, startY)
    local to = Vector2(endX, endY)

    -- 搜索路径，如果返回结果为 null，则说明没有找到路径，否则说明已找到路径，且 pathNode 为终点节点
    -- 顺着 pathNode 一直向上查找 parentNode，最终将到达开始点
    ---@type Node
    local pathNode = self.pathFind:SearchPath(from, to)
    while (nil ~= pathNode) do
        ---@type Vector2
        local pos = self.map:NodeToPosition(pathNode)
        ---@type Vector2
        local vec = Vector2(pos.x, pos.y)
        table.insert(list, 1, vec)
        pathNode = pathNode.Parent
    end

    return list
end

function PathFindingController:EnablePass(x, y)
    local node = self:GetNode(x, y)
    if not node then
        return false
    end

    local nodeType = node.NodeType
    return (nodeType ~= FindPathInfo.NodeType.Null) and  (nodeType ~= FindPathInfo.NodeType.Obstacle)
end

function PathFindingController:PlayerEnablePass(x, y)
    local node = self:GetNode(x, y)
    if not node then
        return false
    end

    local nodeType = node.NodeType
    return (nodeType ~= FindPathInfo.NodeType.Null)
end

function PathFindingController:RandomPath(x, y)
    local node = self:GetNode(x, y)
    if not node then
        return false, Vector3(x, 0, y)
    end
    node.NodeType = FindPathInfo.NodeType.Smooth

    local resultNode = node
    local list = {}
    table.insert(list, node)

    while #list < 8 do
        local neighborArr = {}
        for i = 1, resultNode.neighborType do
            local neighborNode = self.map:NodeNeighbor(resultNode, i)
            local validNode = self:IsValidNode(neighborNode)
            if validNode then
                table.insert(neighborArr, i)
            end
        end

        if #neighborArr > 0 then
            local random = math.random(1, #neighborArr)
            local index = neighborArr[random]
            local neighborNode = self.map:NodeNeighbor(resultNode, index)
            neighborNode.NodeState = FindPathInfo.NodeState.InColsedTable
            table.insert(list, neighborNode)
            resultNode = neighborNode
        else
            break
        end
    end

    for _, node in pairs(list) do
        node:Clear()
    end
    list = {}
    local position = self.map:NodeToPosition(resultNode)
    return true, Vector3(position.x, 0, position.y)
end

function PathFindingController:IsValidNode(node)
    if not node then
        return false
    end

    if node.NodeState == FindPathInfo.NodeState.InColsedTable then
        return false
    end

    return node.NodeType == FindPathInfo.NodeType.Smooth
end

return PathFindingController