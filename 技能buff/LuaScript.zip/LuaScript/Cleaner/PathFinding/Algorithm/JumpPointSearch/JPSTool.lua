---@type FindPathInfo
local FindPathInfo = require "Cleaner.PathFinding.FindPathInfo"

---@type JPSTool
local JPSTool = {}

-- 节点是否有强制邻居
-- IMap _map, Node node, Position dir
function JPSTool:HasForceNeighbour( _map, node, x, y)
    if ((nil == node) or (node.NodeType == FindPathInfo.NodeType.Null) or (node.NodeType == FindPathInfo.NodeType.Obstacle)) then
        return false
    end

    node.ForceNeighbourList = {}
    -- 横、纵 方向
    if ((x == 0) or (y == 0)) then
        local result1 = self:CheckHVForceNeighbour(_map, node, x, y, 1)
        local result2 = self:CheckHVForceNeighbour(_map, node, x, y, -1)
        return result1 or result2
    else -- 对角/斜向
        local result1 = self.CheckDiagonalForceNeighbour(_map, node, x, y, 1)
        local result2 = self.CheckDiagonalForceNeighbour(_map, node, x, y, -1)
        return result1 or result2
    end
end

-- 判断水平、垂直方向(水平向右、水平向左、竖直向上、竖直向下)的强制邻居
-- IMap _map, Node node, Position dir, int sign
function JPSTool:CheckHVForceNeighbour( map, node, x, y, sign)
    local obstacleNodePosX = node.Row + (math.abs(y) * sign)
    local obstacleNodePosY = node.Col + (math.abs(x) * sign)

    ---@type Node
    local obstacleNode = map:GetNode(math.floor(obstacleNodePosX), math.floor(obstacleNodePosY))

    local neighbourPosX = obstacleNodePosX + x
    local neighbourPosY = obstacleNodePosY + y
    ---@type Node
    local neighbourNode = map:GetNode(math.floor(neighbourPosX), math.floor(neighbourPosY))

    if (nil == neighbourNode) then
        return false
    end

    if (neighbourNode.NodeType == FindPathInfo.NodeType.Null) then
        return false
    end

    if (neighbourNode.NodeType == FindPathInfo.NodeType.Obstacle) then
        return false
    end

    if ((nil == obstacleNode) or (obstacleNode.NodeType == FindPathInfo.NodeType.Null) or (obstacleNode.NodeType == FindPathInfo.NodeType.Obstacle)) then
        local pos = map:NodeToPosition(neighbourNode)
        table.insert(node.ForceNeighbourList, pos)
        return true
    end

    return false
end

local obstacleDirX = 0
local ofstacleDirY = 0

local neighbourDirX = 0
local neighbourDirY = 0
-- 判断斜向(左上、左下、右上、右下)的强制邻居
-- IMap _map, Node node, Vector2 dir, int sign
function JPSTool.CheckDiagonalForceNeighbour( map, node, x, y, sign)
    local prePosX = node.Row - x
    local prePosY = node.Col - y
    if (sign == 1) then
        obstacleDirX = x
        neighbourDirX = x
    else
        ofstacleDirY = y
        neighbourDirY = y
    end

    ---@type Position
    local obstacleNodePosX = prePosX + obstacleDirX
    local obstacleNodePosY = prePosY + ofstacleDirY

    ---@type Node
    local obstacleNode = map:GetNode(math.floor(obstacleNodePosX), math.floor(obstacleNodePosY))

    ---@type Position
    local neighbourPosX = obstacleNodePosX + neighbourDirX
    local neighbourPosY = obstacleNodePosY + neighbourDirY
    ---@type Node
    local neighbourNode = map:GetNode(math.floor(neighbourPosX), math.floor(neighbourPosY))

    if ((nil == neighbourNode) or (neighbourNode.NodeType == FindPathInfo.NodeType.Null) or (neighbourNode.NodeType == FindPathInfo.NodeType.Obstacle)) then
        return false
    end

    if ((nil == obstacleNode) or (obstacleNode.NodeType == FindPathInfo.NodeType.Null) or (obstacleNode.NodeType == FindPathInfo.NodeType.Obstacle)) then
        ---@type Position
        local pos = map:NodeToPosition(neighbourNode)
        table.insert(node.ForceNeighbourList, pos)
        return true
    end

    return false
end

return JPSTool