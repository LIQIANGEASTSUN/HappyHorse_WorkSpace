---@class OrderBase 订单基类
local OrderBase = class(nil, "OrderBase")
function OrderBase:ctor()
end

function OrderBase:Destory()
end

return OrderBase