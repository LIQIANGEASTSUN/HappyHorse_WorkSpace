---@type UnitTipsBase
local UnitTipsBase = require "Cleaner.UnitTips.Base.UnitTipsBase"

---@type HpFloatDamage
local HpFloatDamage = require "Cleaner.UnitTips.HpFloatDamage"

---@class TipsHpMonster : UnitTipsBase
local TipsHpMonster = class(UnitTipsBase, "TipsHpMonster")

function TipsHpMonster:ctor(unitId)
    self.offsetPos = Vector3(0, 2, 0)
    self.maxHp = self.unit:GetMaxHp()
    self.isLoaded = false

    self:SetUseUpdate(true)
    self:SetTipsPath("TipsHpMonster.prefab")
end

function TipsHpMonster:Refresh()
    if not self.isLoaded then
        return
    end

    local hp = self.unit:GetHp()
    local progress = hp / self.maxHp
    self.slider.value = progress

    if self.hpFloat then
        self.hpFloat:DamageText(self.tipsData.changeValue)
    end
end

function TipsHpMonster:LoadFinish()
    UnitTipsBase.LoadFinish(self)

    self.isLoaded = true
    self.transform = self.go.transform
    self.slider = self.transform:Find("slider"):GetComponent(typeof(Slider))
    self.txt_countTr = self.transform:Find("txt_count")
    self:Refresh()

    self.hpFloat = HpFloatDamage.new(self.transform,  self.txt_countTr)
end

function TipsHpMonster:Update()
    UnitTipsBase.Update(self)
    self:CalculatePosition()

    if self.hpFloat then
        self.hpFloat:Update()
    end
end

return TipsHpMonster