---@type UnitTipsBase
local UnitTipsBase = require "Cleaner.UnitTips.Base.UnitTipsBase"

---@type HpFloatDamage
local HpFloatDamage = require "Cleaner.UnitTips.HpFloatDamage"

---@class TipsHpPet : TipsHpMonster
local TipsHpPet = class(UnitTipsBase, "TipsHpPet")

function TipsHpPet:ctor(unitId)
    self.offsetPos = Vector3(0, 2, 0)
    self.maxHp = self.unit:GetMaxHp()
    self.isLoaded = false

    self:SetUseUpdate(true)
    self:SetTipsPath("TipsHpPet.prefab")
end

function TipsHpPet:Refresh()
    if not self.isLoaded then
        return
    end

    local hp = self.unit:GetHp()
    local progress = hp / self.maxHp
    self.slider.value = progress

    local level = self.unit:GetLevel()
    self.txt_level1.text = tostring(level)
    self.txt_level.text = tostring(level)

    if self.hpFloat then
        self.hpFloat:DamageText(self.tipsData.changeValue)
    end

    local showType1 = (self.tipsData.changeValue == 0)
    self:ChangeTypeShow(showType1)
end

function TipsHpPet:LoadFinish()
    UnitTipsBase.LoadFinish(self)

    self.isLoaded = true
    self.transform = self.go.transform
    self.type1 = self.transform:Find("Type1")
    self.txt_level1 = self.transform:Find("Type1/txt_level"):GetComponent(typeof(Text))

    self.type2 = self.transform:Find("Type2")
    self.slider = self.transform:Find("Type2/slider"):GetComponent(typeof(Slider))
    self.txt_level = self.transform:Find("Type2/txt_level"):GetComponent(typeof(Text))
    self.txt_countTr = self.transform:Find("Type2/txt_count")

    self:Refresh()

    self.hpFloat = HpFloatDamage.new(self.transform,  self.txt_countTr)
end

function TipsHpPet:ChangeTypeShow(showType1)
    self.type1.gameObject:SetActive(showType1)
    self.type2.gameObject:SetActive(not showType1)
    if not showType1 then
        self.type2HideTime = Time.realtimeSinceStartup + 5
    end
end

function TipsHpPet:Update()
    UnitTipsBase.Update(self)
    self:CalculatePosition()

    if self.hpFloat then
        self.hpFloat:Update()
    end

    if self.type2HideTime and Time.realtimeSinceStartup >= self.type2HideTime then
        self.type2HideTime = nil
        self:ChangeTypeShow(true)
    end
end

return TipsHpPet