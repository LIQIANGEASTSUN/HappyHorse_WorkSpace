---@type UnitTipsBase
local UnitTipsBase = require "Cleaner.UnitTips.Base.UnitTipsBase"

---@class UnitDressNewTips : UnitTipsBase
local UnitDressNewTips = class(UnitTipsBase, "UnitDressNewTips")

function UnitDressNewTips:ctor(unitId)
    self.startTime = 0
    self.endTime = 0
    self.totalTime = 0
    self.offsetPos = Vector3(0, 1, 0)
    self:SetUseUpdate(true)
    self:SetTipsPath("TipsNewDressSkin.prefa")
end

function UnitDressNewTips:LoadFinish()
    UnitTipsBase.LoadFinish(self)
    self.transform = self.go.transform
end

function UnitDressNewTips:RefreshTime()
    if not self.lastRefreshTime then
        self.lastRefreshTime = 0
    end
    if Time.realtimeSinceStartup - self.lastRefreshTime < 1 then
        return
    end

    if not Runtime.CSValid(self.txt_time) then
        return
    end

    if self.startTime > TimeUtil.ServerTime() then
        self.txt_time.text = ""
        return
    end

    local time = self.endTime - TimeUtil.ServerTime()
    self.txt_time.text = TimeUtil.SecToMS(time)

    local progress = 1 - time / self.totalTime
    --self.slider.value = progress
end

function UnitDressNewTips:Update()
    UnitTipsBase.Update(self)
    self:RefreshTime()
end

return UnitDressNewTips
