---@class UnitTipsBase
---@field unit UnitBase
local UnitTipsBase = class(nil, "UnitTipsBase")

function UnitTipsBase:ctor(unitId, tipsType)
    self.unitId = unitId
    self.instanceId = -1
    self.show = false
    self.go = nil
    self.offsetPos = Vector3(0, 1, 0)
    self.positionRefreshTime = 1
    self.isloading = false
    self.lastRefreshPosTime = 0
    self.tipsHideState = TipsStateToHide.None

    self.unit = AppServices.UnitManager:GetUnit(unitId)

    self:SetTipsType(tipsType)
    self:SetUseUpdate(false)

    self.isDestroy = false
end

function UnitTipsBase:GetGameObject()
    if Runtime.CSValid(self.go) then
        return self.go
    end
end

function UnitTipsBase:GetUnitId()
    return self.unitId
end

function UnitTipsBase:SetTipsType(type)
    self.tipsType = type
end

function UnitTipsBase:GetTipsType()
    return self.tipsType
end

function UnitTipsBase:SetTipsPath(path)
    self.tipsPrefabPath = string.format("Prefab/UI/Common/%s", path)
end

function UnitTipsBase:SetInstanceId(instanceId)
    self.instanceId = instanceId
end

function UnitTipsBase:GetInstanceId()
    return self.instanceId
end

function UnitTipsBase:SetUseUpdate(value)
    self.useUpdate = value
end

function UnitTipsBase:GetUseUpdate()
    return self.useUpdate
end

function UnitTipsBase:SetHideState(state)
    self.tipsHideState = state
    self:SetActive(self.show)
end

function UnitTipsBase:ClearHideState()
   self:SetHideState(TipsStateToHide.None)
end

function UnitTipsBase:StateEnableShow()
    return self.tipsHideState <= 0
end

function UnitTipsBase:Refresh()
end

-- function UnitTipsBase:SetTipsData(tipsData)
--     self.tipsData = tipsData
-- end

function UnitTipsBase:Show(tipsData)
    self.tipsData = tipsData
    if not Runtime.CSValid(self.go) then
        self:Instantiate()
        return
    end

    self:Refresh()
    self:SetActive(true)
end

function UnitTipsBase:SetShow(value)
    self.show = value
end

function UnitTipsBase:Hide()
    self:SetActive(false)
end

function UnitTipsBase:SetActive(value)
    if not Runtime.CSValid(self.go) then
        return
    end

    local stateEnableShow = self:StateEnableShow()
    local newValue = value and self.show and stateEnableShow
    self.go:SetActive(newValue)
    if newValue then
        self:CalculatePosition()
    end
    self:CheckTarget()
end

function UnitTipsBase:Click()
    App.mapGuideManager:OnGuideFinishEvent(GuideEvent.TipClick, self)
    MessageDispatcher:SendMessage(MessageType.UnitTipsClick, self.unitId, self.tipsType)
end

function UnitTipsBase:Instantiate()
    if self.isloading then
        return
    end

    self.isloading = true
    local function onLoaded()
        self.go = BResource.InstantiateFromAssetName(self.tipsPrefabPath)
        self:LoadCallBack(self.go)
    end
    App.buildingAssetsManager:LoadAssets({self.tipsPrefabPath}, onLoaded)
end

function UnitTipsBase:LoadCallBack(go)
    if self.isDestroy then
        self:Destroy()
        return
    end

    local tipsRoot = AppServices.UnitTipsManager:GetTipsRoot()
    self.go.transform:SetParent(tipsRoot.transform)
    self.go.transform.localScale = Vector3.one
    self.go.transform.localEulerAngles = Vector3.zero
    self.go.transform.localPosition = Vector3.zero
    local mainCamera = Camera.main
    self.go.transform.rotation = mainCamera.transform.rotation

    self.transform = self.go.transform
    self.rect = self.go:GetComponent(typeof(RectTransform))
    self.btn = self.go:GetComponent(typeof(Button))

    if not Runtime.CSValid(self.go) then
        console.error("nil:"..self.tipsPrefabPath)
    end

    self:LoadFinish()
    self.isloading = false
    ---用于引导
    App.mapGuideManager:OnGuideFinishEvent(GuideEvent.TipShowed, self)
end

function UnitTipsBase:LoadFinish()
    self.lastRefreshPosTime = -1
    self:Refresh()
    self:SetActive(self.show)

    if Runtime.CSValid(self.btn) then
        local function tips_click(go)
            self:Click()
        end
        --insertDeclareBtn
        Util.UGUI_AddButtonListener(self.btn.gameObject, tips_click)
    end

    self:CalculatePosition()
    -- local reSetPosition = function()
    --     if self.waitExtensionId then
    --         WaitExtension.CancelTimeout(self.waitExtensionId)
    --         self.waitExtensionId = nil
    --         self:CalculatePosition()
    --     end
    -- end
    -- self.waitExtensionId = WaitExtension.InvokeRepeating(reSetPosition, 0, 1)
end

function UnitTipsBase:GetTargetPosition()
    self.unit = AppServices.UnitManager:GetUnit(self.unitId)
    if not self.unit then
        return Vector3(0, 0, 0)
    end
    return self.unit:GetAnchorPosition(true)
end

function UnitTipsBase:CheckUpdate()
    if Time.realtimeSinceStartup - self.lastRefreshPosTime < self.positionRefreshTime then
        return
    end
    self.lastRefreshPosTime = Time.realtimeSinceStartup

    self:CheckTarget()
end

function UnitTipsBase:CheckTarget()
    self.unit = AppServices.UnitManager:GetUnit(self.unitId)
    if (not self.unit) or (not self.unit:IsAlive()) then
        AppServices.UnitTipsManager:RemoveTipsAll(self.unitId)
        self:Destroy()
    end
end

function UnitTipsBase:CalculatePosition()
    if not Runtime.CSValid(self.go) then
        return
    end

    self:FollowUnit()
end

function UnitTipsBase:FollowUnit()
    self.transform.position = self:GetTargetPosition() + self.offsetPos
end

function UnitTipsBase:TipsWorldPosition()
    if Runtime.CSValid(self.transform) then
        return self.transform.position
    end
    return Vector3(0, 0, 0)
end

function UnitTipsBase:Update()
    self:CheckUpdate()
end

function UnitTipsBase:GetItemSprite(spriteName)
    local atlas = App.uiAssetsManager:GetAsset(CONST.ASSETS.G_ITEM_ICONS)
    local sprite = atlas:GetSprite(spriteName)
    return sprite
end

function UnitTipsBase:Destroy()
    if Runtime.CSValid(self.go) then
        GameObject.Destroy(self.go)
    end
    self.go = nil
    self.isDestroy = true
end

return UnitTipsBase