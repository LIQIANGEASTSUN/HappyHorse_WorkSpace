local Bit = require "Utils.bitOp"

---@type UnitTipsInfo
local UnitTipsInfo = require "Cleaner.UnitTips.Base.UnitTipsInfo"

---@class UnitTipsManager
---@field tipsMap table<number, table<number, UnitBase>> unitId = {instanceId = UnitBase}
local UnitTipsManager = {
    instanceId = 10000,
    ---@type Dictionary<unitId, Dictionary<instanceId, UnitBase>>
    tipsMap = {},
    tipsHideState = TipsStateToHide.None,
    prefabPath = "Prefab/UI/Common/UnitUITipsPanel.prefab"
}

function UnitTipsManager:Init()
    self:RegisterEvents()
    self:Instantiate()
end

function UnitTipsManager:GetTipsRoot()
    return self.gameObject
end

function UnitTipsManager:GetRectTransform()
    return self.rectTransform
end

function UnitTipsManager:Instantiate()
    local canvas = App.scene.worldCanvasUI
    local function onLoaded()
        local go = BResource.InstantiateFromAssetName(self.prefabPath)
        if Runtime.CSValid(go) then
            self.gameObject = go
            self.gameObject.transform:SetParent(canvas.transform, false)
            self.gameObject.transform:SetLocalScale(1, 1, 1)
            self.gameObject.transform:SetLocalPosition(0, 0, 0)
            self.rectTransform = self.gameObject:GetComponent(typeof(RectTransform))
        end
    end
    App.buildingAssetsManager:LoadAssets({self.prefabPath}, onLoaded)
end

--- 显示Tips 隐藏与 Tips.tipsType 不同的 Tips
function UnitTipsManager:ShowTips(unitId, tipsType, tipsData)
    --console.error("ShowTips:"..unitId.."   "..tipsType)
    local tips = self:GetTip(unitId, tipsType)
    if not tips then
        self:CreateTips(unitId, tipsType)
    end
    local tipsList = self:GetTips(unitId)

    for _, tips in pairs(tipsList) do
        tips:SetHideState(self.tipsHideState)
        local otherType = tips:GetTipsType()
        if tipsType == otherType then
            tips:SetShow(true)
            tips:Show(tipsData)
        else
            tips:SetShow(false)
            tips:Hide()
        end
    end
end

function UnitTipsManager:HideTips(unitId, tipsType)
    --console.error("HideTips:"..unitId.."   "..tipsType)
    local tipsList = self:GetTips(unitId)
    for _, tips in pairs(tipsList) do
        if tipsType == tips:GetTipsType() then
            tips:Hide()
        end
    end
end

function UnitTipsManager:RemoveTipsAll(unitId)
    local tipsList = self:GetTips(unitId)
    for _, tips in pairs(tipsList) do
        self:Remove(tips)
    end
end

function UnitTipsManager:RemoveTips(unitId, tipsType)
    local tipsList = self:GetTips(unitId)
    for _, tips in pairs(tipsList) do
        if tipsType == tips:GetTipsType() then
            self:Remove(tips)
        end
    end
end

function UnitTipsManager:CreateTips(unitId, tipsType)
    local tipsAlias = UnitTipsInfo[tipsType]
    local tips = tipsAlias.new(unitId, tipsType)
    local instanceId = self:NewInstanceId()
    --console.error("CreateTips:"..unitId.."    "..tipsType.."   "..instanceId)

    tips:SetInstanceId(instanceId)
    self:AddTips(tips)
    return tips
end

--- 返回的 unitList 不要 table.remove
function UnitTipsManager:GetTips(unitId)
    local mark = self:GetUnitMark(unitId)
    local unitList = self.tipsMap[mark]
    if not unitList or table.isEmpty(unitList) then
        unitList = {}
        self.tipsMap[mark] = unitList
    end
    return unitList
end

function UnitTipsManager:GetTip(unitId, tipsType)
    local unitList = self:GetTips(unitId)
    for _, tips in pairs(unitList) do
        if tipsType == tips:GetTipsType() then
            return tips
        end
    end
end

function UnitTipsManager:AddTips(tips)
    local unitId = tips:GetUnitId()
    local instanceId = tips:GetInstanceId()

    local unitList = self:GetTips(unitId)
    unitList[instanceId] = tips
end

function UnitTipsManager:Remove(tips)
    if not tips then
        return
    end

    local unitId = tips:GetUnitId()
    local instanceId = tips:GetInstanceId()
    local unitList = self:GetTips(unitId)
    tips:Destroy()

    unitList[instanceId] = nil
end

function UnitTipsManager:RemoveAll()
    for _, list in pairs(self.tipsMap) do
        for _, tips in pairs(list) do
            tips:Destroy()
        end
    end
    self.tipsMap = {}
end

function UnitTipsManager:GetUnitMark(unitId)
    local unit = AppServices.UnitManager:GetUnit(unitId)
    if not unit then
        return tostring(unitId)
    end

    return unit:GetMark()
end

function UnitTipsManager:NewInstanceId()
    self.instanceId = self.instanceId + 1
    return self.instanceId
end

function UnitTipsManager:Update()
    for _, unitList in pairs(self.tipsMap) do
        for _, tips in pairs(unitList) do
            if tips:GetUseUpdate() then
                tips:Update()
            end
        end
    end
end

function UnitTipsManager:AllTipsAddState(state)
    state = self:AddHideState(state)
    for _, unitList in pairs(self.tipsMap) do
        for _, tips in pairs(unitList) do
            tips:SetHideState(state)
        end
    end
end

function UnitTipsManager:AllTipsRemoveState(state)
    state = self:RemoveHideState(state)
    for _, unitList in pairs(self.tipsMap) do
        for _, tips in pairs(unitList) do
            tips:SetHideState(state)
        end
    end
end

function UnitTipsManager:AddHideState(state)
    self.tipsHideState = Bit.Or(self.tipsHideState, state)
    return self.tipsHideState
end

function UnitTipsManager:RemoveHideState(state)
    if Bit.And(self.tipsHideState, state) <= 0 then
        return self.tipsHideState
    end
    self.tipsHideState = Bit.Xor(self.tipsHideState, state)
    return self.tipsHideState
end

function UnitTipsManager:RegisterEvents()
    MessageDispatcher:AddMessageListener(MessageType.UnitTipsAddState, self.AllTipsAddState, self)
    MessageDispatcher:AddMessageListener(MessageType.UnitTipsRemoveState, self.AllTipsRemoveState, self)
end

function UnitTipsManager:UnRegisterEvent()
    MessageDispatcher:RemoveMessageListener(MessageType.UnitTipsAddState, self.AllTipsAddState, self)
    MessageDispatcher:RemoveMessageListener(MessageType.UnitTipsRemoveState, self.AllTipsRemoveState, self)
end

function UnitTipsManager:Release()
    self:RemoveAll()
    self:UnRegisterEvent()
end

return UnitTipsManager
