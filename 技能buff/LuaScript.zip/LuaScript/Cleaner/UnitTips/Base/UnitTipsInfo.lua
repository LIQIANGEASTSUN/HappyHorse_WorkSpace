---@type UnitTipsInfo
local UnitTipsInfo =
    setmetatable(
    {
        _register = {
            [TipsType.UnitBreedFinishTips] = "UnitBreedFinishTips",
            [TipsType.UnitBreedDoingTips] = "UnitBreedDoingTips",
            [TipsType.UnitBreedNewTips] = "UnitBreedNewTips",
            [TipsType.UnitDressNewTips] = "UnitDressNewTips",
            [TipsType.UnitNewBuildTips] = "UnitNewBuildTips",
            [TipsType.UnitOnHookBuildProductDoingTips] = "UnitOnHookBuildProductDoingTips",
            [TipsType.UnitOnHookBuildProductFinishTips] = "UnitOnHookBuildProductFinishTips",
            --[TipsType.UnitProductFinishTips] = "UnitProductFinishTips",
            -- [TipsType.UnitDecorationFactoryProductFinishTips] = "UnitDecorationFactoryProductFinishTips",
            --[TipsType.UnitProductDoingTips] = "UnitProductDoingTips",
            [TipsType.UnitMonsterHpTips] = "TipsHpMonster",
            [TipsType.UnitPetHpTips] = "TipsHpPet",
            [TipsType.UnitBoss] = "TipsBoss",
            [TipsType.UnitNewMonster] = "TipsNewMonster",
            [TipsType.UnitBuildingUpLevel] = "TipsBuildUpLevel",
            [TipsType.UnitPetNestProduction] = "TipsPetNestProduct"
        }
    },
    {
        __index = function(t, k)
            local path = t._register[k]
            path = "Cleaner.UnitTips." .. path
            local v = require(path)
            rawset(t, k, v)
            return v
        end
    }
)

return UnitTipsInfo
