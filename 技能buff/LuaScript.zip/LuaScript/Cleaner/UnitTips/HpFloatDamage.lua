---@class HpFloatDamage
local HpFloatDamage = class(nil, "HpFloatDamage")

function HpFloatDamage:ctor(transform,  txt_countTr)
    self.transform = transform
    self.txt_countTr = txt_countTr
    self.unUseList = {}
    self.useList = {}
end

function HpFloatDamage:DamageText(changeValue)
    if math.abs(changeValue) < 1 then
        return
    end

    local item = {}
    if #self.unUseList > 0 then
        item = self.unUseList[#self.unUseList]
        table.remove(self.unUseList, #self.unUseList)
    else
        local textGo = self:CreateItem(self.txt_countTr, self.transform)
        item.txt_count = textGo.transform:GetComponent(typeof(Text))
        item.rect = textGo.transform:GetComponent(typeof(RectTransform))
    end

    item.time = Time.realtimeSinceStartup
    item.txt_count.text = string.format("%.0f", changeValue)
    item.txt_count.transform.position = Vector3.zero
    item.txt_count.gameObject:SetActive(true)
    item.rect.anchoredPosition3D = Vector3(0, 0, 0)
    table.insert(self.useList, item)
end

function HpFloatDamage:Update()
    for i = #self.useList, 1, -1 do
        local item = self.useList[i]
        local time = Time.realtimeSinceStartup - item.time
        if time >= 2 then
            item.txt_count.gameObject:SetActive(false)
            table.remove(self.useList, i)
            table.insert(self.unUseList, item)
        end

        if Runtime.CSValid(item.rect) then
            item.rect.anchoredPosition3D = item.rect.anchoredPosition3D + Vector3(0, 2, 0)
        end
    end
end

function HpFloatDamage:CreateItem(cloneTr, parent)
    local go = GameObject.Instantiate(cloneTr.gameObject)
    go.transform:SetParent(parent, false)
    go.transform.localScale = Vector3.one
    go.transform.localEulerAngles = Vector3.zero
    go.transform.localPosition = Vector3.zero
    return go
end

return HpFloatDamage