---@type UnitTipsBase
local UnitTipsBase = require "Cleaner.UnitTips.Base.UnitTipsBase"

---@class TipsBuildUpLevel:UnitTipsBase
local TipsBuildUpLevel = class(UnitTipsBase, "TipsBuildUpLevel")

function TipsBuildUpLevel:ctor(unitId)
    self.offsetPos = Vector3(0, 0.3, 0)
    self:SetUseUpdate(false)
    self:SetTipsPath("TipsBuildingUp.prefab")
end

function TipsBuildUpLevel:LoadFinish()
    UnitTipsBase.LoadFinish(self)
    self.arrow = self.go.transform:Find("arrow")
end

return TipsBuildUpLevel