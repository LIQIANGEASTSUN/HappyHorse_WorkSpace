---@type UnitTipsBase
local UnitTipsBase = require "Cleaner.UnitTips.Base.UnitTipsBase"

---@class UnitDressNewTips : UnitTipsBase
local UnitDressNewTips = class(UnitTipsBase, "UnitDressNewTips")

function UnitDressNewTips:ctor(unitId)
    self.startTime = 0
    self.endTime = 0
    self.totalTime = 0
    self.offsetPos = Vector3(0, 1, 0)
    self:SetUseUpdate(false)
    self:SetTipsPath("TipsNewBuild.prefab")
end

function UnitDressNewTips:BindElement()
    self.textContent = find_component(self.go, "IconBG/Text_content", Text)
end

function UnitDressNewTips:Init()
    self.textContent.text = Runtime.Translate("ui_bubble_newBuilding")
end

function UnitDressNewTips:LoadFinish()
    UnitTipsBase.LoadFinish(self)
    self.transform = self.go.transform
    self:BindElement()
    self:Init()
end

return UnitDressNewTips
