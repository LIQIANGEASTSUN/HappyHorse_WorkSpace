---@type UnitTipsBase
local UnitTipsBase = require "Cleaner.UnitTips.Base.UnitTipsBase"

---@class TipsNewMonster:UnitTipsBase
local TipsNewMonster = class(UnitTipsBase, "TipsNewMonster")

function TipsNewMonster:ctor(unitId)
    self.positionRefreshTime = 0
    self.offsetPos = Vector3(0, 2.5, 0)
    self.isLoaded = false

    self:SetUseUpdate(true)
    self:SetTipsPath("TipsNewMonster.prefab")
end

function TipsNewMonster:Refresh()
    if not self.isLoaded then
        return
    end

    self.txt_name.text = "New!"
end

function TipsNewMonster:LoadFinish()
    UnitTipsBase.LoadFinish(self)
    self.isLoaded = true

    if not Runtime.CSValid(self.go) then
        return
    end

    self.transform = self.go.transform
    self.txt_name = self.transform:Find("txt_name"):GetComponent(typeof(Text))
    self:Refresh()
end

function TipsNewMonster:Update()
    UnitTipsBase.Update(self)
    self:CalculatePosition()
end

return TipsNewMonster