---@type UnitTipsBase
local UnitTipsBase = require "Cleaner.UnitTips.Base.UnitTipsBase"

---@class UnitBreedNewTips : UnitTipsBase
local UnitBreedNewTips = class(UnitTipsBase, "UnitBreedNewTips")

function UnitBreedNewTips:ctor(unitId)
    self.startTime = 0
    self.endTime = 0
    self.totalTime = 0
    self.offsetPos = Vector3(0, 1, 0)
    self:SetUseUpdate(false)
    self:SetTipsPath("TipsNewBuild.prefab")
end

function UnitBreedNewTips:BindElement()
    self.textContent = find_component(self.go, "IconBG/Text_content", Text)
end

function UnitBreedNewTips:Init()
    self.textContent.text = Runtime.Translate("ui_bubble_newBuilding")
end

function UnitBreedNewTips:LoadFinish()
    UnitTipsBase.LoadFinish(self)
    self.transform = self.go.transform
    self:BindElement()
    self:Init()
end

return UnitBreedNewTips
