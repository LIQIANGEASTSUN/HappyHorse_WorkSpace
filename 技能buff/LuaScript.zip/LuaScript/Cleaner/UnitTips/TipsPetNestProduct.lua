---@type UnitTipsBase
local UnitTipsBase = require "Cleaner.UnitTips.Base.UnitTipsBase"

---@class TipsPetNestProduct : UnitTipsBase
local TipsPetNestProduct = class(UnitTipsBase, "TipsPetNestProduct")

function TipsPetNestProduct:ctor(unitId)
    self:SetTipsPath("TipsPetNestProduct.prefab")
end

function TipsPetNestProduct:Click()
    UnitTipsBase.Click(self)
    AppServices.NetBuildingManager:SendPetNestProduction(self.agentId)

    AppServices.UnitTipsManager:HideTips(self.unitId, TipsType.UnitPetNestProduction)
end

function TipsPetNestProduct:Refresh()
    if not Runtime.CSValid(self.icon) then
        return
    end
    self.agentId = self.tipsData.agentId
    local production = self.tipsData.production

    for itemId, _ in pairs(production) do
        local itemData = AppServices.Meta:Category("ItemTemplate")[tostring(itemId)]
        local sprite = self:GetItemSprite(itemData.icon)
        self.icon.sprite = sprite
        --self.txt_count.text = tostring(count)
    end
end

function TipsPetNestProduct:LoadFinish()
    UnitTipsBase.LoadFinish(self)

    self.icon = self.go.transform:Find("Icon"):GetComponent(typeof(Image))
    --self.txt_count = self.go.transform:Find("txt_count"):GetComponent(typeof(Text))

    self:Refresh()
end

return TipsPetNestProduct