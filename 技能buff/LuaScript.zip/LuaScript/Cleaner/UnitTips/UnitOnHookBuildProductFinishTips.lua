---@type UnitTipsBase
local UnitTipsBase = require "Cleaner.UnitTips.Base.UnitTipsBase"

---@class UnitOnHookBuildProductFinishTips : UnitTipsBase
local UnitOnHookBuildProductFinishTips = class(UnitTipsBase, "UnitOnHookBuildProductFinishTips")

function UnitOnHookBuildProductFinishTips:ctor(unitId)
    self:SetUseUpdate(true)
    self.offsetPos = Vector3(0, 1, 0)
    self:SetTipsPath("TipsOnHookBuildProductFinish.prefab")
end

function UnitOnHookBuildProductFinishTips:Show(buildMateID)
    self.buildMateID = buildMateID -- 建筑表key
    UnitTipsBase.Show(self, buildMateID)
end

function UnitOnHookBuildProductFinishTips:LoadFinish()
    UnitTipsBase.LoadFinish(self)

    local icon = find_component(self.go.gameObject, "tip/icon", Image)
    local txt_count = find_component(self.go.gameObject, "tip/text", Text)
    local productionData = self.unit:GetProductionData()

    local takeCount = productionData.take or 0
    self.buildingLevelTemplate = self.unit.buildingLevelTemplate
    local everyOneTakeCount = self.buildingLevelTemplate.production[1][2]
    local productItemNumLimit = self.buildingLevelTemplate.productItemNumLimit
    local zCount = (productItemNumLimit - takeCount) * everyOneTakeCount

    for _, data in pairs(productionData.outItem) do
        local key = data.key
        local itemData = AppServices.Meta:Category("ItemTemplate")[tostring(key)]
        local sprite = self:GetItemSprite(itemData.icon)
        icon.sprite = sprite
    end

    if zCount < 0 then
        txt_count.text = ""
    else
        txt_count.text = zCount .. "/" .. zCount
    end
end

function UnitOnHookBuildProductFinishTips:Refresh()
    if self.go then
        self.tip = find_component(self.go.gameObject, "tip")
        self.tipAni = self.tip:GetComponent(typeof(Animator))
        self.tipAni:Play(ONHOOKTIPANI.play)
    end
end

function UnitOnHookBuildProductFinishTips:Destroy()
    UnitTipsBase.Destroy(self)
end

return UnitOnHookBuildProductFinishTips
