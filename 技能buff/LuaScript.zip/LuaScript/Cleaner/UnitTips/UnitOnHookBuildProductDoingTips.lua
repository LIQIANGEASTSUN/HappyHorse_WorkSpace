---@type UnitTipsBase
local UnitTipsBase = require "Cleaner.UnitTips.Base.UnitTipsBase"

---@class UnitOnHookBuildProductDoingTips : UnitTipsBase
local UnitOnHookBuildProductDoingTips = class(UnitTipsBase, "UnitOnHookBuildProductDoingTips")

function UnitOnHookBuildProductDoingTips:ctor()
    self.startTime = 0
    self.endTime = 0
    self.totalTime = 0
    self.offsetPos = Vector3(0, 1, 0)
    self:SetUseUpdate(true)
    self:SetTipsPath("TipsOnHookBuildProductDoing.prefab")
    self.buildingLevelTemplate = nil
    self.productItemNumLimit = nil -- 生产道具存储上限次数
    self.takeCount = 0 -- 领取过的次数
    self.residueTakeCount = 0 -- 剩余领取的次数
    self.everyOneTakeCount = 0 --每次产出的数量
    self.productCount = 0 -- 产出可以 领取的数量
    self.intervalTime = 0 -- 间隔更新时间
    self.INTERVALTIME = 50
    self:RegisgerEvent()
end

function UnitOnHookBuildProductDoingTips:Destroy()
    self:UnRegisterEvent()
    UnitTipsBase.Destroy(self)
end

function UnitOnHookBuildProductDoingTips:RegisgerEvent()
    MessageDispatcher:AddMessageListener(MessageType.BUILDONHOOKTAKEMESSAGE, self.OnTake, self)
end

function UnitOnHookBuildProductDoingTips:UnRegisterEvent()
    MessageDispatcher:RemoveMessageListener(MessageType.BUILDONHOOKTAKEMESSAGE, self.OnTake, self)
end

function UnitOnHookBuildProductDoingTips:Show(buildMateID)
    if self.txt then
        self.txt.text = ""
    end

    self.unit:SetIsTake()
    self.buildMateID = buildMateID -- 建筑表key
    UnitTipsBase.Show(self, buildMateID)
end

function UnitOnHookBuildProductDoingTips:LoadFinish()
    UnitTipsBase.LoadFinish(self)
    self.transform = self.go.transform

    self.tip = find_component(self.go.gameObject, "tip")
    self.tipAni = self.tip:GetComponent(typeof(Animator))

    self.icon = find_component(self.go.gameObject, "tip/icon", Image)
    self.txt = find_component(self.go.gameObject, "tip/text", Text)
    self.slider = find_component(self.go.gameObject, "tip/Slider", Slider)

    local productionData = self.unit:GetProductionData()
    self.startTime = productionData.startTime
    self.endTime = productionData.endTime
    self.totalTime = self.endTime - self.startTime
    self.takeCount = productionData.take or 0
    local buildingLevelTemplate = self.unit.buildingLevelTemplate
    self.everyOneTakeCount = buildingLevelTemplate.production[1][2]
    self.productItemNumLimit = buildingLevelTemplate.productItemNumLimit
    self.residueTakeCount = self.productItemNumLimit - self.takeCount
    local outItem = productionData.outItem[1]
    if outItem then
        local key = outItem.key
        local itemData = AppServices.Meta:Category("ItemTemplate")[tostring(key)]
        local sprite = self:GetItemSprite(itemData.icon)
        self.icon.sprite = sprite
    end

    for _, data in pairs(productionData.outItem) do
        self.productCount = self.productCount + data.value
    end

    self.lastRefreshTime = -1
    self.txt.text = ""
    self:RefreshTime()
end

-- 中途领取
function UnitOnHookBuildProductDoingTips:OnTake()
    local productionData = self.unit:GetProductionData()
    self.residueTakeCount = self.unit.buildingLevelTemplate.productItemNumLimit - productionData.take
    self.takeCount = productionData.take
    if self.tipAni then
        self.tipAni:Play(ONHOOKTIPANI.idle)
    end
end

function UnitOnHookBuildProductDoingTips:RefreshTime()
    if not self.go then
        return
    end
    if not self.lastRefreshTime then
        self.lastRefreshTime = 0
    end
    if Time.realtimeSinceStartup - self.lastRefreshTime < 1 then
        return
    end

    -- local intervalTime = TimeUtil.ServerTime() - self.intervalTime
    -- if intervalTime < self.INTERVALTIME then
    --     return
    -- end
    self.intervalTime = TimeUtil.ServerTime()
    local nTime = self.endTime - TimeUtil.ServerTime()
    local runTime = TimeUtil.ServerTime() - self.startTime
    if not runTime then
        return
    end
    local n = math.floor(runTime / self.unit.buildingLevelTemplate.time)
    local newProduct = (n - self.takeCount) * self.productCount

    local t = self.startTime + self.unit.buildingLevelTemplate.time * (n + 1)
    local time = t - TimeUtil.ServerTime()
    local progress = 1 - time / self.unit.buildingLevelTemplate.time

    if nTime <= 1 then
        self.slider.value = 1
    else
        self.slider.value = progress
    end

    if self.tipAni and newProduct > 0 then
        self.tipAni:Play(ONHOOKTIPANI.play)
    else
        self.tipAni:Play(ONHOOKTIPANI.idle)
    end
    local zResidueTakeCount = self.everyOneTakeCount * self.residueTakeCount
    if zResidueTakeCount < 0 then
        self.txt.text = ""
    else
        self.txt.text = newProduct .. "/" .. zResidueTakeCount
    end
    self.unit:SetIsTake(math.floor(newProduct / self.productCount))
end

function UnitOnHookBuildProductDoingTips:Update()
    UnitTipsBase.Update(self)
    self:RefreshTime()
end

return UnitOnHookBuildProductDoingTips
