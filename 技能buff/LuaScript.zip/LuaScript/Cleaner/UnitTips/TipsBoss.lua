---@type UnitTipsBase
local UnitTipsBase = require "Cleaner.UnitTips.Base.UnitTipsBase"

---@class TipsBoss : UnitTipsBase
local TipsBoss = class(UnitTipsBase, "TipsBoss")

function TipsBoss:ctor(unitId)
    self.positionRefreshTime = 0
    self.offsetPos = Vector3(0, 3, 0)
    self.isLoaded = false
    self:SetUseUpdate(true)
    self:SetTipsPath("TipsBoss.prefab")
end

function TipsBoss:Refresh()
    if not self.isLoaded then
        return
    end

    self.txt_name.text = "Boss"
end

function TipsBoss:LoadFinish()
    UnitTipsBase.LoadFinish(self)
    self.isLoaded = true

    self.transform = self.go.transform
    self.txt_name = self.transform:Find("txt_name"):GetComponent(typeof(Text))
    self:Refresh()
end

function TipsBoss:Update()
    UnitTipsBase.Update(self)
    self:CalculatePosition()
end

return TipsBoss