---@type UnitTipsBase
local UnitTipsBase = require "Cleaner.UnitTips.Base.UnitTipsBase"

---@class UnitBreedFinishTips : UnitTipsBase
local UnitBreedFinishTips = class(UnitTipsBase, "UnitBreedFinishTips")

function UnitBreedFinishTips:ctor(unitId)
    self.startTime = 0
    self.endTime = 0
    self.totalTime = 0
    self.offsetPos = Vector3(0, 1, 0)
    self:SetUseUpdate(false)
    self:SetTipsPath("TipsCommonFinish.prefab")
end

function UnitBreedFinishTips:LoadFinish()
    UnitTipsBase.LoadFinish(self)
    self.transform = self.go.transform
end

return UnitBreedFinishTips
