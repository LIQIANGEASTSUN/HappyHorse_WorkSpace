---@type UnitTipsBase
local UnitTipsBase = require "Cleaner.UnitTips.Base.UnitTipsBase"

---@class UnitBreedDoingTips : UnitTipsBase
local UnitBreedDoingTips = class(UnitTipsBase, "UnitBreedDoingTips")

function UnitBreedDoingTips:ctor(unitId)
    self.startTime = 0
    self.endTime = 0
    self.totalTime = 0
    self.offsetPos = Vector3(0, 1, 0)
    self:SetUseUpdate(true)
    self:SetTipsPath("TipsCommonDoing.prefab")
    self:RegisterEvent()
end

function UnitBreedDoingTips:RegisterEvent()
    self:UnRegisterEvent()
    MessageDispatcher:AddMessageListener(MessageType.BuildingUpLevel, self.BuildingUpLevel, self)
end
function UnitBreedDoingTips:UnRegisterEvent()
    MessageDispatcher:RemoveMessageListener(MessageType.BuildingUpLevel, self.BuildingUpLevel, self)
end

-- 建筑升级事件
function UnitBreedDoingTips:BuildingUpLevel(agentId, msg)
    if AppServices.PetNestManager:IsPetNestAgent(agentId) then --确保是栖息地才处理
        self:SetEndTime()
    end
end

function UnitBreedDoingTips:BindElement()
    self.textContent = find_component(self.go, "IconBG/Text_content", Text)
end

function UnitBreedDoingTips:SetEndTime()
    self.startTime = AppServices.BreedManager:GetBreedAnimalTime()
    self.cfg = AppServices.Meta:Category("BreedTemplate")
    local sn = AppServices.BreedManager:GetBreedAnimalID()
    if sn then
        self.CurCfgRow = self.cfg[tostring(sn)]
        local nValue = AppServices.PetNestManager:GetBreedCD(self.CurCfgRow.habitatSn)
        local nv = self.CurCfgRow.breedTime + nValue
        self.endTime = self.startTime + (nv * 60)
    end
end

function UnitBreedDoingTips:RefreshTime()
    if not self.go then
        return
    end
    local sn = AppServices.BreedManager:GetBreedAnimalID()
    if sn then
        local nTime = self.endTime - TimeUtil.ServerTime()
        if nTime <= 0 then
            self:Destroy()
            AppServices.BreedManager:SetBreedsIsFinish(true)
            MessageDispatcher:SendMessage(MessageType.OnStartBreed, ProductionStatus.Finish)
            return
        end
        AppServices.BreedManager:SetBreedsIsFinish(false)
        self.textContent.text = TimeUtil.SecToMS(nTime)
    end
end

function UnitBreedDoingTips:LoadFinish()
    UnitTipsBase.LoadFinish(self)
    self.transform = self.go.transform
    self:BindElement()
    self:SetEndTime()
end

function UnitBreedDoingTips:Update()
    UnitTipsBase.Update(self)
    self:RefreshTime()
end

function UnitBreedDoingTips:Destroy()
    UnitTipsBase.Destroy(self)
end

return UnitBreedDoingTips
