---@type PlayerStateInfo
local PlayerStateInfo = require "Fsm.Player.PlayerStateInfo"

---@type SceneTemplateTool
local SceneTemplateTool = require "Fsm.Ship.SceneTemplateTool"

---@class PlayerJoystickManager
local PlayerJoystickManager = {
    rockGo = nil,
    isCreating = false,

    joystickDatas = {
        playerState = PlayerStateInfo.StateType.Activate,
        openIslandLevelPanel = false,
    }
}

function PlayerJoystickManager:CreateJoyStick(callBack)
    if Runtime.CSValid(self.joyStick) then
        if callBack then
            callBack(self.joyStick)
        end
        return
    end

    if self.isCreating then
        return
    end

    local function onLoaded()
        self.rockGo = BResource.InstantiateFromAssetName(CONST.ASSETS.G_UI_VIRTUAL_JOYSTICK)
        local canvas = self.rockGo:GetComponent(typeof(Canvas))
        canvas.worldCamera = App.scene:GetSceneCamer()

        self.joyStick = find_component(self.rockGo, "InputPanel", CS.VirtualJoystick.VirtualJoystick)
        self.isCreating = false

        if Runtime.CSValid(self.rockGo) then
            self:SetActiveRock(self.show)
        end
        if callBack then
            callBack(self.joyStick)
        end
    end

    self.isCreating = true
    App.buildingAssetsManager:LoadAssets({CONST.ASSETS.G_UI_VIRTUAL_JOYSTICK}, onLoaded)
end

function PlayerJoystickManager:SetPlayerState(playerState)
    self.joystickDatas.playerState = playerState
    self:Check()
end

function PlayerJoystickManager:SetOpenIslandLevelPanel(value)
    self.joystickDatas.openIslandLevelPanel = value
    self:Check()
end

function PlayerJoystickManager:Check()
    local result = self:JoystickEnableShow()
    self:SetActiveRock(result)
end

function PlayerJoystickManager:JoystickEnableShow()
    local sceneId = App.scene:GetCurrentSceneId()
    local type = SceneTemplateTool:GetType(sceneId)
    if type == SceneTemplateType.Homeland then
        return false
    end

    if self.joystickDatas.playerState ~= PlayerStateInfo.StateType.Activate then
        return false
    end

    if self.joystickDatas.openIslandLevelPanel then
        return false
    end

    return true
end

-- 显示隐藏摇杆
function PlayerJoystickManager:SetActiveRock(value)
    self.show = value

    if not Runtime.CSValid(self.rockGo) then
        if value then
            self:CreateJoyStick()
        end
    else
        self.rockGo:SetActive(value)
    end
end

function PlayerJoystickManager:Destroy()
    if not Runtime.CSValid(self.rockGo) then
        GameObject.Destroy(self.rockGo)
    end
end

return PlayerJoystickManager