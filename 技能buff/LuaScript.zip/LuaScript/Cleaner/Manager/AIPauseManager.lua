---@class AIPauseManager
local AIPauseManager = {}

function AIPauseManager:Init()
    self.pauseAi = false
    self.pauseAIUI = {
        ["IslandFailPanel"] = GlobalPanelEnum.IslandFailPanel,
        ["PetIllustratedPanel"] = GlobalPanelEnum.PetIllustratedPanel,
    }

    self:RegisterEvent()
end

function AIPauseManager:AfterShowPanel(panelVO)
    self.pauseAi = false

    if self.pauseAIUI[panelVO.panelName] then
        self.pauseAi = true
    end
end

function AIPauseManager:AfterDestroyPanel(panelVO)
    self.pauseAi = false
    for _, v in pairs(self.pauseAIUI) do
        if PanelManager.isPanelShowing(v) then
            self.pauseAi = true
            break
        end
    end
end

function AIPauseManager:GetPauseAI()
    return self.pauseAi
end

function AIPauseManager:RegisterEvent()
    MessageDispatcher:AddMessageListener(MessageType.Global_After_Show_Panel, self.AfterShowPanel, self)
    MessageDispatcher:AddMessageListener(MessageType.Global_After_Destroy_Panel, self.AfterDestroyPanel, self)
end

function AIPauseManager:UnRegisterEvent()
    MessageDispatcher:RemoveMessageListener(MessageType.Global_After_Show_Panel, self.AfterShowPanel, self)
    MessageDispatcher:RemoveMessageListener(MessageType.Global_After_Destroy_Panel, self.AfterDestroyPanel, self)
end

function AIPauseManager:Release()
    self:UnRegisterEvent()
    self.pauseAi = false
end

return AIPauseManager