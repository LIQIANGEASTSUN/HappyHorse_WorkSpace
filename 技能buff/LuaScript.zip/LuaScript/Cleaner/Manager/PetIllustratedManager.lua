---@class PetIllustratedManager
local PetIllustratedManager = {}

-- 获取跟随出战的宠物
function PetIllustratedManager:GetInBattleTeamPet()
    local result = {}
    local pets = AppServices.User:GetPets()
    if not pets then
        return result
    end
    for _, pet in pairs(pets) do
        if pet.up == 1 then
            table.insert(result, pet)
        end
    end
    return result
end

function PetIllustratedManager:PlayerLevel()
    local level = AppServices.User:Level()
    return level
end

-- 角色可以携带的最大宠物数量
function PetIllustratedManager:GetMaxCount()
    local config = AppServices.Meta:Category("ConfigTemplate")
    local value = config["petLimitNum"].value
    return tonumber(value)
end

-- Player 当前等级可以携带几个宠物
function PetIllustratedManager:GetPlayerLevelTakeCount()
    local level = self:PlayerLevel()
    local config = AppServices.Meta:Category("LevelTemplate")
    local data = config[tostring(level)]
    return data.takePetNum
end

function PetIllustratedManager:EnableAddPetToTeam()
    local pets = AppServices.PetIllustratedManager:GetInBattleTeamPet()
    local enableUseCount = AppServices.PetIllustratedManager:GetPlayerLevelTakeCount()
    return #pets < enableUseCount
end

function PetIllustratedManager:PetUpTeam(pet)
    AppServices.NetPetManager:SendPetUp(pet.id)
    MessageDispatcher:SendMessage(MessageType.Pet_Up_Team, pet)
end

function PetIllustratedManager:PetDownTeam(pet)
    AppServices.NetPetManager:SendPedDown(pet.id)
    MessageDispatcher:SendMessage(MessageType.Pet_Down_Team, pet)
end

return PetIllustratedManager
