---@class BuildingModifyManager @建筑管理类
local BuildingModifyManager = {
    curUid = 100000,
    curOnHookBuildAgent = nil, -- 挂机建筑的
    delayTime = 1.5
}

function BuildingModifyManager:Init()
    self.sceneName = App.scene:GetCurrentSceneId()
    MessageDispatcher:AddMessageListener(
        MessageType.EntryHomelandAndCameraMoveEnd,
        self.EntryHomelandAndCameraMoveEnd,
        self
    )
    AppServices.Net:Recieved(
        MsgMap.SCMoveBuildings,
        function(msg)
            self:OnReceiveMove(msg)
        end
    )

    AppServices.Net:Recieved(
        MsgMap.SCCleanObj,
        function(msg)
            self:OnReceiveClean(msg)
        end
    )

    AppServices.Net:Recieved(
        MsgMap.SCUnlockBuildings,
        function(msg)
            self:OnReceivePay(msg)
        end
    )

    AppServices.Net:Recieved(
        MsgMap.SCPutBuildings,
        function(msg)
            self:OnReceivePut(msg)
        end
    )
end
function BuildingModifyManager:IsSceneChanged()
    if App.scene then
        return self.sceneName ~= App.scene:GetCurrentSceneId()
    end
    return true
end

---@param agent BaseAgent
function BuildingModifyManager:SendMove(agent)
    -- CSMoveBuildings
    local x, z = agent:GetMin()
    local msg = {
        id = agent:GetId(),
        toPos = {x = x, y = z}
    }

    if agent:GetType() == AgentType.onHookBuild then
        agent:OnMoved()
    end

    AppServices.Net:Send(MsgMap.CSMoveBuildings, msg)
end
function BuildingModifyManager:OnReceiveMove(msg)
    if self:IsSceneChanged() then
        console.error("scene has changed!!!") --@DEL
        return
    end
    local agent = App.scene.objectManager:GetAgent(msg.id)
    if not agent then
        return
    end
    if msg.errorCode and msg.errorCode ~= 0 then
        agent:OnMoveFailed()
    else
        agent:OnMoveSucess()
    end
end

function BuildingModifyManager:SendClean(agent)
    local id = agent:GetId()
    local msg = {
        id = id
    }
    AppServices.Net:Send(MsgMap.CSCleanObj, msg)
end
function BuildingModifyManager:OnReceiveClean(msg)
    -- if self:IsSceneChanged() then
    --     console.error("scene has changed!!!") --@DEL
    --     return
    -- end
    -- local agent = App.scene.objectManager:GetAgent(msg.id)
    -- if not agent then
    --     return
    -- end
    console.hjs("OnReceiveClean:", table.tostring(msg)) --@DEL
end

function BuildingModifyManager:SendPay(agentId, payId, payCount)
    local info = {
        id = agentId,
        cost = {{key = payId, value = payCount}}
    }
    console.hjs("send pay: ", table.tostring(info)) --@DEL
    AppServices.Net:Send(MsgMap.CSUnlockBuildings, info)
end
function BuildingModifyManager:SendUnlockPetNest(agentId, costs) --请求建造栖息地
    ---@type CSUnlockBuildings
    local msg = {
        id = agentId,
        cost = {}
    }
    if costs then
        for _, cost in ipairs(costs) do
            table.insert(msg.cost, {key = cost[1], value = cost[2]})
        end
    end
    console.hxp("### SendUnlock", table.tostring(msg)) --@DEL
    AppServices.NetWorkManager:Send(MsgMap.CSUnlockBuildings, msg)
end
---@param msg SCUnlockBuildings
function BuildingModifyManager:OnReceivePay(msg)
    if not msg then
        console.hxp("### msg nil.") --@DEL
        return
    end
    local agentId = msg.id
    if msg.status <= 0 then
        console.hxp("### unlock failed", agentId) --@DEL
        return
    end
    local time = msg.time
    -- if self:IsSceneChanged() then
    --     console.error("scene has changed!!!") --@DEL
    --     return
    -- end
    local agent = App.scene.objectManager:GetAgent(agentId)
    if not agent then
        console.hxp("### agent not exist.", agentId) --@DEL
        return
    end
    console.hjs("OnReceivePay:", table.tostring(msg)) --@DEL
    if AppServices.PetNestManager:IsPetNestAgent(agentId) then --确保是栖息地才处理
        AppServices.SceneDataManager.current:SetHangTime(agentId, time)
        agent:SetLevel(1) --解锁后为1级
    end
    MessageDispatcher:SendMessage(MessageType.BuildingUnlock, agentId, msg)
end

---@param buildingData BuildingData
function BuildingModifyManager:ShowBuildingGridRationality(state, buildingData)
    self.GridRationalityIndicator:Show(state, buildingData)
end
function BuildingModifyManager:HideBuildingGridRationality()
    self.GridRationalityIndicator:Hide()
end

---建筑全局唯一id(客户端分配)(因为建筑升级时沿用之前低级建筑的通讯识别码uniqueName, 容易造成混乱)
function BuildingModifyManager:GetAutoBuildId()
    return "CID_" .. CS.System.DateTime.Now.Ticks
end

---@private
function BuildingModifyManager:GetAutoBuildData(metaId)
    local meta = AppServices.Meta:GetBindingMeta(metaId)
    if meta then
        local AgentDataType = App.scene.objectManager.GetDataType(meta.type)
        ---@type AgentData
        local data = AgentDataType.new({}, meta)
        local uid = self:GetAutoBuildId()
        local msg = {
            id = uid,
            tid = metaId,
            level = 1,
            direction = false,
            pos = {x = 0, y = 0}
        }
        data:InitServerData(uid, msg)

        if App.scene.mapManager:GetAutoBuild(data) then
            data:CommitTile()
            return data
        else
            -- self:PromoteBuyRegion()
            console.warn(nil, "No place to build!")
        end
    else
        console.error(nil, "No Building Meta:", metaId)
    end
end

function BuildingModifyManager:CreateAgentAuto(tid)
    local data = self:GetAutoBuildData(tid)
    if data then
        local sd = data:GetServerData()
        AppServices.Net:Send(
            MsgMap.CSPutBuildings,
            {
                tid = tid,
                pos = sd.pos,
                instanceId = tostring(sd.id)
            }
        )
        local agent = App.scene.objectManager:CreateAgent(data:GetId(), sd)
        App.scene.objectManager.sceneObjs[agent:GetId()] = agent
        App.scene.mapManager:InsertObject(agent)
        agent:InitState(CleanState.cleared)
        agent:HandleStateChanged()
        agent:EnterEditMode()
        PanelManager.showPanel(GlobalPanelEnum.MovePanel, {agent = agent})
        local position = agent:GetWorldPosition()
        MoveCameraLogic.Instance():MoveCameraToLook2(position, 0.5)
        return true
    end
    return false
end

---直接创建新获得的建筑物并放置在算出来的位置上
function BuildingModifyManager:CreateAgentNoEdit(tid, NeedMoveCamera)
    local data = self:GetAutoBuildData(tid)
    if data then
        local sd = data:GetServerData()
        AppServices.Net:Send(
            MsgMap.CSPutBuildings,
            {
                tid = tid,
                pos = sd.pos,
                instanceId = tostring(sd.id)
            }
        )
        local agent = App.scene.objectManager:CreateAgent(data:GetId(), sd)
        App.scene.objectManager.sceneObjs[agent:GetId()] = agent
        App.scene.mapManager:InsertObject(agent)
        agent:InitState(CleanState.cleared)
        agent:HandleStateChanged()
        if NeedMoveCamera then
            local position = agent:GetWorldPosition()
            MoveCameraLogic.Instance():MoveCameraToLook2(position, 0.5)
        end
        return true
    end
    return false
end

---直接创建新获得的建筑物并放置在算出来的位置上
function BuildingModifyManager:CreateAndFlyAgentNoEdit(tid, fromPos, NeedMoveCamera)
    local duration = 1
    local data = self:GetAutoBuildData(tid)
    if data then
        local sd = data:GetServerData()
        AppServices.Net:Send(
            MsgMap.CSPutBuildings,
            {
                tid = tid,
                pos = sd.pos,
                instanceId = tostring(sd.id)
            }
        )
        local agent = App.scene.objectManager:CreateAgent(data:GetId(), sd)
        App.scene.objectManager.sceneObjs[agent:GetId()] = agent
        App.scene.mapManager:InsertObject(agent)
        agent:InitState(CleanState.cleared)
        agent:HandleStateChanged()
        agent:InitRender(
            function(success)
                if not success then
                    return
                end
                local go = agent:GetGameObject()
                local position = go:GetPosition()
                local moveTween = go.transform:DOMove(position, duration)
                moveTween:ChangeStartValue(fromPos)

                go:SetLocalScale(0.2, 0.2, 0.2)
                go.transform:DOScale(1, duration)
            end
        )
        if NeedMoveCamera then
            local position = agent:GetWorldPosition()
            MoveCameraLogic.Instance():MoveCameraToLook2(position, duration)
        end
        return true
    end
    return false
end

-- 挂机建筑
function BuildingModifyManager:CreateOnHookBuildAgentAuto(tid)
    -- local data = self:GetAutoBuildData(tid)
    -- if data then
    --     local sd = data:GetServerData()
    --     AppServices.Net:Send(
    --         MsgMap.CSPutBuildings,
    --         {
    --             tid = tid,
    --             pos = sd.pos,
    --             instanceId = tostring(sd.id)
    --         }
    --     )
    --     local agent = App.scene.objectManager:CreateAgent(data:GetId(), sd)
    --     self.curOnHookBuildAgent = agent
    --     App.scene.objectManager.sceneObjs[agent:GetId()] = agent
    --     App.scene.mapManager:InsertObject(agent)
    --     agent:InitState(CleanState.cleared)
    --     agent:HandleStateChanged()
    --     return true
    -- end
    return false
end

-- 初始化未构建的挂机建筑 从道具数据中
function BuildingModifyManager:InitNotBuiltOnHookBuild()
    -- body
    -- local itemList = AppServices.User:GetItemsList()
    -- for _, v in pairs(itemList) do
    --     if ItemId.IsBuilding(v.itemId) then
    --         for i = 1, v.count do
    --             AppServices.FloatBuildingBubbleManager:CreateBubble(v.itemId)
    --         end
    --     end
    -- end
end

function BuildingModifyManager:OnReceivePut(msg)
    if self:IsSceneChanged() then
        console.error("scene has changed!!!") --@DEL
        return
    end
    local agent = App.scene.objectManager:GetAgent(msg.instanceId)
    if not agent then
        console.error("did not find agent:", tostring(msg.instanceId)) --@DEL
        return
    end
    if msg.errorCode ~= 0 then
        agent:Destroy()
        return
    end
    agent:SetId(msg.id)
    App.scene.objectManager.sceneObjs[msg.instanceId] = nil
    App.scene.objectManager.sceneObjs[msg.id] = agent
end

-- 进入家园摄像机移动完毕信息
function BuildingModifyManager:EntryHomelandAndCameraMoveEnd()
    local moveCamera = function()
        if self.curOnHookBuildAgent then
            console.jf("...进入家园后摄像机移动完毕检测是否有挂机的建筑...")
            local position = self.curOnHookBuildAgent:GetWorldPosition()
            if not App.mapGuideManager:HasRunningGuide() then
                MoveCameraLogic.Instance(true):MoveCameraToLook2(position, 0.5)
            end
            self.curOnHookBuildAgent = nil
        end
    end

    WaitExtension.SetTimeout(moveCamera, self.delayTime)
end

---场景切换, 数据缓存清除
function BuildingModifyManager:Release()
    MessageDispatcher:RemoveMessageListener(
        MessageType.EntryHomelandAndCameraMoveEnd,
        self.EntryHomelandAndCameraMoveEnd,
        self
    )
    AppServices.Net:Remove(
        MsgMap.SCMoveBuildings,
        function(msg)
            self:OnReceiveMove(msg)
        end
    )

    AppServices.Net:Remove(
        MsgMap.SCCleanObj,
        function(msg)
            self:OnReceiveClean(msg)
        end
    )

    AppServices.Net:Remove(
        MsgMap.SCUnlockBuildings,
        function(msg)
            self:OnReceivePay(msg)
        end
    )

    AppServices.Net:Remove(
        MsgMap.SCPutBuildings,
        function(msg)
            self:OnReceivePut(msg)
        end
    )
    ---建筑场景配置信息
    if self.GridRationalityIndicator then
        self.GridRationalityIndicator:OnDestroy()
    end
    self.GridRationalityIndicator = nil
end
return BuildingModifyManager
