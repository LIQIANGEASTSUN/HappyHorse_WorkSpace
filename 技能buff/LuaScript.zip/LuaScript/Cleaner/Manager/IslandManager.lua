---@type SceneTemplateTool
local SceneTemplateTool = require "Fsm.Ship.SceneTemplateTool"

---@type IslandManager
local IslandManager = {
    -- 解锁的岛屿
    unlcokIslandMap = {},
    shipDockLevel = 1,
    progressMax = 10000,

    costAgentType = {
        [AgentType.ground] = true,
        [AgentType.linkHomeland_groud] = true,
    },
    costAgents = {},
    bossAgents = {}
}

function IslandManager:Init()
    self:RegisterEvent()
end

function IslandManager:InIsland()
    local sceneId = App.scene:GetCurrentSceneId()
    local type = SceneTemplateTool:GetType(sceneId)
    local isIsland = (type == SceneTemplateType.Island)
    return isIsland, sceneId
end

-- 岛屿可以出航
function IslandManager:EnableSailling(islandId)
    return self:IsUnLock(islandId)
end

function IslandManager:GetShipDockInfo()
    local id = self.shipDockId
    local sn = self.shipDockSn
    local level = self.shipDockLevel
    return id, sn, level
end

-- 岛屿解锁
function IslandManager:IsUnLock(islandId)
    local result = self.unlcokIslandMap[islandId]
    if result then
        return true
    end

    local type = SceneTemplateTool:GetType(islandId)
    if type == SceneTemplateType.Homeland then
        return true
    end

    local metaData = SceneTemplateTool:GetData(islandId)
    local unlockCondition = metaData.unlockCondition
    if not unlockCondition or #unlockCondition <= 0 then
        return true
    end

    result = true
    for _, data in pairs(unlockCondition) do
        if data[1] == IslandUnlockCondition.ShipDock_Level then
            result = self:CheckShipyardLevel(data)
        elseif data[1] == IslandUnlockCondition.Pre_island then
            result = self:CheckIslandProgress(data)
        end

        if not result then
            break
        end
    end

    self.unlcokIslandMap[islandId] = result
    return result
end

function IslandManager:CheckShipyardLevel(data)
    return self.shipDockLevel >= tonumber(data[2])
end

function IslandManager:GetIslandProgress(islandId)
    local progress = AppServices.User:GetSceneProgress(islandId)
    return progress / self.progressMax
end

function IslandManager:CheckIslandProgress(data)
    local preIslandId = data[2]
    local progress = AppServices.User:GetSceneProgress(preIslandId)
    return progress >= self.progressMax
end

function IslandManager:BuildingRemove(removeBuildId)
    self:Calculate()
    self:CheckIslandComplete()
end

function IslandManager:PlotNumCleared(sceneId, agentId)
    self:Calculate()
    self:CheckIslandComplete()
end

function IslandManager:CheckIslandComplete()
    local sceneId = App.scene:GetCurrentSceneId()
    local progress = self:GetIslandProgress(sceneId)
    if progress >= 1 then
        MessageDispatcher:SendMessage(MessageType.IslandLinkHomeland, sceneId)
    end
end

function IslandManager:Calculate()
    local islandId = App.scene:GetCurrentSceneId()
    local progress = AppServices.User:GetSceneProgress(islandId)
    if progress >= self.progressMax then
        return
    end
    local total = #self.costAgents + #self.bossAgents
    if total <= 0 then
        self:SendSceneProcess(islandId, self.progressMax)
        return
    end

    local count = 0
    for _, id in ipairs(self.costAgents) do
        local agent = App.scene.objectManager:GetAgent(id)
        local state = agent:GetState()
        if state == CleanState.cleared then
            count = count + 1
        end
    end

    for _, id in ipairs(self.bossAgents) do
        local agent = App.scene.objectManager:GetAgent(id)
        if not agent then
            count = count + 1
        end
    end

    local progress = math.floor(count / total * self.progressMax)
    AppServices.NetIslandManager:SendSceneProgress(islandId, progress)
    MessageDispatcher:SendMessage(MessageType.IslandProgressChange, islandId, progress)
end

function IslandManager:GetAllMonsterAgent()
    local islandId = App.scene:GetCurrentSceneId()
    local islandConfig = SceneTemplateTool:GetData(islandId)
    local monsterId = islandConfig.monsterId
    for _, id in pairs(monsterId) do
        table.insert(self.bossAgents, id)
    end
end

function IslandManager:GetPlotNum(agentId)
    --local islandConfig = SceneTemplateTool:GetData(islandId)
    --return islandConfig.plotNum
    return #self.costAgents
end

function IslandManager:ShipDockLevel(id, sn, level)
    self.shipDockId = id
    self.shipDockSn = sn
    self.shipDockLevel = level
end

function IslandManager:GetLatestSaillingId()
    local result = SceneTemplateTool:GetMaxIslandId()
    local ids = SceneTemplateTool:GetAllIsland()
    local enableSailing = false
    for _, id in pairs(ids) do
        enableSailing = self:EnableSailling(id)
        if enableSailing then
            result = id
            break
        end
    end

    return result
end

function IslandManager:ChangeScene()
    self.costAgents = {}
    self.bossAgents = {}
    self:GetAllMonsterAgent()
end

function IslandManager:CheckAgent(agent)
    local type = agent:GetType()
    if not self.costAgentType[type] then
        return
    end

    local _, _, total = agent:GetCurrentCost()
    if total <= 0 then
        return
    end
    table.insert(self.costAgents, agent:GetId())
end

function IslandManager:BossAgent(agent)
    local type = agent:GetType()
    if type ~= AgentType.animal then
        return
    end
    local monsterId = agent.data.mapData.monsterId
    local configId = tostring(monsterId)
    local monsterConfig = AppServices.Meta:Category("MonsterTemplate")[tostring(configId)]
    local isBossAgent = (monsterConfig.isBoss == 1)
    if not isBossAgent then
        return
    end
    table.insert(self.bossAgents, agent:GetId())
end

function IslandManager:RegisterEvent()
    MessageDispatcher:AddMessageListener(MessageType.BuildingRemove, self.BuildingRemove, self)
    MessageDispatcher:AddMessageListener(MessageType.ShipDockLevel, self.ShipDockLevel, self)
    MessageDispatcher:AddMessageListener(MessageType.Global_After_Plant_Cleared, self.PlotNumCleared, self)
end

function IslandManager:UnRegisterEvent()
    MessageDispatcher:RemoveMessageListener(MessageType.BuildingRemove, self.BuildingRemove, self)
    MessageDispatcher:RemoveMessageListener(MessageType.ShipDockLevel, self.ShipDockLevel, self)
    MessageDispatcher:RemoveMessageListener(MessageType.Global_After_Plant_Cleared, self.PlotNumCleared, self)
end

function IslandManager:Release()
    self:UnRegisterEvent()
end

return IslandManager



--[[
    function IslandManager:BuildingRemove(removeBuildId)
    local islandId = App.scene:GetCurrentSceneId()
    local progress = AppServices.User:GetSceneProgress(islandId)
    if progress >= self.progressMax then
        return
    end

    local bossIds = self:GetAllMonsterAgent(islandId)
    if #bossIds <= 0 then
        return
    end
    local plotNum = self:GetPlotNum(islandId)
    local total = (#bossIds + plotNum)

    local modify = false
    local progress = 0
    for _, bossId in pairs(bossIds) do
        if tostring(bossId) == removeBuildId then
            modify = true
            progress = 1 / total * self.progressMax
        end
    end

    if modify then
        self:ProgressChange(islandId, progress)
    end
end

function IslandManager:PlotNumCleared(sceneId, agentId)
    local islandId = App.scene:GetCurrentSceneId()
    local progress = AppServices.User:GetSceneProgress(islandId)
    if progress >= self.progressMax then
        return
    end

    local plotNum = self:GetPlotNum(islandId)
    if plotNum <= 0 then
        return
    end
    local bossIds = self:GetAllMonsterAgent(islandId)
    local total = (#bossIds + plotNum)
    local progress = 1 / total * self.progressMax
    self:ProgressChange(islandId, progress)
end

]]