---@class FloatBuildingBubbleManager @建筑管理类
local FloatBuildingBubbleManager = {
    show = true
}
local BubblePath = "Prefab/UI/Common/MapBubble.prefab"

-- 在区域中随机一个坐标
function FloatBuildingBubbleManager:GetRandPosOnRegion()
    local regionid = 1
    local region = App.scene.mapManager:FindRegion(regionid)
    if region then
        local x = math.random(region.bounds.xMin, region.bounds.xMax)
        local z = math.random(region.bounds.zMin, region.bounds.zMax)
        return App.scene.mapManager:ToWorld(x, z)
    end
    return Vector3(20, 0, 10)
end

-- 添加气泡
function FloatBuildingBubbleManager:OnLoadedBubble(buildID, position)
    if Runtime.CSNull(self.bubbleRoot) then
        self.bubbleRoot = GameUtil.CreateWorldCanvas("BubbleRoot")
        self.bubbleRoot.layer = CS.UnityEngine.LayerMask.NameToLayer("UI")
        self.bubbleRoot:SetPosition(0, 0.1, 0)
        self.bubbleRoot:SetActive(self.show)
    end
    local go = BResource.InstantiateFromAssetName(BubblePath, self.bubbleRoot, false)

    -- local img = find_component(go, "Image_bubble", Image)
    -- img.raycastTarget = true
    local pos
    local FloatBuildingBubble = require("MainCity.UI.FloatBuildingBubble")
    local bubble = FloatBuildingBubble.new(go)
    local bubbleData = self:GetOneBuildBubbleByBuildID(buildID)

    if bubbleData then
        pos = position or Vector3(bubbleData.position.x, bubbleData.position.y, bubbleData.position.z)
        bubble:SetData(
            {
                position = pos,
                tid = bubbleData.tid,
                new = false
            }
        )
    else
        pos = position or self:GetRandPosOnRegion()
        local _tid = AppServices.BuildingModifyManager:GetAutoBuildId()
        bubble:SetData(
            {
                position = {x = pos.x, y = pos.y, z = pos.z},
                tid = _tid,
                new = true
            }
        )
    end
    pos.y = 0
    go:SetPosition(pos)
    bubble:Init(buildID)
    self:SetBuildBubble({id = buildID, data = bubble:GetData()})
end

function FloatBuildingBubbleManager:ShowAll()
    self.show = true
    if Runtime.CSValid(self.bubbleRoot) then
        self.bubbleRoot:SetActive(true)
    end
end
function FloatBuildingBubbleManager:HideAll()
    self.show = false
    if Runtime.CSValid(self.bubbleRoot) then
        self.bubbleRoot:SetActive(false)
    end
end

-- 添加气泡
function FloatBuildingBubbleManager:CreateBubble(buildID, position)
    buildID = tostring(buildID)
    console.jf("...添加气泡... buildID", buildID) --@DEL

    App.commonAssetsManager:LoadAssets(
        {BubblePath},
        function()
            self:OnLoadedBubble(buildID, position)
        end
    )
end

-------------------------------------------------------------------------------------------------------------------------------------------------------------

-- local FILENAME = "bubble.dat"
-- local PATH = FileUtil.GetPersistentPath() .. "/" .. AppServices.User:GetUid() .. FILENAME
-- local PATH = "C:/Users/Administrator/" .. AppServices.User:GetUid() .. FILENAME
function FloatBuildingBubbleManager:TryInitFromFile()
    local buildBubbleInfo = AppServices.User.BubbleData:GetKeyValue(USERDEFAULTKEY.buildBubble, {})
    if buildBubbleInfo then
        for _, value in pairs(buildBubbleInfo) do
            if table.len(value) > 0 then
                for _, v in pairs(value) do
                    v.new = true
                end
            end
        end
    else
        buildBubbleInfo = {}
    end
    self:SetBuildBubbleInfo(buildBubbleInfo)

    --TODO 以后再选择一个好时机吧
    MessageDispatcher:AddMessageListener(MessageType.On_Enter_ExploreIsland, self.HideAll, self)
    MessageDispatcher:AddMessageListener(MessageType.EntryHomelandAndCameraMoveEnd, self.ShowAll, self)
end

-- function FloatBuildingBubbleManager:InitFromData(src)

-- end

function FloatBuildingBubbleManager:SyncData(data)
    -- self:InitFromData(data)
    self:WriteToFile()
end

function FloatBuildingBubbleManager:WriteToFile()
    AppServices.User.BubbleData:SetKeyValue(USERDEFAULTKEY.buildBubble, self.buildBubbleInfo, true)
end

function FloatBuildingBubbleManager:decode(src)
    local data
    --封装新数据, 兼容老数据
    if src and src.data then
        data = src.data
    else
        -- 老数据
        data = src
    end
    return data
end

function FloatBuildingBubbleManager:SetBuildBubbleInfo(info)
    if info then
        self.buildBubbleInfo = info
        return
    end
    self.buildBubbleInfo = {}
end

function FloatBuildingBubbleManager:SetBuildBubble(info)
    local cache = self.buildBubbleInfo[info.id]
    info.data.new = false
    if cache then
        local found = false
        for _, value in pairs(cache) do
            if value.tid == info.data.tid then
                value = info.data
                found = true
                break
            end
        end
        if not found then
            table.insert(cache, info.data)
        end
    else
        self.buildBubbleInfo[info.id] = {}
        cache = {}
        table.insert(cache, info.data)
    end
    self.buildBubbleInfo[info.id] = cache
    self:WriteToFile()
end

-- 获取绑定建筑ID的所有气泡数据
function FloatBuildingBubbleManager:GetOneBuildBubbleByBuildID(buildID)
    if not self.buildBubbleInfo then
        AppServices.FloatBuildingBubbleManager:TryInitFromFile()
    end

    local _table = self.buildBubbleInfo[buildID]
    local _value = nil
    if _table then
        for _, value in pairs(_table) do
            if value.new == true then
                value.new = false
                _value = value
                break
            end
        end
    end
    return _value
end

-- 重置气泡数据(气泡被拖拽结束调用一次)
function FloatBuildingBubbleManager:ResetBuildBubbleDataByBubbleID(buildID, bubbleID, newData)
    local _data = self.buildBubbleInfo[buildID]
    if _data then
        for i, v in ipairs(_data) do
            if v.tid == bubbleID then
                _data[i] = newData
            end
        end
    end
    self.buildBubbleInfo[buildID] = _data
    self:WriteToFile()
end

-- 删除气泡数据
function FloatBuildingBubbleManager:RemoveBuildBubbleByBubbleID(buildID, bubbleID)
    local data = self.buildBubbleInfo[buildID]
    local removeIndex
    for i, v in ipairs(data) do
        if v.tid == bubbleID then
            removeIndex = i
        end
    end
    console.jf(
        "self:RemoveBuildBubbleByBubbleID...",
        "buildID:",
        buildID,
        "bubbleID:",
        bubbleID,
        "removeIndex:",
        removeIndex
    )
    table.remove(self.buildBubbleInfo[buildID], removeIndex)
    self:WriteToFile()
end

return FloatBuildingBubbleManager
