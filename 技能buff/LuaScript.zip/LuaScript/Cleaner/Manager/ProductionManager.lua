
---@class ProductionManager
local ProductionManager = {}

function ProductionManager:Init()
    self:RegisterEvent()
end

function ProductionManager:AddAll()

end

function ProductionManager:AddProduction(id)

end

function ProductionManager:RemoveProduction(id)

end

function ProductionManager:Release()
    self.UnRegisterEvent()
end

function ProductionManager:RegisterEvent()
    MessageDispatcher:AddMessageListener(MessageType.AddProduction, self.AddProduction, self)
    MessageDispatcher:AddMessageListener(MessageType.RemoveProduction, self.RemoveProduction, self)
end

function ProductionManager:UnRegisterEvent()
    MessageDispatcher:RemoveMessageListener(MessageType.AddProduction, self.AddProduction, self)
    MessageDispatcher:RemoveMessageListener(MessageType.RemoveProduction, self.RemoveProduction, self)
end

return ProductionManager