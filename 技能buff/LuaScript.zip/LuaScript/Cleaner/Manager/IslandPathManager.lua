---@type PathFindingController
local PathFindingController = require "Cleaner.PathFinding.PathFindingController"

---@type FindPathInfo
local FindPathInfo = require "Cleaner.PathFinding.FindPathInfo"

---@type IslandPathManager
local IslandPathManager = {
}

function IslandPathManager:Init()
    self.pathFindingController = PathFindingController.new(FindPathInfo.AlgorithmType.Astar, FindPathInfo.MapType.Quad_Eight_Cleaner)
end

function IslandPathManager:Search(startPos, endPos)
    local list = self.pathFindingController:Search(startPos.x, startPos.y, endPos.x, endPos.y)
    return list
end

function IslandPathManager:EnablePass(x, y)
    return self.pathFindingController:EnablePass(x, y)
end

function IslandPathManager:PlayerEnablePass(x, y)
    return self.pathFindingController:PlayerEnablePass(x, y)
end

function IslandPathManager:RandomPath(x, y)
    return self.pathFindingController:RandomPath(x, y)
end

function IslandPathManager:Release()
    self.pathFindingController = nil
end

return IslandPathManager