---@class IslandFightManager
local IslandFightManager = {}

--- 战斗状态
local FightState = {
    --- 无效状态
    None = 1,
    --- 战斗中
    Fighting = 2,
}

function IslandFightManager:StartFight(islandId)
    self:RegisterEvent()
    self.islandId = tonumber(islandId)
    self.fightState = FightState.Fighting
    self.entityHpMap = {}
    self.deathMap = {}
    self.quiteIsland = false
    local data = self:ReadFile()
    self:SetHpData(data)
end

function IslandFightManager:SetHpData(data)
    if tonumber(data.islandId) <= 0 or tonumber(data.islandId) ~= self.islandId then
        return
    end

    for _, hpData in pairs(data.hpDatas) do
        local type = hpData.type
        local hp = hpData.hp
        self:SetTypeHp(type, hp)
    end
end

function IslandFightManager:PetDown(entityId)
    self:CheckFail()
end

function IslandFightManager:EntityDeath(entityId, sn)
    local entity = AppServices.EntityManager:GetEntity(entityId)
    local entityType = entity:GetEntityType()
    if entityType ~= EntityType.Pet then
        return
    end
    local petConfig = AppServices.Meta:Category("PetTemplate")[tostring(sn)]
    self.deathMap[petConfig.type] = true
    self:CheckFail()
    self:WriteFile()
end

function IslandFightManager:PetRecover()
    self.deathMap = {}
    self.entityHpMap = {}
end

function IslandFightManager:CheckFail()
    if self.fightState == FightState.None then
        return
    end

    if (not self:IsFail()) then
        return
    end

    MessageDispatcher:SendMessage(MessageType.IslandFail)
    local sceneId = App.scene:GetCurrentSceneId()
    AppServices.NetIslandManager:SendExploredFail(sceneId)

    if self.waitFailPanel then
        return
    end
    self.waitFailPanel = true
    PopupManager:CallWhenIdle(function ()
        self.waitFailPanel = false
        if self.fightState == FightState.Fighting and self:IsFail() then
            PanelManager.showPanel(GlobalPanelEnum.IslandFailPanel)
        end
    end)
end

function IslandFightManager:IsFail()
    local pets = AppServices.User:GetPets()
    if #pets <= 0 then
        return false
    end

    local upTeamCount = 0
    local deathCount = 0
    for _, pet in pairs(pets) do
        if pet.up ~= 0 then
            upTeamCount = upTeamCount + 1
            if self.deathMap[pet.type] then
                deathCount = deathCount + 1
            end
        end
    end

    return deathCount >= upTeamCount
end

function IslandFightManager:SetTypeHp(type, hp)
    self.entityHpMap[type] = hp
end

function IslandFightManager:GetTypeHp(type)
    return self.entityHpMap[type]
end

function IslandFightManager:QuitFight(islandId)
    self.islandId = tonumber(islandId)
    self.fightState = FightState.None

    self.quiteIsland = true
    self:WriteFile()
    self.entityHpMap = {}
    self.deathMap = {}
    self:UnRegisterEvent()
end

function IslandFightManager:RegisterEvent()
    MessageDispatcher:AddMessageListener(MessageType.EntityDeath, self.EntityDeath, self)
    MessageDispatcher:AddMessageListener(MessageType.IslandFightWriteFile, self.WriteFile, self)
    MessageDispatcher:AddMessageListener(MessageType.PetRecover, self.PetRecover, self)
end

function IslandFightManager:UnRegisterEvent()
    MessageDispatcher:RemoveMessageListener(MessageType.EntityDeath, self.EntityDeath, self)
    MessageDispatcher:RemoveMessageListener(MessageType.IslandFightWriteFile, self.WriteFile, self)
    MessageDispatcher:RemoveMessageListener(MessageType.PetRecover, self.PetRecover, self)
end

--- File ------------------------------------------------
function IslandFightManager:FilePath()
    if not self.filePath then
        self.filePath = FileUtil.GetPersistentPath() .. "/" .. AppServices.User:GetUid() .. "islandFight.dat"
    end
    return self.filePath
end

function IslandFightManager:ReadFile()
    local filePath = self:FilePath()
    local rawData = FileUtil.ReadFromFile(filePath, true)
    local data = self:decode(table.deserialize(rawData))
    return data
end

function IslandFightManager:WriteFile()
    local data = self:encode()
    local jsonStr = table.serialize(data)
    local filePath = self:FilePath()
    FileUtil.SaveWriteFile(jsonStr, filePath, true)
end

function IslandFightManager:encode()
    local data = self:decode(nil)

    data.islandId = self.islandId
    for type, hp in pairs(self.entityHpMap) do
        local hpData = {type = type, hp = hp}
        table.insert(data.hpDatas, hpData)
    end

    data.quiteIsland = self.quiteIsland
    return data
end

function IslandFightManager:decode(data)
    if not data then
        data = {}
        data.islandId = -1
        data.hpDatas = {}
    end

    if data.quiteIsland then
        data.hpDatas = {}
    end

    return data
end
--------------------------------------------------------

return IslandFightManager