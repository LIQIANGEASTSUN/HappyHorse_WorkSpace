---@class NetExploreIslandManager 探索地图网络消息
local NetExploreIslandManager = {}

function NetExploreIslandManager:Init()
    self:RegisterEvent()
end

function NetExploreIslandManager:CheckFirstEnterIsland(sn)
    if not AppServices.User:IsExploredIsland(sn) then
        AppServices.NetWorkManager:Send(MsgMap.CSExploreIsland, {sn = sn})
    end
end

function NetExploreIslandManager:OnExploreIsland(msg)
    local sn = msg.sn
    AppServices.User:SetExploredIsland(sn)
    MessageDispatcher:SendMessage(MessageType.On_FisrtEnter_ExploreIsland, sn)
end

function NetExploreIslandManager:RegisterEvent()
    -- 注册消息
    -- AppServices.NetWorkManager:addObserver(MsgMap.SCExploreIsland, self.OnExploreIsland, self)
    -- MessageDispatcher:AddMessageListener(MessageType.On_Enter_ExploreIsland, self.CheckFirstEnterIsland, self)
end

function NetExploreIslandManager:UnRegisterEvent()
    -- AppServices.NetWorkManager:removeObserver(MsgMap.SCExploreIsland, self.OnExploreIsland, self)
    -- MessageDispatcher:RemoveMessageListener(MessageType.On_Enter_ExploreIsland, self.CheckFirstEnterIsland, self)
end

function NetExploreIslandManager:Release()
    self:UnRegisterEvent()
end

return NetExploreIslandManager
