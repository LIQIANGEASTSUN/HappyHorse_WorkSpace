-- 引导网络消息模块
---@class NetGuideManager
local NetGuideManager = {
    recycles = {}
}

function NetGuideManager:Init()
    self:RegisterEvent()
end
function NetGuideManager:Release()
    self:UnRegisterEvent()
end
function NetGuideManager:RegisterEvent()
    AppServices.NetWorkManager:addObserver(MsgMap.CSGuide, self.SendGuideComplete, self)
    AppServices.NetWorkManager:addObserver(MsgMap.SCGuide, self.ReceiveGuideComplete, self)
end
function NetGuideManager:UnRegisterEvent()
    AppServices.NetWorkManager:removeObserver(MsgMap.CSGuide, self.SendGuideComplete, self)
    AppServices.NetWorkManager:removeObserver(MsgMap.SCGuide, self.ReceiveGuideComplete, self)
end

--region Request
---@param msg CSGuide
function NetGuideManager:SendGuideComplete(guideId)
    local msg = {
        id = guideId
    }
    AppServices.NetWorkManager:Send(MsgMap.CSGuide, msg)
end
---@param msg SCGuide
function NetGuideManager:ReceiveGuideComplete(msg)
    App.mapGuideManager:SetCompleteIdsElement(msg.id)
end
--endregion

return NetGuideManager
