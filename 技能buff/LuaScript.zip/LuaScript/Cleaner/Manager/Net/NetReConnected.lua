---@type LoginServer
local LoginServer = require "Login.LoginServer"

---@class NetReConnected
local NetReConnected = {}

function NetReConnected:Init()
    self:RegisterEvent()
end

function NetReConnected:ReconnectSuccess()
    local loginInfo = AppServices.User:GetLoginInfo()
    if not loginInfo then
        return
    end

    --console.error("NetReConnected:ReconnectSuccess:")
    local msg = {
        userIdentity = loginInfo.userIdentity,
        token = loginInfo.token
    }
    AppServices.Net:Send(MsgMap.CSReconnect, msg)
end

function NetReConnected:ReceiveReconnected(msg)
    local resultCode = msg.resultCode
    --console.error("NetReConnected:ReceiveReconnected:"..tostring(resultCode))
    if resultCode < 0 then
        --LoginServer:ConnectServer(info, bindpage)
        local info, bindpage = AppServices.User:GetLoginInfo()
        AppServices.Net:Send(MsgMap.CSLogin, info)
    else
        -- MessageDispatcher:SendMessage(MessageType.ConnectedServer)
        AppServices.Connecting:ClosePanel()
    end
end

function NetReConnected:Release()
    self:UnRegisterEvent()
end

function NetReConnected:RegisterEvent()
    AppServices.NetWorkManager:addObserver(MsgMap.SCReconnect, self.ReceiveReconnected, self)
end

function NetReConnected:UnRegisterEvent()
    AppServices.NetWorkManager:removeObserver(MsgMap.SCReconnect, self.ReceiveReconnected, self)
end

return NetReConnected
