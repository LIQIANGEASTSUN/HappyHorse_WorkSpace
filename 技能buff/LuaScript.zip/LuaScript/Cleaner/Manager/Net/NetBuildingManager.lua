-- 宠物网络消息模块
---@class NetBuildingManager
local NetBuildingManager = {}

---@type SceneTemplateTool
local SceneTemplateTool = require "Fsm.Ship.SceneTemplateTool"

function NetBuildingManager:Init()
    self:RegisterEvent()
end

-- 发送建筑升级
function NetBuildingManager:SendBuildLevel(id)
    local msg = {id = tostring(id)}
    AppServices.NetWorkManager:Send(MsgMap.CSLevelBuildings, msg)
end

-- 接收建筑升级
function NetBuildingManager:ReceiveBuildLevel(msg)
    local id = msg.id
    local level = msg.level

    local agent = App.scene.objectManager:GetAgent(id)
    agent:SetLevel(level)

    MessageDispatcher:SendMessage(MessageType.BuildingUpLevel, id, level, agent:GetTemplateId())
    -- PopupManager:CallWhenIdle(
    --     function()
    --         local arguments = {id = id, sn = agent:GetTemplateId(), level = level}
    --         PanelManager.showPanel(GlobalPanelEnum.BuildUpLevelPanel, arguments)
    --     end
    -- )

    local params = {
        buildingID = tostring(id),
        buildingLevel = level
    }
    DcDelegates:Log("building_upgrade", params)
end

-- 发送生产消息
function NetBuildingManager:SendStartProduction(id)
    local msg = {id = tostring(id)}
    AppServices.NetWorkManager:Send(MsgMap.CSStartProduction, msg)
end

-- 接收生产消息
function NetBuildingManager:ReceiveStartProduction(msg)
    local id = msg.id
    MessageDispatcher:SendMessage(MessageType.ReceiveStartProduction, id)

    local productionData = AppServices.User:GetProduction(id)
    local count = productionData and 0 or 1
    local itemId

    local productNum = {}
    if productionData then
        for _, item in pairs(productionData.outItem) do
            if not itemId then
                itemId = item.key
            end
            count = count + item.value
            productNum[item.key] = item.value
        end
    end
    MessageDispatcher:SendMessage(MessageType.StartProduction, itemId, count)

    local islandId = SceneTemplateTool:GetHomelandId()
    local agent = App.scene.objectManager:GetAgent(id)
    local params = {
        buildingID = tostring(id),
        buildingLevel = agent:GetLevel(),
        productNum = productNum,
        islandID = tostring(islandId)
    }
    DcDelegates:Log("building_product", params)
end

function NetBuildingManager:SendTakeProduction(id)
    local msg = {id = tostring(id)}
    AppServices.NetWorkManager:Send(MsgMap.CSTakeProduction, msg)
    -- local production = AppServices.User:GetProduction(id)
    -- if production then
    --     production.status = 0
    -- end
    --console.error("SendTakeProduction:"..id)
end

function NetBuildingManager:ReceiveTakeProduction(msg)
    local id = msg.id
    local production = AppServices.User:GetProduction(id)
    AppServices.User:RemoveProduction(id)
    MessageDispatcher:SendMessage(MessageType.BuildingTakeProduction, id, production)
    --console.error("ReceiveTakeProduction:"..id)
end

function NetBuildingManager:SendRemoveBuilding(id)
    local msg = {id = tostring(id)}
    AppServices.SceneDataManager.current:SetRemoveBuild(id)
    AppServices.NetWorkManager:Send(MsgMap.CSRemoveBuildings, msg)
    MessageDispatcher:SendMessage(MessageType.BuildingRemove, id)
end

function NetBuildingManager:ReceiveRemoveBuilding(msg)
    local id = msg.id
    MessageDispatcher:SendMessage(MessageType.BuildingRemove, id)
end

function NetBuildingManager:SendSpeedProduction(agentId)
    local msg = {
        id = agentId
    }
    AppServices.NetWorkManager:Send(MsgMap.CSSpeedProduction, msg)
    --console.error("SendSpeedProduction:"..type(agentId).."   "..agentId)
    self:ReceiveSpeedProduction(msg)
end

--- 食品工厂加速
function NetBuildingManager:ReceiveSpeedProduction(msg)
    local agentId = msg.id
    local data = AppServices.User:GetProduction(agentId)
    local time = TimeUtil.ServerTime()
    data.endTime = time - 1
    --console.error("ReceiveSpeedProduction:"..type(agentId).."   "..agentId)
end

-- CS挂机建筑
function NetBuildingManager:SendOnHookBuilding(msg)
    console.jf("...CS挂机建筑...")
    local _msg = {id = tostring(msg.id), petId = msg.petId}
    local agent = App.scene.objectManager:GetAgent(msg.id)
    if agent then
        local unit = agent:GetUnit(UnitType.OnHookBuildUnit)
        if unit then
            unit:SetPetID(msg.petId)
            unit:StartTakeProduction()
        end
    end

    -- 埋点挂机生产
    local buildingLevelTemplate = agent:GetUnit(UnitType.OnHookBuildUnit).buildingLevelTemplate
    local _productNum = {}
    local key = tostring(buildingLevelTemplate.production[1][1])
    local value = buildingLevelTemplate.production[1][2]
    _productNum[key] = value
    local param = {
        buildingID = tostring(agent:GetId()),
        buikdingLevel = agent:GetLevel(),
        productNum = _productNum,
        islandID = tostring(SceneTemplateTool:GetHomelandId())
    }
    DcDelegates:Log("building_product", param)

    AppServices.NetWorkManager:Send(MsgMap.CSHangProduction, _msg)
end

-- SC挂机建筑
function NetBuildingManager:ReceiveOnHookBuilding(msg)
    console.jf("...SC挂机建筑...")
end

-- 领取挂机建筑
function NetBuildingManager:SendTakeHangProduction(id)
    local msg = {id = tostring(id)}
    AppServices.NetWorkManager:Send(MsgMap.CSTakeHangProduction, msg)

    -------------------------- 领取挂机建筑奖励埋点 ---------------------------------

    local agent = App.scene.objectManager:GetAgent(msg.id)
    if not agent then
        return
    end
    local buildingLevelTemplate = agent:GetUnit(UnitType.OnHookBuildUnit).buildingLevelTemplate
    local param = {
        rewardItemId = tostring(buildingLevelTemplate.production[1][1]),
        rewardCount = buildingLevelTemplate.production[1][2]
    }
    DcDelegates:Log("idle_reward", param)
end

function NetBuildingManager:ReceiveTakeHangProduction(msg)
    -- body
end

-- 穿戴协议
function NetBuildingManager:SendSkinWear(id)
    local nID = tonumber(id)
    local msg = {sn = nID}
    AppServices.DressUpMabager:SetPlayerSkinWear(nID)
    CharacterManager.Instance():SetPlayerSkin(id)
    MessageDispatcher:sendSubMessage(MessageType.PlayerChangeSkinNotice) -- 穿戴的通知
    AppServices.NetWorkManager:Send(MsgMap.CSSkinWear, msg)
end

-- 穿戴协议
function NetBuildingManager:ReceiveSkinWear(msg)
    console.jf("...穿戴协议协议网络返回...ID", msg.sn)
end

--- 栖息地领取收益
function NetBuildingManager:SendPetNestProduction(id)
    local msg = {id = tostring(id)}
    AppServices.NetWorkManager:Send(MsgMap.CSTakeHomeReward, msg)
end

--- 栖息地领取收益回调
function NetBuildingManager:ReceivePetNestProduction(msg)
    local id = msg.id
    local time = msg.time
    MessageDispatcher:SendMessage(MessageType.PetNestTakeHomeReward, id)
    AppServices.SceneDataManager.current:SetHangTime(id, time)
end

-- 开始繁育
function NetBuildingManager:SendPetBreed(id)
    local msg = {sn = tostring(id)}
    AppServices.BreedManager:SetBreedsIsFinish(false)
    AppServices.NetWorkManager:Send(MsgMap.CSPetBreed, msg)
end

-- 开始繁育
function NetBuildingManager:ReceivePetBreed(msg)
    console.jf("..........开始繁育.....................msg.id", msg.id)
    AppServices.BreedManager:SetBreedOnlyID(msg.id)
    MessageDispatcher:SendMessage(MessageType.OnStartBreed, ProductionStatus.Doing)
end

-- 繁育奖励
function NetBuildingManager:SendPetBreedReward(id)
    local msg = {id = tostring(id)}
    AppServices.BreedManager:SetBreedOnlyID(nil)
    AppServices.NetWorkManager:Send(MsgMap.CSTakeBreedReward, msg)
end

-- 繁育奖励
function NetBuildingManager:ReceivePetBreedReward(msg)
    -- body
    console.jf("..........繁育奖励.....................msg.id", msg.id)
    msg.sn = AppServices.BreedManager:GetBreedAnimalID()
    MessageDispatcher:SendMessage(MessageType.OnStartBreed, ProductionStatus.None)
    MessageDispatcher:SendMessage(MessageType.OnEndBreed, msg)
    AppServices.BreedManager:ClearPetBreeds()
end

-- 繁育加速
function NetBuildingManager:SendPetSpeedBreed(id)
    local msg = {id = tostring(id)}
    AppServices.NetWorkManager:Send(MsgMap.CSSpeedBreed, msg)
    self:SendPetBreedReward(id)
end

-- 繁育加速
function NetBuildingManager:ReceiveSpeedBreedReward(msg)
    console.jf("..........繁育加速.....................msg.id", msg.id)
end

function NetBuildingManager:RegisterEvent()
    AppServices.NetWorkManager:addObserver(MsgMap.SCLevelBuildings, self.ReceiveBuildLevel, self)
    AppServices.NetWorkManager:addObserver(MsgMap.SCStartProduction, self.ReceiveStartProduction, self)
    AppServices.NetWorkManager:addObserver(MsgMap.SCTakeProduction, self.ReceiveTakeProduction, self)
    AppServices.NetWorkManager:addObserver(MsgMap.SCRemoveBuildings, self.ReceiveRemoveBuilding, self)
    --- 挂机建筑
    AppServices.NetWorkManager:addObserver(MsgMap.SCHangProduction, self.ReceiveOnHookBuilding, self)
    AppServices.NetWorkManager:addObserver(MsgMap.SCSpeedProduction, self.ReceiveSpeedProduction, self)
    AppServices.NetWorkManager:addObserver(MsgMap.SCTakeHangProduction, self.ReceiveTakeHangProduction, self)
    AppServices.NetWorkManager:addObserver(MsgMap.SCSkinWear, self.ReceiveSkinWear, self)
    AppServices.NetWorkManager:addObserver(MsgMap.SCTakeHomeReward, self.ReceivePetNestProduction, self)
    -- 繁育
    AppServices.NetWorkManager:addObserver(MsgMap.SCPetBreed, self.ReceivePetBreed, self)
    AppServices.NetWorkManager:addObserver(MsgMap.SCTakeBreedReward, self.ReceivePetBreedReward, self)
    AppServices.NetWorkManager:addObserver(MsgMap.SCSpeedBreed, self.ReceiveSpeedBreedReward, self)
end

function NetBuildingManager:UnRegisterEvent()
    AppServices.NetWorkManager:removeObserver(MsgMap.SCLevelBuildings, self.ReceiveBuildLevel, self)
    AppServices.NetWorkManager:removeObserver(MsgMap.SCStartProduction, self.ReceiveStartProduction, self)
    AppServices.NetWorkManager:removeObserver(MsgMap.SCTakeProduction, self.ReceiveTakeProduction, self)
    AppServices.NetWorkManager:removeObserver(MsgMap.SCRemoveBuildings, self.ReceiveRemoveBuilding, self)
    --- 挂机建筑
    AppServices.NetWorkManager:removeObserver(MsgMap.SCHangProduction, self.ReceiveOnHookBuilding, self)
    AppServices.NetWorkManager:removeObserver(MsgMap.SCSpeedProduction, self.ReceiveSpeedProduction, self)
    AppServices.NetWorkManager:removeObserver(MsgMap.SCTakeHangProduction, self.ReceiveTakeHangProduction, self)
    AppServices.NetWorkManager:removeObserver(MsgMap.SCSkinWear, self.ReceiveSkinWear, self)
    AppServices.NetWorkManager:removeObserver(MsgMap.SCTakeHomeReward, self.ReceivePetNestProduction, self)
    -- 繁育
    AppServices.NetWorkManager:removeObserver(MsgMap.SCPetBreed, self.ReceivePetBreed, self)
    AppServices.NetWorkManager:removeObserver(MsgMap.SCTakeBreedReward, self.ReceivePetBreedReward, self)
    AppServices.NetWorkManager:removeObserver(MsgMap.SCSpeedBreed, self.ReceiveSpeedBreedReward, self)
end

function NetBuildingManager:Release()
    self:UnRegisterEvent()
end

return NetBuildingManager
