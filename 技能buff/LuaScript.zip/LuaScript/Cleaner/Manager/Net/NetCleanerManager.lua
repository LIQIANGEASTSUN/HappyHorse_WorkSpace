-- Cleaner网络消息模块
---@class NetCleanerManager
local NetCleanerManager = {
    recycles = {}
}

function NetCleanerManager:Init()
    self:RegisterEvent()
end
function NetCleanerManager:Release()
    self:UnRegisterEvent()
end

function NetCleanerManager:OnCleanerLvUp(msg)
    -- local level = AppServices.User:Level()
    -- local exp = AppServices.User:GetExpTotal()
    -- if level == msg.level and exp == msg.exp then --两端数据一致
    -- else
    --     console.hxp("### 此时两端数据不一致", level, msg.level, exp, msg.exp) --@DEL
    -- end
    --AppServices.User:SetExp(msg.exp)
end

function NetCleanerManager:RegisterEvent()
    AppServices.NetWorkManager:addObserver(MsgMap.SCRoleLevelUp, self.OnCleanerLvUp, self)
end

function NetCleanerManager:UnRegisterEvent()
    AppServices.NetWorkManager:removeObserver(MsgMap.SCRoleLevelUp, self.OnCleanerLvUp, self)
end

return NetCleanerManager
