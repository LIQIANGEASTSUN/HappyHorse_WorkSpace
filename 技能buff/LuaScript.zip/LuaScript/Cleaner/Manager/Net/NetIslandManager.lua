---@class NetIslandManager
local NetIslandManager = {}

-- 初始化
function NetIslandManager:Init()
    self:RegisterEvent()
end

function NetIslandManager:SendUnlockIsland(sn)
    local msg = {
        sn = tonumber(sn)
    }
    AppServices.NetWorkManager:Send(MsgMap.CSUnlockIsland, msg)
end

-- 岛屿解锁
function NetIslandManager:ReceiveUnlockIsland(msg)
    --local islandId = tonumber(msg.sn)
    --AppServices.User:SetUnlockIsland(islandId)
end

-- 岛屿连接到家园
function NetIslandManager:ReceiveLinkIsland(msg)
    --local islandId = tonumber(msg.sn)
    --AppServices.User:SetLinkIsland(islandId)
end

function NetIslandManager:SendExploredFail(sn)
    local msg = {
        sn = tonumber(sn)
    }
    AppServices.NetWorkManager:Send(MsgMap.CSExploreFail, msg)
end

function NetIslandManager:ReceiveExploredFail(msg)
    --local islandId = tonumber(msg.sn)
end

function NetIslandManager:SendSceneProgress(sn, progress)
    local msg = {
        sn = tonumber(sn),
        progress = progress
    }
    AppServices.NetWorkManager:Send(MsgMap.CSSceneProgress, msg)
    AppServices.User:SetSceneProgress(sn, progress)
end

function NetIslandManager:ReceiveSceneProgress(msg)

end

-- 注册消息
function NetIslandManager:RegisterEvent()
    -- 注册消息
    AppServices.NetWorkManager:addObserver(MsgMap.SCUnlockIsland, self.ReceiveUnlockIsland, self)
    AppServices.NetWorkManager:addObserver(MsgMap.SCLinkIsland, self.ReceiveLinkIsland, self)
    AppServices.NetWorkManager:addObserver(MsgMap.SCExploreFail, self.ReceiveExploredFail, self)
    AppServices.NetWorkManager:addObserver(MsgMap.CSSceneProgress, self.ReceiveSceneProgress, self)
end

-- 移除消息
function NetIslandManager:UnRegisterEvent()
    -- 移除消息
    AppServices.NetWorkManager:removeObserver(MsgMap.SCUnlockIsland, self.ReceiveUnlockIsland, self)
    AppServices.NetWorkManager:removeObserver(MsgMap.SCLinkIsland, self.ReceiveLinkIsland, self)
    AppServices.NetWorkManager:removeObserver(MsgMap.SCExploreFail, self.ReceiveExploredFail, self)
    AppServices.NetWorkManager:removeObserver(MsgMap.CSSceneProgress, self.ReceiveSceneProgress, self)
end

-- 释放
function NetIslandManager:Release()
    self:UnRegisterEvent()
end

return NetIslandManager
