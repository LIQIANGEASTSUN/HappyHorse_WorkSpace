--[[
    栖息地相关消息
]]
---@class NetPetNestManager
local NetPetNestManager = {}

---@class CSUnlockBuildings
---@field id number Agent Id
---@field cost CSUnlockBuildingsItem[]
-- cost = {
--     {key = itemId, value = cost}
-- }

---@class CSUnlockBuildingsItem
---@field key string itemId
---@field value number 消耗数

---@class SCUnlockBuildings
---@field id string Agent Id
---@field status number 0:未解锁 1:已解锁
---@field time number 同步服务器帧时间（ms）

---@class CSLevelBuildings
---@field id string 建筑物唯一id

---@class SCLevelBuildings
---@field id string 建筑物唯一id
---@field level number 建筑等级

function NetPetNestManager:Init()
    self:RegisterEvent()
end
function NetPetNestManager:Release()
    self:UnRegisterEvent()
end
function NetPetNestManager:RegisterEvent()
    -- AppServices.NetWorkManager:addObserver(MsgMap.SCUnlockBuildings, self.ReceiveUnlock, self)
end
function NetPetNestManager:UnRegisterEvent()
    -- AppServices.NetWorkManager:removeObserver(MsgMap.SCUnlockBuildings, self.ReceiveUnlock, self)
end

-- function NetPetNestManager:SendUnlock(agentId, costs)
--     ---@type CSUnlockBuildings
--     local msg = {
--         id = agentId,
--         cost = {}
--     }
--     if costs then
--         for _, cost in ipairs(costs) do
--             table.insert(msg.cost, {key = cost[1], value = cost[2]})
--         end
--     end
--     console.hxp("### SendUnlock", table.tostring(msg)) --@DEL
--     AppServices.NetWorkManager:Send(MsgMap.CSUnlockBuildings, msg)
-- end
-- ---@param msg SCUnlockBuildings
-- function NetPetNestManager:ReceiveUnlock(msg)
--     console.hxp("### ReceiveUnlock:", table.tostring(msg)) --@DEL
--     local agentId = msg.id
--     MessageDispatcher:SendMessage(MessageType.BuildingUnlock, agentId)
-- end

return NetPetNestManager
