-- 繁育
---@type BreedManager
local BreedManager = {}

---@type PetTemplateTool
local PetTemplateTool = require "Cleaner.Entity.Pet.PetTemplateTool"

function BreedManager:Init()
    self.breedData = nil
    self.BreedAnimalTable = {}
    self.newAddBreedAnimalID = nil
    self.cfg = AppServices.Meta:Category("BreedTemplate")
    self:RegisterEvent()
end

function BreedManager:RegisterEvent()
    self:UnRegisterEvent()
    MessageDispatcher:AddMessageListener(MessageType.AddPet, self.AddPet, self)
    MessageDispatcher:AddMessageListener(MessageType.PetUpLevel, self.AddPet, self)
    MessageDispatcher:AddMessageListener(MessageType.OnEndBreed, self.StartReward, self)
    -- MessageDispatcher:AddMessageListener(MessageType.BuildingUnlock, self.BuildingUnlock, self)
end
function BreedManager:UnRegisterEvent()
    MessageDispatcher:RemoveMessageListener(MessageType.AddPet, self.AddPet, self)
    MessageDispatcher:RemoveMessageListener(MessageType.PetUpLevel, self.AddPet, self)
    MessageDispatcher:RemoveMessageListener(MessageType.OnEndBreed, self.StartReward, self)
    -- MessageDispatcher:RemoveMessageListener(MessageType.BuildingUnlock, self.BuildingUnlock, self)
end

-- 获取宠物的事件
function BreedManager:AddPet()
    console.jf("...获取宠物的事件...")
    self:NewAddBreedAnimal()
end

function BreedManager:InitBreedAnimal()
    for key, value in pairs(self.cfg) do
        if self:GetIsLock(value) == false then
            if table.indexOf(self.BreedAnimalTable, value.sn) == nil then
                table.insert(self.BreedAnimalTable, value.sn)
            end
        end
    end
end

function BreedManager:NewAddBreedAnimal()
    for key, value in pairs(self.cfg) do
        if self:GetIsLock(value) == false then
            if table.indexOf(self.BreedAnimalTable, value.sn) == nil then
                table.insert(self.BreedAnimalTable, value.sn)
                self:SetNewAddBreedAnimalID(value.sn)
                console.jf("提示 ： 出现了new的宠物可以繁育了 ....")
                MessageDispatcher:SendMessage(MessageType.OnBreedUnLock, ProductionStatus.None)
            end
        end
    end
end

function BreedManager:SetNewAddBreedAnimalID(sn)
    self.newAddBreedAnimalID = sn
end

function BreedManager:GetNewAddBreedAnimalID()
    return self.newAddBreedAnimalID
end

-- 当前繁育动物的表ID（sn）
function BreedManager:SetBreedAnimalID(id)
    self.breedAnimalID = id
end

-- 繁育动物的ID
function BreedManager:GetBreedAnimalID()
    return self.breedAnimalID
end

-- 当前繁育动物时间
function BreedManager:SetBreedAnimalTime(num)
    self.breedAnimalTime = num
end

-- 繁育动物的时间
function BreedManager:GetBreedAnimalTime()
    if not self.breedAnimalTime then
        self:SetBreedAnimalTime(TimeUtil.ServerTime())
    end
    return self.breedAnimalTime
end

-- 设置繁育是否完成
function BreedManager:SetBreedsIsFinish(b)
    self.breedIsFinish = b
end

-- 繁育是否完成
function BreedManager:GetBreedsIsFinish()
    return self.breedIsFinish
end

-- 设置繁育信息
function BreedManager:SetPetBreeds(breedsData)
    if breedsData then
        self.breedData = breedsData[1]
        self:SetBreedAnimalID(self.breedData.sn)
        self:SetBreedAnimalTime(self.breedData.startTime * 0.001)
        self:SetBreedOnlyID(self.breedData.id)
    end
    self:InitBreedAnimal()
end

-- 清除繁育信息
function BreedManager:ClearPetBreeds()
    self.breedData = nil
    self:SetBreedAnimalID(nil)
    self:SetBreedAnimalTime(nil)
    self:SetBreedOnlyID(nil)
end

-- 繁育信息
function BreedManager:GetPetBreeds()
    console.jf("繁育信息为：", self.breedData)
    return self.breedData
end

-- 繁育唯一 id
function BreedManager:SetBreedOnlyID(id)
    self.breedOnlyID = id
end
-- 繁育唯一 id
function BreedManager:GetBreedOnlyID()
    return self.breedOnlyID
end

--  宠物是或否可以繁育
function BreedManager:GetIsLock(cfg)
    local isLock = true
    local parent1Key = PetTemplateTool:Getkey(cfg.parentType1, cfg.parentLevel1)
    local parent2Key = PetTemplateTool:Getkey(cfg.parentType2, cfg.parentLevel2)

    local cfg1 = PetTemplateTool:GetData(parent1Key)
    local cfg2 = PetTemplateTool:GetData(parent2Key)

    local pet1 = AppServices.User:GetPetWithType(cfg1.type)
    local pet2 = AppServices.User:GetPetWithType(cfg2.type)

    if pet1 and pet2 then
        if pet1.level >= cfg.parentLevel1 and pet2.level >= cfg.parentLevel2 then
            isLock = false
        end
    end
    return isLock
end

function BreedManager:GetCfg()
    return self.cfg
end

-- 繁育奖励
function BreedManager:StartReward(msg)
    local reward = msg.reward
    local sn = tostring(msg.sn)
    local cfg = self.cfg[sn].product
    local getInfos = {}

    console.jf("..........繁育奖励........reward....", reward.key, reward.value)

    for key, value in pairs(cfg) do
        if reward.key == value[1] and reward.value == value[2] then
            table.insert(getInfos, {value[1], value[2]})
        end
    end
    local msg = {rewardItems = cfg, getInfos = getInfos, hasDragon = true}
    PanelManager.showPanel(GlobalPanelEnum.BreedRandomPanel, msg)
end

-- 控制摄像机 打开UI
function BreedManager:OnShowBreedPanel(agentId, callback)
    local agent = App.scene.objectManager:GetAgent(agentId)
    if agent then
        local pos = agent:GetCenterPostion()
        self:CameraFocus2Agent(pos, callback, 0.5, 40)
    end
end

function BreedManager:CameraFocus2Agent(pos, callback, duration, cameraSize)
    duration = duration or 0.3
    cameraSize = cameraSize or 40
    MoveCameraLogic.Instance():MoveCameraToLook2(pos, duration, cameraSize, callback, true)
end

BreedManager:Init()
return BreedManager
