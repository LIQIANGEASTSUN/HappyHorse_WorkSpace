local EntityTypes = setmetatable(
    {
        _register = {
            [EntityType.Monster] = "MonsterEntity",
            [EntityType.Pet] = "PetEntity",
            [EntityType.PetHL] = "PetHLEntity",
        }
    },
    {
        __index = function(t, k)
            local alias = t._register[k]
            if not alias then
                alias = "BaseEntity"
            end
            local path = "Cleaner.Entity."..alias
            local v = require(path)
            rawset(t, k, v)
            return v
        end
    }
)

---@class EntityManager 生物管理器
local EntityManager = {
    ---@type Dictionary<number, BaseEntity>
    entityDic = {},
    ---@type List<number>
    entityCallLateUpate = {},
    instanceId = 100000000
}

local InvokeCbk = Runtime.InvokeCbk
local CSNull = Runtime.CSNull
local entityRoot = nil

--每次进入场景执行一次
function EntityManager:Initialize(callback)
    self:RegisterEvents()
end

function EntityManager:HandleClick()
    local ids = UserInput.getCastList()
    for _, id in pairs(ids) do
        local entity = self:GetEntity(id)
        if entity then
            entity:ProcessClick()
        end
    end
end

function EntityManager:NewInstanceId()
    self.instanceId = self.instanceId + 1
    return self.instanceId
end

function EntityManager:CreateEntity(id, entityType, callback)
    local entityId = self:NewInstanceId()
    local entityClass = EntityTypes[entityType]
    local baseEntity = entityClass.new(entityId, entityType, id)

    local finish = function()
        self.entityDic[baseEntity.entityId] = baseEntity
        if baseEntity.NeedLateUpdate and baseEntity:NeedLateUpdate() then
            table.insert(self.entityCallLateUpate, baseEntity.entityId)
        end
        InvokeCbk(callback, baseEntity)
    end

    baseEntity:InitRender(finish)
end

function EntityManager:GetRoot()
    if CSNull(entityRoot) then
        entityRoot = GameObject("MagicalCreaturesRootCanvas")
        entityRoot:SetLocalScale(Vector3.one)
        entityRoot:SetPosition(Vector3.zero)
    end
    return entityRoot
end

---@return BaseEntity[]
function EntityManager:GetEntityWithType(entityType)
    local list = {}
    for _, entity in pairs(self.entityDic) do
        if entity:GetEntityType() == entityType then
            table.insert(list, entity)
        end
    end
    return list
end

---@return BaseEntity
function EntityManager:GetEntity(entityId)
    return self.entityDic[entityId]
end

---@return BaseEntity
function EntityManager:GetEntityWithName(name)
    local entityId = tonumber(name)
    if not entityId then
        return nil
    end
    return self:GetEntity(entityId)
end

function EntityManager:GetAllEntity()
    local entities = {}
    for _, v in pairs(self.entityDic) do
        table.insert(entities, v)
    end
    return entities
end

function EntityManager:RemoveEntity(entityId)
    local entity = self.entityDic[entityId]
    if entity then
        self.entityDic[entityId] = nil
        entity:Destroy()
    end
end

function EntityManager:RemoveAll()
    for _, entity in pairs(self.entityDic) do
        entity:Destroy()
    end
    self.entityDic = {}
    self.entityCallLateUpate = {}
end

---------------------------------------- 刷新相关 ----------------------------------------
function EntityManager:Update(dt)
    -- if self.isDirty then
    --     self:WriteToFile()
    -- end

    for i = #self.entityCallLateUpate, 1, -1 do
        local entityId = self.entityCallLateUpate[i]
        local entity = self.entityDic[entityId]
        if not entity then
            table.remove(self.entityCallLateUpate, i)
        else
            entity:Update(dt)
        end
    end
end

---------------------------------------- 数据相关 ----------------------------------------
function EntityManager:MarkDirty()
    self.isDirty = true
end

function EntityManager:RegisterEvents()
    UserInput.registerListener(self, UserInputType.clickEntity, self.HandleClick)
end

function EntityManager:UnRegisterEvent()
    UserInput.removeListener(self, UserInputType.clickEntity)
end

function EntityManager:Release()
    self:UnRegisterEvent()
    self:RemoveAll()
end

return EntityManager