-- 皮肤装扮管理器
---@type DressUpMabager
local DressUpMabager = {}

function DressUpMabager:Init()
    self.playerNewSkin = {}
    self.cfg = AppServices.Meta:Category("SkinTemplate")
    MessageDispatcher:AddMessageListener(MessageType.Global_After_AddItem, self.OnGetItemEvent, self)
end

function DressUpMabager:OnGetItemEvent(itemId, count, _isInit)
    -- 如果是初始化/断线重连进入，直接返回
    if _isInit then
        return
    end
    if self:IsSkinItem(itemId) then
        self:SetPlayerNewSkin(itemId)
        local agent = App.scene.objectManager:GetAgentByType(AgentType.dress_up)
        if agent then
            agent.dressUpUnit:ShowNewTab()
        end
    end
end

-- 是否为皮肤道具
function DressUpMabager:IsSkinItem(itemId)
    local is = false
    for key, _ in pairs(self.cfg) do
        if key == tostring(itemId) then
            is = true
        end
    end
    return is
end

-- 设置玩家获取的新的皮肤
function DressUpMabager:SetPlayerNewSkin(id)
    table.insert(self.playerNewSkin, id)
    MessageDispatcher:sendSubMessage(MessageType.DressNewSkinNotice)
end

-- 通过id判断是否为新的皮肤
function DressUpMabager:GetPlayerNewSkin(id)
    local is = false
    for _, value in pairs(self.playerNewSkin) do
        if value == tostring(id) then
            is = true
        end
    end
    return is
end

-- 清空玩家获取的新的皮肤
function DressUpMabager:ClearPlayerNewSkin(id)
    if id then
        for index, value in pairs(self.playerNewSkin) do
            if tostring(id) == value then
                table.remove(self.playerNewSkin, index)
            end
        end
    else
        table.clear(self.playerNewSkin)
    end
end

-- 皮肤穿戴
function DressUpMabager:SetPlayerSkinWear(id)
    if not id then
        console.error("皮肤穿戴 id 参数为null")
        return
    end
    console.jf("...皮肤穿戴...ID :", id)
    self.skinWearId = id
end

-- 皮肤穿戴
function DressUpMabager:GetPlayerSkinWear()
    return self.skinWearId
end

-- 获取玩家皮肤模型
function DressUpMabager:GetPlayerModelByID(id)
    local _sid = tostring(id)
    local prefabPath = "Prefab/Art/Characters/Skin/" .. self.cfg[_sid].prefab
    return prefabPath
end

DressUpMabager:Init()
return DressUpMabager
