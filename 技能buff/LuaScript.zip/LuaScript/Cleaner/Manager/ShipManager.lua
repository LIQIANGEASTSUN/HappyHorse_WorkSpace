---@type ShipStateInfo
local ShipStateInfo = require "Fsm.Ship.ShipStateInfo"

---@type FsmStateMachine
local FsmStateMachine = require "Fsm.StateMachine.FsmStateMachine"

---@type SceneTemplateTool
local SceneTemplateTool = require "Fsm.Ship.SceneTemplateTool"

---@class ShipManager
local ShipManager = {}

function ShipManager:Init()
    self:CreateState()
end

function ShipManager:ChangeState(toStateType, transitionData)
    if self.fsmStateMachine then
        self.fsmStateMachine:ChangeState(toStateType, transitionData)
    end
end

function ShipManager:GetCurrentState()
    if self.fsmStateMachine then
        return self.fsmStateMachine:GetCurrentState()
    end
end

function ShipManager:CreateState()
    ---@type FsmStateMachine 创建状态机
    self.fsmStateMachine = FsmStateMachine.new()
    for _, type in pairs(ShipStateInfo.ShipStateType) do
        local state = ShipStateInfo.States[type]
        local boatState = state.new(self)
        self.fsmStateMachine:Add(boatState)
    end

    local toStateType = ShipStateInfo.ShipStateType.Homeland
    local sceneId = App.scene:GetCurrentSceneId()
    local type = SceneTemplateTool:GetType(sceneId)
    if type == SceneTemplateType.Island then
        toStateType = ShipStateInfo.ShipStateType.Island
    end
    self:ChangeState(toStateType)
end

function ShipManager:Release()
    if self.fsmStateMachine then
        self.fsmStateMachine:OnExit()
    end
end

return ShipManager