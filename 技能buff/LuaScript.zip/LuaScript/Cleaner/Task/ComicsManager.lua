---@class ComicsManager 对话触发器
local ComicsManager = {
    taskSns = {},
    levels = {},
    itemIds = {},
    reachPoints = {}
}

function ComicsManager:init()
    self:RegisterListeners()
end

function ComicsManager:RegisterListeners()
    MessageDispatcher:AddMessageListener(MessageType.Global_After_Player_Levelup, self.OnPlayerLevelUp, self)
    MessageDispatcher:AddMessageListener(MessageType.Global_After_AddItem, self.OnPlayerLevelUp, self)
    MessageDispatcher:AddMessageListener(MessageType.Task_After_TaskSubmit, self.OnTaskSubmit, self)
    local cfgs = self:getAllConfigs()
    for sn, cfg in pairs(cfgs) do
        local triggerType = cfg.triggerType
        if triggerType == ComicsTriggerType.Task then
            self.taskSns[cfg.taskSn] = sn
        elseif triggerType == ComicsTriggerType.Level then
            self.levels[cfg.level] = sn
        elseif triggerType == ComicsTriggerType.Item then
            self.itemIds[cfg.item[1]] = sn
        elseif triggerType == ComicsTriggerType.ReachPoint then
            self.reachPoints[cfg.pos] = sn
        end
    end
end

function ComicsManager:RemoveListeners()
    MessageDispatcher:RemoveMessageListener(MessageType.Global_After_Player_Levelup, self.OnPlayerLevelUp, self)
    MessageDispatcher:RemoveMessageListener(MessageType.Global_After_AddItem, self.OnPlayerLevelUp, self)
    MessageDispatcher:RemoveMessageListener(MessageType.Task_After_TaskSubmit, self.OnTaskSubmit, self)
end

function ComicsManager:getAllConfigs()
    local cfgs = self._cfgs
    if not cfgs then
        cfgs = {}
        local tmps = AppServices.Meta:Category("ShowTComicsTempate")
        for _, cfg in pairs(tmps) do
            cfgs[cfg.sn] = cfg
        end
        self._cfgs = cfgs
    end
    return cfgs
end

function ComicsManager:GetConfig(sn)
    local cfgs = self:getAllConfigs()
    return cfgs[sn]
end

function ComicsManager:IsPlaying()
    return self._isPlaying
end

function ComicsManager:SetPlaying(isPlaying)
    self._isPlaying = isPlaying
end

function ComicsManager:StartComics(sn)
    if self:IsPlaying() then
        return
    end
    local key = "ComicsPlayed"
    local played = AppServices.User.Default:GetKeyValue(key, {})
    if played[sn] then
        return
    end
    played[sn] = true
    AppServices.User.Default:SetKeyValue(key, played, true)
    self:SetPlaying(true)
    PlayComics(sn, function()
        self:SetPlaying(false)
        self:CheckPlay()
    end)
end

function ComicsManager:CheckPlay()

end

---任务完成
function ComicsManager:OnTaskSubmit(taskSn)
    if not self.taskSns[taskSn] then
        return
    end
    local sn = self.taskSns[taskSn]
    self:StartComics(sn)
end

---玩家升级
function ComicsManager:OnPlayerLevelUp(level)
    if not self.levels[level] then
        return
    end
    local sn = self.levels[level]
    self:StartComics(sn)
end

---获得道具
function ComicsManager:OnGetItem(itemId, count)
    if not self.itemIds[itemId] then
        return
    end
    local sn = self.itemIds[itemId]
    self:StartComics(sn)
end

---到达某个地点
function ComicsManager:OnReachPoint(x, z)

end

ComicsManager:init()
return ComicsManager