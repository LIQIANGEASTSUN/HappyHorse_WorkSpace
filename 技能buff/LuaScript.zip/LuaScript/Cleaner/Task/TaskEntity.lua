---@class TaskEntity
local TaskEntity = class(nil, "TaskEntity")

function TaskEntity:ctor(taskSn, data)
    self:setSn(taskSn)
    self:initCondition()
    self:initProgress(data)
    if self:IsDone() then
    end
end

---初始化任务条件监听
---@private
function TaskEntity:initCondition()
    local cfg = self:GetConfig()
    if not cfg then
        return
    end
    local conditionSn = cfg.taskEnum
    local TaskTypes = require("Cleaner.Task.TaskType")
    local sub_class = TaskTypes[conditionSn]
    if sub_class then
        local sub = sub_class.new(conditionSn, cfg.args, self)
        self:addCondition(sub)
    end
end

---@private
---初始化任务进度
function TaskEntity:addCondition(taskCondition)
    ---@type TaskConditionBase
    self.taskCondition = taskCondition
end

---@return TaskConditionBase
function TaskEntity:GetCondition()
    return self.taskCondition
end

---@private
---初始化进度
function TaskEntity:initProgress(data)
    local progress = data and data.progress or 0
    ---TODO LZL 根据TaskCondition来计算progress, 比如累计
    self:setProgress(progress)
end

---@private
---设置任务id
function TaskEntity:setSn(taskSn)
    self.taskSn = taskSn
end

---获得任务id
function TaskEntity:GetSn()
    return self.taskSn
end

function TaskEntity:GetTaskType()
    local cfg = self:GetConfig()
    return cfg.taskType
end
---获取任务的配置表
function TaskEntity:GetConfig()
    if not self.cfg then
        self.cfg = AppServices.Meta:Category("TaskTemplate")[tostring(self:GetSn())]
    end
    return self.cfg
end

function TaskEntity:LoginInit()
    local condition = self:GetCondition()
    if not condition then
        return
    end
    condition:RegisterListener()
end

function TaskEntity:ListenBeforeStart()
    local condition = self:GetCondition()
    if not condition then
        return
    end
    console.lzl("Task_Log 提前开始监听", self)
    condition:RegisterListener()
end

function TaskEntity:IsStartListen()
    local condition = self:GetCondition()
    if not condition then
        return
    end
    return condition:IsStartListen()
end

---检查在接到任务的时候, 是不是已经完成了
function TaskEntity:StartCheck()
    local condition = self:GetCondition()
    if not condition then
        return
    end
    if condition:GetCountType() ~= TaskCountType.Count then
        condition:RegisterListener()
        return
    end
    local progress = condition:StartCheck()
    local curPro = self:GetProgress()
    local total = self:GetTotal()
    if progress > curPro or progress == total then
        local isFinish = self:AddProgress(progress - curPro)
        if not isFinish then
            condition:RegisterListener()
        end
    else
        condition:RegisterListener()
    end
end

function TaskEntity:setProgress(progress)
    -- console.lzl("Task_Log 设置任务进度 任务id", self:GetSn(), "设置为", progress, '原来', self.progress or 0) --@DEl
    self.progress = progress
end

function TaskEntity:AddProgress(addValue)
    local newProgress = self:GetProgress() + addValue
    self:setProgress(newProgress)
    -- console.lzl("Task_Log 增加任务进度 任务id", self:GetSn(), self:GetTasKDesc(), "addValue", addValue, 'newProgress', newProgress, 'total', self:GetTotal())--@DEl
    MessageDispatcher:SendMessage(MessageType.Task_OnTaskAddProgress, self:GetSn(), self:GetTaskType())
    if newProgress >= self:GetTotal() then
        self:TaskFinish()
        return true
    end
end

function TaskEntity:GetProgress()
    return self.progress or 0
end

function TaskEntity:GetTotal()
    local cfg = self:GetConfig()
    return cfg and cfg.needNum or 1
end

function TaskEntity:GetTasKDesc()
    local cond = self:GetCondition()
    if not cond then
        return
    end
    local str = cond:GetTasKDesc()
    return str
end

function TaskEntity:TaskFinish()
    local cond = self:GetCondition()
    if cond then
        cond:RemoveListener()
    end
    MessageDispatcher:SendMessage(MessageType.Task_OnTaskFinish, self:GetSn(), self:GetTaskType())
end

function TaskEntity:IsDone()
    return self:GetProgress() >= self:GetTotal()
end

function TaskEntity:removeCondition()
    if self.taskCondition then
        self.taskCondition:Destory()
        self.taskCondition = nil
    end
end

function TaskEntity:__tostring()
	local cfg = self:GetConfig()
    local cond = self:GetCondition()
    local str = cond and cond:GetTasKDesc() or 'no TaskEnum Data'
	return string.format( "TaskEntity [%s] title [%s]", cfg.sn, str)
end

function TaskEntity:Destory()
    self.taskSn = nil
    self.cfg = nil
    self:removeCondition()
end

return TaskEntity
