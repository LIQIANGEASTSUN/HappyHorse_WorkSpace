---@class TaskManager 任务管理器
local TaskManager = {
    ---任务进度数据
    ---@type TaskEntity[]
    taskEntities = {},
    ---任务状态快速缓存
    _taskStateCache = {},
    ---前置任务(配置了前置任务的任务, 在前置任务开始的时候开始监听)
    _startRecordTasks = {},
    ---有前置任务的任务
    _havePreListenTasks = {},
}

---@type TaskEntity
local TaskEntity = require("Cleaner.Task.TaskEntity")

function TaskManager:Init()
    if self._inited then
        return
    end
    self._inited = true
    self:RegisterListener()
    self:initTaskSort()
    local task = AppServices.User:GetTaskInfo()
    local progress = task.progress
    local finishs = task.finish
    for _, v in ipairs(progress) do
        self:UpdateTaskState(v.key, TaskState.started)
    end
    for _, taskSn in ipairs(finishs) do
        self:UpdateTaskState(taskSn, TaskState.finish)
    end
    if not task.taskSn and table.isEmpty(progress) and table.isEmpty(finishs) then
        local startTaskSn = AppServices.Meta:GetConfigMetaValueNumber("taskStart", 1)
        AppServices.User:SetCurrentTaskSn(startTaskSn)
        self:StartNextTask(startTaskSn)
    else
        self:InitTaskList(task.taskSn, progress, finishs)
    end
    -- 处理需要提前监听的任务
    for taskSn, preTaskSn in pairs(self._havePreListenTasks) do
        local taskState = self:GetTaskState(taskSn) or TaskState.locked
        local preTaskState = self:GetTaskState(preTaskSn) or TaskState.locked
        if preTaskState > TaskState.locked and taskState < TaskState.finish then
            local e = self:GetTaskEntity(taskSn)
            if not (e and e:IsStartListen()) then
                if not e then
                    e = self:CreateTaskEntity(taskSn)
                    self:SetTaskEntity(taskSn, e)
                    AppServices.User:UpdateTaskProgress(taskSn, 0)
                end
                e:ListenBeforeStart()
            end
        end
    end
end

---@private
---初始化任务排序权重
function TaskManager:initTaskSort()
    local startTaskSn = AppServices.Meta:GetConfigMetaValueNumber("taskStart", 1)
    local count = 1
    self._taskSortRate = {[startTaskSn] = count * 100}
    local cfg = self:GetConfigBySn(startTaskSn)
    while cfg and cfg.nextSn > 0 do
        count = count + 1
        self._taskSortRate[cfg.nextSn] = count * 100
        cfg = self:GetConfigBySn(cfg.nextSn)
        local startRecordSn = cfg.startRecordSn
        if startRecordSn and startRecordSn ~= 0 then
            local startRecordTasks = self._startRecordTasks[startRecordSn]
            if not startRecordTasks then
                startRecordTasks = {}
                self._startRecordTasks[startRecordSn] = startRecordTasks
            end
            table.insert(startRecordTasks, cfg.sn)
            self._havePreListenTasks[cfg.sn] = startRecordSn
        end
        if not cfg or not cfg.nextSn or cfg.nextSn <= 0 then
            break
        end
    end
end

---根据任务sn获取前置任务是此任务的所有任务sn
function TaskManager:GetStartRecordTasks(taskSn)
    return self._startRecordTasks[taskSn]
end

function TaskManager:InitTaskList(curTaskSn, progress, finishs)
    local started = false
    for _, data in ipairs(progress) do
        local taskSn = data.key
        local taskEntity = self:CreateTaskEntity(taskSn, {progress = data.value})
        self:SetTaskEntity(taskSn, taskEntity)
        taskEntity:LoginInit()
        if not started and curTaskSn == taskSn then
            started = true
        end
    end
    if not started and curTaskSn and curTaskSn ~= -1 then
        self:initMainTaskOnLogin(curTaskSn)
        started = true
    end
    if not started then
        table.sort(
            finishs,
            function(a, b)
                local sr = self._taskSortRate
                return sr[a] < sr[b]
            end
        )
        local cfg = self:GetConfigBySn(finishs[#finishs])
        if cfg and cfg.nextSn and cfg.nextSn > 0 then
            AppServices.User:SetCurrentTaskSn(cfg.nextSn)
            self:initMainTaskOnLogin(cfg.nextSn)
        end
    end
end
function TaskManager:RegisterListener()
    if self._registered then
        return
    end
    self._registered = true
    console.lzl("注册任务回调") --@DEL
    AppServices.NetWorkManager:addObserver(MsgMap.SCTaskFinish, self.OnTaskFinishMsg, self)
    MessageDispatcher:AddMessageListener(MessageType.Task_OnTaskAddProgress, self.OnTaskAddProgress, self)
end

function TaskManager:GetConfigBySn(taskSn)
    local cfgs = self._cfgs
    if not cfgs then
        local tmps = AppServices.Meta:Category("TaskTemplate")
        cfgs = {}
        for _, cfg in pairs(tmps) do
            cfgs[cfg.sn] = cfg
        end
        self._cfgs = cfgs
    end
    return cfgs[taskSn]
end

---更新任务状态
---@param newState TaskState 任务状态
function TaskManager:UpdateTaskState(taskSn, newState)
    self._taskStateCache[taskSn] = newState
end

---@return TaskState
function TaskManager:GetTaskState(taskSn)
    return self._taskStateCache[taskSn]
end

function TaskManager:CreateTaskEntity(taskSn, data)
    local e = TaskEntity.new(taskSn, data)
    return e
end

function TaskManager:SetTaskEntity(taskSn, taskEntity)
    if self.taskEntities[taskSn] and taskEntity then
        console.error("已经设置过任务了", taskSn)
        return
    end
    self.taskEntities[taskSn] = taskEntity
end

function TaskManager:GetTaskEntity(taskSn)
    return self.taskEntities[taskSn]
end

function TaskManager:GetTaskEntities()
    return self.taskEntities
end

---登录的时候开始了一个任务, 这个任务要在进入场景之后检测并开始
function TaskManager:initMainTaskOnLogin(taskSn)
    AppServices.User:UpdateTaskProgress(taskSn, 0)
    local taskEntity = self:GetTaskEntity(taskSn)
    if not taskEntity then
        taskEntity = self:CreateTaskEntity(taskSn)
        self:SetTaskEntity(taskSn, taskEntity)
    end
    -- self:StartTask(taskEntity)
    self:UpdateTaskState(taskSn, TaskState.started)
end

---进入场景之后检查进度
function TaskManager:CheckProgress(finishCallback)
    local mainTaskSn = self:GetMainTask()
    for taskSn, taskEntity in pairs(self:GetTaskEntities()) do
        taskEntity:StartCheck()
        if taskSn == mainTaskSn then
            MessageDispatcher:SendMessage(MessageType.Task_OnTaskStart, taskSn, taskEntity:GetTaskType())
        end
    end
    Runtime.InvokeCbk(finishCallback)
end

function TaskManager:StartNextTask(taskSn)
    -- AppServices.User:UpdateTaskProgress(taskSn, 0)
    local taskEntity = self:GetTaskEntity(taskSn)
    if not taskEntity then
        taskEntity = self:CreateTaskEntity(taskSn)
        self:SetTaskEntity(taskSn, taskEntity)
    end
    self:StartTask(taskEntity)
    DcDelegates:Log(SDK_EVENT.quest_generate, {questId = tostring(taskSn)})
    local startRecordTasks = self:GetStartRecordTasks(taskSn)
    if not table.isEmpty(startRecordTasks) then
        for _, sn in ipairs(startRecordTasks) do
            local e = self:GetTaskEntity(sn)
            if not e then
                e = self:CreateTaskEntity(sn)
                self:SetTaskEntity(sn, e)
                AppServices.User:UpdateTaskProgress(sn, 0)
            end
            e:ListenBeforeStart()
        end
    end
end

---@param taskEntity TaskEntity
function TaskManager:StartTask(taskEntity)
    local taskSn = taskEntity:GetSn()
    self:UpdateTaskState(taskSn, TaskState.started)
    taskEntity:StartCheck()
    MessageDispatcher:SendMessage(MessageType.Task_OnTaskStart, taskSn, taskEntity:GetTaskType())
end

function TaskManager:TaskFinish(taskSn)
    if not taskSn then
        return
    end
    local tasks = AppServices.User:GetTaskInfo()
    if table.exists(tasks and tasks.finish or {}, taskSn) then
        console.error("任务已经完成", taskSn) --@DEL
        return
    end
    local taskEntity = self:GetTaskEntity(taskSn)
    if not taskEntity then
        console.error("没有刷新到任务", taskSn) --@DEL
        return
    end
    if not taskEntity:IsDone() then
        console.error("任务还未完成", taskSn, taskEntity:GetProgress(), taskEntity:GetTotal()) --@DEL
        return
    end
    local msg = {
        sn = taskSn
    }
    console.lzl("请求完成任务", taskSn) --@DEL
    AppServices.NetWorkManager:Send(MsgMap.CSTaskFinish, msg)
end

function TaskManager:OnTaskFinishMsg(msg)
    local taskSn = msg.sn
    console.lzl("请求完成任务--回调", taskSn) --@DEL
    if not taskSn then
        return
    end
    DcDelegates:Log(SDK_EVENT.quest_complete, {questId = tostring(taskSn)})
    self:UpdateTaskState(taskSn, TaskState.finish)
    local userMgr = AppServices.User
    userMgr:SetTaskFinish(taskSn)
    local taskEntity = self:GetTaskEntity(taskSn)
    local taskType = taskEntity:GetTaskType()
    taskEntity:Destory()
    MessageDispatcher:SendMessage(MessageType.Task_After_TaskSubmit, taskSn, taskType)
    self:SetTaskEntity(taskSn, nil)
    local cfg = self:GetConfigBySn(taskSn)
    -- 发奖励
    local flyAnimaton = AppServices.FlyAnimation
    local pos
    ---@type TaskButton
    local widget = App.scene:GetWidget(CONST.MAINUI.ICONS.TaskButton)
    if widget and Runtime.CSValid(widget:GetMainIconGameObject()) then
        local t = widget:GetMainIconGameObject():GetPosition()
        pos = Vector3(t.x, t.y, t.z)
    end
    local sizeDelta = Vector2(80, 80)
    for _, item in ipairs(cfg.reward or {}) do
        local itemId = item[1]
        local count = item[2]
        userMgr:AddItemOnlyExp(itemId, count, ItemGetMethod.Task)
        local flyCount = math.min(5, count)
        for i = 1, flyCount do
            WaitExtension.SetTimeout(
                function()
                    flyAnimaton.CreateItemWithFly(
                        {
                            itemId = tostring(itemId),
                            initPos = pos,
                            sizeDelta = sizeDelta,
                            noJump = true,
                            onFinish = function()
                                userMgr:FlushExp()
                            end
                        }
                    )
                end,
                (i - 1) * 0.1
            )
        end
    end
    -- 开启下一个任务
    if cfg.nextSn and cfg.nextSn ~= -1 then
        if userMgr:GetCurrentTaskSn() == taskSn then
            userMgr:SetCurrentTaskSn(cfg.nextSn)
        end
        self:StartNextTask(cfg.nextSn)
    elseif cfg.nextSn == -1 then
        if widget and Runtime.CSValid(widget:GetMainIconGameObject()) then
            widget:setActive(false)
        end
    end
end

function TaskManager:OnTaskAddProgress(taskSn, newProgress)
    AppServices.User:UpdateTaskProgress(taskSn, newProgress)
end
---@return int, TaskEntity
function TaskManager:GetMainTask()
    local sn = AppServices.User:GetCurrentTaskSn()
    local entity = self:GetTaskEntity(sn)
    return sn, entity
end

-- TaskManager:Init()

return TaskManager
