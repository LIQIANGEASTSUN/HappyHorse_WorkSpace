---@class TaskTypes
local TaskTypes =
    setmetatable(
    {},
    {
        __index = function(t, k)
            local name = TaskTypeNames[k]
            if name then
                local path = "Cleaner.Task.Conditions." .. name
                local v = include(path)
                rawset(t, k, v)
                return v
            else
                console.error("Task of Type:[" .. tostring(k) .. "] Not Found!")
            end
        end
    }
)
return TaskTypes