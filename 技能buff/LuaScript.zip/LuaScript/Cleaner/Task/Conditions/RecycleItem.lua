local SuperCls = require"Cleaner.Task.TaskConditionBase"
---@class RecycleItem:TaskConditionBase
local RecycleItem = class(SuperCls, "RecycleItem")
---获取监听
function RecycleItem:GetSubTaskEvents()
    return MessageType.Global_After_Recycle, self.OnTrigger
end

function RecycleItem:OnTrigger(itemHash)
    local args = self:GetArgs()
    local id = args and args[1]
    if not id then
        id = 2
    end
    for itemId, cnt in pairs(itemHash) do
        if itemId == id then
            self:AddProgress(cnt)
        end
    end
end

function RecycleItem:StartCheck()
    return 0
end

function RecycleItem:GetTasKDesc()
    local cfg = self:GetConfig()
    if not cfg then
        return
    end
    local str = cfg.requirement
    -- 使用装饰工厂{num}次
    local num = tostring(self:GetTaskEntity():GetTotal())
    return Runtime.Translate(str, {num = num})
end

return RecycleItem