local SuperCls = require"Cleaner.Task.TaskConditionBase"
---@class LinkIsland:TaskConditionBase
local LinkIsland = class(SuperCls, "LinkIsland")
---获取监听
function LinkIsland:GetSubTaskEvents()
    return MessageType.Global_After_Agent_Cleared, self.OnTrigger
end

function LinkIsland:OnTrigger(agentId)
    local args = self:GetArgs()
    local agent = App.scene.objectManager:GetAgent(agentId)
    if agent then
        local at = agent:GetType()
        if table.exists(args, at) then
            local e= self:GetTaskEntity()
            console.lzl("Task_Log 增加任务进度", e:GetProgress(), e)
            self:AddProgress(1)
        end
    end
end

function LinkIsland:StartCheck()
    return 0
end

function LinkIsland:GetTasKDesc()
    local cfg = self:GetConfig()
    if not cfg then
        return
    end
    local str = cfg.requirement
    local num = tostring(self:GetTaskEntity():GetTotal())
    return Runtime.Translate(str, {num = num})
end

return LinkIsland