local SuperCls = require"Cleaner.Task.TaskConditionBase"
---@class BuildingLevelup:TaskConditionBase
local BuildingLevelup = class(SuperCls, "BuildingLevelup")

function BuildingLevelup:StartCheck()
    local buildingSn = self:GetTaskArg()
    local agent = App.scene.objectManager:GetAgentByTemplateId(buildingSn)
    if not agent then
        return 0
    end
    local lv = agent:GetLevel()
    return lv
end

---获取监听
function BuildingLevelup:GetSubTaskEvents()
    return MessageType.BuildingUpLevel, self.OnTrigger
end

function BuildingLevelup:OnTrigger(id, level, sn)
    local tarSn = self:GetTaskArg()
    if tarSn ~= sn then
        return
    end
    local oldLv = self:GetTaskEntity():GetProgress()
    if level > oldLv then
        self:AddProgress(level - oldLv)
    end

end

function BuildingLevelup:GetTasKDesc()
    local cfg = self:GetConfig()
    if not cfg then
        return
    end
    local str = cfg.requirement
    local tarSn = self:GetTaskArg()
    local cfg = AppServices.Meta:Category("BuildingTemplate")[tostring(tarSn)]
    local num = tostring(self:GetTaskEntity():GetTotal())
    -- {buildingName}升到{level}级
    return Runtime.Translate(str, {buildingName = Runtime.Translate(cfg.name), level=num})
end

return BuildingLevelup