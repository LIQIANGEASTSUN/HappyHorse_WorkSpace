local SuperCls = require"Cleaner.Task.TaskConditionBase"
---@class FindAgent:TaskConditionBase
local FindAgent = class(SuperCls, "FindAgent")
---获取监听
function FindAgent:GetSubTaskEvents()
    -- MessageType.IslandLinkHomeland
    return MessageType.Global_After_Agent_Clearing, self.OnTrigger
end


function FindAgent:RegisterListener()
    if self._registered then
        return
    end
    MessageDispatcher:AddMessageListener(MessageType.IslandLinkHomeland, self.OnIslandLinkHomeland, self)
    SuperCls.RegisterListener(self)
end

function FindAgent:RemoveListener()
    if not self._registered then
        return
    end
    MessageDispatcher:RemoveMessageListener(MessageType.IslandLinkHomeland, self.OnIslandLinkHomeland, self)
    SuperCls.RemoveListener(self)
end

function FindAgent:OnTrigger(sceneId, agentId)
    local templateId = self:GetTaskArg()
    if not templateId then
        return
    end
    local agent = App.scene.objectManager:GetAgent(agentId)
    if agent and agent:GetSn() == templateId and agent:IsInHomeland() then
        local sn = agent:GetSn()
        local usrMgr = AppServices.User
        if not usrMgr:IsFindBuilding(sn) then
            usrMgr:SetFindBuilding(sn)
            AppServices.NetWorkManager:Send(MsgMap.CSFindBuildings, {sn=sn})
        end
        self:AddProgress(1)
    end
end

function FindAgent:OnIslandLinkHomeland(islandId)
    local templateId = self:GetTaskArg()
    if not templateId then
        return
    end
    local agent = App.scene.objectManager:GetAgentByTemplateId(templateId)
    if agent and agent:CanBeSeen(true) then
        local region = agent:GetRegion()
        if not region then
            return
        end
        if region:GetId() == islandId then
            local sn = agent:GetSn()
            local usrMgr = AppServices.User
            if not usrMgr:IsFindBuilding(sn) then
                usrMgr:SetFindBuilding(sn)
                AppServices.NetWorkManager:Send(MsgMap.CSFindBuildings, {sn=sn})
            end
            self:AddProgress(1)
        end
    end
end

function FindAgent:GetTasKDesc()
    local cfg = self:GetConfig()
    if not cfg then
        return
    end
    local str = cfg.requirement
    local templateId = self:GetTaskArg()
    local buildConfig = AppServices.Meta:Category("BuildingTemplate")[tostring(templateId)]
    return Runtime.Translate(str, {factoryName = Runtime.Translate(buildConfig.name)})
end

function FindAgent:StartCheck()
    local templateId = self:GetTaskArg()
    local usrMgr = AppServices.User
    if usrMgr:IsFindBuilding(templateId) then
        return 1
    end
    local agent = App.scene.objectManager:GetAgentByTemplateId(templateId)
    if agent and agent:CanBeSeen(true) and agent:IsInHomeland() then
        if not usrMgr:IsFindBuilding(templateId) then
            usrMgr:SetFindBuilding(templateId)
            AppServices.NetWorkManager:Send(MsgMap.CSFindBuildings, {sn=agent:GetSn()})
        end
        return 1
    else
        return 0
    end
end

return FindAgent