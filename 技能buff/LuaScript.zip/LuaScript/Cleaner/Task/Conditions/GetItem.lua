local SuperCls = require"Cleaner.Task.TaskConditionBase"
---@class GetItem:TaskConditionBase
local GetItem = class(SuperCls, "GetItem")
---获取监听
function GetItem:GetSubTaskEvents()
    return MessageType.Global_After_AddItem, self.OnTrigger
end

function GetItem:OnTrigger(itemId, count)
    local id = tostring(self:GetTaskArg())
    if not id then
        return
    end
    if itemId == id then
        self:AddProgress(count or 1)
    end
end

function GetItem:StartCheck()
    local id = tostring(self:GetTaskArg())
    if not id then
        return 0
    end
    local count = AppServices.User:GetItemAmount(id)
    return count
end

function GetItem:GetTasKDesc()
    local cfg = self:GetConfig()
    if not cfg then
        return
    end
    local str = cfg.requirement
    -- 收集{itemName}{num}个
    local num = tostring(self:GetTaskEntity():GetTotal())
    local itemName = AppServices.Meta:GetItemName(self:GetTaskArg())
    return Runtime.Translate(str, {num = num, itemName=itemName})
end

return GetItem