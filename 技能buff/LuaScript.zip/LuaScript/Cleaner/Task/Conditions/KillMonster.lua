local SuperCls = require"Cleaner.Task.TaskConditionBase"
---@class KillMonster:TaskConditionBase
local KillMonster = class(SuperCls, "KillMonster")

---获取监听
function KillMonster:GetSubTaskEvents()
    return MessageType.OnKillMonster, self.OnTrigger
end

function KillMonster:OnTrigger(agentId, sn, count)
    local tarAgentId = self:GetTaskArg()
    if not tarAgentId then
        return
    end
    tarAgentId = tostring(tarAgentId)
    if not tarAgentId or agentId == tarAgentId then
        self:AddProgress(count or 1)
    end
end

function KillMonster:StartCheck()
    local taskEntity = self:GetTaskEntity()
    if not taskEntity then
        return 0
    end
    local agentId = self:GetTaskArg()
    agentId = tostring(agentId)
    local cur = AppServices.User:IsKillMonster(agentId) and 1 or 0
    return cur or 0
end

function KillMonster:GetTasKDesc()
    local cfg = self:GetConfig()
    if not cfg then
        return
    end
    local str = cfg.requirement
    local agentId = self:GetTaskArg()
    agentId = tostring(agentId)
    local mapData = App.scene.objectManager:GetMapData(agentId)
    local monId = mapData.monsterId
    local monCfg = AppServices.Meta:Category("MonsterTemplate")[tostring(monId)]
    return Runtime.Translate(str, {monsterName = Runtime.Translate(monCfg.name)})
end

return KillMonster