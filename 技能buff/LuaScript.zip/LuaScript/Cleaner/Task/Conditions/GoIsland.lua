local SuperCls = require"Cleaner.Task.TaskConditionBase"
---@class GoIsland:TaskConditionBase
local GoIsland = class(SuperCls, "GoIsland")

---获取监听
function GoIsland:GetSubTaskEvents()
    return MessageType.On_FisrtEnter_ExploreIsland, self.OnTrigger
end

function GoIsland:OnTrigger(islandId)
    local tarSn = self:GetTaskArg()
    if not tarSn then
        return
    end
    if islandId == tarSn then
        self:AddProgress(1)
    end
end

function GoIsland:StartCheck()
    local tarSn = self:GetTaskArg()
    if not tarSn then
        return 0
    end
    return AppServices.User:IsExploredIsland(tarSn) and 1 or 0
end

function GoIsland:GetTasKDesc()
    local cfg = self:GetConfig()
    if not cfg then
        return
    end
    local str = cfg.requirement
    local tarSn = self:GetTaskArg()
    local cfg = AppServices.Meta:Category("SceneTemplate")[tostring(tarSn)]
    return Runtime.Translate(str, {islandName = Runtime.Translate(cfg.name)})
end


return GoIsland