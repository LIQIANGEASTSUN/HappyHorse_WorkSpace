local SuperCls = require"Cleaner.Task.TaskConditionBase"
---@class ProductDecoration:TaskConditionBase
local ProductDecoration = class(SuperCls, "ProductDecoration")
---获取监听
function ProductDecoration:GetSubTaskEvents()
    return MessageType.StartProductDecoration, self.OnTrigger
end

function ProductDecoration:OnTrigger(agentId)
    local agentSn = self:GetTaskArg()
    local agent = App.scene.objectManager:GetAgent(agentId)
    if not agent then
        return
    end
    if agent:GetSn() == agentSn then
        self:AddProgress(1)
    end
end

function ProductDecoration:StartCheck()
    return 0
end

function ProductDecoration:GetTasKDesc()
    local cfg = self:GetConfig()
    if not cfg then
        return
    end
    local str = cfg.requirement
    -- 使用装饰工厂{num}次
    local num = tostring(self:GetTaskEntity():GetTotal())
    return Runtime.Translate(str, {num = num})
end

return ProductDecoration