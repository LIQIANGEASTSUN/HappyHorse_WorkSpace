local SuperCls = require"Cleaner.Task.TaskConditionBase"
---@class PetHLActionHook:TaskConditionBase
local PetHLActionHook = class(SuperCls, "PetHLActionHook")
---获取监听
function PetHLActionHook:GetSubTaskEvents()
    return MessageType.PetHLArriveingHook, self.OnTrigger
end

function PetHLActionHook:OnTrigger(sn)
    local tarSn = self:GetTaskArg()
    if not tarSn then
        return
    end
    if sn == tarSn then
        self:AddProgress(1)
    end
end

function PetHLActionHook:GetTasKDesc()
    local cfg = self:GetConfig()
    if not cfg then
        return
    end
    local str = cfg.requirement
    local tarSn = self:GetTaskArg()
    local buildingCfg = AppServices.Meta:GetBindingMeta(tarSn)
    return Runtime.Translate(str, {idleBuildingName = Runtime.Translate(buildingCfg.name)})
end
return PetHLActionHook