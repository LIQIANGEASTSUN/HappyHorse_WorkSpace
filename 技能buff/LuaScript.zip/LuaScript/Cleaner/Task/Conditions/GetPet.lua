local SuperCls = require"Cleaner.Task.TaskConditionBase"
---@class GetPet:TaskConditionBase
local GetPet = class(SuperCls, "GetPet")
---获取监听
function GetPet:GetSubTaskEvents()
    return MessageType.AddPet, self.OnTrigger
end

function GetPet:OnTrigger(id, petType, level, count)
    local tarAttribute = self:GetTaskArg()
    if not tarAttribute then
        return
    end
    local petCfgTool = AppServices.PetTemplateTool
    local sn = petCfgTool:Getkey(petType, level)
    local cfg = petCfgTool:GetData(sn)
    if cfg.attribute == tarAttribute then
        self:AddProgress(count or 1)
    end
end

function GetPet:GetTasKDesc()
    local cfg = self:GetConfig()
    if not cfg then
        return
    end
    local str = cfg.requirement
    local tarAttribute = self:GetTaskArg()
    local typeStr = PetAttributeKey[tarAttribute]
    typeStr = Runtime.Translate(typeStr)
    local num = tostring(self:GetTaskEntity():GetTotal())
    return Runtime.Translate(str, {num = num, type=typeStr})
end

return GetPet