local SuperCls = require"Cleaner.Task.TaskConditionBase"
---@class IslandComplete:TaskConditionBase
local IslandComplete = class(SuperCls, "IslandComplete")

---获取监听
function IslandComplete:GetSubTaskEvents()
    return MessageType.IslandLinkHomeland, self.OnTrigger
end

function IslandComplete:OnTrigger(islandId)
    local tarId = self:GetTaskArg()
    if tarId == islandId then
        self:AddProgress(1)
    end
end

function IslandComplete:StartCheck()
    local islandId = self:GetTaskArg()
    local isUnlock = false --AppServices.User:IsLinkHomeland(islandId)
    if isUnlock then
        return 1
    else
        return 0
    end
end

function IslandComplete:GetTasKDesc()
    local cfg = self:GetConfig()
    if not cfg then
        return
    end
    local str = cfg.requirement
    local tarSn = self:GetTaskArg()
    local cfg = AppServices.Meta:Category("SceneTemplate")[tostring(tarSn)]
    return Runtime.Translate(str, {islandName = Runtime.Translate(cfg.name)})
end

return IslandComplete