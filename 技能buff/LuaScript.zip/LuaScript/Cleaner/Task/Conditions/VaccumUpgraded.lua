local SuperCls = require"Cleaner.Task.TaskConditionBase"
---@class VaccumUpgraded:TaskConditionBase
local VaccumUpgraded = class(SuperCls, "VaccumUpgraded")

function VaccumUpgraded:StartCheck()
    local allInfos = AppServices.User:GetVaccumInfos()
    local maxLv = 0
    for _, equip in ipairs(allInfos) do
        maxLv = math.max(maxLv, equip.levle)
    end
    return maxLv
end

---获取监听
function VaccumUpgraded:GetSubTaskEvents()
    return MessageType.VaccumUpgraded, self.OnTrigger
end

function VaccumUpgraded:OnTrigger(equip)
    local tarLevel = self:GetTaskArg()
    if not tarLevel then
        return
    end
    local cur = self:StartCheck()
    local oldNum = self:GetTaskEntity():GetProgress()
    if cur > oldNum then
        self:AddProgress(cur - oldNum)
    end

end

function VaccumUpgraded:GetTasKDesc()
    local cfg = self:GetConfig()
    if not cfg then
        return
    end
    local str = cfg.requirement
    local num = tostring(self:GetTaskEntity():GetTotal())
    return Runtime.Translate(str, {level=num})
end

return VaccumUpgraded