local SuperCls = require"Cleaner.Task.TaskConditionBase"
---@class ProductItem:TaskConditionBase
local ProductItem = class(SuperCls, "ProductItem")
---获取监听
function ProductItem:GetSubTaskEvents()
    return MessageType.StartProduction, self.OnTrigger
end

function ProductItem:OnTrigger(itemId, count)
    local id = self:GetTaskArg()
    if not id then
        return
    end
    if id == itemId then
        self:AddProgress(count or 1)
    end
end

function ProductItem:StartCheck()
    return 0
end

function ProductItem:GetTasKDesc()
    local cfg = self:GetConfig()
    if not cfg then
        return
    end
    local str = cfg.requirement
    -- 生产{itemName}{num}个
    local num = tostring(self:GetTaskEntity():GetTotal())
    local itemName = AppServices.Meta:GetItemName(self:GetTaskArg())
    return Runtime.Translate(str, {num = num, itemName=itemName})
end

return ProductItem