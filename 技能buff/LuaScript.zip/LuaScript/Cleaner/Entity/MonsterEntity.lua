---@type BaseEntity
local BaseEntity = require "Cleaner.Entity.BaseEntity"

---@type AttributeInfo
local AttributeInfo = require "Cleaner.Fight.Attribute.AttributeInfo"

---@type MonsterActionTool
local MonsterActionTool = require "Cleaner.AIConfig.MonsterIsland.MonsterActionTool"

---@type BTConstant
local BTConstant = require "Cleaner.AIConfig.BTConstant"

---@class MonsterEntity : BaseEntity
local MonsterEntity = class(BaseEntity, "MonsterEntity")

function MonsterEntity:ctor()
end

function MonsterEntity:InitConfig()
    self.tableTemplate = "MonsterTemplate"
    self.dataCfg = "MonsterEntityData"
    self.renderCfg = "EntityRender"
    self.assetPath = "Prefab/Art/Characters/Monster/%s.prefab"
end

function MonsterEntity:Init(birthPos)
    self:SetBirthPos(birthPos)
    self:SetPosition(birthPos)
    self:CreateMoveTool()

    self:CreateFightUnit(CampType.Red)
    self:CreateSkill()
    self:CreateAI()
    self:CheckTips()
    self:CreateAttribute()
    self:RegisterEvent()
end

function MonsterEntity:GetType()
    return self.data:GetType()
end

function MonsterEntity:CreateFightUnit(camp)
    BaseEntity.CreateFightUnit(self, camp)
    local fightUnit = self:GetUnit(UnitType.FightUnit)
    fightUnit:SetEnableAttack(true)
end

function MonsterEntity:CreateAttribute()
    self:AddAttribute(AttributeInfo.Type.Attack, 0)
    self:AddAttribute(AttributeInfo.Type.Shield, 0)

    local hp = self.data.meta.hp
    self:AddAttribute(AttributeInfo.Type.MaxHp, hp)
end

function MonsterEntity:CreateMoveTool()
    local moveType = AppServices.UnitMoveManager.MoveType.FindPathAlgorithm
    self:ChangeMoveTool(moveType)
end

function MonsterEntity:ChangeMoveTool(moveType)
    BaseEntity.ChangeMoveTool(self, moveType)
    self.unitMove:SetSpeed(self.data.meta.speed)
end

function MonsterEntity:CreateAI()
    self.monsterActionTool = MonsterActionTool.new(self)
    self:CreateBehaviorTree("MonsterIsland")
    self.monsterActionTool:Init()
end

function MonsterEntity:CreateSkill()
    local skills = {self.data.meta.skillId}

    local fightUnit = self:GetUnit(UnitType.FightUnit)
    fightUnit:AddSkill(skills)
    fightUnit:SetDamageHpTipsType(TipsType.UnitMonsterHpTips)
end

function MonsterEntity:GetSearchDistance()
    return self.data.meta.search
end

function MonsterEntity:SetHp(hp)
    BaseEntity.SetHp(self, hp)
    if self.behaviorTree then
        self.behaviorTree:SetFloatParameter(BTConstant.PetHp, hp)
    end
end

function MonsterEntity:IsSendKillBoss()
    local isBoss = self.data:IsBoss()
    if isBoss then
        return isBoss
    end
    return self.data.meta.isBoss == 2
end

function MonsterEntity:CheckTips()
    local monsterType = self:GetType()
    local find = AppServices.User:IsFindMonster(monsterType)
    if not find then
        AppServices.NetPetManager:SendFindMonster(monsterType)
    end

    local fightUnit = self:GetUnit(UnitType.FightUnit)
    local instanceId = fightUnit:GetInstanceId()
    local isBoss = self.data:IsBoss()
    if isBoss then
        self.render:SetLocalScale(2, 2, 2)
        AppServices.UnitTipsManager:ShowTips(instanceId, TipsType.UnitBoss)
        return
    end

    if not find then
        AppServices.UnitTipsManager:ShowTips(instanceId, TipsType.UnitNewMonster)
    end
end

function MonsterEntity:SetAgentId(agentId)
    self.data:SetAgentId(agentId)
end

function MonsterEntity:GetAgentId()
    return self.data:GetAgentId()
end

function MonsterEntity:SetRegionId(regionId)
    self.data:SetRegionId(regionId)
end

function MonsterEntity:GetRegionId()
    return self.data:GetRegionId()
end

function MonsterEntity:Suckable()
    return not self.alive
end

function MonsterEntity:GetSuckLevel()
    return self.data:GetSuckLevel()
end

--- 被吸尘器吸后的处理
function MonsterEntity:AfterCleaned()
    BaseEntity.AfterCleaned(self)
    MessageDispatcher:SendMessage(MessageType.MonsterBeSuck, self.entityId)
    AppServices.EntityManager:RemoveEntity(self.entityId)
end

function MonsterEntity:LinkedHomeland(islandId)
    local regionId = self:GetRegionId()
    if regionId == islandId then
        AppServices.EntityManager:RemoveEntity(self.entityId)
    end
end

function MonsterEntity:Update(dt)
    BaseEntity.Update(self, dt)
end

function MonsterEntity:NeedLateUpdate()
    return true
end

function MonsterEntity:RegisterEvent()
    MessageDispatcher:AddMessageListener(MessageType.IslandLinkHomeland, self.LinkedHomeland, self)
end

function MonsterEntity:UnRegisterEvent()
    MessageDispatcher:RemoveMessageListener(MessageType.IslandLinkHomeland, self.LinkedHomeland, self)
end

function MonsterEntity:Destroy()
    BaseEntity.Destroy(self)
    self:UnRegisterEvent()
end

return MonsterEntity