---@type FightUnitEntity
local FightUnitEntity = require "Cleaner.Unit.FightUnitEntity"

---@type AttributeInfo
local AttributeInfo = require "Cleaner.Fight.Attribute.AttributeInfo"

---@type AttributeManager
local AttributeManager =  require "Cleaner.Fight.Attribute.AttributeManager"

---@type BehaviorTreeEntity
local BehaviorTreeEntity = require "Cleaner.BehaviorTree.BehaviorTreeEntity"

-- local CSNull = Runtime.CSNull
-- local InvokeCbk = Runtime.InvokeCbk
---实体基类
---@class BaseEntity
---@field unitMap table<int, UnitBase>
---@field behaviorTree BehaviorTreeEntity
---@field sn number
local BaseEntity = class(nil, "BaseEntity")
local LEVEL_SIZES = {
    0.7,
    0.8,
    0.9,
    1
}

local animationTransition = {
    ["run"] = "Walk",
    ["idle"] = "Idle_A",
    ["die"] = "Death",
    ["attack"] = "Attack",
}

function BaseEntity:ctor(entityId, entityType, sn)
    self.entityId = entityId
    self.entityType = entityType
    self.sn = sn
    ---@type MagicalCreatureMsg
    self.data = nil
    self.visible = true
    self.alive = true
    ---@type dictionary<int, UnitBase>
    self.unitMap = {}
    ---@type EntityRender
    self.render = nil

    ---@type UnitMoveBase
    self.unitMove = nil
    self.inCameraView = true
    self.checkCameraView = true

    self:InitConfig()
    self:InitData()
end

function BaseEntity:InitConfig()
    self.tableTemplate = ""
    self.dataCfg = ""
    self.renderCfg = ""
    self.assetPath = ""
end

function BaseEntity:InitData()
    local config = AppServices.Meta:Category(self.tableTemplate)
    local meta = config[self.sn]
    local dataAlias = require ("Cleaner.Entity.Data." .. self.dataCfg)
    self.data = dataAlias.new(meta)
end

function BaseEntity:InitRender(callBack)
    if self.render then
        return
    end

    local EntityRender = require ("Cleaner.Entity.Render." .. self.renderCfg)
    self.render = EntityRender.new(self.entityId)
    self:LoadAsset(callBack)
end

function BaseEntity:LoadAsset(callBack)
    local assetName = self:GetAssetName()
    local assetPath = string.format(self.assetPath, assetName)
    self.render:LoadAsset(assetPath, callBack)
end

function BaseEntity:GetAssetName()
    return self.data.meta.model
end

function BaseEntity:SetStrengthData(data)
    self.data.physicalStrength = data.physicalStrength
    self.data.getPhysicalStrengthTime = data.getPhysicalStrengthTime
end

function BaseEntity:SetAvailableTime(ts)
    self.data.availableTime = ts
end

function BaseEntity:SetBirthPos(bornPos)
    self.bornPos = bornPos
end

function BaseEntity:GetBornPos()
    return self.bornPos
end

function BaseEntity:SetPosition(position)
    if self.render then
        self.render:SetPosition(position)
    end
end

function BaseEntity:GetPosition()
    if self.render then
        return self.render:GetPosition()
    end
    return Vector3.zero
end

function BaseEntity:GetWorldPosition()
    return self:GetPosition()
end

function BaseEntity:GetAnchorPosition()
    if self.render then
        return self.render:GetAnchorPosition()
    end
    return Vector3.zero
end

function BaseEntity:GetGameObject()
    if self.render then
        return self.render:GetGameObject()
    end
    return nil
end

function BaseEntity:GetSize()
    local level = self.data.meta.level
    return LEVEL_SIZES[level]
end

function BaseEntity:SetForward(forward)
    self.render:SetForward(forward)
end

function BaseEntity:GetVisible()
    return self.visible
end

function BaseEntity:SetVisible(visible)
    if self.visible == visible then
        return
    end
    self.visible = visible
    if self.render then
        self.render:SetVisible(visible)
    end
    if Runtime.CSValid(self.shadow) then
        self.shadow:SetActive(visible)
    end
end

function BaseEntity:TriggerEvent(evt, ...)
    if not self.listeners then
        return
    end
    for _, evtCb in pairs(self.listeners) do
        Runtime.InvokeCbk(evtCb[evt], ...)
    end
end

---@return BehaviorTreeEntity
function BaseEntity:BehaviorTreeEntity()
    return self.behaviorTree
end

function BaseEntity:CreateBehaviorTree(configName)
    self.behaviorTree = BehaviorTreeEntity.new(configName, self)
end

function BaseEntity:RegisterEvent(listener, evt, handler)
    if not self.listeners then
        self.listeners = {}
    end
    if not self.listeners[listener] then
        self.listeners[listener] = {}
    end
    self.listeners[listener][evt] = handler
end

function BaseEntity:UnregisterEvent(listener, evt)
    if not self.listeners then
        return
    end
    if not self.listeners[listener] then
        return
    end
    if evt then
        self.listeners[listener][evt] = nil
    else
        self.listeners[listener] = nil
    end
end

function BaseEntity:GetShadow()
end

function BaseEntity:TweenAlpha(toValue, duration)
    self.alpha = toValue
    if self.alphaTween then
        self.alphaTween:Kill()
    end
    self.tweens = {}
    self.alphaTween = {
        onComplete = nil,
        Kill = function()
            for _, tween in pairs(self.tweens) do
                tween:Kill()
            end
            self.tweens = {}
        end
    }
    local shadow = self:GetShadow()
    if Runtime.CSValid(shadow) then
        local shadowTween = GameUtil.DoFade(shadow, toValue, duration)
        table.insert(self.tweens, shadowTween)
    end
    local skins = self.render:GetComponentsInChildren(typeof(MeshRenderer))
    for i = 1, skins.Length do
        local skin = skins[i - 1]
        local skinTween = GameUtil.DoFade(skin, toValue, duration)
        table.insert(self.tweens, skinTween)
    end
    local tween = GameUtil.DoFade(self.render, toValue, duration)
    table.insert(self.tweens, tween)
    tween.onComplete = function()
        self.tweens = {}
        Runtime.InvokeCbk(self.alphaTween.onComplete)
        self.alphaTween = nil
    end
    return self.alphaTween
end

function BaseEntity:GetEntityType()
    return self.entityType
end

function BaseEntity:CreateFightUnit(camp)
    local fightUnit = self:GetUnit(UnitType.FightUnit)
    if not fightUnit then
        fightUnit = FightUnitEntity.new(self)
        fightUnit:SetCamp(camp)
        self:AddUnit(fightUnit)
    end
end

function BaseEntity:AddUnit(unit)
    local unitType = unit:GetUnitType()
    self.unitMap[unitType] = unit:GetInstanceId()
    AppServices.UnitManager:AddUnit(unit)
end

function BaseEntity:GetUnit(unitType)
    local unitId = self.unitMap[unitType]
    if unitId then
        return AppServices.UnitManager:GetUnit(unitId)
    end
    return nil
end

function BaseEntity:ChangeMoveTool(moveType)
    if not self.moveMap then
        self.moveMap = {}
    end

    if not self.entityMove then
        local transform = self:GetGameObject().transform
        self.entityMove = EntityMoveController.Instance:AddEntity(transform, false)
    end

    if self.moveMap[moveType] then
        self.unitMove = self.moveMap[moveType]
    else
        self.unitMove = AppServices.UnitMoveManager:CreateMove(self, moveType)
        self.moveMap[moveType] = self.unitMove
    end
end

function BaseEntity:AddAttribute(type, value)
    if not self.attributeManager then
        self.attributeManager = AttributeManager.new(self)
    end
    self.attributeManager:AddAttribute(type, value)
end

function BaseEntity:GetAttribute(type)
    if self.attributeManager then
        return self.attributeManager:GetAttribute(type)
    end
    return nil
end

function BaseEntity:RemoveAttribute(type)
    if self.attributeManager then
        self.attributeManager:RemoveAttribute(type)
    end
end

function BaseEntity:GetAttributeManager()
    return self.attributeManager
end

-- buffId
function BaseEntity:AddBuff(buffId, skillId)
    ---@type FightUnitBase
    local fightUnit = self:GetUnit(UnitType.FightUnit)
    fightUnit:AddBuff(buffId, skillId)
end

function BaseEntity:ClearBuff()
    ---@type FightUnitBase
    local fightUnit = self:GetUnit(UnitType.FightUnit)
    fightUnit:ClearBuff()
end

function BaseEntity:PlayAnimation(animation)
    local type = self.data:GetType()
    if type ~= 501 and type ~= 502 and type ~= 503 then
         animation = animationTransition[animation]
    end

    if self.alive then
        local entityGo = self:GetGameObject()
        entityGo:PlayAnim(animation)
    end
end

function BaseEntity:GetAnimationLength(animation)
    if self.alive then
        local entityGo = self:GetGameObject()
        local length = entityGo:GetRuntimeClipLength(animation)
        return length
    end
end

function BaseEntity:GetHp()
    if not self.data then
        return -1
    end
    return self.data:GetHp()
end

function BaseEntity:GetMaxHp()
    if not self.alive then
        return 1
    end

    local attributeBase = self:GetAttribute(AttributeInfo.Type.MaxHp)
    return attributeBase:GetValue()
end

function BaseEntity:Damage(value)
    if self.alive then
        self:ChangeHp(value * -1)
    end
end

function BaseEntity:SetHp(hp)
    if self.alive then
        self.data:SetHp(hp)
    end
end

function BaseEntity:Cure(value)
    if self.alive then
        self:ChangeHp(value)
    end
end

function BaseEntity:ChangeHp(value)
    local maxHp = self:GetMaxHp()
    local hp = self:GetHp()
    hp = math.clamp(hp + value, 0, maxHp)
    self:SetHp(hp)
end

function BaseEntity:SetAlive(value)
    self.alive = value
end

function BaseEntity:SetDeath()
    self:SetAlive(false)
end

function BaseEntity:IsAlive()
    return self.alive
end

function BaseEntity:GetSearchDistance()
    return 0
end

function BaseEntity:ProcessClick()
end

function BaseEntity:NeedLateUpdate()
    return false
end

function BaseEntity:Suckable()
    return false
end

function BaseEntity:GetSuckLevel()
    return 1
end

function BaseEntity:GetEntityId()
    return self.entityId
end

function BaseEntity:GetSn()
    return self.data.meta.sn
end

function BaseEntity:Clean(value)
    self:AfterCleaned()
end

--- 被吸尘器吸后的处理
function BaseEntity:AfterCleaned()
end

function BaseEntity:InCameraView(force)
    local timeArrive = (not self.calcaluteTime) or (Time.realtimeSinceStartup > self.calcaluteTime)
    if (not force) and (not timeArrive) then
        return self.inCameraView
    end

    self.calcaluteTime = Time.realtimeSinceStartup + 1

    local mainCamera = App.scene.mainCamera
    local screenPos = mainCamera:WorldToScreenPoint(self:GetPosition())
    local viewPortPos = mainCamera:ScreenToViewportPoint(screenPos)
    if viewPortPos.x < -0.1 or viewPortPos.x > 1.1 or viewPortPos.y < -0.1 or viewPortPos.y > 1.1 then
        self.inCameraView = false
        return self.inCameraView
    end

    self.inCameraView = true
    return self.inCameraView
end

function BaseEntity:Update(dt)
    self.dt = dt

    if (not self:InCameraView()) and self.checkCameraView then
        return
    end

    if self.behaviorTree then
        self.behaviorTree:Execute()
    end
end

function BaseEntity:Destroy()
    for _, unitId in pairs(self.unitMap) do
        AppServices.UnitManager:RemoveUnitWithId(unitId)
    end
    self.unitMap = {}

    if self.behaviorTree then
        self.behaviorTree:Exit()
    end

    self:SetAlive(false)
    self.data = nil

    self.cloneMask = nil
    self.shadow = nil
    if self.alphaTween then
        self.alphaTween:Kill()
    end

    if self.render then
        self.render:Destroy()
    end

    if self.entityMove then
        local agentId = self.entityMove:GetAgentId()
        EntityMoveController.Instance:RemoveEntity(agentId)
    end
end

return BaseEntity