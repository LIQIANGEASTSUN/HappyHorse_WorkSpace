---@type PetTemplateTool
local PetTemplateTool = require "Cleaner.Entity.Pet.PetTemplateTool"

---@type PetFollowPlayer
local PetFollowPlayer = require "Cleaner.Entity.Pet.PetFollowPlayer"

---@type SceneTemplateTool
local SceneTemplateTool = require "Fsm.Ship.SceneTemplateTool"

---@type BaseEntity
local BaseEntity = require "Cleaner.Entity.BaseEntity"

---@type AttributeInfo
local AttributeInfo = require "Cleaner.Fight.Attribute.AttributeInfo"

---@type PetActionTool
local PetActionTool = require "Cleaner.AIConfig.PetIsland.PetActionTool"

---@type BTConstant
local BTConstant = require "Cleaner.AIConfig.BTConstant"

---@class PetEntity:BaseEntity 探索岛上宠物
local PetEntity = class(BaseEntity, "PetEntity")

function PetEntity:ctor()
    self.checkCameraView = false
end

function PetEntity:InitConfig()
    self.tableTemplate = "PetTemplate"
    self.dataCfg = "PetEntityData"
    self.renderCfg = "EntityRender"
    self.assetPath = "Prefab/Art/Characters/Monster/%s.prefab"
end

function PetEntity:Init(birthPos)
    self:SetBirthPos(birthPos)
    self:SetPosition(birthPos)
    self:CreateMoveTool()

    self:CreateFightUnit(CampType.Blue)
    self:CreateAttribute()
    self:CreateSkill()
    self:CreateAI()
    self:CreateBuff()
    self:RegisterEvent()
end

function PetEntity:GetType()
    return self.data:GetType()
end

function PetEntity:CreateFightUnit(camp)
    BaseEntity.CreateFightUnit(self, camp)
    local fightUnit = self:GetUnit(UnitType.FightUnit)
    fightUnit:SetEnableAttack(true)
end

function PetEntity:CreateAttribute()
    self:AddAttribute(AttributeInfo.Type.Attack, 0)
    self:AddAttribute(AttributeInfo.Type.Shield, 0)

    local hp = self.data.meta.hp
    self:AddAttribute(AttributeInfo.Type.MaxHp, hp)
end

function PetEntity:CreateMoveTool()
    local moveType = AppServices.UnitMoveManager.MoveType.FindPathAlgorithm
    self:ChangeMoveTool(moveType)
end

function PetEntity:ChangeMoveTool(moveType)
    BaseEntity.ChangeMoveTool(self, moveType)
    self.unitMove:SetSpeed(self.data.speed)
end

function PetEntity:CreateAI()
    self.petActionTool = PetActionTool.new(self)
    self:CreateBehaviorTree("PetIsland")
    self.petActionTool:Init()
end

function PetEntity:CreateSkill()
    local skills = {self.data.meta.skillId}
    ---@type FightUnitBase
    local fightUnit = self:GetUnit(UnitType.FightUnit)
    fightUnit:ClearSkill()
    fightUnit:AddSkill(skills)
    fightUnit:SetDamageHpTipsType(TipsType.UnitPetHpTips)
    fightUnit:NotifyHp(0, TipsType.UnitPetHpTips, true)
end

function PetEntity:CreateBuff()
    self:ClearBuff()
    local buffId = self.data.meta.buffId
    self:AddBuff(buffId)

    local homelandId = SceneTemplateTool:GetHomelandId()
    ---@type SceneData
    local sceneData = AppServices.SceneDataManager:SceneData(homelandId)
    local petNestSn = self.data:GetPetNestSn()
    local petNestLevel = sceneData:GetPetNestLevel(petNestSn)
    for level = 1, petNestLevel do
        local config = AppServices.BuildingLevelTemplateTool:GetConfig(petNestSn, level)
        if config.buff > 0 and config.target == 2 then
            self:AddBuff(config.buff)
        end
    end
end

function PetEntity:ReceiveUpgrade(type, level)
    if self.data.meta.type ~= type then
        return
    end

    local currentModelName = self.data.meta.model
    local sn = PetTemplateTool:Getkey(type, level)

    local meta = AppServices.Meta:Category("PetTemplate")[tostring(sn)]
    self.data:ResetMeta(meta)
    if self:IsAlive() then
        local maxHp = self:GetMaxHp()
        self:SetHp(maxHp)
    end

    self:CreateSkill()
    self:CreateBuff()

    if currentModelName ~= meta.model then
        self:ReLoadGo(sn)
    else
        self:RefreshHp()
    end
end

function PetEntity:SetHp(hp)
    BaseEntity.SetHp(self, hp)
    if self.behaviorTree then
        self.behaviorTree:SetFloatParameter(BTConstant.PetHp, hp)
    end
end

function PetEntity:ChangeHp(value)
    BaseEntity.ChangeHp(self, value)
    MessageDispatcher:SendMessage(MessageType.Pet_Hp_Change, self.data:GetType())
end

function PetEntity:ReLoadGo(sn)
    self.render:Destroy()
    local finish = function(go)
        local position = self:GetPosition()
        self:SetPosition(position)
        self:PlayAnimation(EntityAnimationName.idle)
        self:RefreshHp()
    end

    self:LoadAsset(finish)
end

function PetEntity:RefreshHp()
    if not self:IsAlive() then
        return
    end
    local fightUnit = self:GetUnit(UnitType.FightUnit)
    fightUnit:NotifyHp(0, TipsType.UnitPetHpTips, true)
end

function PetEntity:Update(dt)
    BaseEntity.Update(self, dt)
end

function PetEntity:NeedLateUpdate()
    return true
end

function PetEntity:PetDownTeam(pet)
    if pet.type == self.data.meta.type then
        AppServices.EntityManager:RemoveEntity(self.entityId)
        AppServices.IslandFightManager:PetDown(self.entityId)
    end
end

function PetEntity:LinkedHomeland(islandId)
    AppServices.EntityManager:RemoveEntity(self.entityId)
end

function PetEntity:PetRecover()
    --console.error("PetEntity:PetRecover")
    self:SetAlive(true)
    local maxHp = self:GetMaxHp()
    self:SetHp(maxHp)
    self:SetVisible(true)

    MessageDispatcher:SendMessage(MessageType.Pet_Hp_Change, self.data.meta.type)
end

function PetEntity:RegisterEvent()
    MessageDispatcher:AddMessageListener(MessageType.IslandLinkHomeland, self.LinkedHomeland, self)
    MessageDispatcher:AddMessageListener(MessageType.PetUpLevel, self.ReceiveUpgrade, self)
    MessageDispatcher:AddMessageListener(MessageType.Pet_Down_Team, self.PetDownTeam, self)
    MessageDispatcher:AddMessageListener(MessageType.PetRecover, self.PetRecover, self)
end

function PetEntity:UnRegisterEvent()
    MessageDispatcher:RemoveMessageListener(MessageType.IslandLinkHomeland, self.LinkedHomeland, self)
    MessageDispatcher:RemoveMessageListener(MessageType.PetUpLevel, self.ReceiveUpgrade, self)
    MessageDispatcher:RemoveMessageListener(MessageType.Pet_Down_Team, self.PetDownTeam, self)
    MessageDispatcher:RemoveMessageListener(MessageType.PetRecover, self.PetRecover, self)
end

function PetEntity:Destroy()
    BaseEntity.Destroy(self)
    self:UnRegisterEvent()
    PetFollowPlayer:RemoveEntity(self.entityId)
end

return PetEntity