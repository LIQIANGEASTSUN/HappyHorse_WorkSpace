
---@class EntityRender
local EntityRender = class(nil, "EntityRender")

function EntityRender:ctor(entityId)
    self.entityId = entityId
    self.gameObject = nil
    self.transform = nil
    self.position = Vector3(0, 0, 0)
end

function EntityRender:LoadAsset(assetPath, callBack)
    App.buildingAssetsManager:LoadAssets(
        {assetPath},
        function()
            self.gameObject = BResource.InstantiateFromAssetName(assetPath)
            self.gameObject.name = tostring(self.entityId)
            local parent = AppServices.EntityManager:GetRoot()
            self.gameObject:SetParent(parent, false)
            self.transform = self.gameObject.transform
            Runtime.InvokeCbk(callBack, self.gameObject)
        end
    )
end

function EntityRender:GetGameObject()
    return self.gameObject
end

function EntityRender:SetPosition(position)
    if not Runtime.CSValid(self.gameObject) then
        return
    end

    self.gameObject:SetPosition(position)
    --self.position = position
    --self.anchorPosition = self:GetPosition() + Vector3(0, 1, 0)
end

function EntityRender:GetPosition()
    if not Runtime.CSValid(self.gameObject) then
        local pos = Camera.main:ScreenToWorldPoint(Vector3(Screen.width / 2, Screen.height / 2, 0))
        return pos
    end
    --return self.position --
    return self.gameObject:GetPosition()
end

function EntityRender:GetAnchorPosition()
    --return self.anchorPosition
    return self:GetPosition() + Vector3(0, 1, 0)
end

function EntityRender:SetForward(forward)
    local rot = Quaternion.LookRotation(forward, Vector3.up)
    self.transform.rotation = rot
end

function EntityRender:SetLocalScale(x, y, z)
    self.gameObject:SetLocalScale(x, y, z)
end

function EntityRender:SetVisible(visible)
    self.gameObject:SetActive(visible)
end

function EntityRender:Destroy()
    if Runtime.CSValid(self.gameObject) then
        Runtime.CSDestroy(self.gameObject)
    end
    self.gameObject = nil
end

return EntityRender