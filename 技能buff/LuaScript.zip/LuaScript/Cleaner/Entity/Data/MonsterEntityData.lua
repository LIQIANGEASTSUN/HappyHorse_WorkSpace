local BaseEntityData = require "Cleaner.Entity.Data.BaseEntityData"
---@class MonsterEntityData
local MonsterEntityData = class(BaseEntityData, "MonsterEntityData")

function MonsterEntityData:ctor(meta)
    self.hp = meta.hp
end

function MonsterEntityData:GetHp()
    return self.hp
end

function MonsterEntityData:SetHp(hp)
    self.hp = hp
end

function MonsterEntityData:GetSuckLevel()
    return self.meta.suckLevel
end

function MonsterEntityData:IsBoss()
    return self.meta.isBoss == 1
end

function MonsterEntityData:GetType()
    return self.meta.monsterType
end

function MonsterEntityData:GetPatrol()
    return self.meta.patrol
end

function MonsterEntityData:GetSpeciesType()
    return BaseEntityData.GetSpeciesType(self)
end

function MonsterEntityData:SetAgentId(agentId)
    self.agentId = agentId
end

function MonsterEntityData:GetAgentId()
    return self.agentId
end

function MonsterEntityData:SetRegionId(regionId)
    self.regionId = regionId
end

function MonsterEntityData:GetRegionId()
    return self.regionId
end

return MonsterEntityData