local BaseEntityData = require "Cleaner.Entity.Data.BaseEntityData"
---@class PetEntityData
local PetEntityData = class(BaseEntityData, "PetEntityData")

function PetEntityData:ctor(meta)
    self.hp = meta.hp
    -- 宠物速度跟 Player 一样，先暂时写固定值
    self.speed = 5
end

function PetEntityData:ResetMeta(meta)
    self.meta = meta
end

function PetEntityData:GetType()
    return self.meta.type
end

function PetEntityData:GetHp()
    return self.hp
end

function PetEntityData:SetHp(hp)
    self.hp = hp
end

function PetEntityData:GetPetNestSn()
    return self.meta.habitatSn
end

return PetEntityData