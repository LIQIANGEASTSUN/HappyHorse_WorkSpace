---@class BaseEntityData
local BaseEntityData = class(nil, "BaseEntityData")

function BaseEntityData:ctor(meta)
    self.meta = meta
    self.position = Vector3(0, 0, 0)
end

function BaseEntityData:GetSn()
    return self.meta.sn
end

function BaseEntityData:GetMeta()
    return self.meta
end

function BaseEntityData:GetHp()
    return 1
end

function BaseEntityData:SetHp(hp)

end

function BaseEntityData:GetSpeciesType()
    return self.meta.attribute
end

function BaseEntityData:GetType()
    return -1
end

return BaseEntityData