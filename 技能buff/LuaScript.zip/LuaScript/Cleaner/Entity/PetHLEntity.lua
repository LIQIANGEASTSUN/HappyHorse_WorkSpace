---@type PetTemplateTool
local PetTemplateTool = require "Cleaner.Entity.Pet.PetTemplateTool"

---@type PetHLHookTool
local PetHLHookTool = require "Cleaner.AIConfig.PetHL.PetHLHookTool"
---@type PetHLNestTool
local PetHLNestTool = require "Cleaner.AIConfig.PetHL.PetHLNestTool"

---@type AttributeInfo
local AttributeInfo = require "Cleaner.Fight.Attribute.AttributeInfo"

---@type BaseEntity
local BaseEntity = require "Cleaner.Entity.BaseEntity"

---@class PetHLEntity:BaseEntity 探索岛上宠物
---@field data PetHLEntityData
local PetHLEntity = class(BaseEntity, "PetHLEntity")

function PetHLEntity:ctor()

end

function PetHLEntity:InitConfig()
    self.tableTemplate = "PetTemplate"
    self.dataCfg = "PetHLEntityData"
    self.renderCfg = "EntityRender"
    self.assetPath = "Prefab/Art/Characters/Monster/%s.prefab"
end

function PetHLEntity:Init(birthPos)
    self:SetBirthPos(birthPos)
    self:SetPosition(birthPos)
    self:CreateMoveTool()
    self:CreateFightUnit(CampType.Blue)

    self:CreateAI()
    self:CreateAttribute()
    self:RegisterEvent()
end

function PetHLEntity:CreateMoveTool()
    local moveType = AppServices.UnitMoveManager.MoveType.FindPathAlgorithm
    self:ChangeMoveTool(moveType)
end

function PetHLEntity:ChangeMoveTool(moveType)
    BaseEntity.ChangeMoveTool(self, moveType)
    self.unitMove:SetSpeed(1)
end

function PetHLEntity:CreateFightUnit(camp)
    BaseEntity.CreateFightUnit(self, camp)
    local fightUnit = self:GetUnit(UnitType.FightUnit)
    fightUnit:SetEnableAttack(false)
end

function PetHLEntity:CreateAI()
    -- self:CreateBehaviorTree("PetHL")
    self:CreateBehaviorTree("PetHL3")
    self.petHLHookTool = PetHLHookTool.new(self)
    self:InstancePetHLNestTool()
end

function PetHLEntity:CreateAttribute()
    self:AddAttribute(AttributeInfo.Type.BreedTime, 1500)
    self:AddAttribute(AttributeInfo.Type.Attack, 0)
    self:AddAttribute(AttributeInfo.Type.Shield, 0)
    local hp = self.data.meta.hp
    self:AddAttribute(AttributeInfo.Type.MaxHp, hp)
end

function PetHLEntity:InstancePetHLNestTool()
    if AppServices.PetNestManager:IsPetHasNest(self.sn) then
        self.petHLNestTool = PetHLNestTool.new(self)
    end
end

function PetHLEntity:GetPatrolRadius()
    return self.data:GetPatrolRadius()
end

function PetHLEntity:ReceiveUpgrade(type, level)
    if self.data.meta.type ~= type then
        return
    end

    local currentModelName = self.data.meta.model
    local sn = PetTemplateTool:Getkey(type, level)

    local meta = AppServices.Meta:Category("PetTemplate")[tostring(sn)]
    self.data:ResetMeta(meta)

    if currentModelName ~= meta.model then
        self:ReLoadGo(sn)
    end
end

function PetHLEntity:ReLoadGo(sn)
    self.render:Destroy()
    local finish = function(go)
        local position = self:GetPosition()
        self:SetPosition(position)
        self:PlayAnimation(EntityAnimationName.idle)
    end
    self:LoadAsset(finish)
end

function PetHLEntity:Update(dt)
    BaseEntity.Update(self, dt)
end

function PetHLEntity:NeedLateUpdate()
    return true
end

function PetHLEntity:RegisterEvent()
    MessageDispatcher:AddMessageListener(MessageType.PetUpLevel, self.ReceiveUpgrade, self)
end

function PetHLEntity:UnRegisterEvent()
    MessageDispatcher:RemoveMessageListener(MessageType.PetUpLevel, self.ReceiveUpgrade, self)
end

function PetHLEntity:Destroy()
    BaseEntity.Destroy(self)
    self:UnRegisterEvent()
    self.petHLHookTool:Release()
    if self.petHLNestTool then
        self.petHLNestTool:Release()
    end
end

return PetHLEntity