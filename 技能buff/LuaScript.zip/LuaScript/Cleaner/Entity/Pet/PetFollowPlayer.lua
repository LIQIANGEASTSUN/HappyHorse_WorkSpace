--- 宠物跟随 Player
---@class PetFollowPlayer
local PetFollowPlayer = {
    targetTr = nil,
    entityArr = {},
    childMap = {},
}

local GetPlayer = function()
    local playerCharacter = CharacterManager.Instance():Find("Player")
    if playerCharacter then
        return playerCharacter:GetGameObject().transform
    end
    return nil
end

function PetFollowPlayer:GetPlayerPos()
    if not Runtime.CSValid(self.targetTr) then
        self.targetTr = GetPlayer()
    end

    if not Runtime.CSValid(self.targetTr) then
        return
    end
    return self.targetTr:GetPosition()
end

---@param entity BaseEntity 计算宠物跟随的位置
function PetFollowPlayer:GetFollowPos(entity)
    if not Runtime.CSValid(self.targetTr) then
        self.targetTr = GetPlayer()
    end

    if not Runtime.CSValid(self.targetTr) then
        return false, entity:GetPosition()
    end

    local index = 1
    local entityId = entity.entityId
    for i, id in ipairs(self.entityArr) do
        if id == entityId then
            index = i
            break
        end
    end

    local child = self.childMap[index]
    local destination = child.position
    local x, z = App.scene.mapManager:ToLocal(Vector3(destination.x, 0, destination.z))
    destination = App.scene.mapManager:ToWorld(x, z)
    return true, destination
end

-- 第 n 行的个数 count = n + 1
function PetFollowPlayer:AddEntity(entityId)
    table.insert(self.entityArr, entityId)
    self:ReLayout()
end

function PetFollowPlayer:RemoveEntity(entityId)
    for i, id in ipairs(self.entityArr) do
        if id == entityId then
            table.remove(self.entityArr, i)
        end
    end
    self:ReLayout()
end

-- 是否奇数
local function IsOdd(value)
    local floor = value % 2
    return floor == 1
end

-- 如果个数小于 5 个，则排一行就行了
-- 如果个数大于 5 个，则第一排 3 个，每增加一排，多 2 个, 阵型如下
--     * * *
--   * * * * *
-- * * * * * * *
-- 或者，如果个数大于 5 个，则第一排 4 个，每增加一排，多 1 个, 阵型如下
--   * * * *
--  * * * * *
-- * * * * * *
function PetFollowPlayer:ReLayout()
    if not Runtime.CSValid(self.targetTr) then
        self.targetTr = GetPlayer()
    end

    if not Runtime.CSValid(self.targetTr) then
        return
    end

    local numberPerRow = #self.entityArr
    if numberPerRow >= 5 then
        numberPerRow = 4
    end

    -- row 行从 0 开始
    local row = 0
    -- 每一行的index 从 0 开始
    local index = 0
    for i = 1, #self.entityArr do
        local data = {
            row = row,
            -- 每一行的第多少个，从 0 开始
            index = index,
            rowCount = numberPerRow
        }

        self:SetChildPos(i, data)
        index = index + 1
        if index >= numberPerRow then
            index = 0
            numberPerRow = math.min(numberPerRow + 1, #self.entityArr - i)
            row = row + 1
        end
    end
end

function PetFollowPlayer:SetChildPos(index, data)
    local col = 0
    --data.row, data.index, data.rowCount
    if IsOdd(data.rowCount) then
        -- 从中间往两边排列，下面这行是 index 对应的位置
        --  3， 1， 0， 2， 4
        -- 这一行是奇数个 (index + 1) / 2 取整
        -- index：0， 1， 2， 3， 4， 5， 6
        -- col  ：0，-1， 1，-2， 2，-3， 3
        col = (data.index + 1) / 2
        col = math.floor(col)
        -- 正负号：index 为奇数取 -1， 偶数取 1
        local sign = IsOdd(data.index) and -1 or 1
        col = col * sign
    else
        -- 从中间往两边排列，下面这行是 index 对应的位置
        -- 4, 2， 0， 1， 3, 5
        -- 这一行是偶数个 (index) / 2 取整
        -- index：  0，   1，    2，   3，    4，   5
        -- col  ：-0.5， 0.5， -1.5， 1.5， -2.5， 2.5
        col = (data.index) / 2
        col = math.floor(col) + 0.5
        -- 正负号：index 为奇数取 1， 偶数取 -1
        local sign = IsOdd(data.index) and 1 or -1
        col = col * sign
    end

    local child = self.childMap[index]
    if not child then
        child = GameObject("follow").transform
        child:SetParent(self.targetTr)
        child:SetLocalEulerAngle(0, 0, 0)
        self.childMap[index] = child
    end

    local localX = col * 1.35
    local localZ = (data.row + 1.35) * -1
    child:SetLocalPosition(Vector3(localX, 0, localZ))
end

function PetFollowPlayer:Release()
    self.targetTr = nil
    self.entityArr = {}
    self.childMap = {}
end

return PetFollowPlayer