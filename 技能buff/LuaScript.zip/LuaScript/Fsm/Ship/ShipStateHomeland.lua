---@type ShipStateBase
local ShipStateBase = require "Fsm.Ship.ShipStateBase"

---@type ShipStateInfo
local ShipStateInfo = require "Fsm.Ship.ShipStateInfo"

---@type SceneTemplateTool
local SceneTemplateTool = require "Fsm.Ship.SceneTemplateTool"

---@type PetTemplateTool
local PetTemplateTool = require "Cleaner.Entity.Pet.PetTemplateTool"

---@class ShipStateHomeland
local ShipStateHomeland = class(ShipStateBase, "ShipStateHomeland")
-- 船状态：在家园港口

function ShipStateHomeland:ctor()
    self.stateType = ShipStateInfo.ShipStateType.Homeland
    self:Init()
end

function ShipStateHomeland:Init()
    ShipStateBase.Init(self)
end

function ShipStateHomeland:OnEnter()
    --console.error("ShipStateHomeland:OnEnter")
    self.activity = true

    self:SetData()
    MessageDispatcher:SendMessage(MessageType.EntryHomelandAndCameraMoveEnd)
    MessageDispatcher:SendMessage(MessageType.On_Enter_Homeland)
    self:RegisterEvent()
    AppServices.PetNestManager:UpdateLstPetNest()
end

function ShipStateHomeland:OnExit()
    self.activity = false
    self:UnRegisterEvent()
end

function ShipStateHomeland:SetData()
    local sceneId = App.scene:GetCurrentSceneId()
    local playerPos, bornDir = SceneTemplateTool:GetHomelandPos(sceneId)
    MoveCameraLogic.Instance():MoveCameraToLook2(playerPos, 0.5)
    self:SpawnPlayer(playerPos, bornDir)
    self:SpawnPet(playerPos, bornDir)

    MessageDispatcher:SendMessage(MessageType.ShipButtonShow, true)
end

function ShipStateHomeland:SpawnPlayer(playerPos, birthDir)
    local playerParams = {position = playerPos, birthDir = birthDir}
    CharacterManager.Instance():CreateByName("PlayerHome", playerParams)
end

function ShipStateHomeland:SpawnPet(playerPos, bornDir)
    local petList = AppServices.EntityManager:GetEntityWithType(EntityType.PetHL)
    local petMap = {}
    for _, pet in pairs(petList) do
        local type = pet.data:GetType()
        petMap[type] = true
    end

    local _, petSpawnPos = self:PetSpawnPosition(playerPos, bornDir)
    self.petSpawnPos = petSpawnPos
    local pets = AppServices.User:GetPets()
    for _, pet in pairs(pets) do
        if not petMap[pet.type] then
            self:AddPet(pet.id, pet.type, pet.level, 1)
        end
    end
end

function ShipStateHomeland:CreatePetCallBack(entity, petSpawnPos, id)
    local result, position = AppServices.IslandPathManager:RandomPath(petSpawnPos.x, petSpawnPos.z)
    if result then
        entity:Init(position)
    else
        entity:Init(petSpawnPos)
    end

    local entityId = entity:GetEntityId()
    --- 所属栖息地 配置表sn
    local habitatSn = entity.data:GetHabitatSn()
    MessageDispatcher:SendMessage(MessageType.PetHLCreateFinish, id, entityId, habitatSn)
end

-- 查找一个可行走的位置，生成宠物用
function ShipStateHomeland:PetSpawnPosition(playerPos, bornDir)
    local originPos = playerPos - bornDir * 2.5

    local find = false
    local petSpawnPos = originPos
    self:EnablePassPosition(originPos, function(position)
        local enablePass = AppServices.IslandPathManager:EnablePass(position.x, position.y)
        local worldPos = Vector3(position.x, 0, position.y)
        if enablePass then
            petSpawnPos = worldPos
            find = true
            return false
        end
        return true
    end)

    return find, petSpawnPos
end

function ShipStateHomeland:GoIslandEvent(islandId)
    if not self.activity then
        return
    end

    if not SceneTemplateTool:IsValid(islandId) then
        return
    end

    self:GoIsland(islandId)
end

function ShipStateHomeland:GoIsland(islandId)
    if not self.activity then
        return
    end
    AppServices.RequestMapDataProcessor:Start(islandId)
end

function ShipStateHomeland:AddPet(id, type, level, count)
    local key = PetTemplateTool:Getkey(type, level)
    AppServices.EntityManager:CreateEntity(tostring(key), EntityType.PetHL, function(entity)
        self:CreatePetCallBack(entity, self.petSpawnPos, id)
    end)
end

function ShipStateHomeland:RegisterEvent()
    MessageDispatcher:AddMessageListener(MessageType.GoToIsland, self.GoIslandEvent, self)
    MessageDispatcher:AddMessageListener(MessageType.AddPet, self.AddPet, self)
end

function ShipStateHomeland:UnRegisterEvent()
    MessageDispatcher:RemoveMessageListener(MessageType.GoToIsland, self.GoIslandEvent, self)
    MessageDispatcher:RemoveMessageListener(MessageType.AddPet, self.AddPet, self)
end

return ShipStateHomeland