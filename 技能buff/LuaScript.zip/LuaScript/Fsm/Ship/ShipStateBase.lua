---@type FsmStateBase
local FsmStateBase = require "Fsm.StateMachine.FsmStateBase"

---@type ChangeSceneAnimation
local ChangeSceneAnimation = require "Game.Common.ChangeSceneAnimation"

---@type SudokuScrewCross
local SudokuScrewCross = require "Cleaner.PathFinding.Search.SudokuScrewCross"

---@class ShipStateBase
local ShipStateBase = class(FsmStateBase, "ShipStateBase")
-- 探索船状态基类

function ShipStateBase:ctor()
    self.stateType = 0
    self.activity = false
end

function ShipStateBase:SetEntity()
    self:SetCommonTransition()
end

function ShipStateBase:Init()

end

-- Player 碰撞到船
function ShipStateBase:TriggerPlayer()

end

-- 处理点击
function ShipStateBase:ProcessClick()

end

function ShipStateBase:SetEntityPosition(entity, playerPos)
    local x = Random.Range(-1, 1)
    local z = Random.Range(-1, 1)
    local pos = playerPos + Vector3(x, 0, z)
    entity:SetPosition(pos)
end

function ShipStateBase:StartSailing(finish)
    ChangeSceneAnimation.Instance():EnterCityIn(finish)
end

function ShipStateBase:EndSailing()
    ChangeSceneAnimation.Instance():PlayOut(nil)
end

-- 查找一个可行走的位置，生成宠物用
function ShipStateBase:EnablePassPosition(originPos, callBack)
    local petSpawnPos = Vector2(originPos.x, originPos.z)
    SudokuScrewCross:Search( petSpawnPos, 0, 10, callBack)
end
--[[
function ShipStateBase:OnEnter()
end

function ShipStateBase:OnTick()
end

function ShipStateBase:OnExit()
end
--]]

return ShipStateBase