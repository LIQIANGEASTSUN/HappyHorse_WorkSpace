---@type ShipStateBase
local ShipStateBase = require "Fsm.Ship.ShipStateBase"

---@type PetFollowPlayer
local PetFollowPlayer = require "Cleaner.Entity.Pet.PetFollowPlayer"

---@type ShipStateInfo
local ShipStateInfo = require "Fsm.Ship.ShipStateInfo"

---@type SceneTemplateTool
local SceneTemplateTool = require "Fsm.Ship.SceneTemplateTool"

---@type PetTemplateTool
local PetTemplateTool = require "Cleaner.Entity.Pet.PetTemplateTool"

---@class ShipStateIsland:ShipStateBase
local ShipStateIsland = class(ShipStateBase, "ShipStateIsland")
-- 船状态：在岛屿港口

function ShipStateIsland:ctor()
    self.stateType = ShipStateInfo.ShipStateType.Island
    self:Init()
end

function ShipStateIsland:Init()
    ShipStateBase.Init(self)
end

function ShipStateIsland:OnEnter()
    self.activity = true
    --console.error("ShipStateIsland:OnEnter")
    self.sceneId = App.scene:GetCurrentSceneId()
    AppServices.IslandFightManager:StartFight(self.sceneId)
    self:SetData()
    self:RegisterEvent()

    MessageDispatcher:SendMessage(MessageType.On_Enter_ExploreIsland, self.sceneId)
end

function ShipStateIsland:OnExit()
    self:RemoveAllPet()
    self.activity = false
    MessageDispatcher:SendMessage(MessageType.LeaveIsLand, self.sceneId)
    MessageDispatcher:SendMessage(MessageType.IslandShowPetTeam, false)

    self:UnRegisterEvent()
    AppServices.IslandFightManager:QuitFight(self.sceneId)
end

function ShipStateIsland:SetData()
    MessageDispatcher:SendMessage(MessageType.IslandShowPetTeam, true)

    local sceneId = App.scene:GetCurrentSceneId()
    local playerPos, bornDir = SceneTemplateTool:GetIslandPos(sceneId)
    self:SpawnPlayer(playerPos, bornDir)
    self:SpawnPet()

    local enableUseShip = self:EnableUseShip()
    MessageDispatcher:SendMessage(MessageType.ShipButtonShow, enableUseShip)
end

function ShipStateIsland:EnableUseShip()
    local sn = AppServices.Meta:GetConfigMetaValue("defaultIsland", 0)
    local defaultId = tonumber(sn)
    local sceneId = App.scene:GetCurrentSceneId()
    local type = SceneTemplateTool:GetType(sceneId)
    if type == SceneTemplateType.Homeland then
        return true
    end
    return sceneId ~= defaultId
end

function ShipStateIsland:SpawnPlayer(playerPos, bornDir)
    local playerParams = {position = playerPos, birthDir = bornDir}
    CharacterManager.Instance():CreateByName("Player", playerParams)
end

function ShipStateIsland:SpawnPet()
    local pets = AppServices.User:GetPets()
    for _, pet in pairs(pets) do
        if pet.up == 1 then
            local key = PetTemplateTool:Getkey(pet.type, pet.level)
            AppServices.EntityManager:CreateEntity(
                tostring(key),
                EntityType.Pet,
                function(entity)
                    self:CreatePetCallBack(entity)
                end
            )
        end
    end
end

function ShipStateIsland:PetUpTeam(pet)
    local key = PetTemplateTool:Getkey(pet.type, pet.level)
    AppServices.EntityManager:CreateEntity(
        tostring(key),
        EntityType.Pet,
        function(entity)
            self:CreatePetCallBack(entity)
        end
    )
end

---@param entity BaseEntity
function ShipStateIsland:CreatePetCallBack(entity)
    PetFollowPlayer:AddEntity(entity.entityId)
    local _, birthPos = self:PetSpawnPosition()
    entity:Init(birthPos)

    local type = entity.data.meta.type
    local hp = AppServices.IslandFightManager:GetTypeHp(type)
    if hp then
        entity:SetHp(hp)
    else
        local maxHp = entity:GetMaxHp()
        entity:SetHp(maxHp)
    end
    MessageDispatcher:SendMessage(MessageType.Pet_Hp_Change, type)
end

-- 查找一个可行走的位置，生成宠物用
function ShipStateIsland:PetSpawnPosition()
    local playerCharacter = CharacterManager.Instance():Find("Player")
    local transform = playerCharacter:GetGameObject().transform
    local originPos = transform.transform.position - transform.forward * 1.5

    local find = false
    local petSpawnPos = originPos
    self:EnablePassPosition(
        originPos,
        function(position)
            local enablePass = AppServices.IslandPathManager:EnablePass(position.x, position.y)
            if enablePass then
                petSpawnPos = Vector3(position.x, 0, position.y)
                find = true
                return false
            end
            return true
        end
    )

    return find, petSpawnPos
end

function ShipStateIsland:GoHomelandStart()
    if not self.activity then
        return
    end

    local islandId = SceneTemplateTool:GetHomelandId()
    AppServices.RequestMapDataProcessor:Start(islandId)
end

-- 退出岛屿时，移除所有宠物
function ShipStateIsland:RemoveAllPet()
    local entities = AppServices.EntityManager:GetAllEntity()
    for _, entity in ipairs(entities) do
        local entityType = entity:GetEntityType()
        if entityType == EntityType.Pet then
            AppServices.EntityManager:RemoveEntity(entity.entityId)
        end
    end
end

function ShipStateIsland:LinkedHomeland(islandId)
    local currentIslandId = App.scene:GetCurrentSceneId()
    if currentIslandId ~= islandId then
        console.error("当前在岛屿%d,但是接收到岛屿%d连接到家园的消息了", currentIslandId, islandId)
        return
    end

    local arguments = {islandId = islandId}
    PanelManager.showPanel(GlobalPanelEnum.ShipIslandLinkHomelandPanel, arguments)
end

function ShipStateIsland:RegisterEvent()
    MessageDispatcher:AddMessageListener(MessageType.IslandLinkHomeland, self.LinkedHomeland, self)
    MessageDispatcher:AddMessageListener(MessageType.GoToHomeland, self.GoHomelandStart, self)
    MessageDispatcher:AddMessageListener(MessageType.Pet_Up_Team, self.PetUpTeam, self)
end

function ShipStateIsland:UnRegisterEvent()
    MessageDispatcher:RemoveMessageListener(MessageType.IslandLinkHomeland, self.LinkedHomeland, self)
    MessageDispatcher:RemoveMessageListener(MessageType.GoToHomeland, self.GoHomelandStart, self)
    MessageDispatcher:RemoveMessageListener(MessageType.Pet_Up_Team, self.PetUpTeam, self)
end

return ShipStateIsland