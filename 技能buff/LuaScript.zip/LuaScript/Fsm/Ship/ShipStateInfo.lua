---@class ShipStateInfo
local ShipStateInfo = { }

--- 船状态类型
ShipStateInfo.ShipStateType = {
    --- 船在家园港口停靠
    Homeland = 1,
    --- 船在岛屿港口停靠
    Island = 4,
}

ShipStateInfo.States = setmetatable(
    {
        _register = {
            [ShipStateInfo.ShipStateType.Homeland] = "Fsm.Ship.ShipStateHomeland",
            [ShipStateInfo.ShipStateType.Island] = "Fsm.Ship.ShipStateIsland",
        }
    },
    {
        __index = function(t, k)
            local path = t._register[k]
            local v = require(path)
            rawset(t, k, v)
            return v
        end
    }
)

return ShipStateInfo