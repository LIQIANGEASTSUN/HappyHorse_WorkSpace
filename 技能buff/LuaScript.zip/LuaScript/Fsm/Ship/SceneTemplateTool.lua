
---@class SceneTemplateTool
local SceneTemplateTool = {
    islandIds = {},
    homelandId = nil,
    maxIslandId = 0
}

function SceneTemplateTool:GetHomelandId()
    if not self.homelandId then
        self:GetAllIsland()
    end
    return self.homelandId
end

function SceneTemplateTool:GetType(islandId)
    local key = tostring(islandId)
    local data = self:GetData(key)
    if data then
        return data.type
    end

    return SceneTemplateType.Homeland
end

function SceneTemplateTool:GetAllIsland()
    if #self.islandIds > 0 then
        return self.islandIds
    end

    local config = AppServices.Meta:Category("SceneTemplate")
    for _, data in pairs(config) do
        if data.type == SceneTemplateType.Island then
            table.insert(self.islandIds, data.sn)
            if data.sn > self.maxIslandId then
                self.maxIslandId = data.sn
            end
        elseif data.type == SceneTemplateType.Homeland then
            if not self.homelandId then
                self.homelandId = data.sn
            end
        end
    end

    table.sort(self.islandIds, function(a, b)
        return tonumber(a) < tonumber(b)
    end)

    return self.islandIds
end

function SceneTemplateTool:GetMaxIslandId()
    if #self.islandIds <= 0 then
        self:GetAllIsland()
    end
    return self.maxIslandId
end

function SceneTemplateTool:IsValid(islandId)
    local key = tostring(islandId)
    local data = self:GetData(key)
    if not data then
        return false
    end
    return true
end

function SceneTemplateTool:GetData(key)
    local config = AppServices.Meta:Category("SceneTemplate")
    return config[tostring(key)]
end

function SceneTemplateTool:GetPosData(islandId)
    local data = self:GetData(islandId)
    local playerPos = Vector3(data.bornPosition[1], data.bornPosition[2], data.bornPosition[3])
    local bornDir = Vector3(data.bornDir[1], 0, data.bornDir[2])
    return playerPos, bornDir
end

function SceneTemplateTool:GetHomelandPos(islandId)
    local key = tostring(islandId)
    if not self:IsValid(islandId) then
        self:GetAllIsland()
        key = self.homelandId
    end
    return self:GetPosData(key)
end

function SceneTemplateTool:GetIslandPos(islandId)
    local key = tostring(islandId)
    if not self:IsValid(islandId) then
        self:GetAllIsland()
        key = self.islandIds[1]
    end
    return self:GetPosData(key)
end

return SceneTemplateTool