---@type PlayerStateBase
local PlayerStateBase = require "Fsm.Player.PlayerStateBase"

---@type PlayerStateInfo
local PlayerStateInfo = require "Fsm.Player.PlayerStateInfo"

---@class PlayerStateSilent:FsmStateBase
local PlayerStateSilent = class(PlayerStateBase, "PlayerStateSilent")
--- Player 状态：静默中
function PlayerStateSilent:ctor()
    self.stateType = PlayerStateInfo.StateType.Silent
    self:Init()
end

function PlayerStateSilent:Init()
    PlayerStateBase.Init(self)
end

function PlayerStateSilent:OnEnter()
    --console.error("PlayerStateSilent:OnEnter")
    PlayerStateBase.OnEnter(self)
    AppServices.PlayerJoystickManager:SetPlayerState(self.stateType)
end

function PlayerStateSilent:EnablePath(position, dir)
    return false
end

return PlayerStateSilent