---@type FsmStateBase
local FsmStateBase = require "Fsm.StateMachine.FsmStateBase"

---@class PlayerStateBase:FsmStateBase
local PlayerStateBase = class(FsmStateBase, "PlayerStateBase")
--- Player 状态：基类
function PlayerStateBase:ctor(playerCharacter)
    ---@type PlayerCharacter
    self.playerCharacter = playerCharacter
    self.stateType = 0
    self.toOtherState = 0
end

function PlayerStateBase:Init()
    self:SetCommonTransition()
end

function PlayerStateBase:OnEnter()
    FsmStateBase.OnEnter(self)
end

function PlayerStateBase:OnTick(dt)
    FsmStateBase.OnTick(self, dt)
end

function PlayerStateBase:OnExit()
    FsmStateBase.OnExit(self)
end

function PlayerStateBase:EnablePath(position, dir)
    return false
end

-- 所有状态通用的切换条件
function PlayerStateBase:SetCommonTransition()
    self:ToOtherStateTransition()
end

-- 从 当提前状态到其 toOtherState 状态
function PlayerStateBase:ToOtherStateTransition()
    local transition = {index = 1}
    transition.CanTransition = function()
        -- 逻辑判断
        ---@type TargetSearchResult
        local result = self.toOtherState > 0
        return result, self.toOtherState
    end
    self:AddTransition(transition)
end

return PlayerStateBase