
---@class PlayerStateInfo
local PlayerStateInfo = {}


--- Player 状态
PlayerStateInfo.StateType = {
    --- 激活中
    Activate = 1,
    --- 静默中
    Silent = 2,
}

PlayerStateInfo.States = {
    [PlayerStateInfo.StateType.Activate] = "Fsm.Player.PlayerStateActivate",
    [PlayerStateInfo.StateType.Silent] = "Fsm.Player.PlayerStateSilent",
}

return PlayerStateInfo