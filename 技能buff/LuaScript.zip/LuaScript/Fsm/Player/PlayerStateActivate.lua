---@type PlayerStateBase
local PlayerStateBase = require "Fsm.Player.PlayerStateBase"

---@type PosIsOnWater
local PosIsOnWater = require "Cleaner.Fight.EntityMove.PosIsOnWater"

---@type PlayerStateInfo
local PlayerStateInfo = require "Fsm.Player.PlayerStateInfo"

---@class PlayerStateActivate:FsmStateBase
local PlayerStateActivate = class(PlayerStateBase, "PlayerStateActivate")
-- Player 状态：激活中
function PlayerStateActivate:ctor()
    self.stateType = PlayerStateInfo.StateType.Activate
    self:Init()
end

function PlayerStateActivate:Init()
    PlayerStateBase.Init(self)
    self.vaccumCleaner = self.playerCharacter:GetVaccumCleaner()
end

function PlayerStateActivate:OnEnter()
    --console.error("PlayerStateActivate:OnEnter")
    PlayerStateBase.OnEnter(self)
    AppServices.PlayerJoystickManager:SetPlayerState(self.stateType)
end

function PlayerStateActivate:OnTick(dt)
    PlayerStateBase.OnTick(self, dt)
    if self.vaccumCleaner and self.vaccumCleaner.alive and dt then
        self.vaccumCleaner:Update(dt)
    end
end

function PlayerStateActivate:EnablePath(position, dir)
    if not self:CanUse() then
        return false
    end
    local pos = position + dir * 0.5
    local onWater = PosIsOnWater:IsOnWater(pos) -- AppServices.IslandPathManager:PlayerEnablePass(pos.x, pos.z)
    if onWater then
        self:CheckPosition()
    end
    return not onWater
end

function PlayerStateActivate:CanUse()
    if PanelManager.isShowingAnyPanel() then
        return
    end
    if App.mapGuideManager:HasRunningGuide() then
        if App.mapGuideManager:IsMovePlayerDisabled() then
            return
        end
    end
    if App.screenPlayActive then
        return
    end

    return true
end

function PlayerStateActivate:CheckPosition()
    local pos = self.playerCharacter:GetPosition()
    if not PosIsOnWater:IsOnWater(pos) then
        return
    end

    --- 将 Player 放回最后一个有效的位置
    local newPos = pos + (self.playerCharacter.validPos - pos).normalized * 0.5
    self.playerCharacter:SetPosition(newPos)
end

return PlayerStateActivate