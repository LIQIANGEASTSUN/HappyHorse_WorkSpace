local config = [====[{
"1001":{"id":"1001","guideType":"","ObstacleId":"","bustPos":"","maskType":"","maskConfig":"","skipType":"","bustText":""}
}]====]
return table.deserialize(config)