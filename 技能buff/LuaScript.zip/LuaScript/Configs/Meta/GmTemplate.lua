return{["1"]={["sn"]=1,["desc"]="加经验",["name"]="addExp",["param1"]="100",["param2"]=0.0},
["2"]={["sn"]=2,["desc"]="加道具",["name"]="addItem",["param1"]="2",["param2"]="100"},
["3"]={["sn"]=3,["desc"]="调等级",["name"]="setLv",["param1"]="10",["param2"]=0.0}}