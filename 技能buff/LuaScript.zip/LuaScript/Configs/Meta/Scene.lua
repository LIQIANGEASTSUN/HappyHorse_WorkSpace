return{["2"]={["type"]=3,["icon"]="ui_map_icon16",["bornPosition"]={12.846,0,-7.315},["whetherRecordPos"]=1},
["401"]={["type"]=6,["icon"]="ui_map_active_icon02",["bornPosition"]={19.9,0,3.5},["whetherRecordPos"]=1},
["101"]={["type"]=6,["icon"]="ui_map_active_icon02",["bornPosition"]={19.9,0,3.5},["whetherRecordPos"]=1}}