return{["1001"]={["sn"]=1001,["orderLevel"]={1},["totalValueTime"]=30,["threeItem"]={{1000,1},{0,0.8},{0,0.7}}},
["1002"]={["sn"]=1002,["orderLevel"]={1,2},["totalValueTime"]=50,["threeItem"]={{200,1},{400,0.8},{400,0.7}}},
["1003"]={["sn"]=1003,["orderLevel"]={1,2},["totalValueTime"]=70,["threeItem"]={{200,1},{400,0.8},{400,0.7}}},
["1004"]={["sn"]=1004,["orderLevel"]={1,2},["totalValueTime"]=90,["threeItem"]={{200,1},{400,0.8},{400,0.7}}},
["1005"]={["sn"]=1005,["orderLevel"]={1,2},["totalValueTime"]=120,["threeItem"]={{200,1},{400,0.8},{400,0.7}}}}