local cfg = [====[
{
    "Id": "Cleaner_drama1_1",
    "BgImage": {
        "IsEnabled": false,
        "Name": "",
        "Start": 0,
        "End": 0,
        "InAnim": "",
        "IdleAnim": "",
        "OutAnim": "",
        "IdleLoop": true,
        "IsSpine": true
    },
    "Dialogues": [
        {
            "TextKey": "",
            "HideSkipButton": false,
            "Avatars": [
                {
                    "Action": "Inactive",
                    "Avatar": "Player",
                    "Emotion": "default",
                    "BubbleImage": "",
                    "Index": 1,
                    "Alias": "",
                    "Animation": "",
                    "AvatarType": "Image",
                    "AnimationLoop": false,
                    "takeItem": "",
                    "takeItemOffset": {
                        "x": 0.0,
                        "y": 0.0,
                        "z": 0.0
                    }
                }
            ],
            "Actions": [],
            "Paragraphs": [
                {
                    "TextKey": "Description_subunlockfanyu",
                    "LetterDelay": 0.0,
                    "AutoNextDelay": 0.0
                }
            ]
        },
        {
            "TextKey": "",
            "HideSkipButton": false,
            "Avatars": [
                {
                    "Action": "Active",
                    "Avatar": "Player",
                    "Emotion": "default",
                    "BubbleImage": "",
                    "Index": 1,
                    "Alias": "",
                    "Animation": "",
                    "AvatarType": "Image",
                    "AnimationLoop": false,
                    "takeItem": "",
                    "takeItemOffset": {
                        "x": 0.0,
                        "y": 0.0,
                        "z": 0.0
                    }
                }
            ],
            "Actions": [],
            "Paragraphs": [
                {
                    "TextKey": "Description_sub013BMergeDragon",
                    "LetterDelay": 0.0,
                    "AutoNextDelay": 0.0
                }
            ]
        }
    ]
}
]====]
return table.deserialize(cfg)