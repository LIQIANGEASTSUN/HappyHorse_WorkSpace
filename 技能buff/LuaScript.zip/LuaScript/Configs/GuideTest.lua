

return function()

    --AppServices.RVO2Manager:CreateTest()

    AppServices.IslandManager:Calculate()
    AppServices.IslandManager:CheckIslandComplete()

    -- local PetAttributeEntity = require "Cleaner.PetNest.Attribute.PetAttributeEntity"
    -- local entity = PetAttributeEntity.new(501101)

    -- local maxHp = entity:GetMaxHp()
    -- console.error("maxHp:"..tostring(maxHp))

    -- local damage = entity:GetMaxAttack()
    -- console.error("damage:"..tostring(damage))

end

--[[
    local buffId= 50102

    ---@type BuffDescript
    local BuffDescript = require "Cleaner.Fight.Buff.BuffDescript"
    local msg = BuffDescript:Descript(buffId)

    for buffId = 50102, 50107 do
        local msg = BuffDescript:Descript(buffId)
        console.error("id:"..buffId)
        console.error("msg:"..msg)
    end

    ---@type AttributeInfo
    local AttributeInfo = require "Cleaner.Fight.Attribute.AttributeInfo"

    local list = AppServices.EntityManager:GetEntityWithType(EntityType.PetHL)
    ---@type BaseEntity
    local entity = list[1]

    --- 添加属性
    entity:AddAttribute(AttributeInfo.Type.BreedTime, 1500)

    --- 添加 buff
    entity:AddBuff(50105)

    local fightUnit = entity:GetUnit(UnitType.FightUnit)
    --- 通过 FightUnitBase 获取 属性
    ---@type AttributeBase
    local attributeBase = fightUnit:GetAttribute(AttributeInfo.Type.BreedTime)

    --- 通过 entity 获取属性值
    attributeBase = entity:GetAttribute(AttributeInfo.Type.BreedTime)
    local value = attributeBase:GetValue()
    console.error("value:"..value)

    --- 清除所有buff
    entity:ClearBuff()
]]