return {
  island101_ground_complete = {
    x = 0.0,
    y = 1.10672188
  },
  decorate_keel_02 = {
    x = 0.274243116,
    y = -1.431797
  },
  island105_building_cave = {
    x = -2.10438728,
    y = -1.1742897
  },
  island103_building_mountain = {
    x = -0.2947235,
    y = -3.95991516
  },
  island2_ground_02 = {
    x = 1.0,
    y = 0.0
  },
  island2_ground_03 = {
    x = 1.0,
    y = 0.0
  },
  island2_ground_07 = {
    x = 1.0,
    y = 0.0
  },
  island3_ground_01 = {
    x = 1.0,
    y = 0.0
  },
  island3_ground_02 = {
    x = 1.0,
    y = 0.0
  },
  island3_ground_03 = {
    x = 1.0,
    y = 0.0
  },
  island4_ground_05 = {
    x = 1.0,
    y = 0.0
  },
  island4_ground_06 = {
    x = 1.0,
    y = 0.0
  },
  island5_ground_02 = {
    x = 0.0,
    y = 1.0
  },
  island5_ground_04 = {
    x = 1.0,
    y = 0.0
  },
  island6_ground_02 = {
    x = 1.0,
    y = 0.0
  },
  island6_ground_06 = {
    x = 1.0,
    y = 0.0
  }
}
