return {
  ["4054"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {42, 37},
    pos = {28,0,-4},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4055"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {17, 3},
    pos = {2.95,0,-38.32},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4056"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {21, 22},
    pos = {6.51,0,-19.11},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4057"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {40, 35},
    pos = {26.09,0,-6.05},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4058"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {21, 23},
    pos = {7.37,0,-18.35},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4061"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {12, 36},
    pos = {-2.02,0,-4.68},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4062"] = {
    tid = 60404501,
    monsterId = 0,
    coord = {27, 55},
    pos = {13.06,0,13.87},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4063"] = {
    tid = 60404502,
    monsterId = 0,
    coord = {22, 10},
    pos = {7.53,0,-30.52},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4064"] = {
    tid = 60404201,
    monsterId = 0,
    coord = {7, 38},
    pos = {-6.84,0,-2.98},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4065"] = {
    tid = 60404202,
    monsterId = 0,
    coord = {61, 28},
    pos = {46.76,0,-13.43},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4066"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {43, 59},
    pos = {29.48,0,18.46},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4067"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {38, 38},
    pos = {24.05,0,-2.87},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4099"] = {
    tid = 60404501,
    monsterId = 0,
    coord = {28, 13},
    pos = {13.97,0,-28.24},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4100"] = {
    tid = 60404501,
    monsterId = 0,
    coord = {33, 22},
    pos = {18.83,0,-18.65},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4101"] = {
    tid = 60404501,
    monsterId = 0,
    coord = {54, 33},
    pos = {40.3,0,-8.24},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4102"] = {
    tid = 60404501,
    monsterId = 0,
    coord = {60, 31},
    pos = {45.92,0,-9.7},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4103"] = {
    tid = 60404501,
    monsterId = 0,
    coord = {1, 39},
    pos = {-12.755,0,-1.577},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4104"] = {
    tid = 60404501,
    monsterId = 0,
    coord = {54, 60},
    pos = {40.32,0,19.19},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4105"] = {
    tid = 60404502,
    monsterId = 0,
    coord = {1, 43},
    pos = {-12.58,0,1.9},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4106"] = {
    tid = 60404502,
    monsterId = 0,
    coord = {20, 41},
    pos = {5.992,0,0.496},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4107"] = {
    tid = 60404502,
    monsterId = 0,
    coord = {15, 29},
    pos = {1.23,0,-11.53},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4108"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {14, 30},
    pos = {-0.43,0,-10.51},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4109"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {16, 31},
    pos = {1.65,0,-10.43},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4110"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {14, 28},
    pos = {-0.07,0,-12.71},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4111"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {11, 24},
    pos = {-2.67,0,-16.81},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4112"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {11, 21},
    pos = {-2.7,0,-20.02},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4113"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {14, 20},
    pos = {-0.1,0,-20.75},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4114"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {15, 44},
    pos = {1.12,0,2.55},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4115"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {11, 44},
    pos = {-2.58,0,3.2},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4116"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {3, 44},
    pos = {-11,0,3.16},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4117"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {30, 61},
    pos = {16.01,0,19.94},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4118"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {28, 62},
    pos = {13.54,0,20.79},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4119"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {25, 61},
    pos = {11.03,0,20.4},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4120"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {25, 59},
    pos = {10.93,0,18.28},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4121"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {29, 60},
    pos = {14.6,0,18.51},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4122"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {28, 57},
    pos = {13.87,0,16.19},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4123"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {36, 52},
    pos = {21.57,0,10.67},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4124"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {56, 62},
    pos = {41.72,0,20.92},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4125"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {53, 62},
    pos = {39.06,0,20.96},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4126"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {56, 58},
    pos = {41.68,0,16.96},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4127"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {50, 62},
    pos = {36.14,0,20.62},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4128"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {50, 58},
    pos = {36.39,0,16.75},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4129"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {48, 62},
    pos = {33.58,0,20.66},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4130"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {45, 62},
    pos = {30.81,0,20.92},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4131"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {46, 58},
    pos = {31.65,0,17.28},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4132"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {49, 56},
    pos = {34.84,0,15.3},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4133"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {50, 55},
    pos = {35.75,0,14.25},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4134"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {27, 27},
    pos = {12.66,0,-13.7},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4135"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {30, 28},
    pos = {15.88,0,-13.07},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4136"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {28, 30},
    pos = {13.9,0,-11.28},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4137"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {26, 29},
    pos = {12.11,0,-11.6},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4138"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {35, 44},
    pos = {20.62,0,2.67},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4139"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {32, 44},
    pos = {17.77,0,3.17},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4140"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {33, 42},
    pos = {18.98,0,1.34},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4141"] = {
    tid = 60404202,
    monsterId = 0,
    coord = {36, 62},
    pos = {21.93,0,20.55},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4142"] = {
    tid = 60404202,
    monsterId = 0,
    coord = {56, 34},
    pos = {41.85,0,-7.03},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4143"] = {
    tid = 60404202,
    monsterId = 0,
    coord = {51, 34},
    pos = {36.79,0,-7.36},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4144"] = {
    tid = 60404202,
    monsterId = 0,
    coord = {49, 31},
    pos = {34.9,0,-10.26},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4145"] = {
    tid = 60404202,
    monsterId = 0,
    coord = {33, 24},
    pos = {19.38,0,-16.92},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4146"] = {
    tid = 60404202,
    monsterId = 0,
    coord = {33, 19},
    pos = {19.47,0,-21.77},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4147"] = {
    tid = 60404202,
    monsterId = 0,
    coord = {34, 15},
    pos = {19.56,0,-25.97},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4148"] = {
    tid = 60404202,
    monsterId = 0,
    coord = {24, 13},
    pos = {10.01,0,-28.15},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4149"] = {
    tid = 60404202,
    monsterId = 0,
    coord = {26, 12},
    pos = {12.41,0,-28.55},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4150"] = {
    tid = 60404202,
    monsterId = 0,
    coord = {29, 15},
    pos = {14.58,0,-26.17},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4151"] = {
    tid = 60404202,
    monsterId = 0,
    coord = {21, 7},
    pos = {7.18,0,-33.88},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4152"] = {
    tid = 60404202,
    monsterId = 0,
    coord = {22, 5},
    pos = {7.9,0,-36.26},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4153"] = {
    tid = 60404202,
    monsterId = 0,
    coord = {20, 5},
    pos = {6.43,0,-35.94},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4154"] = {
    tid = 60404202,
    monsterId = 0,
    coord = {17, 10},
    pos = {3.27,0,-31.1},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4155"] = {
    tid = 60404202,
    monsterId = 0,
    coord = {5, 44},
    pos = {-9.03,0,2.92},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4156"] = {
    tid = 60404202,
    monsterId = 0,
    coord = {1, 44},
    pos = {-12.79,0,3.28},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4157"] = {
    tid = 60404202,
    monsterId = 0,
    coord = {0, 44},
    pos = {-14.01,0,2.74},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4158"] = {
    tid = 60404202,
    monsterId = 0,
    coord = {0, 41},
    pos = {-13.81,0,0.41},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4159"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {10, 32},
    pos = {-3.72,0,-8.5},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4160"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {7, 32},
    pos = {-6.7,0,-8.81},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4161"] = {
    tid = 60404204,
    monsterId = 0,
    coord = {7, 36},
    pos = {-6.83,0,-5.43},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4162"] = {
    tid = 60404202,
    monsterId = 0,
    coord = {20, 52},
    pos = {5.69,0,10.56},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4163"] = {
    tid = 60404202,
    monsterId = 0,
    coord = {21, 51},
    pos = {7.09,0,10.19},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4164"] = {
    tid = 60404202,
    monsterId = 0,
    coord = {49, 51},
    pos = {35.38,0,9.98},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4165"] = {
    tid = 60404202,
    monsterId = 0,
    coord = {50, 53},
    pos = {35.52,0,12.43},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4166"] = {
    tid = 60404202,
    monsterId = 0,
    coord = {46, 51},
    pos = {32.12,0,10.14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4167"] = {
    tid = 60404202,
    monsterId = 0,
    coord = {44, 60},
    pos = {30.01,0,19.09},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4168"] = {
    tid = 60404201,
    monsterId = 0,
    coord = {61, 27},
    pos = {46.92,0,-14.35},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4169"] = {
    tid = 60404201,
    monsterId = 0,
    coord = {61, 29},
    pos = {47.07,0,-11.74},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4170"] = {
    tid = 60404201,
    monsterId = 0,
    coord = {61, 34},
    pos = {47.11,0,-7.42},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4171"] = {
    tid = 60404201,
    monsterId = 0,
    coord = {57, 34},
    pos = {43.24,0,-7.33},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4172"] = {
    tid = 60404201,
    monsterId = 0,
    coord = {57, 23},
    pos = {42.53,0,-17.85},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4173"] = {
    tid = 60404201,
    monsterId = 0,
    coord = {50, 33},
    pos = {36.07,0,-8.29},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4174"] = {
    tid = 60404201,
    monsterId = 0,
    coord = {52, 34},
    pos = {38.18,0,-6.92},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4175"] = {
    tid = 60404201,
    monsterId = 0,
    coord = {44, 31},
    pos = {30.05,0,-9.85},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4176"] = {
    tid = 60404201,
    monsterId = 0,
    coord = {34, 17},
    pos = {19.83,0,-23.73},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4177"] = {
    tid = 60404201,
    monsterId = 0,
    coord = {34, 14},
    pos = {19.83,0,-26.91},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4178"] = {
    tid = 60404201,
    monsterId = 0,
    coord = {35, 26},
    pos = {20.95,0,-14.98},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4179"] = {
    tid = 60404201,
    monsterId = 0,
    coord = {34, 23},
    pos = {20.07,0,-17.74},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4180"] = {
    tid = 60404201,
    monsterId = 0,
    coord = {23, 24},
    pos = {9.31,0,-17.13},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4181"] = {
    tid = 60404201,
    monsterId = 0,
    coord = {19, 22},
    pos = {5.15,0,-18.53},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4182"] = {
    tid = 60404201,
    monsterId = 0,
    coord = {19, 18},
    pos = {4.89,0,-23.38},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4183"] = {
    tid = 60404201,
    monsterId = 0,
    coord = {17, 13},
    pos = {3.11,0,-28.01},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4184"] = {
    tid = 60404201,
    monsterId = 0,
    coord = {22, 7},
    pos = {8.05,0,-34.12},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4185"] = {
    tid = 60404201,
    monsterId = 0,
    coord = {17, 9},
    pos = {2.87,0,-31.98},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4186"] = {
    tid = 60404201,
    monsterId = 0,
    coord = {12, 20},
    pos = {-1.94,0,-20.86},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4187"] = {
    tid = 60404201,
    monsterId = 0,
    coord = {11, 23},
    pos = {-2.51,0,-18.11},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4188"] = {
    tid = 60404201,
    monsterId = 0,
    coord = {3, 43},
    pos = {-11.33,0,1.88},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4189"] = {
    tid = 60404201,
    monsterId = 0,
    coord = {7, 44},
    pos = {-7.2,0,3.05},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4190"] = {
    tid = 60404201,
    monsterId = 0,
    coord = {3, 39},
    pos = {-10.64,0,-2.14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4191"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {29, 26},
    pos = {14.57,0,-14.53},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4192"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {30, 30},
    pos = {16.49,0,-10.94},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4193"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {16, 27},
    pos = {1.98,0,-14.4},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4194"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {17, 30},
    pos = {2.94,0,-11.46},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4195"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {13, 22},
    pos = {-1,0,-19},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4196"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {33, 12},
    pos = {19.27,0,-28.76},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4197"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {21, 3},
    pos = {7.4,0,-38.13},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4198"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {17, 7},
    pos = {3.17,0,-34.28},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4199"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {51, 31},
    pos = {36.65,0,-9.64},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4200"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {59, 33},
    pos = {45.07,0,-7.55},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4201"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {61, 25},
    pos = {46.71,0,-16.22},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4202"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {51, 23},
    pos = {36.76,0,-17.92},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4203"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {45, 30},
    pos = {30.72,0,-10.81},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4204"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {47, 31},
    pos = {33.09,0,-9.97},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4205"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {34, 41},
    pos = {20.28,0,-0.44},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4206"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {33, 44},
    pos = {19.43,0,2.82},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4207"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {31, 42},
    pos = {17.34,0,0.99},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4208"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {26, 42},
    pos = {12.2,0,0.8},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4209"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {27, 31},
    pos = {12.99,0,-9.9},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4210"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {15, 32},
    pos = {0.57,0,-8.79},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4211"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {17, 44},
    pos = {2.94,0,2.69},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4212"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {9, 34},
    pos = {-5.08,0,-7.29},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4213"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {7, 34},
    pos = {-7,0,-6.9},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4214"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {12, 34},
    pos = {-2.37,0,-6.9},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4215"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {3, 41},
    pos = {-11.23,0,0.01},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4216"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {0, 40},
    pos = {-13.83,0,-1.22},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4217"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {22, 51},
    pos = {8.25,0,10.44},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4218"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {26, 60},
    pos = {12.32,0,19.02},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4219"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {20, 62},
    pos = {5.77,0,20.78},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4220"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {27, 59},
    pos = {12.94,0,17.74},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4221"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {25, 57},
    pos = {10.68,0,16.44},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4222"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {30, 59},
    pos = {16.21,0,17.54},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4223"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {38, 62},
    pos = {23.78,0,20.52},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4224"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {46, 60},
    pos = {31.74,0,19.28},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4225"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {53, 57},
    pos = {38.85,0,16.35},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4226"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {51, 61},
    pos = {37.27,0,20.32},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4227"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {55, 57},
    pos = {40.83,0,16.02},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4228"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {49, 57},
    pos = {34.84,0,16.31},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4229"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {48, 54},
    pos = {34.15,0,12.79},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4230"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {48, 51},
    pos = {33.87,0,10.11},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4231"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {42, 36},
    pos = {28,0,-5},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4232"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {43, 37},
    pos = {29,0,-4},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4233"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {43, 36},
    pos = {29,0,-5},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4234"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {40, 37},
    pos = {26,0,-4},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4235"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {40, 36},
    pos = {26,0,-5},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4236"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {41, 37},
    pos = {27,0,-4},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4237"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {41, 36},
    pos = {27,0,-5},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4238"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {40, 39},
    pos = {26,0,-2},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4239"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {40, 38},
    pos = {26,0,-3},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4240"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {41, 39},
    pos = {27,0,-2},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4241"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {41, 38},
    pos = {27,0,-3},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4242"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {40, 43},
    pos = {26,0,2},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4243"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {40, 42},
    pos = {26,0,1},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4244"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {41, 43},
    pos = {27,0,2},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4245"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {41, 42},
    pos = {27,0,1},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4246"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {40, 41},
    pos = {26,0,0},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4247"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {40, 40},
    pos = {26,0,-1},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4248"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {41, 41},
    pos = {27,0,0},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4249"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {41, 40},
    pos = {27,0,-1},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4250"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {42, 43},
    pos = {28,0,2},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4251"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {42, 42},
    pos = {28,0,1},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4252"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {43, 43},
    pos = {29,0,2},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4253"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {43, 42},
    pos = {29,0,1},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4254"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {42, 39},
    pos = {28,0,-2},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4255"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {42, 38},
    pos = {28,0,-3},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4256"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {43, 39},
    pos = {29,0,-2},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4257"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {43, 38},
    pos = {29,0,-3},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4258"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {42, 41},
    pos = {28,0,0},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4259"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {42, 40},
    pos = {28,0,-1},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4260"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {43, 41},
    pos = {29,0,0},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4261"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {43, 40},
    pos = {29,0,-1},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4262"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {36, 43},
    pos = {22,0,2},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4263"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {36, 42},
    pos = {22,0,1},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4264"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {37, 43},
    pos = {23,0,2},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4265"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {37, 42},
    pos = {23,0,1},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4266"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {38, 43},
    pos = {24,0,2},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4267"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {38, 42},
    pos = {24,0,1},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4268"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {39, 43},
    pos = {25,0,2},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4269"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {39, 42},
    pos = {25,0,1},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4270"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {38, 41},
    pos = {24,0,0},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4271"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {38, 40},
    pos = {24,0,-1},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4272"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {39, 41},
    pos = {25,0,0},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4273"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {39, 40},
    pos = {25,0,-1},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4274"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {36, 41},
    pos = {22,0,0},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4275"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {36, 40},
    pos = {22,0,-1},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4276"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {37, 41},
    pos = {23,0,0},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4277"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {37, 40},
    pos = {23,0,-1},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4278"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {39, 60},
    pos = {25,0,19},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4279"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {39, 59},
    pos = {25,0,18},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4280"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {40, 60},
    pos = {26,0,19},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4281"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {40, 59},
    pos = {26,0,18},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4282"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {20, 55},
    pos = {6,0,14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4283"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {20, 54},
    pos = {6,0,13},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4284"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {21, 55},
    pos = {7,0,14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4285"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {21, 54},
    pos = {7,0,13},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4286"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {22, 55},
    pos = {8,0,14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4287"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {22, 54},
    pos = {8,0,13},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4288"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {23, 55},
    pos = {9,0,14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4289"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {23, 54},
    pos = {9,0,13},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4290"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {22, 57},
    pos = {8,0,16},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4291"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {22, 56},
    pos = {8,0,15},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4292"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {23, 57},
    pos = {9,0,16},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4293"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {23, 56},
    pos = {9,0,15},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4294"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {20, 57},
    pos = {6,0,16},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4295"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {20, 56},
    pos = {6,0,15},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4296"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {21, 57},
    pos = {7,0,16},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4297"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {21, 56},
    pos = {7,0,15},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4298"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {20, 61},
    pos = {6,0,20},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4299"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {20, 60},
    pos = {6,0,19},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4300"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {21, 61},
    pos = {7,0,20},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4301"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {21, 60},
    pos = {7,0,19},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4302"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {22, 61},
    pos = {8,0,20},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4303"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {22, 60},
    pos = {8,0,19},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4304"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {23, 61},
    pos = {9,0,20},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4305"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {23, 60},
    pos = {9,0,19},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4306"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {22, 59},
    pos = {8,0,18},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4307"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {22, 59},
    pos = {8,0,18},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4308"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {23, 59},
    pos = {9,0,18},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4309"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {23, 59},
    pos = {9,0,18},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4310"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {20, 59},
    pos = {6,0,18},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4311"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {20, 59},
    pos = {6,0,18},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4312"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {21, 59},
    pos = {7,0,18},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4313"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {21, 59},
    pos = {7,0,18},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4314"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {34, 60},
    pos = {20,0,19},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4315"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {34, 59},
    pos = {20,0,18},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4316"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {35, 60},
    pos = {21,0,19},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4317"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {35, 59},
    pos = {21,0,18},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4318"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {34, 62},
    pos = {20,0,21},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4319"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {34, 61},
    pos = {20,0,20},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4320"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {35, 62},
    pos = {21,0,21},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4321"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {35, 61},
    pos = {21,0,20},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4322"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {32, 62},
    pos = {18,0,21},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4323"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {32, 61},
    pos = {18,0,20},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4324"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {33, 62},
    pos = {19,0,21},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4325"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {33, 61},
    pos = {19,0,20},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4326"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {32, 60},
    pos = {18,0,19},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4327"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {32, 59},
    pos = {18,0,18},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4328"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {33, 60},
    pos = {19,0,19},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4329"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {33, 59},
    pos = {19,0,18},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4330"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {11, 43},
    pos = {-3,0,2},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4331"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {11, 42},
    pos = {-3,0,1},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4332"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {12, 43},
    pos = {-2,0,2},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4333"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {12, 42},
    pos = {-2,0,1},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4334"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {39, 62},
    pos = {25,0,21},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4335"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {39, 61},
    pos = {25,0,20},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4336"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {40, 62},
    pos = {26,0,21},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4337"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {40, 61},
    pos = {26,0,20},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4338"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {41, 62},
    pos = {27,0,21},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4339"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {41, 61},
    pos = {27,0,20},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4340"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {42, 62},
    pos = {28,0,21},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4341"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {42, 61},
    pos = {28,0,20},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4342"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {41, 60},
    pos = {27,0,19},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4343"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {41, 59},
    pos = {27,0,18},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4344"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {42, 60},
    pos = {28,0,19},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4345"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {42, 59},
    pos = {28,0,18},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4346"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {5, 43},
    pos = {-9,0,2},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4347"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {5, 42},
    pos = {-9,0,1},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4348"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {6, 43},
    pos = {-8,0,2},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4349"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {6, 42},
    pos = {-8,0,1},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4350"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {9, 43},
    pos = {-5,0,2},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4351"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {9, 42},
    pos = {-5,0,1},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4352"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {10, 43},
    pos = {-4,0,2},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4353"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {10, 42},
    pos = {-4,0,1},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4354"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {7, 43},
    pos = {-7,0,2},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4355"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {7, 42},
    pos = {-7,0,1},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4356"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {8, 43},
    pos = {-6,0,2},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4357"] = {
    tid = 60404401,
    monsterId = 0,
    coord = {8, 42},
    pos = {-6,0,1},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4358"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {37, 39},
    pos = {22.87,0,-1.95},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4359"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {39, 39},
    pos = {24.96,0,-2.02},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4360"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {39, 37},
    pos = {25.11,0,-3.61},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4361"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {43, 35},
    pos = {28.7,0,-6.23},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4362"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {55, 23},
    pos = {41.05,0,-18},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4363"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {57, 26},
    pos = {43.25,0,-15.18},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4364"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {55, 34},
    pos = {41.34,0,-7.1},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4365"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {58, 32},
    pos = {44.13,0,-9},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4366"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {60, 30},
    pos = {45.88,0,-11.28},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4367"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {60, 26},
    pos = {45.94,0,-15.02},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4368"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {59, 23},
    pos = {45.28,0,-17.93},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4369"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {52, 33},
    pos = {38.24,0,-8.37},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4370"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {50, 25},
    pos = {36.13,0,-16.38},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4371"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {52, 23},
    pos = {38.41,0,-17.68},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4372"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {46, 31},
    pos = {31.88,0,-10.3},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4373"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {37, 26},
    pos = {22.51,0,-14.52},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4374"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {42, 26},
    pos = {28.47,0,-15.23},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4375"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {6, 44},
    pos = {-7.93,0,3.11},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4376"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {33, 41},
    pos = {18.63,0,0.31},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4377"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {35, 42},
    pos = {20.7,0,1.21},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4378"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {31, 43},
    pos = {16.77,0,1.59},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4379"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {27, 43},
    pos = {13.09,0,1.66},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4380"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {26, 40},
    pos = {12.07,0,-1.17},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4381"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {29, 30},
    pos = {15.37,0,-10.65},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4382"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {34, 26},
    pos = {19.77,0,-15.22},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4383"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {30, 26},
    pos = {16,0,-14.84},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4384"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {27, 26},
    pos = {12.97,0,-15.04},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4385"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {26, 26},
    pos = {12.07,0,-14.72},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4386"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {28, 28},
    pos = {13.51,0,-12.76},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4387"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {26, 32},
    pos = {12.16,0,-8.96},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4388"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {34, 21},
    pos = {20.08,0,-20.08},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4389"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {32, 21},
    pos = {17.88,0,-19.91},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4390"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {32, 24},
    pos = {17.95,0,-17.11},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4391"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {31, 13},
    pos = {17.13,0,-28.02},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4392"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {30, 12},
    pos = {15.53,0,-29.01},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4393"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {28, 14},
    pos = {13.66,0,-26.81},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4394"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {26, 12},
    pos = {12.13,0,-28.88},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4395"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {23, 13},
    pos = {9.11,0,-28.01},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4396"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {16, 20},
    pos = {2.03,0,-21.15},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4397"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {14, 24},
    pos = {-0.09,0,-17.29},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4398"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {13, 26},
    pos = {-1.1,0,-14.53},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4399"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {14, 27},
    pos = {0.44,0,-14.16},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4400"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {12, 32},
    pos = {-2.38,0,-8.65},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4401"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {10, 35},
    pos = {-3.81,0,-6.19},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4402"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {8, 36},
    pos = {-5.61,0,-5.03},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4403"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {4, 41},
    pos = {-9.97,0,-0.06},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4404"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {1, 41},
    pos = {-12.67,0,0.24},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4405"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {2, 44},
    pos = {-12.08,0,2.8},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4406"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {1, 43},
    pos = {-13.32,0,1.99},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4407"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {4, 43},
    pos = {-9.9,0,1.51},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4408"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {11, 20},
    pos = {-3.11,0,-20.9},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4409"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {9, 44},
    pos = {-4.61,0,2.81},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4410"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {8, 41},
    pos = {-5.76,0,-0.01},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4411"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {9, 32},
    pos = {-5.1,0,-8.92},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4412"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {13, 29},
    pos = {-1.14,0,-12.01},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4413"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {17, 28},
    pos = {3.22,0,-12.82},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4414"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {15, 21},
    pos = {1.01,0,-19.75},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4415"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {29, 59},
    pos = {14.88,0,17.82},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4416"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {24, 26},
    pos = {10.04,0,-14.98},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4417"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {24, 33},
    pos = {9.89,0,-8.19},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4418"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {24, 44},
    pos = {9.74,0,2.59},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4419"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {20, 43},
    pos = {6.37,0,2.07},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4420"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {16, 43},
    pos = {2.17,0,1.68},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4421"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {14, 43},
    pos = {-0.19,0,1.94},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4422"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {14, 38},
    pos = {0.34,0,-3.47},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4423"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {26, 50},
    pos = {12.131,0,9.431},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4424"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {19, 51},
    pos = {5.17,0,9.9},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4425"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {19, 61},
    pos = {5.13,0,19.68},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4426"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {21, 62},
    pos = {7.38,0,20.94},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4427"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {50, 53},
    pos = {35.84,0,11.74},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4428"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {31, 60},
    pos = {16.81,0,18.51},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4429"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {31, 62},
    pos = {17,0,20.64},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4430"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {29, 62},
    pos = {14.72,0,20.64},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4431"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {27, 60},
    pos = {13.38,0,18.77},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4432"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {25, 60},
    pos = {10.95,0,18.84},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4433"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {24, 61},
    pos = {10.05,0,19.88},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4434"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {38, 60},
    pos = {24.11,0,18.91},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4435"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {43, 62},
    pos = {29.1,0,20.86},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4436"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {45, 59},
    pos = {31.13,0,18.19},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4437"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {47, 62},
    pos = {32.59,0,20.78},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4438"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {47, 60},
    pos = {33.43,0,19.16},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4439"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {49, 62},
    pos = {35.08,0,20.68},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4440"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {50, 60},
    pos = {35.74,0,19.31},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4441"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {54, 62},
    pos = {40.29,0,20.57},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4442"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {56, 60},
    pos = {42.1,0,19.13},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4443"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {54, 59},
    pos = {39.92,0,17.87},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4444"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {51, 57},
    pos = {37.21,0,16.07},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4445"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {52, 60},
    pos = {38.2,0,19.02},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4446"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {48, 56},
    pos = {33.75,0,14.62},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4447"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {46, 53},
    pos = {31.61,0,12.21},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4448"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {47, 53},
    pos = {32.62,0,11.7},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4449"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {31, 51},
    pos = {17.46,0,9.87},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4450"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {38, 51},
    pos = {24.22,0,10.34},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4451"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {32, 29},
    pos = {17.58,0,-12.25},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4452"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {29, 29},
    pos = {14.86,0,-12.25},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4453"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {32, 27},
    pos = {18.49,0,-14.27},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4454"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {36, 38},
    pos = {22.07,0,-2.94},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4455"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {38, 36},
    pos = {24.48,0,-4.93},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4456"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {33, 40},
    pos = {19.15,0,-0.57},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4457"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {34, 39},
    pos = {19.88,0,-2.1},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4458"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {26, 39},
    pos = {12.3,0,-2.37},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4459"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {27, 41},
    pos = {13.12,0,-0.44},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4460"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {26, 34},
    pos = {12.01,0,-6.69},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4461"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {28, 32},
    pos = {14.28,0,-8.76},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4462"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {24, 28},
    pos = {9.85,0,-12.57},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4463"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {24, 31},
    pos = {9.99,0,-9.93},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4464"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {18, 26},
    pos = {3.99,0,-14.88},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4465"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {19, 28},
    pos = {4.88,0,-12.51},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4466"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {16, 28},
    pos = {1.51,0,-12.51},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4467"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {16, 33},
    pos = {2.05,0,-8.3},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4468"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {14, 26},
    pos = {0.12,0,-15.13},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4469"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {13, 27},
    pos = {-0.85,0,-13.77},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4470"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {15, 42},
    pos = {0.73,0,1.19},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4471"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {19, 44},
    pos = {5.16,0,2.74},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4472"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {17, 43},
    pos = {3.3,0,1.69},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4473"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {6, 39},
    pos = {-8.05,0,-1.99},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4474"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {10, 36},
    pos = {-4.47,0,-4.9},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4475"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {22, 9},
    pos = {7.92,0,-31.67},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4476"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {8, 37},
    pos = {-6.29,0,-3.62},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4477"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {15, 22},
    pos = {0.73,0,-19.05},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4478"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {13, 24},
    pos = {-0.96,0,-16.92},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4479"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {11, 23},
    pos = {-3.24,0,-18.24},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4480"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {16, 21},
    pos = {2.49,0,-20.1},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4481"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {17, 15},
    pos = {3.08,0,-26.18},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4482"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {18, 13},
    pos = {4.41,0,-28.14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4483"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {22, 13},
    pos = {7.88,0,-28.1},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4484"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {47, 57},
    pos = {33,0,16.38},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4485"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {17, 5},
    pos = {3.01,0,-36.29},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4486"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {18, 9},
    pos = {4.04,0,-32.25},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4487"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {22, 1},
    pos = {7.92,0,-39.67},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4488"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {33, 18},
    pos = {18.83,0,-22.87},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4489"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {33, 14},
    pos = {18.89,0,-27.08},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4490"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {32, 12},
    pos = {17.72,0,-29.02},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4491"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {31, 22},
    pos = {17.48,0,-19.01},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4492"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {30, 13},
    pos = {15.69,0,-27.95},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4493"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {47, 30},
    pos = {32.54,0,-11.24},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4494"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {44, 26},
    pos = {30.12,0,-14.83},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4495"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {50, 26},
    pos = {35.77,0,-15.03},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4496"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {52, 31},
    pos = {38.01,0,-9.99},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4497"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {50, 30},
    pos = {35.97,0,-10.99},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4498"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {52, 24},
    pos = {38.07,0,-16.69},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4499"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {54, 23},
    pos = {40.16,0,-18.11},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4500"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {61, 23},
    pos = {46.94,0,-18.04},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4501"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {59, 24},
    pos = {45.2,0,-16.72},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4502"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {58, 23},
    pos = {43.62,0,-18.14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4503"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {59, 28},
    pos = {45.29,0,-13.1},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4504"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {61, 33},
    pos = {46.61,0,-8.26},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4505"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {57, 33},
    pos = {42.6,0,-8.16},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4506"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {24, 51},
    pos = {10.03,0,10.14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4507"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {19, 53},
    pos = {4.9,0,12.05},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4508"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {19, 58},
    pos = {4.93,0,16.9},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4509"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {24, 62},
    pos = {9.55,0,20.85},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4510"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {29, 58},
    pos = {15.33,0,17.45},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4511"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {26, 58},
    pos = {12.16,0,16.84},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4512"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {26, 59},
    pos = {12.25,0,18},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4513"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {24, 59},
    pos = {9.67,0,17.77},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4514"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {30, 57},
    pos = {16.11,0,15.64},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4515"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {28, 61},
    pos = {13.59,0,19.62},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4516"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {36, 59},
    pos = {21.81,0,18.46},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4517"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {38, 58},
    pos = {24.11,0,16.94},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4518"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {43, 60},
    pos = {28.85,0,18.81},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4519"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {39, 52},
    pos = {25.03,0,11.21},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4520"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {49, 60},
    pos = {34.74,0,19.3},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4521"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {53, 61},
    pos = {38.8,0,19.62},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4522"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {52, 58},
    pos = {37.93,0,17.03},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4523"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {46, 54},
    pos = {32.42,0,12.66},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4524"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {22, 11},
    pos = {8.15,0,-29.944},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4525"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {21, 11},
    pos = {7.294,0,-29.894},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4526"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {22, 10},
    pos = {8.278,0,-30.794},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4527"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {21, 10},
    pos = {7.166,0,-31.238},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4528"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {21, 11},
    pos = {6.55,0,-30.23},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4529"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {21, 10},
    pos = {6.567,0,-31.396},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4530"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {22, 9},
    pos = {7.936,0,-32.325},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4531"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {21, 9},
    pos = {6.978,0,-32.404},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4532"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {18, 11},
    pos = {4.274,0,-29.973},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4533"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {19, 11},
    pos = {5.15,0,-30.25},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4534"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {18, 10},
    pos = {4.471,0,-31.357},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4535"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {19, 11},
    pos = {4.608,0,-30.329},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4536"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {19, 10},
    pos = {5.104,0,-31.436},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4537"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {19, 9},
    pos = {4.95,0,-31.999},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4538"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {18, 8},
    pos = {4.069,0,-33.036},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4539"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {17, 8},
    pos = {2.717,0,-32.681},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4540"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {19, 8},
    pos = {4.924,0,-32.878},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4541"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {19, 7},
    pos = {4.805,0,-33.935},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4542"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {18, 6},
    pos = {4.223,0,-34.854},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4543"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {17, 6},
    pos = {2.854,0,-35.161},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4544"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {17, 4},
    pos = {2.93,0,-37.23},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4735"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {26, 23},
    pos = {12.08,0,-18.35},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4736"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {22, 23},
    pos = {8.2,0,-18.35},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4737"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {23, 23},
    pos = {9.17,0,-18.35},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4738"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {24, 23},
    pos = {10.06,0,-18.35},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4739"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {25, 23},
    pos = {11.03,0,-18.35},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4740"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {31, 23},
    pos = {16.52,0,-18.35},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4741"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {27, 23},
    pos = {12.95,0,-18.35},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4742"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {28, 23},
    pos = {13.83,0,-18.35},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4743"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {29, 23},
    pos = {14.69,0,-18.35},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4744"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {30, 23},
    pos = {15.59,0,-18.35},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4745"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {21, 22},
    pos = {7.37,0,-19.14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4746"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {26, 22},
    pos = {12.08,0,-19.14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4747"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {22, 22},
    pos = {8.2,0,-19.14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4748"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {23, 22},
    pos = {9.17,0,-19.14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4749"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {24, 22},
    pos = {10.06,0,-19.14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4750"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {25, 22},
    pos = {11.03,0,-19.14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4751"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {31, 22},
    pos = {16.52,0,-19.14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4752"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {27, 22},
    pos = {12.95,0,-19.14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4753"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {28, 22},
    pos = {13.83,0,-19.14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4754"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {29, 22},
    pos = {14.69,0,-19.14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4755"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {30, 22},
    pos = {15.59,0,-19.14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4756"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {21, 21},
    pos = {7.37,0,-19.99},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4757"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {26, 21},
    pos = {12.08,0,-19.99},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4758"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {22, 21},
    pos = {8.2,0,-19.99},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4759"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {23, 21},
    pos = {9.17,0,-19.99},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4760"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {24, 21},
    pos = {10.06,0,-19.99},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4761"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {25, 21},
    pos = {11.03,0,-19.99},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4762"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {31, 21},
    pos = {16.52,0,-19.99},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4763"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {27, 21},
    pos = {12.95,0,-19.99},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4764"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {28, 21},
    pos = {13.83,0,-19.99},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4765"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {29, 21},
    pos = {14.69,0,-19.99},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4766"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {30, 21},
    pos = {15.59,0,-19.99},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4767"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {24, 20},
    pos = {10.06,0,-20.73},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4768"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {24, 19},
    pos = {10.06,0,-21.52},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4769"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {24, 19},
    pos = {10.06,0,-22.37},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4770"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {24, 18},
    pos = {10.06,0,-23.16},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4773"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {31, 18},
    pos = {16.52,0,-23.17},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4774"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {31, 16},
    pos = {16.52,0,-24.96},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4775"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {31, 15},
    pos = {16.52,0,-25.81},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4776"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {31, 20},
    pos = {16.52,0,-20.85},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4777"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {31, 19},
    pos = {16.52,0,-21.64},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4778"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {31, 19},
    pos = {16.52,0,-22.49},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4779"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {32, 18},
    pos = {18.16,0,-23.17},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4780"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {32, 16},
    pos = {18.16,0,-24.96},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4781"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {32, 15},
    pos = {18.16,0,-25.81},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4782"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {31, 18},
    pos = {17.39,0,-23.17},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4783"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {31, 16},
    pos = {17.39,0,-24.96},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4784"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {31, 15},
    pos = {17.39,0,-25.81},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4785"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {32, 14},
    pos = {18.16,0,-26.59},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4786"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {32, 14},
    pos = {18.16,0,-27.38},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4787"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {32, 13},
    pos = {18.16,0,-28.23},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4788"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {36, 37},
    pos = {21.836,0,-3.64},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4789"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {14, 23},
    pos = {0.07,0,-18.15},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4790"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {14, 24},
    pos = {0.18,0,-16.75},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4791"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {15, 24},
    pos = {1.4,0,-17.06},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4792"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {16, 21},
    pos = {1.82,0,-19.58},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4793"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {15, 20},
    pos = {1.15,0,-21.22},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4794"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {15, 23},
    pos = {1.17,0,-18.48},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4795"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {12, 22},
    pos = {-2.29,0,-18.67},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4796"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {12, 20},
    pos = {-2.34,0,-21.14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4797"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {17, 19},
    pos = {3.06,0,-21.85},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4798"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {17, 16},
    pos = {3.11,0,-25.01},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4799"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {17, 18},
    pos = {3.08,0,-23.37},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4800"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {16, 22},
    pos = {2.3,0,-19},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4801"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {16, 24},
    pos = {2.14,0,-17.27},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4802"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {17, 26},
    pos = {2.61,0,-15.28},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4803"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {17, 27},
    pos = {3.31,0,-13.86},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4804"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {16, 29},
    pos = {2.14,0,-12.49},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4805"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {15, 27},
    pos = {0.99,0,-13.82},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4806"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {14, 27},
    pos = {-0.02,0,-13.67},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4807"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {13, 30},
    pos = {-1.33,0,-11.26},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4808"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {15, 31},
    pos = {0.63,0,-9.81},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4809"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {17, 31},
    pos = {3.17,0,-9.66},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4810"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {18, 29},
    pos = {4.21,0,-12.18},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4811"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {19, 27},
    pos = {4.79,0,-14.09},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4812"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {14, 34},
    pos = {0.27,0,-6.96},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4813"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {16, 34},
    pos = {2.09,0,-7.32},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4814"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {14, 42},
    pos = {-0.22,0,0.97},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4815"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {14, 37},
    pos = {0.05,0,-4.39},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4816"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {12, 37},
    pos = {-2.18,0,-3.85},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4817"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {11, 36},
    pos = {-3.21,0,-5.32},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4818"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {8, 33},
    pos = {-6.1,0,-7.68},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4819"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {9, 33},
    pos = {-4.73,0,-8.36},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4820"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {9, 35},
    pos = {-4.8,0,-5.63},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4821"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {10, 36},
    pos = {-3.77,0,-5.27},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4822"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {11, 41},
    pos = {-2.98,0,-0.14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4823"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {10, 44},
    pos = {-3.79,0,3.12},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4824"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {9, 44},
    pos = {-5.47,0,3.12},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4825"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {5, 40},
    pos = {-8.82,0,-1.33},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4826"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {6, 41},
    pos = {-7.94,0,-0.14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4827"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {4, 42},
    pos = {-9.83,0,0.82},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4828"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {2, 42},
    pos = {-12.08,0,0.5},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4829"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {2, 40},
    pos = {-12.15,0,-0.56},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4830"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {7, 37},
    pos = {-7.18,0,-3.82},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4831"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {11, 37},
    pos = {-2.83,0,-4.19},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4832"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {15, 42},
    pos = {1.25,0,1.01},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4833"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {38, 37},
    pos = {23.65,0,-3.64},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4834"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {37, 37},
    pos = {22.506,0,-3.64},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4835"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {37, 37},
    pos = {23.047,0,-3.64},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4837"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {38, 36},
    pos = {23.65,0,-5.032},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4839"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {37, 36},
    pos = {23.047,0,-5.032},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4840"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {36, 37},
    pos = {21.836,0,-4.304},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4841"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {38, 37},
    pos = {23.65,0,-4.304},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4842"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {37, 37},
    pos = {22.506,0,-4.304},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4843"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {37, 37},
    pos = {23.047,0,-4.304},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4844"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {38, 35},
    pos = {23.65,0,-6.318},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4845"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {37, 35},
    pos = {23.047,0,-6.318},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4846"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {38, 35},
    pos = {23.65,0,-5.59},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4847"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {37, 35},
    pos = {23.047,0,-5.59},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4848"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {35, 37},
    pos = {21.223,0,-4.35},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4849"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {35, 37},
    pos = {20.62,0,-4.35},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4850"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {35, 37},
    pos = {21.223,0,-3.622},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4851"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {35, 37},
    pos = {20.62,0,-3.622},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4852"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {42, 26},
    pos = {27.873,0,-15.188},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4853"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {41, 26},
    pos = {27.27,0,-15.188},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4854"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {42, 27},
    pos = {27.873,0,-14.46},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4855"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {41, 27},
    pos = {27.27,0,-14.46},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4856"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {48, 29},
    pos = {33.813,0,-11.538},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4857"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {47, 29},
    pos = {33.21,0,-11.538},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4858"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {48, 30},
    pos = {33.813,0,-10.81},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4859"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {47, 30},
    pos = {33.21,0,-10.81},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4860"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {52, 30},
    pos = {37.613,0,-11.018},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4861"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {51, 30},
    pos = {37.01,0,-11.018},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4862"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {52, 31},
    pos = {37.613,0,-10.29},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4863"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {51, 31},
    pos = {37.01,0,-10.29},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4864"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {52, 33},
    pos = {38.143,0,-8.268},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4865"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {52, 33},
    pos = {37.54,0,-8.268},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4866"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {52, 33},
    pos = {38.143,0,-7.54},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4867"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {52, 33},
    pos = {37.54,0,-7.54},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4868"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {56, 32},
    pos = {41.513,0,-9.218},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4869"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {55, 32},
    pos = {40.91,0,-9.218},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4870"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {56, 33},
    pos = {41.513,0,-8.49},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4871"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {55, 33},
    pos = {40.91,0,-8.49},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4872"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {59, 32},
    pos = {44.903,0,-9.088},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4873"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {58, 32},
    pos = {44.3,0,-9.088},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4874"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {59, 33},
    pos = {44.903,0,-8.36},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4875"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {58, 33},
    pos = {44.3,0,-8.36},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4876"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {59, 26},
    pos = {45.103,0,-14.768},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4877"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {58, 26},
    pos = {44.5,0,-14.768},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4878"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {59, 27},
    pos = {45.103,0,-14.04},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4879"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {58, 27},
    pos = {44.5,0,-14.04},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4880"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {61, 23},
    pos = {46.673,0,-18.068},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4881"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {60, 23},
    pos = {46.07,0,-18.068},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4882"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {61, 24},
    pos = {46.673,0,-17.34},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4883"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {60, 24},
    pos = {46.07,0,-17.34},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4884"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {56, 23},
    pos = {42.123,0,-17.728},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4885"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {56, 23},
    pos = {41.52,0,-17.728},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4886"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {56, 24},
    pos = {42.123,0,-17},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4887"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {56, 24},
    pos = {41.52,0,-17},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4888"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {58, 27},
    pos = {43.843,0,-14.228},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4889"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {57, 27},
    pos = {43.24,0,-14.228},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4890"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {58, 28},
    pos = {43.843,0,-13.5},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4891"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {57, 28},
    pos = {43.24,0,-13.5},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4892"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {59, 28},
    pos = {44.903,0,-12.688},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4893"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {58, 28},
    pos = {44.3,0,-12.688},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4894"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {59, 29},
    pos = {44.903,0,-11.96},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4895"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {58, 29},
    pos = {44.3,0,-11.96},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4896"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {54, 24},
    pos = {39.703,0,-17.088},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4897"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {53, 24},
    pos = {39.1,0,-17.088},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4898"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {54, 25},
    pos = {39.703,0,-16.36},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4899"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {53, 25},
    pos = {39.1,0,-16.36},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4900"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {49, 29},
    pos = {35.163,0,-12.458},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4901"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {49, 29},
    pos = {34.56,0,-12.458},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4902"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {49, 29},
    pos = {35.163,0,-11.73},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4903"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {49, 29},
    pos = {34.56,0,-11.73},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4904"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {46, 26},
    pos = {32.483,0,-15.218},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4905"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {46, 26},
    pos = {31.88,0,-15.218},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4906"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {46, 27},
    pos = {32.483,0,-14.49},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4907"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {46, 27},
    pos = {31.88,0,-14.49},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4908"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {48, 26},
    pos = {33.813,0,-15.118},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4909"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {47, 26},
    pos = {33.21,0,-15.118},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4910"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {48, 27},
    pos = {33.813,0,-14.39},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4911"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {47, 27},
    pos = {33.21,0,-14.39},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4912"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {49, 26},
    pos = {35.223,0,-15.288},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4913"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {49, 26},
    pos = {34.62,0,-15.288},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4914"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {49, 26},
    pos = {35.223,0,-14.56},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4915"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {49, 26},
    pos = {34.62,0,-14.56},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4916"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {38, 26},
    pos = {23.893,0,-15.188},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4917"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {37, 26},
    pos = {23.29,0,-15.188},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4918"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {38, 27},
    pos = {23.893,0,-14.46},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4919"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {37, 27},
    pos = {23.29,0,-14.46},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4920"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {41, 26},
    pos = {26.613,0,-15.188},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4921"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {40, 26},
    pos = {26.01,0,-15.188},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4922"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {41, 27},
    pos = {26.613,0,-14.46},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4923"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {40, 27},
    pos = {26.01,0,-14.46},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4924"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {39, 26},
    pos = {25.253,0,-15.188},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4925"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {39, 26},
    pos = {24.65,0,-15.188},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4926"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {39, 27},
    pos = {25.253,0,-14.46},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4927"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {39, 27},
    pos = {24.65,0,-14.46},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4928"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {32, 19},
    pos = {17.8,0,-22.33},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4929"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {33, 21},
    pos = {18.52,0,-20.16},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4930"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {34, 22},
    pos = {20.19,0,-18.51},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4931"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {32, 23},
    pos = {17.56,0,-18.04},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4932"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {33, 17},
    pos = {19.08,0,-23.85},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4933"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {30, 14},
    pos = {16.37,0,-26.8},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4934"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {31, 14},
    pos = {17.21,0,-27.16},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4935"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {30, 12},
    pos = {16.18,0,-29},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4936"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {32, 12},
    pos = {18.47,0,-29.31},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4937"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {30, 13},
    pos = {16.35,0,-28.07},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4938"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {27, 12},
    pos = {13.2,0,-29.17},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4939"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {24, 12},
    pos = {10.13,0,-29.14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4940"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {25, 13},
    pos = {11.32,0,-28.18},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4941"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {26, 14},
    pos = {11.87,0,-26.72},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4942"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {22, 14},
    pos = {8.39,0,-27.06},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4943"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {23, 14},
    pos = {9.01,0,-27.24},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4944"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {23, 20},
    pos = {8.98,0,-20.81},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4945"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {25, 20},
    pos = {10.79,0,-20.76},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4946"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {25, 19},
    pos = {10.7,0,-22.35},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4947"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {30, 20},
    pos = {15.69,0,-20.87},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4948"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {31, 20},
    pos = {17.21,0,-21.01},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4949"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {31, 19},
    pos = {17.12,0,-22.22},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4950"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {30, 18},
    pos = {15.73,0,-23.32},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4951"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {24, 16},
    pos = {9.99,0,-25.15},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4952"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {23, 18},
    pos = {9.23,0,-23.46},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4953"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {42, 28},
    pos = {27.63,0,-13.41},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4954"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {16, 23},
    pos = {1.91,0,-17.95},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4955"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {15, 24},
    pos = {0.6,0,-17.4},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4956"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {18, 20},
    pos = {3.55,0,-20.87},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4957"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {17, 21},
    pos = {3.22,0,-20.24},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4958"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {16, 21},
    pos = {1.62,0,-20.21},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4959"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {17, 26},
    pos = {3.32,0,-15.11},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4960"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {19, 26},
    pos = {5.08,0,-15.12},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4961"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {20, 27},
    pos = {5.62,0,-14.41},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4962"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {19, 29},
    pos = {5.1,0,-11.93},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4963"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {17, 28},
    pos = {2.81,0,-13.06},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4964"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {18, 31},
    pos = {4,0,-10.14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4965"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {18, 30},
    pos = {4.15,0,-11.19},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4966"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {16, 29},
    pos = {1.88,0,-11.68},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4967"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {15, 29},
    pos = {1.07,0,-11.87},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4968"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {15, 34},
    pos = {1.48,0,-7.39},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4969"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {24, 30},
    pos = {10.27,0,-11.13},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4970"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {23, 27},
    pos = {9.25,0,-13.53},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4971"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {21, 26},
    pos = {6.94,0,-15.09},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4972"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {23, 26},
    pos = {8.77,0,-15.2},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4973"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {26, 28},
    pos = {11.85,0,-12.64},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4974"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {28, 28},
    pos = {14.35,0,-13.16},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4975"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {30, 27},
    pos = {16.26,0,-14.32},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4976"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {31, 27},
    pos = {17.43,0,-13.63},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4977"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {32, 26},
    pos = {17.62,0,-14.51},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4978"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {33, 28},
    pos = {19.34,0,-12.86},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4979"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {34, 27},
    pos = {19.65,0,-13.96},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4980"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {38, 28},
    pos = {24.143,0,-13.38},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4981"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {40, 28},
    pos = {25.51,0,-13.41},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4982"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {41, 28},
    pos = {27.01,0,-13.41},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4983"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {40, 28},
    pos = {26.32,0,-13.41},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4984"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {39, 28},
    pos = {24.894,0,-13.41},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4985"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {42, 28},
    pos = {27.63,0,-12.809},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4986"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {38, 28},
    pos = {24.143,0,-12.779},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4987"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {40, 28},
    pos = {25.51,0,-12.809},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4988"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {41, 28},
    pos = {27.01,0,-12.809},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4989"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {40, 28},
    pos = {26.32,0,-12.809},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4990"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {39, 28},
    pos = {24.894,0,-12.809},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4991"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {36, 36},
    pos = {22.3,0,-5.08},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4994"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {36, 36},
    pos = {21.68,0,-5.08},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4995"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {35, 36},
    pos = {20.99,0,-5.08},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4997"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {36, 35},
    pos = {22.3,0,-6.338},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4998"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {36, 35},
    pos = {21.68,0,-6.338},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4999"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {35, 35},
    pos = {20.99,0,-6.338},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5000"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {36, 35},
    pos = {22.3,0,-5.683},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5001"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {36, 35},
    pos = {21.68,0,-5.683},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5002"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {35, 35},
    pos = {20.99,0,-5.683},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5003"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {16, 37},
    pos = {2.17,0,-4.15},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5004"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {15, 37},
    pos = {1.12,0,-4.15},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5005"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {17, 37},
    pos = {3.04,0,-4.15},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5006"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {18, 37},
    pos = {3.92,0,-4.15},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5007"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {19, 37},
    pos = {4.78,0,-4.15},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5008"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {16, 36},
    pos = {2.17,0,-4.94},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5009"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {15, 36},
    pos = {1.12,0,-4.94},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5010"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {17, 36},
    pos = {3.04,0,-4.94},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5011"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {18, 36},
    pos = {3.92,0,-4.94},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5012"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {19, 36},
    pos = {4.78,0,-4.94},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5013"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {16, 35},
    pos = {2.17,0,-5.79},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5014"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {15, 35},
    pos = {1.12,0,-5.79},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5015"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {17, 35},
    pos = {3.04,0,-5.79},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5016"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {18, 35},
    pos = {3.92,0,-5.79},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5017"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {19, 35},
    pos = {4.78,0,-5.79},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5018"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {12, 39},
    pos = {-2.08,0,-2.28},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5019"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {14, 36},
    pos = {0.09,0,-5.41},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5020"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {17, 34},
    pos = {2.89,0,-7.38},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5021"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {17, 33},
    pos = {3.07,0,-8.43},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5022"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {20, 36},
    pos = {5.88,0,-4.56},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5023"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {17, 38},
    pos = {3.33,0,-3.33},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5024"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {15, 38},
    pos = {1,0,-3.19},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5025"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {17, 42},
    pos = {2.54,0,0.72},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5026"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {19, 43},
    pos = {5.13,0,1.96},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5027"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {20, 44},
    pos = {6.33,0,2.77},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5028"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {23, 44},
    pos = {8.82,0,2.96},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5029"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {24, 42},
    pos = {10.04,0,1.07},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5030"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {24, 43},
    pos = {10.14,0,1.82},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5031"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {23, 43},
    pos = {8.8,0,1.65},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5032"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {23, 42},
    pos = {8.84,0,0.72},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5033"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {19, 42},
    pos = {4.95,0,1.21},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5034"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {14, 35},
    pos = {-0.21,0,-6.32},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5035"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {11, 38},
    pos = {-3.15,0,-3.17},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5036"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {10, 37},
    pos = {-3.84,0,-4.06},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5037"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {9, 37},
    pos = {-5.08,0,-4.13},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5038"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {7, 41},
    pos = {-6.82,0,-0.24},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5039"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {3, 40},
    pos = {-11.23,0,-0.87},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5040"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {7, 39},
    pos = {-7.16,0,-1.83},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5041"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {6, 40},
    pos = {-7.89,0,-1.27},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5042"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {5, 41},
    pos = {-8.54,0,-0.06},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5043"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {9, 44},
    pos = {-4.99,0,3.22},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5044"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {14, 44},
    pos = {-0.15,0,2.66},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5045"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {12, 35},
    pos = {-1.75,0,-5.55},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5046"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {15, 34},
    pos = {0.83,0,-6.89},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5047"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {40, 52},
    pos = {25.8,0,10.93},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5048"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {41, 52},
    pos = {26.67,0,10.93},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5049"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {42, 52},
    pos = {27.55,0,10.93},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5050"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {42, 52},
    pos = {28.41,0,10.93},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5051"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {43, 52},
    pos = {29.31,0,10.93},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5052"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {40, 51},
    pos = {25.8,0,10.14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5053"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {39, 51},
    pos = {24.75,0,10.14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5054"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {44, 51},
    pos = {30.24,0,10.14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5055"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {41, 51},
    pos = {26.67,0,10.14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5056"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {42, 51},
    pos = {27.55,0,10.14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5057"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {42, 51},
    pos = {28.41,0,10.14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5058"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {43, 51},
    pos = {29.31,0,10.14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5059"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {39, 33},
    pos = {24.56,0,-7.57},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5060"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {39, 33},
    pos = {25.43,0,-7.57},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5061"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {40, 33},
    pos = {26.31,0,-7.57},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5062"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {41, 33},
    pos = {27.17,0,-7.57},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5063"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {42, 33},
    pos = {28.07,0,-7.57},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5064"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {39, 33},
    pos = {24.56,0,-8.36},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5065"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {38, 33},
    pos = {23.51,0,-8.36},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5066"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {43, 33},
    pos = {29,0,-8.36},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5067"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {39, 33},
    pos = {25.43,0,-8.36},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5068"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {40, 33},
    pos = {26.31,0,-8.36},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5069"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {41, 33},
    pos = {27.17,0,-8.36},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5070"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {42, 33},
    pos = {28.07,0,-8.36},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5071"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {54, 29},
    pos = {40.37,0,-11.81},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5072"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {55, 29},
    pos = {41.24,0,-11.81},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5073"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {55, 29},
    pos = {41.12,0,-11.81},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5074"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {56, 29},
    pos = {41.98,0,-11.81},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5075"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {57, 29},
    pos = {42.88,0,-11.81},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5076"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {54, 28},
    pos = {40.37,0,-12.6},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5077"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {53, 28},
    pos = {39.32,0,-12.6},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5078"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {58, 28},
    pos = {43.81,0,-12.6},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5079"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {55, 28},
    pos = {41.24,0,-12.6},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5080"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {55, 28},
    pos = {41.12,0,-12.6},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5081"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {56, 28},
    pos = {41.98,0,-12.6},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5082"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {57, 28},
    pos = {42.88,0,-12.6},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5083"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {45, 52},
    pos = {30.74,0,11.06},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5084"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {33, 53},
    pos = {19.3,0,11.83},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5085"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {34, 53},
    pos = {20.27,0,11.83},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5086"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {32, 52},
    pos = {18.47,0,11.04},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5087"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {33, 52},
    pos = {19.3,0,11.04},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5088"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {34, 52},
    pos = {20.27,0,11.04},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5089"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {32, 51},
    pos = {18.47,0,10.19},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5090"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {33, 51},
    pos = {19.3,0,10.19},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5091"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {34, 51},
    pos = {20.27,0,10.19},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5092"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {35, 55},
    pos = {21.05,0,14.33},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5093"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {36, 55},
    pos = {22.02,0,14.33},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5094"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {34, 55},
    pos = {20.22,0,13.54},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5095"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {35, 55},
    pos = {21.05,0,13.54},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5096"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {36, 55},
    pos = {22.02,0,13.54},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5097"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {34, 54},
    pos = {20.22,0,12.69},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5098"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {35, 54},
    pos = {21.05,0,12.69},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5099"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {36, 54},
    pos = {22.02,0,12.69},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5100"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {35, 53},
    pos = {20.97,0,11.83},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5101"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {22, 34},
    pos = {8.16,0,-6.67},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5102"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {22, 34},
    pos = {8.16,0,-7.46},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5103"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {22, 33},
    pos = {8.16,0,-8.31},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5104"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {22, 32},
    pos = {8.16,0,-9.05},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5105"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {22, 31},
    pos = {8.16,0,-9.84},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5106"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {23, 32},
    pos = {9.06,0,-9.13},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5107"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {23, 31},
    pos = {9.06,0,-9.92},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5108"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {23, 30},
    pos = {9.06,0,-10.77},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5109"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {23, 29},
    pos = {9.06,0,-11.51},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5110"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {23, 29},
    pos = {9.06,0,-12.3},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5111"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {22, 30},
    pos = {8.16,0,-10.72},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5112"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {22, 29},
    pos = {8.16,0,-11.51},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5113"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {22, 29},
    pos = {8.16,0,-12.36},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5114"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {22, 28},
    pos = {8.16,0,-13.1},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5115"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {22, 27},
    pos = {8.16,0,-13.89},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5116"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {21, 32},
    pos = {7.32,0,-9.39},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5117"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {21, 31},
    pos = {7.32,0,-10.18},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5118"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {21, 30},
    pos = {7.32,0,-11.03},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5119"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {21, 29},
    pos = {7.32,0,-11.77},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5120"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {21, 28},
    pos = {7.32,0,-12.56},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5121"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {20, 26},
    pos = {5.57,0,-15.13},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5122"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {23, 27},
    pos = {9.01,0,-14.48},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5123"] = {
    tid = 60404502,
    monsterId = 0,
    coord = {38, 34},
    pos = {23.79,0,-7.44},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5124"] = {
    tid = 60404502,
    monsterId = 0,
    coord = {34, 32},
    pos = {20.45,0,-8.63},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5125"] = {
    tid = 60404502,
    monsterId = 0,
    coord = {28, 39},
    pos = {13.65,0,-2.14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5126"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {24, 53},
    pos = {9.7,0,11.77},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5127"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {25, 53},
    pos = {10.57,0,11.77},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5128"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {25, 53},
    pos = {11.45,0,11.77},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5129"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {26, 53},
    pos = {12.31,0,11.77},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5130"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {27, 53},
    pos = {13.21,0,11.77},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5131"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {24, 52},
    pos = {9.7,0,10.98},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5132"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {25, 52},
    pos = {10.57,0,10.98},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5133"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {25, 52},
    pos = {11.45,0,10.98},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5134"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {26, 52},
    pos = {12.31,0,10.98},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5135"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {27, 52},
    pos = {13.21,0,10.98},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5139"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {18, 41},
    pos = {4.15,0,0.33},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5140"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {18, 40},
    pos = {3.92,0,-1.09},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5141"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {19, 41},
    pos = {4.89,0,0.12},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5142"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {19, 40},
    pos = {4.66,0,-0.56},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5174"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {30, 46},
    pos = {15.66,0,5.44},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5175"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {29, 45},
    pos = {15.43,0,4.02},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5176"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {30, 46},
    pos = {16.4,0,5.23},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5177"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {30, 46},
    pos = {16.17,0,4.55},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5181"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {26, 50},
    pos = {11.652,0,8.57},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5182"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {26, 48},
    pos = {11.817,0,7.15},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5183"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {26, 49},
    pos = {12.02,0,8.36},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5184"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {26, 49},
    pos = {11.79,0,7.68},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5188"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {25, 47},
    pos = {11.36,0,6.08},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5189"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {26, 45},
    pos = {11.993,0,3.843},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5190"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {26, 47},
    pos = {12.1,0,5.87},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5191"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {26, 46},
    pos = {11.87,0,5.19},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5195"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {23, 41},
    pos = {9.45,0,-0.33},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5196"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {23, 39},
    pos = {9.22,0,-1.75},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5197"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {24, 40},
    pos = {10.19,0,-0.54},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5198"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {24, 40},
    pos = {9.96,0,-1.22},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5202"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {21, 43},
    pos = {7.39,0,1.84},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5203"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {21, 41},
    pos = {7.16,0,0.42},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5204"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {22, 43},
    pos = {8.13,0,1.63},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5205"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {22, 42},
    pos = {7.9,0,0.95},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5206"] = {
    tid = 60404203,
    monsterId = 0,
    coord = {21, 44},
    pos = {6.92,0,3.06},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5207"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {25, 50},
    pos = {11.04,0,9.08},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5208"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {25, 46},
    pos = {11.04,0,5.02},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5209"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {25, 48},
    pos = {11.04,0,7.04},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5210"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {30, 50},
    pos = {16.12,0,9.08},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5211"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {30, 46},
    pos = {16.12,0,5.02},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5212"] = {
    tid = 60404701,
    monsterId = 0,
    coord = {30, 48},
    pos = {16.12,0,7.04},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5213"] = {
    tid = 60404103,
    monsterId = 0,
    coord = {30, 49},
    pos = {15.79,0,8.378},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5217"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {29, 49},
    pos = {15.311,0,7.517},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5218"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {29, 47},
    pos = {15.476,0,6.097},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5219"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {30, 48},
    pos = {15.679,0,7.307},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5220"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {29, 48},
    pos = {15.449,0,6.627},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5223"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {32, 53},
    pos = {17.83,0,11.91},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5227"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {36, 56},
    pos = {21.7,0,14.93},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5228"] = {
    tid = 60404101,
    monsterId = 0,
    coord = {33, 54},
    pos = {18.75,0,12.97},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5229"] = {
    tid = 60404102,
    monsterId = 0,
    coord = {33, 54},
    pos = {19.49,0,13.5},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5284"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {31, 17},
    pos = {16.52,0,-24.06},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5285"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {32, 17},
    pos = {18.16,0,-24.06},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["5286"] = {
    tid = 60404104,
    monsterId = 0,
    coord = {31, 17},
    pos = {17.39,0,-24.06},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["4046"] = {
    tid = 606004,
    monsterId = 0,
    coord = {19, 0},
    pos = {5,0,-41},
    euler = {0,0,0},
    scale = {1,1,1}
  },
  ["4047"] = {
    tid = 6070401,
    monsterId = 0,
    coord = {20, 12},
    pos = {6,0,-29},
    euler = {0,0,0},
    scale = {1,1,1}
  },
  ["4052"] = {
    tid = 6070402,
    monsterId = 0,
    coord = {31, 26},
    pos = {17,0,-15},
    euler = {0,0,0},
    scale = {1,1,1}
  },
  ["4048"] = {
    tid = 6070403,
    monsterId = 0,
    coord = {44, 29},
    pos = {30,0,-12},
    euler = {0,0,0},
    scale = {1,1,1}
  },
  ["4049"] = {
    tid = 6070405,
    monsterId = 0,
    coord = {24, 36},
    pos = {9,0,-5},
    euler = {0,0,0},
    scale = {1,1,1}
  },
  ["4050"] = {
    tid = 6070404,
    monsterId = 0,
    coord = {28, 45},
    pos = {14,0,4},
    euler = {0,0,0},
    scale = {1,1,1}
  },
  ["4051"] = {
    tid = 6070407,
    monsterId = 0,
    coord = {37, 57},
    pos = {23,0,16},
    euler = {0,0,0},
    scale = {1,1,1}
  },
  ["4053"] = {
    tid = 6070406,
    monsterId = 0,
    coord = {12, 41},
    pos = {-3,0,0},
    euler = {0,0,0},
    scale = {1,1,1}
  },
  ["5231"] = {
    tid = 605,
    monsterId = 10402,
    coord = {30, 20},
    pos = {16.23,0,-21.38},
    euler = {0,224.944,0},
    scale = {1,1,1}
  },
  ["5234"] = {
    tid = 605,
    monsterId = 10401,
    coord = {28, 20},
    pos = {14.42,0,-21.46},
    euler = {0,207.574,0},
    scale = {1,1,1}
  },
  ["5235"] = {
    tid = 605,
    monsterId = 10402,
    coord = {31, 18},
    pos = {16.74,0,-22.73},
    euler = {0,224.944,0},
    scale = {1,1,1}
  },
  ["5236"] = {
    tid = 605,
    monsterId = 10401,
    coord = {16, 23},
    pos = {1.55,0,-17.61},
    euler = {0,134.776,0},
    scale = {1,1,1}
  },
  ["5237"] = {
    tid = 605,
    monsterId = 10402,
    coord = {35, 39},
    pos = {21.08,0,-2.36},
    euler = {0,212.158,0},
    scale = {1,1,1}
  },
  ["5238"] = {
    tid = 605,
    monsterId = 10401,
    coord = {14, 23},
    pos = {0.27,0,-18.2},
    euler = {0,134.776,0},
    scale = {1,1,1}
  },
  ["5239"] = {
    tid = 605,
    monsterId = 10402,
    coord = {16, 22},
    pos = {1.73,0,-19.32},
    euler = {0,134.776,0},
    scale = {1,1,1}
  },
  ["5240"] = {
    tid = 605,
    monsterId = 10401,
    coord = {27, 33},
    pos = {13.3,0,-7.85},
    euler = {0,112.634,0},
    scale = {1,1,1}
  },
  ["5241"] = {
    tid = 605,
    monsterId = 10402,
    coord = {33, 40},
    pos = {19.09,0,-1.36},
    euler = {0,212.158,0},
    scale = {1,1,1}
  },
  ["5242"] = {
    tid = 605,
    monsterId = 10401,
    coord = {33, 38},
    pos = {19.43,0,-3.12},
    euler = {0,212.158,0},
    scale = {1,1,1}
  },
  ["5243"] = {
    tid = 605,
    monsterId = 10402,
    coord = {41, 27},
    pos = {26.84,0,-14.12},
    euler = {0,275.029,0},
    scale = {1,1,1}
  },
  ["5244"] = {
    tid = 605,
    monsterId = 10401,
    coord = {39, 28},
    pos = {25.3,0,-13.06},
    euler = {0,275.029,0},
    scale = {1,1,1}
  },
  ["5245"] = {
    tid = 605,
    monsterId = 10402,
    coord = {39, 26},
    pos = {24.96,0,-14.9},
    euler = {0,275.029,0},
    scale = {1,1,1}
  },
  ["5246"] = {
    tid = 605,
    monsterId = 10401,
    coord = {16, 42},
    pos = {2.1,0,1.07},
    euler = {0,162.616,0},
    scale = {1,1,1}
  },
  ["5247"] = {
    tid = 605,
    monsterId = 10402,
    coord = {29, 31},
    pos = {14.61,0,-9.7},
    euler = {0,112.634,0},
    scale = {1,1,1}
  },
  ["5248"] = {
    tid = 605,
    monsterId = 10401,
    coord = {29, 34},
    pos = {14.59,0,-7.45},
    euler = {0,112.634,0},
    scale = {1,1,1}
  },
  ["5249"] = {
    tid = 605,
    monsterId = 10402,
    coord = {52, 25},
    pos = {37.97,0,-15.62},
    euler = {0,281.556,0},
    scale = {1,1,1}
  },
  ["5250"] = {
    tid = 605,
    monsterId = 10401,
    coord = {15, 42},
    pos = {0.81,0,0.74},
    euler = {0,162.616,0},
    scale = {1,1,1}
  },
  ["5251"] = {
    tid = 605,
    monsterId = 10402,
    coord = {17, 41},
    pos = {3.16,0,0.01},
    euler = {0,162.616,0},
    scale = {1,1,1}
  },
  ["5252"] = {
    tid = 605,
    monsterId = 10401,
    coord = {18, 27},
    pos = {4.39,0,-14.11},
    euler = {0,60.648,0},
    scale = {1,1,1}
  },
  ["5253"] = {
    tid = 605,
    monsterId = 10402,
    coord = {17, 28},
    pos = {2.89,0,-13.29},
    euler = {0,60.648,0},
    scale = {1,1,1}
  },
  ["5254"] = {
    tid = 605,
    monsterId = 10401,
    coord = {18, 28},
    pos = {3.96,0,-12.93},
    euler = {0,60.648,0},
    scale = {1,1,1}
  },
  ["5255"] = {
    tid = 605,
    monsterId = 10402,
    coord = {23, 33},
    pos = {9.49,0,-8},
    euler = {0,60.648,0},
    scale = {1,1,1}
  },
  ["5256"] = {
    tid = 605,
    monsterId = 10401,
    coord = {23, 34},
    pos = {8.71,0,-6.6},
    euler = {0,60.648,0},
    scale = {1,1,1}
  },
  ["5257"] = {
    tid = 605,
    monsterId = 10402,
    coord = {9, 35},
    pos = {-5.4,0,-5.78},
    euler = {0,60.648,0},
    scale = {1,1,1}
  },
  ["5258"] = {
    tid = 605,
    monsterId = 10401,
    coord = {10, 34},
    pos = {-3.9,0,-6.63},
    euler = {0,60.648,0},
    scale = {1,1,1}
  },
  ["5259"] = {
    tid = 605,
    monsterId = 10402,
    coord = {4, 42},
    pos = {-10.33,0,1.42},
    euler = {0,99.974,0},
    scale = {1,1,1}
  },
  ["5260"] = {
    tid = 605,
    monsterId = 10403,
    coord = {4, 41},
    pos = {-9.98,0,-0.33},
    euler = {0,99.974,0},
    scale = {1,1,1}
  },
  ["5261"] = {
    tid = 605,
    monsterId = 10404,
    coord = {5, 41},
    pos = {-8.74,0,0.19},
    euler = {0,99.974,0},
    scale = {1,1,1}
  },
  ["5262"] = {
    tid = 605,
    monsterId = 10401,
    coord = {59, 24},
    pos = {45.25,0,-16.84},
    euler = {0,304.242,0},
    scale = {1,1,1}
  },
  ["5263"] = {
    tid = 605,
    monsterId = 10402,
    coord = {61, 25},
    pos = {46.52,0,-15.8},
    euler = {0,304.242,0},
    scale = {1,1,1}
  },
  ["5264"] = {
    tid = 605,
    monsterId = 10403,
    coord = {59, 25},
    pos = {44.89,0,-15.56},
    euler = {0,304.242,0},
    scale = {1,1,1}
  },
  ["5265"] = {
    tid = 605,
    monsterId = 10402,
    coord = {58, 32},
    pos = {44.03,0,-9.15},
    euler = {0,248.16,0},
    scale = {1,1,1}
  },
  ["5266"] = {
    tid = 605,
    monsterId = 10403,
    coord = {60, 31},
    pos = {45.58,0,-10.14},
    euler = {0,248.16,0},
    scale = {1,1,1}
  },
  ["5267"] = {
    tid = 605,
    monsterId = 10402,
    coord = {58, 31},
    pos = {43.72,0,-10.35},
    euler = {0,248.16,0},
    scale = {1,1,1}
  },
  ["5268"] = {
    tid = 605,
    monsterId = 10401,
    coord = {51, 25},
    pos = {36.61,0,-15.57},
    euler = {0,310.547,0},
    scale = {1,1,1}
  },
  ["5269"] = {
    tid = 605,
    monsterId = 10402,
    coord = {34, 53},
    pos = {20.3,0,11.59},
    euler = {0,277.139,0},
    scale = {1,1,1}
  },
  ["5270"] = {
    tid = 605,
    monsterId = 10401,
    coord = {28, 59},
    pos = {14.24,0,18.23},
    euler = {0,157.629,0},
    scale = {1,1,1}
  },
  ["5271"] = {
    tid = 605,
    monsterId = 10402,
    coord = {30, 60},
    pos = {15.98,0,19.5},
    euler = {0,157.629,0},
    scale = {1,1,1}
  },
  ["5272"] = {
    tid = 605,
    monsterId = 10401,
    coord = {29, 58},
    pos = {15.38,0,17.02},
    euler = {0,157.629,0},
    scale = {1,1,1}
  },
  ["5273"] = {
    tid = 605,
    monsterId = 10404,
    coord = {21, 53},
    pos = {6.528,0,11.961},
    euler = {0,85.214,0},
    scale = {1,1,1}
  },
  ["5274"] = {
    tid = 605,
    monsterId = 10401,
    coord = {35, 54},
    pos = {21.29,0,12.93},
    euler = {0,277.139,0},
    scale = {1,1,1}
  },
  ["5275"] = {
    tid = 605,
    monsterId = 10402,
    coord = {20, 51},
    pos = {6.026,0,10.132},
    euler = {0,85.214,0},
    scale = {1,1,1}
  },
  ["5276"] = {
    tid = 605,
    monsterId = 10401,
    coord = {19, 52},
    pos = {5.13,0,10.64},
    euler = {0,85.214,0},
    scale = {1,1,1}
  },
  ["5277"] = {
    tid = 605,
    monsterId = 10402,
    coord = {39, 53},
    pos = {25.31,0,11.66},
    euler = {0,72.845,0},
    scale = {1,1,1}
  },
  ["5278"] = {
    tid = 605,
    monsterId = 10401,
    coord = {49, 52},
    pos = {35.06,0,10.78},
    euler = {0,294.952,0},
    scale = {1,1,1}
  },
  ["5279"] = {
    tid = 605,
    monsterId = 10402,
    coord = {48, 53},
    pos = {33.68,0,11.7},
    euler = {0,294.952,0},
    scale = {1,1,1}
  },
  ["5280"] = {
    tid = 605,
    monsterId = 10401,
    coord = {52, 62},
    pos = {37.8,0,20.5},
    euler = {0,217.968,0},
    scale = {1,1,1}
  },
  ["5281"] = {
    tid = 605,
    monsterId = 10402,
    coord = {53, 60},
    pos = {39.05,0,18.96},
    euler = {0,217.968,0},
    scale = {1,1,1}
  },
  ["5282"] = {
    tid = 605,
    monsterId = 10403,
    coord = {51, 60},
    pos = {37.17,0,19.19},
    euler = {0,217.968,0},
    scale = {1,1,1}
  },
  ["5283"] = {
    tid = 605,
    monsterId = 10402,
    coord = {38, 53},
    pos = {24,0,11.84},
    euler = {0,72.845,0},
    scale = {1,1,1}
  }
}
