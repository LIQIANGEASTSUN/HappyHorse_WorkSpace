return {
  ["203"] = {
    tid = 60401301,
    monsterId = 0,
    coord = {4, 15},
    pos = {7.29,0,15.61},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["198"] = {
    tid = 60401202,
    monsterId = 0,
    coord = {4, 12},
    pos = {7.24,0,12.875},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["246"] = {
    tid = 60401201,
    monsterId = 0,
    coord = {4, 13},
    pos = {7.2,0,13.915},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["328"] = {
    tid = 60401103,
    monsterId = 0,
    coord = {7, 13},
    pos = {9.645,0,13.8},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["106"] = {
    tid = 60401102,
    monsterId = 0,
    coord = {4, 10},
    pos = {6.92,0,10.795},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1345"] = {
    tid = 60401102,
    monsterId = 0,
    coord = {7, 10},
    pos = {10.222,0,11.203},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1342"] = {
    tid = 60401101,
    monsterId = 0,
    coord = {7, 11},
    pos = {10.248,0,12.236},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1433"] = {
    tid = 60401101,
    monsterId = 0,
    coord = {4, 11},
    pos = {7.087,0,11.617},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1434"] = {
    tid = 60401101,
    monsterId = 0,
    coord = {4, 11},
    pos = {6.75,0,12.278},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1435"] = {
    tid = 60401101,
    monsterId = 0,
    coord = {7, 12},
    pos = {10.22,0,13.064},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["3385"] = {
    tid = 60401101,
    monsterId = 0,
    coord = {8, 14},
    pos = {10.708,0,14.648},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["3386"] = {
    tid = 60401101,
    monsterId = 0,
    coord = {6, 11},
    pos = {8.79,0,11.76},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["3387"] = {
    tid = 60401101,
    monsterId = 0,
    coord = {5, 10},
    pos = {7.75,0,10.63},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["3388"] = {
    tid = 60401101,
    monsterId = 0,
    coord = {6, 14},
    pos = {8.75,0,15.33},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["3389"] = {
    tid = 60401101,
    monsterId = 0,
    coord = {7, 15},
    pos = {10.22,0,15.83},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["3391"] = {
    tid = 60401103,
    monsterId = 0,
    coord = {7, 11},
    pos = {9.69,0,12.46},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["3392"] = {
    tid = 60401103,
    monsterId = 0,
    coord = {6, 10},
    pos = {9.47,0,11.27},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["3393"] = {
    tid = 60401103,
    monsterId = 0,
    coord = {6, 13},
    pos = {8.82,0,14.29},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["3394"] = {
    tid = 60401103,
    monsterId = 0,
    coord = {5, 12},
    pos = {8.13,0,12.61},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["3396"] = {
    tid = 60401301,
    monsterId = 0,
    coord = {9, 15},
    pos = {11.682,0,15.718},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1200"] = {
    tid = 605,
    monsterId = 10101,
    coord = {7, 14},
    pos = {10,0,15},
    euler = {0,208.31,0},
    scale = {1,1,1}
  },
  ["3298"] = {
    tid = 60601,
    monsterId = 0,
    coord = {6, 10},
    pos = {9,-0.01,11},
    euler = {0,0,0},
    scale = {1,1,1}
  },
  ["1474"] = {
    tid = 60601,
    monsterId = 0,
    coord = {4, 10},
    pos = {7,-0.01,11},
    euler = {0,0,0},
    scale = {1,1,1}
  },
  ["1475"] = {
    tid = 60601,
    monsterId = 0,
    coord = {6, 8},
    pos = {9,-0.01,9},
    euler = {0,0,0},
    scale = {1,1,1}
  },
  ["1476"] = {
    tid = 60601,
    monsterId = 0,
    coord = {4, 8},
    pos = {7,-0.01,9},
    euler = {0,0,0},
    scale = {1,1,1}
  },
  ["1453"] = {
    tid = 6070101,
    monsterId = 0,
    coord = {4, 12},
    pos = {7,-0.01,13},
    euler = {0,0,0},
    scale = {1,1,1}
  },
  ["1454"] = {
    tid = 6070101,
    monsterId = 0,
    coord = {6, 12},
    pos = {9,-0.01,13},
    euler = {0,0,0},
    scale = {1,1,1}
  },
  ["1455"] = {
    tid = 6070101,
    monsterId = 0,
    coord = {6, 14},
    pos = {9,-0.01,15},
    euler = {0,0,0},
    scale = {1,1,1}
  },
  ["1456"] = {
    tid = 6070101,
    monsterId = 0,
    coord = {4, 14},
    pos = {7,-0.01,15},
    euler = {0,0,0},
    scale = {1,1,1}
  },
  ["1458"] = {
    tid = 6070101,
    monsterId = 0,
    coord = {8, 14},
    pos = {11,-0.01,15},
    euler = {0,0,0},
    scale = {1,1,1}
  },
  ["3235"] = {
    tid = 60601,
    monsterId = 0,
    coord = {6, 4},
    pos = {9,-0.01,5},
    euler = {0,0,0},
    scale = {1,1,1}
  },
  ["3236"] = {
    tid = 60601,
    monsterId = 0,
    coord = {4, 4},
    pos = {7,-0.01,5},
    euler = {0,0,0},
    scale = {1,1,1}
  },
  ["3237"] = {
    tid = 60601,
    monsterId = 0,
    coord = {6, 6},
    pos = {9,-0.01,7},
    euler = {0,0,0},
    scale = {1,1,1}
  },
  ["3238"] = {
    tid = 60601,
    monsterId = 0,
    coord = {4, 6},
    pos = {7,-0.01,7},
    euler = {0,0,0},
    scale = {1,1,1}
  },
  ["3413"] = {
    tid = 60601,
    monsterId = 0,
    coord = {10, 4},
    pos = {13,-0.01,5},
    euler = {0,0,0},
    scale = {1,1,1}
  },
  ["3414"] = {
    tid = 60601,
    monsterId = 0,
    coord = {10, 6},
    pos = {13,-0.01,7},
    euler = {0,0,0},
    scale = {1,1,1}
  },
  ["3415"] = {
    tid = 60601,
    monsterId = 0,
    coord = {8, 4},
    pos = {11,-0.01,5},
    euler = {0,0,0},
    scale = {1,1,1}
  },
  ["3416"] = {
    tid = 60601,
    monsterId = 0,
    coord = {8, 6},
    pos = {11,-0.01,7},
    euler = {0,0,0},
    scale = {1,1,1}
  }
}
