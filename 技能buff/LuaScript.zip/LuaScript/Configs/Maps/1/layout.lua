return {
  mapSize = {15, 17},
  gridSize = 1.0,
  version = 1,
  Anchor = {3,0,1},
  Min = {-65.1,0,-60.7},
  Max = {66.6,0,72.4},
  types = {
  {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
  {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
  {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
  {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
  {0,0,0,0,3,3,3,3,3,3,3,3,3,3,3,3,0},
  {0,0,0,0,3,3,3,3,3,3,3,3,3,3,3,3,0},
  {0,0,0,0,3,3,3,3,3,3,3,3,3,3,3,3,0},
  {0,0,0,0,3,3,3,3,3,3,3,3,3,3,3,3,0},
  {0,0,0,0,3,3,3,3,2,2,2,2,2,2,3,3,0},
  {0,0,0,0,3,3,3,3,2,2,2,2,2,2,3,3,0},
  {0,0,0,0,3,3,3,3,2,2,2,2,2,2,3,3,0},
  {0,0,0,0,3,3,3,3,2,2,2,2,2,2,3,3,0},
  {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
  {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
  {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}
},
  openGrids = {
    {5, 6}
  },
  keyGrids = {},
  keyGridDelays = {},
  gridRelations = {
    {
      grid = {4, 4},
      relatedGrids = {
        {4, 5}
      }
    },
    {
      grid = {4, 7},
      relatedGrids = {
        {4, 8}
      }
    },
    {
      grid = {4, 8},
      relatedGrids = {
        {4, 9}
      }
    },
    {
      grid = {4, 9},
      relatedGrids = {
        {4, 10}
      }
    },
    {
      grid = {4, 10},
      relatedGrids = {
        {4, 11}
      }
    },
    {
      grid = {4, 11},
      relatedGrids = {
        {4, 12}
      }
    },
    {
      grid = {4, 12},
      relatedGrids = {
        {4, 13}
      }
    },
    {
      grid = {4, 13},
      relatedGrids = {
        {4, 14}
      }
    },
    {
      grid = {4, 14},
      relatedGrids = {
        {4, 15}
      }
    },
    {
      grid = {4, 15},
      relatedGrids = {
        {5, 15}
      }
    },
    {
      grid = {5, 4},
      relatedGrids = {
        {5, 5}
      }
    },
    {
      grid = {5, 15},
      relatedGrids = {
        {6, 15}
      }
    },
    {
      grid = {6, 4},
      relatedGrids = {
        {6, 5}
      }
    },
    {
      grid = {6, 15},
      relatedGrids = {
        {7, 15}
      }
    },
    {
      grid = {7, 4},
      relatedGrids = {
        {7, 5}
      }
    },
    {
      grid = {7, 7},
      relatedGrids = {
        {7, 8}
      }
    },
    {
      grid = {7, 8},
      relatedGrids = {
        {7, 9}
      }
    },
    {
      grid = {7, 9},
      relatedGrids = {
        {7, 10}
      }
    },
    {
      grid = {7, 10},
      relatedGrids = {
        {7, 11}
      }
    },
    {
      grid = {7, 11},
      relatedGrids = {
        {7, 12}
      }
    },
    {
      grid = {7, 12},
      relatedGrids = {
        {7, 13}
      }
    },
    {
      grid = {7, 13},
      relatedGrids = {
        {7, 14}
      }
    },
    {
      grid = {7, 15},
      relatedGrids = {
        {7, 14}
      }
    },
    {
      grid = {8, 4},
      relatedGrids = {
        {8, 5}
      }
    },
    {
      grid = {8, 7},
      relatedGrids = {
        {8, 6}
      }
    },
    {
      grid = {8, 14},
      relatedGrids = {
        {8, 15}
      }
    },
    {
      grid = {8, 15},
      relatedGrids = {
        {9, 15}
      }
    },
    {
      grid = {9, 4},
      relatedGrids = {
        {9, 5}
      }
    },
    {
      grid = {9, 7},
      relatedGrids = {
        {9, 6}
      }
    },
    {
      grid = {9, 14},
      relatedGrids = {
        {10, 14}
      }
    },
    {
      grid = {9, 15},
      relatedGrids = {
        {9, 14}
      }
    },
    {
      grid = {10, 4},
      relatedGrids = {
        {10, 5}
      }
    },
    {
      grid = {10, 7},
      relatedGrids = {
        {10, 6}
      }
    },
    {
      grid = {10, 14},
      relatedGrids = {
        {10, 15}
      }
    },
    {
      grid = {10, 15},
      relatedGrids = {
        {11, 15}
      }
    },
    {
      grid = {11, 4},
      relatedGrids = {
        {10, 5}
      }
    },
    {
      grid = {11, 5},
      relatedGrids = {
        {11, 4}
      }
    },
    {
      grid = {11, 6},
      relatedGrids = {
        {11, 7}
      }
    },
    {
      grid = {11, 7},
      relatedGrids = {
        {10, 6}
      }
    },
    {
      grid = {11, 15},
      relatedGrids = {
        {11, 14}
      }
    }
  }
}
