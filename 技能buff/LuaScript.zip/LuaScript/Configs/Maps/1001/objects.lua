return {
  ["483"] = {
    tid = 60302,
    monsterId = 0,
    coord = {12, 12},
    pos = {19.21,0,13.04},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["468"] = {
    tid = 60201,
    monsterId = 0,
    coord = {15, 2},
    pos = {22,-0.5,3},
    euler = {0,180,0},
    scale = {1,1,1}
  },
  ["3247"] = {
    tid = 616001,
    monsterId = 0,
    coord = {0, 8},
    pos = {7,0,9},
    euler = {270,0,0},
    scale = {1,1,1}
  },
  ["3249"] = {
    tid = 61501,
    monsterId = 0,
    coord = {2, 5},
    pos = {9,0,6},
    euler = {270,0,0},
    scale = {1,1,1}
  },
  ["3251"] = {
    tid = 61701,
    monsterId = 0,
    coord = {6, 5},
    pos = {13,0,6},
    euler = {270,0,0},
    scale = {1,1,1}
  },
  ["3261"] = {
    tid = 616002,
    monsterId = 0,
    coord = {0, 16},
    pos = {7,0,17},
    euler = {270,0,0},
    scale = {1,1,1}
  },
  ["3259"] = {
    tid = 616003,
    monsterId = 0,
    coord = {8, 16},
    pos = {15,0,17},
    euler = {270,0,0},
    scale = {1,1,1}
  },
  ["3255"] = {
    tid = 616004,
    monsterId = 0,
    coord = {16, 16},
    pos = {23,0,17},
    euler = {270,0,0},
    scale = {1,1,1}
  },
  ["3253"] = {
    tid = 616005,
    monsterId = 0,
    coord = {24, 16},
    pos = {31,0,17},
    euler = {270,0,0},
    scale = {1,1,1}
  },
  ["3265"] = {
    tid = 616006,
    monsterId = 0,
    coord = {32, 16},
    pos = {39,0,17},
    euler = {270,0,0},
    scale = {1,1,1}
  },
  ["3266"] = {
    tid = 616007,
    monsterId = 0,
    coord = {32, 24},
    pos = {39,0,25},
    euler = {270,0,0},
    scale = {1,1,1}
  },
  ["3267"] = {
    tid = 616008,
    monsterId = 0,
    coord = {24, 24},
    pos = {31,0,25},
    euler = {270,0,0},
    scale = {1,1,1}
  },
  ["3268"] = {
    tid = 616009,
    monsterId = 0,
    coord = {16, 24},
    pos = {23,0,25},
    euler = {270,0,0},
    scale = {1,1,1}
  },
  ["3269"] = {
    tid = 616010,
    monsterId = 0,
    coord = {8, 24},
    pos = {15,0,25},
    euler = {270,0,0},
    scale = {1,1,1}
  },
  ["3271"] = {
    tid = 616011,
    monsterId = 0,
    coord = {0, 24},
    pos = {7,0,25},
    euler = {270,0,0},
    scale = {1,1,1}
  },
  ["6"] = {
    tid = 611021,
    monsterId = 0,
    coord = {10, 4},
    pos = {16.7,0.01,4.643},
    euler = {270,0,0},
    scale = {1,1,1}
  },
  ["4"] = {
    tid = 611021,
    monsterId = 0,
    coord = {13, 4},
    pos = {19.681,0.01,4.643},
    euler = {270,0,0},
    scale = {1,1,1}
  },
  ["7"] = {
    tid = 611021,
    monsterId = 0,
    coord = {11, 4},
    pos = {18.2,0.01,4.643},
    euler = {270,0,0},
    scale = {1,1,1}
  },
  ["8"] = {
    tid = 611022,
    monsterId = 0,
    coord = {19, 6},
    pos = {26.354,0.01,7.473},
    euler = {270,90,0},
    scale = {1,1,1}
  },
  ["2"] = {
    tid = 611022,
    monsterId = 0,
    coord = {19, 8},
    pos = {26.354,0.01,8.972},
    euler = {270,90,0},
    scale = {1,1,1}
  },
  ["5"] = {
    tid = 611022,
    monsterId = 0,
    coord = {19, 11},
    pos = {26.354,0.01,11.605},
    euler = {270,90,0},
    scale = {1,1,1}
  },
  ["3"] = {
    tid = 611022,
    monsterId = 0,
    coord = {19, 9},
    pos = {26.354,0.01,10.475},
    euler = {270,90,0},
    scale = {1,1,1}
  },
  ["303"] = {
    tid = 611020,
    monsterId = 0,
    coord = {17, 7},
    pos = {24,0,8},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1432"] = {
    tid = 611020,
    monsterId = 0,
    coord = {17, 9},
    pos = {24,0,10},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1351"] = {
    tid = 611019,
    monsterId = 0,
    coord = {17, 11},
    pos = {24,0,12},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1350"] = {
    tid = 611018,
    monsterId = 0,
    coord = {8, 4},
    pos = {15,0,5},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1427"] = {
    tid = 611018,
    monsterId = 0,
    coord = {8, 14},
    pos = {15,0,15},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1428"] = {
    tid = 611018,
    monsterId = 0,
    coord = {18, 14},
    pos = {25,0,15},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1429"] = {
    tid = 611018,
    monsterId = 0,
    coord = {11, 14},
    pos = {18,0,15},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1430"] = {
    tid = 611018,
    monsterId = 0,
    coord = {9, 13},
    pos = {16,0,14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1431"] = {
    tid = 611018,
    monsterId = 0,
    coord = {18, 9},
    pos = {25,0,10},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1374"] = {
    tid = 611017,
    monsterId = 0,
    coord = {8, 5},
    pos = {15,0,6},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1415"] = {
    tid = 611017,
    monsterId = 0,
    coord = {10, 12},
    pos = {17,0,13},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1424"] = {
    tid = 611017,
    monsterId = 0,
    coord = {8, 12},
    pos = {15,0,13},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1417"] = {
    tid = 611017,
    monsterId = 0,
    coord = {10, 6},
    pos = {17,0,7},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1418"] = {
    tid = 611017,
    monsterId = 0,
    coord = {8, 8},
    pos = {15,0,9},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1419"] = {
    tid = 611017,
    monsterId = 0,
    coord = {17, 9},
    pos = {24,0,10},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1420"] = {
    tid = 611017,
    monsterId = 0,
    coord = {17, 13},
    pos = {24,0,14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1421"] = {
    tid = 611017,
    monsterId = 0,
    coord = {18, 7},
    pos = {25,0,8},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1422"] = {
    tid = 611017,
    monsterId = 0,
    coord = {17, 8},
    pos = {24,0,9},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1423"] = {
    tid = 611017,
    monsterId = 0,
    coord = {11, 12},
    pos = {18,0,13},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1352"] = {
    tid = 611016,
    monsterId = 0,
    coord = {9, 6},
    pos = {16,0,7},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1413"] = {
    tid = 611016,
    monsterId = 0,
    coord = {17, 10},
    pos = {24,0,11},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1414"] = {
    tid = 611016,
    monsterId = 0,
    coord = {17, 11},
    pos = {24,0,12},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1363"] = {
    tid = 611015,
    monsterId = 0,
    coord = {17, 15},
    pos = {24,0,16},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1405"] = {
    tid = 611015,
    monsterId = 0,
    coord = {10, 5},
    pos = {17,0,6},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1406"] = {
    tid = 611015,
    monsterId = 0,
    coord = {9, 5},
    pos = {16,0,6},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1407"] = {
    tid = 611015,
    monsterId = 0,
    coord = {8, 7},
    pos = {15,0,8},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1408"] = {
    tid = 611015,
    monsterId = 0,
    coord = {19, 8},
    pos = {26,0,9},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1409"] = {
    tid = 611015,
    monsterId = 0,
    coord = {18, 8},
    pos = {25,0,9},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1410"] = {
    tid = 611015,
    monsterId = 0,
    coord = {17, 12},
    pos = {24,0,13},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1411"] = {
    tid = 611015,
    monsterId = 0,
    coord = {9, 11},
    pos = {16,0,12},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1412"] = {
    tid = 611015,
    monsterId = 0,
    coord = {11, 13},
    pos = {18,0,14},
    euler = {270,180,0},
    scale = {1,1,1}
  },
  ["1426"] = {
    tid = 611015,
    monsterId = 0,
    coord = {10, 13},
    pos = {17,0,14},
    euler = {270,180,0},
    scale = {1,1,1}
  }
}
