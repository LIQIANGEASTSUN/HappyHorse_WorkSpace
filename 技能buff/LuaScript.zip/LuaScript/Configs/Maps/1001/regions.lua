return {
  regionMetas = {},
  rectMetas = {}
}
