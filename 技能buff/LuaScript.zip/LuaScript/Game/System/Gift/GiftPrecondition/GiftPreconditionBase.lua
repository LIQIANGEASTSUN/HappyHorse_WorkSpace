---
--- Created by Betta.
--- DateTime: 2021/9/9 16:10
---
---@class GiftPreConditionBase
local GiftPreConditionBase = {}

function GiftPreConditionBase:ctor()

end

function GiftPreConditionBase:Check()
    return false
end

return GiftPreConditionBase
