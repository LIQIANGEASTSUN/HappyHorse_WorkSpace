
---@class PetNestConstant
local PetNestConstant= {}

---栖息地建筑buff作用目标
PetNestConstant.BuffTargetType = {
    Nest = 1, ---栖息地
    Pet = 2, --- 家园宠物
}

return PetNestConstant