--[[
    PetNestManager配置分部类
]]
---@class PetNestManager
---@field mapBuildingMeta table<number, table<number, BuildingLevelTemplate>> 建筑配置映射map [snBuilding] = { [snBuildingLevel] = BuildingLevelTemplate }
---@field mapPetMeta table<number, table<number, PetTemplate>> 宠物配置映射map [snBuilding] = { [snPet] = PetTemplate }

local PetNestManager = {}

local StringBuildingLevelTemplate = "BuildingLevelTemplate"

--region class
---@class BuildingTemplate 建筑表
---@field sn number id
---@field name string 建筑名
---@field model string 模型预制
---@field icon string 模型icon
---@field x number 大小_x
---@field z number 大小_z
---@field type AgentType Agent类型，BuildingTemplate中的type和AgentType一一对应
---@field consume JSONArray 填充格子消耗
---@field rewardItem JSONArray 采集后获得的物资[[物品id,数量]]
---@field refreshCd number 资源再生CD（单位：秒；-1=不需要）
---@field resourceBuildingLevel number 资源建筑等级

---@class BuildingLevelTemplate 建筑等级表
---@field sn number id
---@field name string 此等级建筑名
---@field building number 建筑sn，对应BuildingTemplate的sn
---@field level number 建筑等级
---@field buff number buff id

---@class BuffTemplate Buff表
---@field sn number id
---@field buffType number buff类型
---@field buffValue JSONArray buff值

---@class PetTemplate
---@field sn number id
---@field name string 宠物名
---@field desc string 宠物描述
---@field model string 宠物模型
---@field icon string 宠物icon
---@field headIcon string 宠物头像icon
---@field type number 类型
---@field habitatSn number 栖息地建筑BuildingTemplate的sn
---@field product JSONArray 产出道具
---@field productTime number 产出时间
--endregion

function PetNestManager:InitMeta()
    self:InitMapBuildingMeta()
    self:InitMapPetMeta()
end
function PetNestManager:InitMapBuildingMeta()
    self.mapBuildingMeta = {}
    ---@type BuildingLevelTemplate[]
    local cfg = AppServices.Meta:Category(StringBuildingLevelTemplate)
    for _, cfgv in pairs(cfg) do
        local snBuilding = cfgv.building
        if self:IsBuildingPetNest(snBuilding) then
            if not self.mapBuildingMeta[snBuilding] then
                self.mapBuildingMeta[snBuilding] = {}
            end
            self.mapBuildingMeta[snBuilding][cfgv.sn] = cfgv
        end
    end
end
function PetNestManager:InitMapPetMeta()
    self.mapPetMeta = {}
    local cfgPetTemplate = AppServices.Meta:Category("PetTemplate")
    for _, cfgv in pairs(cfgPetTemplate) do
        local snBuilding = cfgv.habitatSn
        if not self.mapPetMeta[snBuilding] then
            self.mapPetMeta[snBuilding] = {}
        end
        self.mapPetMeta[snBuilding][cfgv.sn] = cfgv
    end
end

---@return table<number, table<number, BuildingLevelTemplate>>
function PetNestManager:GetMapBuildingMeta()
    if not self.mapBuildingMeta then
        self:InitMeta()
    end
    return self.mapBuildingMeta
end
---@return table<number, table<number, PetTemplate>>
function PetNestManager:GetMapPetMeta()
    if not self.mapPetMeta then
        self:InitMeta()
    end
    return self.mapPetMeta
end

--region 建筑相关
---@param sn number BuildingTemplate主键
---@return BuildingTemplate 根据sn返回一条 BuildingTemplate
function PetNestManager:GetBuildingTemplateBySn(sn)
    local cfgv = AppServices.Meta:GetBindingMeta(sn)
    return cfgv
end
---@param sn number BuildingLevelTemplate 主键
---@return BuildingLevelTemplate 根据sn返回一条 BuildingLevelTemplate
function PetNestManager:GetBuildingLevelTemplateBySn(sn)
    local cfg = AppServices.Meta:Category("BuildingLevelTemplate")
    local cfgv = cfg[tostring(sn)]
    return cfgv
end
---@param snBuilding number BuildingTemplate 主键
---@param level number 建筑等级
---@return BuildingLevelTemplate 根据建筑sn和等级返回一条 BuildingLevelTemplate
function PetNestManager:GetBuildingLevelTemplateBySnBuildingAndLevel(snBuilding, level)
    local cfgv = AppServices.BuildingLevelTemplateTool:GetConfig(snBuilding, level)
    return cfgv
end
---@param snBuilding number BuildingTemplate主键
---@return table<number, BuildingLevelTemplate> 根据BuildingTemplate主键获取该建筑所有等级建筑配置列表
function PetNestManager:GetBuildingLevelTemplatesBySn(snBuilding)
    local mapBuildingMeta = self:GetMapBuildingMeta()
    local mapBuildingLevelTemplate = mapBuildingMeta[snBuilding]
    return mapBuildingLevelTemplate
end
---@return boolean 此建筑是否为动物栖息地
function PetNestManager:IsBuildingPetNest(sn)
    local cfgv = self:GetBuildingTemplateBySn(sn)
    local isPetNest = cfgv.type == AgentType.pet_nest
    return isPetNest
end
---@return number 根据agentId获取snBuilding，适用于场景中没有对应Agent的情况
function PetNestManager:GetSnBuildingByAgentId(agentId)
    local json = App.scene.objectManager:GetMapData(agentId)
    local snBuilding = json.tid
    return snBuilding
end
---@return number 根据BuildingLevelTemplate的sn获取其栖息地sn
function PetNestManager:GetSnBuildingBySnBuildingLevel(snBuildingLevel)
    local cfg = self:GetBuildingLevelTemplateBySn(snBuildingLevel)
    local snBuilding = cfg.building
    return snBuilding
end
--endregion

--region buff相关
---@param sn number BuffTemplate 主键
---@return BuffTemplate 根据sn返回一条 BuffTemplate
function PetNestManager:GetBuffTemplateBySn(sn)
    local cfgv = AppServices.Meta:GetBuffMeta(sn)
    return cfgv
end
--endregion

--region 宠物相关
---@field snPet number 宠物配置sn
---@return PetTemplate
function PetNestManager:GetPetTemplateBySn(snPet)
    local cfg = AppServices.Meta:Category("PetTemplate")
    local cfgv = cfg[tostring(snPet)]
    return cfgv
end
---@param snBuilding number BuildingTemplate主键
---@return PetTemplate[] 返回栖息地为 snBuilding 的PetTemplate列表
function PetNestManager:GetPetTemplatesBySnBuilding(snBuilding)
    local cfg = self.mapPetMeta[snBuilding]
    return cfg
end
---@return number 根据宠物sn获取其栖息地sn
function PetNestManager:GetSnBuildingBySnPet(snPet)
    local cfg = self:GetPetTemplateBySn(snPet)
    local snBuilding = cfg.habitatSn
    return snBuilding
end
--endregion

return PetNestManager