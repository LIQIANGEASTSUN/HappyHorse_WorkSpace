--[[
    PetNestManager主分部类
]]
---@type PetTemplateTool
local PetTemplateTool = require "Cleaner.Entity.Pet.PetTemplateTool"
---@type BuffDescript
local BuffDescript = require "Cleaner.Fight.Buff.BuffDescript"
---@type PetNestConstant
local PetNestConstant = require("Game.System.PetNest.PetNestConstant")
---@type AttributeInfo
local AttributeInfo = require "Cleaner.Fight.Attribute.AttributeInfo"
---@type PetAttributeEntity
local PetAttributeEntity = require "Cleaner.PetNest.Attribute.PetAttributeEntity"

---@class PetNestManager
---@field lstPetNest CPetNest[] 栖息地集合
---@field mapNestLevelEffect table<number, CPetNestEffect[]> key=BuildingTemplate的sn，value=此栖息地的属性列表
---@field mapPetSnAttributeEntity table<number, PetAttributeEntity> 宠物sn = PetAttributeEntity实例

local PetNestManager = require("Game.System.PetNest.PetNestManagerMeta")

function PetNestManager:Init()
    self:RegisterEvent()
    self:InitMeta()
    self:InitMapNestLevelEffect()
end
--region CPetNestEffect
---@class CPetNestEffect 栖息地属性类
---@field buildingSn number 栖息地建筑表sn
---@field buildingLvSn number 栖息地建筑等级表sn
---@field level number 等级
---@field buffId number buffId

function PetNestManager:InitMapNestLevelEffect()
    self.mapNestLevelEffect = {}
    local map = self:GetMapBuildingMeta()
    for snBuildingTemplate, cfgBuildingLevelTemplateList in pairs(map) do
        local list = {}
        for snBuildingLevelTemplate, cfgBuildingLevelTemplate in pairs(cfgBuildingLevelTemplateList) do
            local effect = {
                buildingSn = snBuildingTemplate,
                buildingLvSn = snBuildingLevelTemplate,
                level = cfgBuildingLevelTemplate.level,
                buffId = cfgBuildingLevelTemplate.buff,
            }
            table.insert(list, effect)
        end
        self.mapNestLevelEffect[snBuildingTemplate] = list
    end
end
--endregion
function PetNestManager:RegisterEvent()
    self:UnRegisterEvent()
    MessageDispatcher:AddMessageListener(MessageType.PetHLCreateFinish, self.PetHLCreateFinish, self)
end
function PetNestManager:UnRegisterEvent()
    MessageDispatcher:RemoveMessageListener(MessageType.PetHLCreateFinish, self.PetHLCreateFinish, self)
end

--[[
    更新栖息地建筑列表
    调用时机：进家园；获得宠物；
]]
function PetNestManager:UpdateLstPetNest()
    self.lstPetNest = {}
    ---@type PetNestAgent[]
    local agents = App.scene.objectManager:GetAgentsByType(AgentType.pet_nest) or {}
    for _, agent in pairs(agents) do
        local agentId = agent:GetId()
        if self:IsNestCanBeBuild(agentId) then --没宠物的栖息地实例不构建
            local petNest = self:CreatePetNest(agent)
            table.insert(self.lstPetNest, petNest)
        end
    end --for
    self:UpdateLstPetNestPets()
end
function PetNestManager:UpdateLstPetNestPets()
    local pets = AppServices.User:GetPets()
    if #pets <= 0 then
        console.hxp("### no pet now") --@DEL
        return
    end
    for id, pet in pairs(pets) do
        local snPet = PetTemplateTool:Getkey(pet.type, pet.level)
        if self:IsPetHasNest(snPet) then
            local pet = self:CreatePet(id)
            local snBuilding = self:GetSnBuildingBySnPet(snPet)
            local petNest = self:GetPetNestBySnBuiding(snBuilding)
            table.insert(petNest.pets, pet)
        end --if
    end --for
end

--region CPetNest
---@class CPetNest 栖息地类
---@field agentId number Agent Id
---@field pets CPetNestPet[] 该栖息地的宠物列表
---@field GetPetBySerId CPetNestPet 获取宠物函数
---@field SnBuilding number 栖息地建筑sn函数
---@field SnBuildingLevel number 栖息地建筑等级sn函数
---@field Name string 栖息地名字函数
---@field Level number 等级函数
---@field NextLevel number 下一级函数
---@field HookIncome number 挂机收入函数（包括宠物的加成）
---@field IsUnlock boolean 是否解锁函数
---@field IsLevelMax boolean 是否满级函数
---@field PetTypes boolean[] 获取栖息地宠物类型列表函数
---@field Type number 此栖息地宠物类型函数
---@field TypeCount number 此栖息地宠物当前数函数
---@field TypeCountAll number 此栖息地宠物总数函数
---@field BuildCost table 建造消耗函数
---@field LevelUpCost table 升级消耗函数

---@param agent PetNestAgent
---@return CPetNest
function PetNestManager:CreatePetNest(agent)
    ---@type CPetNest
    local petNest = {
        agentId = agent:GetId(),
        pets = {},
        petTypes = {}
    }
    --region function
    petNest.GetPetBySerId = function(serId)
        for _, pet in ipairs(petNest.pets) do
            if pet.id == serId then
                return pet
            end
        end
    end
    petNest.SnBuilding = function()
        local tplId = agent:GetTemplateId()
        return tplId
    end
    petNest.SnBuildingLevel = function()
        local snBuilding = petNest:SnBuilding()
        local level = petNest:Level()
        local cfgv = self:GetBuildingLevelTemplateBySnBuildingAndLevel(snBuilding, level)
        return cfgv and cfgv.sn or 0
    end
    petNest.Level = function()
        local level = agent:GetLevel()
        return level
    end
    petNest.NextLevel = function()
        if petNest:IsLevelMax() then
            return -1 --满级后下一级返回-1
        end
        local level = petNest:Level()
        return level + 1
    end
    petNest.Name = function()
        if petNest:IsUnlock() then --已解锁，返回BuildingLevelTemplate的name
            local snBuildingLevel = petNest:SnBuildingLevel()
            local cfgv = self:GetBuildingLevelTemplateBySn(snBuildingLevel)
            return cfgv.name
        else --未解锁，返回BuildingTemplate的name
            local snBuilding = petNest:SnBuilding()
            local cfgv = self:GetBuildingTemplateBySn(snBuilding)
            return cfgv.name
        end
    end
    petNest.HookIncome = function()
        local pne = agent:GetPetNestEarnings()
        local production = pne:EarningsPerMinute()
        local ret = math.floor(production[tonumber(ItemId.COIN)])
        return ret
    end
    petNest.IsUnlock = function()
        local level = petNest:Level()
        return level > 0 --等级大于0的建筑已解锁
    end
    petNest.IsLevelMax = function()
        local snBuilding = petNest:SnBuilding()
        local map = self:GetMapBuildingMeta()
        local mapBuidingLevel = map[snBuilding]
        local len = table.count(mapBuidingLevel)
        local level = petNest:Level()
        return level >= len
    end
    petNest.PetTypes = function()
        if petNest.petTypes and table.count(petNest.petTypes) > 0 then
            return petNest.petTypes
        end
        petNest.petTypes = {}
        local map = self:GetMapPetMeta()
        local snBuilding = petNest:SnBuilding()
        local cfg = map[snBuilding]
        for _, cfgv in pairs(cfg) do
            petNest.petTypes[cfgv.type] = true
        end
        return petNest.petTypes
    end
    petNest.Type = function()
        local pet = petNest.pets[1] --栖息地下任意一只宠物的类型就是栖息地类型
        local type = pet:Type()
        return type
    end
    petNest.TypeCount = function()
        local len = #petNest.pets --一种类型宠物就一只，所以宠物数就是宠物类型数
        return len
    end
    petNest.TypeCountAll = function()
        local petTypes = petNest.PetTypes()
        local len = table.count(petTypes)
        return len
    end
    petNest.BuildCost = function()
        local snBuilding = petNest:SnBuilding()
        local cfgv = self:GetBuildingTemplateBySn(snBuilding)
        return cfgv.consume
    end
    petNest.LevelUpCost = function()
        local snBuildingLevel = petNest:SnBuildingLevel()
        local cfgv = self:GetBuildingLevelTemplateBySn(snBuildingLevel)
        return cfgv.upgradeCost
    end
    --endregion
    return petNest
end
--endregion

--region CPetNestPet
---@class CPetNestPet 宠物类
---@field id number 宠物id
---@field SnPet number 宠物表sn函数
---@field Icon string 动物icon函数
---@field Name string 宠物名字函数
---@field Desc string 描述函数
---@field HookIncome number 挂机收入函数
---@field Type number 宠物类型函数

---@return CPetNestPet
function PetNestManager:CreatePet(id)
    local serPet = AppServices.User:GetPet(id)
    ---@type CPetNestPet
    local pet = {
        id = id,
    }
    --region function
    pet.SnPet = function()
        local snPet = PetTemplateTool:Getkey(serPet.type, serPet.level)
        return snPet
    end
    pet.Icon = function(this)
        local cfgv = self:GetPetTemplateBySn(this:SnPet())
        local icon = cfgv.icon
        return icon
    end
    pet.Name = function()
        local cfgPet = self:GetPetTemplateBySn(pet:SnPet())
        local str = Runtime.Translate(cfgPet.name)
        return str
    end
    pet.Desc = function()
        local cfgPet = self:GetPetTemplateBySn(pet:SnPet())
        local str = Runtime.Translate(cfgPet.desc)
        return str
    end
    pet.HookIncome = function() --宠物的产出直接读表即可
        local cfgv = self:GetPetTemplateBySn(pet:SnPet())
        local productItem = cfgv.productItem
        local productCount = productItem[1][2] --需确保配的是[[道具sn,数量]]
        local productTime = cfgv.productTime or 1
        productTime = math.max(0.01, productTime) --最小0.01，防止除0
        local div = math.floor(productCount / productTime) --向下取整
        return div
    end
    pet.Type = function()
        local cfgv = self:GetPetTemplateBySn(pet:SnPet())
        local type = cfgv.type
        return type
    end
    --endregion
    return pet
end
--endregion

---@return boolean 此Agent是否为栖息地
function PetNestManager:IsPetNestAgent(agentId)
    local agent = App.scene.objectManager:GetAgent(agentId)
    if agent and agent:GetType() == AgentType.pet_nest then
        return true
    end
end

--打开栖息地界面
---@param agentId number 栖息地建筑Agent的Id
function PetNestManager:ShowUIPetNestPanel(agentId)
    local agent = self:GetPetNestAgentByAgentId(agentId)
    if not agent then
        console.hxp("### no agent. agentId=", agentId) --@DEL
        return
    end
    local pos = agent:GetCenterPostion()
    self:CameraFocus2Agent(pos, function()
        if PanelManager.isPanelShowing(GlobalPanelEnum.UIPetNestPanel) then
            MessageDispatcher:SendMessage(MessageType.PetNestAgentFocusFinish, agentId)
        else
            PanelManager.showPanel(GlobalPanelEnum.UIPetNestPanel, {agentId = agentId})
        end
    end)
end
function PetNestManager:CameraFocus2Agent(pos, callback, duration, cameraSize)
    duration = duration or 0.3
    cameraSize = cameraSize or 40
    MoveCameraLogic.Instance():MoveCameraToLook2(pos, duration, cameraSize, callback, true)
    -- MoveCameraLogic.Instance():SetFocusOnPoint(pos, value.value.smoothMove, value.value.size or 40, callback)
end

---@return boolean 栖息地可建造（即获得了此栖息地的宠物）
function PetNestManager:IsNestCanBeBuild(agentId)
    local snBuilding = self:GetSnBuildingByAgentId(agentId)
    local cfgs = AppServices.PetNestManager:GetPetTemplatesBySnBuilding(snBuilding)
    if cfgs then
        for _, cfgv in pairs(cfgs) do
            local pet = AppServices.User:GetPetWithType(cfgv.type)
            if pet then
                return true
            end
        end
    end
end

---@return PetNestAgent 根据AgentId获取栖息地Agent
function PetNestManager:GetPetNestAgentByAgentId(agentId)
    local agent = App.scene.objectManager:GetAgent(agentId)
    return agent
end
---@return AgentData 根据AgentId获取栖息地AgentData
function PetNestManager:GetPetNestAgentDataByAgentId(agentId)
    local agent = self:GetPetNestAgentByAgentId(agentId)
    local data = agent:GetData()
    return data
end
---@return CPetNest[] 获取 lstPetNest
function PetNestManager:GetLstPetNest()
    return self.lstPetNest
end
---@return CPetNest 根据agentId获取CPetNest
function PetNestManager:GetPetNestByAgentId(agentId)
    if self.lstPetNest then
        for index, petNest in ipairs(self.lstPetNest) do
            if petNest.agentId == agentId then
                return petNest
            end
        end
    end
end
---@return CPetNest 根据snBuilding获取CPetNest
function PetNestManager:GetPetNestBySnBuiding(sn)
    if self.lstPetNest then
        for index, petNest in ipairs(self.lstPetNest) do
            if petNest:SnBuilding() == sn then
                return petNest
            end
        end
    end
end
---@return CPetNest 根据 snPet 获取CPetNest
function PetNestManager:GetPetNestBySnPet(snPet)
    if self.lstPetNest then
        for _, petNest in ipairs(self.lstPetNest) do
            local pets = petNest.pets
            for _, pet in ipairs(pets) do
                if pet:SnPet() == snPet then
                    return petNest
                end
            end
        end
    end
end
function PetNestManager:GetPetNestByPetId(id)
    if self.lstPetNest then
        for _, petNest in ipairs(self.lstPetNest) do
            local pets = petNest.pets
            for _, pet in ipairs(pets) do
                if pet.id == id then
                    return petNest
                end
            end
        end
    end
end

--region 宠物类型相关
---@return CPetNestPet[] 根据宠物类型获取已获得的宠物列表
function PetNestManager:GetPetsByType(type)
    if self.lstPetNest then
        for _, petNest in ipairs(self.lstPetNest) do
            if petNest:Type() == type then
                return petNest.pets
            end
        end
    end
end
function PetNestManager:GetTypeNameByType(type)
    local typeName = Runtime.Translate("TODO") --类型名
    return typeName
end
---@return string 根据建筑sn和等级返回其buff描述
function PetNestManager:GetPetNestLevelDesc(snBuilding, level)
    local cfgv = self:GetBuildingLevelTemplateBySnBuildingAndLevel(snBuilding, level)
    local buff = cfgv.buff
    local msg
    if buff <= 0 then
        msg = Runtime.Translate("ui_habitat_attribute_1")
    else
        msg = BuffDescript:Descript(buff)
    end
    return msg
end
--endregion

---@return boolean 消耗材料是否足够
function PetNestManager:IsCostEnough(cfgCost)
    local isEnougth = AppServices.ItemCostManager:IsItemEnougth(cfgCost)
    return isEnougth
end

---@return boolean 宠物是否有栖息地
function PetNestManager:IsPetHasNest(snPet)
    local snBuilding = self:GetSnBuildingBySnPet(snPet)
    local petNest = self:GetPetNestBySnBuiding(snBuilding)
    if petNest then
        return true
    end
    return false
end

---家园宠物创建完
---@param id number 服务器消息宠物id
---@param entityId number 宠物实体id
---@param habitatSn number 栖息地sn
function PetNestManager:PetHLCreateFinish(id, entityId, habitatSn)
    self:UpdateLstPetNest()
    local petNest = self:GetPetNestBySnBuiding(habitatSn)
    if not petNest then
        return
    end
    if petNest:IsUnlock() then
        return
    end
    local agent = self:GetPetNestAgentByAgentId(petNest.agentId)
    if not agent then
        return
    end
    if agent:GetState() ~= CleanState.cleared then
        agent:SetState(CleanState.cleared)
    end
end
---@return number 根据宠物serverId获取其entity
function PetNestManager:GetPetEntityById(id)
    local pet = AppServices.User:GetPet(id)
    local entityList = AppServices.EntityManager:GetEntityWithType(EntityType.PetHL)
    if entityList and #entityList > 0 then
        for _, entity in ipairs(entityList) do
            local type = entity.data:GetType()
            if type == pet.type then
                return entity
            end
        end
    end
end

--region Attribute
function PetNestManager:GetMapPetAttributeEntity()
    if not self.mapPetSnAttributeEntity then
        self.mapPetSnAttributeEntity = {}
    end
    return self.mapPetSnAttributeEntity
end
function PetNestManager:GetPetAttributeEntityBySnPet(snPet)
    local map = self:GetMapPetAttributeEntity()
    if not map[snPet] then
        map[snPet] = PetAttributeEntity.new(snPet)
        self:AddBuffsForPetAttribute(snPet)
    end
    return map[snPet]
end
---@param type number 宠物类型
---@param level number 宠物等级
---@return PetAttributeEntity
function PetNestManager:GetPetAttributeEntityByPetTypeLevel(type, level)
    local snPet = PetTemplateTool:Getkey(type, level)
    local petAttributeEntity = self:GetPetAttributeEntityBySnPet(snPet)
    return petAttributeEntity
end
---@return PetAttributeEntity
function PetNestManager:GetPetAttributeEntityByPetId(id)
    local pet = AppServices.User:GetPet(id)
    local petAttributeEntity = self:GetPetAttributeEntityByPetTypeLevel(pet.type, pet.level)
    return petAttributeEntity
end
---@return number, number 根据宠物serverId获取其最大血量和攻击力
function PetNestManager:GetPetHpAttackById(id)
    local petAttributeEntity = self:GetPetAttributeEntityByPetId(id)
    local hp = petAttributeEntity:GetMaxHp() --HP
    local attack = petAttributeEntity:GetMaxAttack() --Attack
    return hp, attack
end
--endregion

--region buff
---给该栖息地中的宠物PetAttributeEntity加buff，只能在家园用，基于栖息地Agent
function PetNestManager:AddBuffsForNestPetAttribute(agentId)
    local petNest = self:GetPetNestByAgentId(agentId)
    if not petNest then
        console.hxp("### no petNest", agentId) --@DEL
        return
    end
    if petNest.pets and #petNest.pets > 0 then
        for _, pet in ipairs(petNest.pets) do
            self:AddBuffsForPetAttribute(pet:SnPet())
        end
    end
end
function PetNestManager:AddBuffsForPetAttribute(snPet) --给宠物PetAttributeEntity加buff
    local petAttributeEntity = self:GetPetAttributeEntityBySnPet(snPet)
    local buffIds = self:GetBuffsBySnPet(snPet)
    if buffIds then
        for _, buffId in ipairs(buffIds) do
            petAttributeEntity:AddBuff(buffId)
        end
    end
end
---@param snPet number 宠物sn
---@return number[] 获取此宠物对应的栖息地给宠物加的buffId列表
function PetNestManager:GetBuffsBySnPet(snPet)
    local buffIds = {}
    local petNest= self:GetPetNestBySnPet(snPet)
    if not petNest then
        console.hxp("### no petNest", snPet) --@DEL
        return
    end
    local curLevel = petNest:Level()
    if curLevel <= 0 then
        return
    end
    local snBuilding = petNest:SnBuilding()
    for i = 1, curLevel do
        local cfgv = AppServices.PetNestManager:GetBuildingLevelTemplateBySnBuildingAndLevel(snBuilding, i)
        local buffId = cfgv.buff or 0
        local target = cfgv.target or 0
        if target == PetNestConstant.BuffTargetType.Nest then
        elseif target == PetNestConstant.BuffTargetType.Pet then
            if buffId > 0 then
                table.insert(buffIds, buffId)
            end
        else
            console.hxp("### invalid target.") --@DEL
        end
    end
    return buffIds
end
--endregion

--region breed
---@param snBuilding number 栖息地建筑sn
---@return number 获取经buff加成后的繁育时长
function PetNestManager:GetBreedCD(snBuilding)
    local petNest = self:GetPetNestBySnBuiding(snBuilding)
    if not petNest then
        return
    end
    local agent = self:GetPetNestAgentByAgentId(petNest.agentId)
    if not agent then
        return
    end
    local attr = agent:GetAttribute(AttributeInfo.Type.BreedTime)
    local value = attr and attr:GetValue() or 0
    return value
end
--endregion

PetNestManager:Init()
return PetNestManager