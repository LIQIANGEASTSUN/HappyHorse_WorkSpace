---@class FlyAnimation
local FlyAnimation = {}
local Feature = CS.Bridge.Feature

---@type Reward3DItem
local Reward3DItem = require("UI.Components.Reward3DItem")
local RewardItem = require("UI.Components.RewardItem")
local BezierCurve = require("System.Core.BezierCurve")
--  构建道具的对象 并调用执行飞的动画
---@param info.itemId 道具id
---@param info.pos 起始的位置
function FlyAnimation.CreateItemWithFly(info)
    info.initPos = info.initPos or MoveCameraLogic.Instance():GetLookPosition()
    info.pos = info.pos or info.initPos
    info.url = info.url or CONST.ASSETS.G_REWARD_ITEM
    info.onFinish = info.onFinish or nil
    info.flyItemCallback = info.flyItemCallback or nil
    info.flyTime = info.flyTime or 0.6
    info.ease = info.ease or Ease.InOutSine

    ---@type RewardItem
    local reward = RewardItem.new()
    local item = BResource.InstantiateFromAssetName(info.url)
    info.target = ItemId.GetWidget(info.itemId)
    reward:InitWithGameObject(item)
    reward:Generate(info)
    FlyAnimation:FlyItem(info, reward)
end

---@class Item3DIconParam
---@field itemId string|number 道具id
---@field initPos Vector3 原始位置
---@field pos Vector3 弹跳位置
---@field url string 资源路径
---@field flyTime number 飞行时间
---@field flyItemCallback function 单个Item飞行回调
---@field targetShowEnterAnim boolean 目标图标是否显示
--  构建道具的对象 并调用执行飞的动画
---@param info Item3DIconParam
function FlyAnimation.Create3DItemWithFly(info)
    info.initPos = info.initPos or MoveCameraLogic.Instance():GetLookPosition()
    info.pos = info.pos or info.initPos
    info.flyTime = info.flyTime or 0.75
    info.ease = info.ease or Ease.InOutSine

    local item = Reward3DItem.new()
    local pool = AppServices.PoolManager:GetPool("Fly3DItem")
    local itemEntity = pool:GetEntity(true)
    info.target = ItemId.GetWidget(info.itemId)
    item:InitWithEntity(itemEntity)
    item:Generate(info)
    FlyAnimation:FlyObjectToObject(item, info.target:GetMainIconGameObject(info.itemId), info)

    if RuntimeContext.UNITY_IOS then
        Feature.PlayPreset(4)  -- LightImpact
    end
end

function FlyAnimation:FlyItem(info, flyItem)
    local target = info.target or ItemId.GetWidget(info.itemId)
    if target then
        if info.targetShowEnterAnim then
            if target.inLayout then
                target:ShowEnterAnimInLayout()
            else
                target:ShowEnterAnim()
            end
            target:SetInteractable(false)
        end
        FlyAnimation:FlyObjectToObject(flyItem, target:GetMainIconGameObject(info.itemId), info)

        self:OnFlyFinishCallBack(info, target, flyItem)
    else
        console.error("No Widget Found Of ID: ", info.itemId) --@DEL
    end
end

function FlyAnimation:FlyObjectToObject(flyObject, destObject, info)
    local parent = destObject:GetParent()
    flyObject.gameObject:SetParent(parent, false)
    local initLocalPos = GameUtil.WorldToUISpace(parent, info.initPos)
    flyObject.gameObject:SetLocalPosition(initLocalPos)

    local jumpToLocalPos = GameUtil.WorldToUISpace(parent, info.pos)
    local go = flyObject.gameObject
    go:SetLocalScale(0, 0, 0)
    local beginDelay = 0.1
    if not info.noJump then
        local jumpDuration = 0.65
        beginDelay = beginDelay + jumpDuration
        go.transform:DOLocalJump(jumpToLocalPos, 90, 3, jumpDuration)
    end
    local scale = 1
    local scaleTween = go.transform:DOScale(scale, 0.45)
    scaleTween:SetEase(Ease.OutBack)

    local startPos = initLocalPos
    local destPos = destObject:GetLocalPosition()
    local controlPos = Vector3(startPos.x, destPos.y, 0)
    local wayPoints = Vector3List()
    for i = 1, 4 do
        local p = BezierCurve.SecondOrder(startPos, controlPos, destPos, i / 4)
        wayPoints:AddItem(p)
    end
    BPath.DoLocalPath(
        flyObject.gameObject.transform,
        wayPoints,
        info.flyTime,
        info.ease,
        function()
            if Runtime.CSValid(destObject) then
                destObject.transform:DOKill(true)
                destObject.transform:DOPunchScale(Vector3(0.3, 0.3, 0.3), 0.3)
            end
            flyObject:Destroy()
            Runtime.InvokeCbk(info.onFinish)
        end,
        beginDelay
    )
end

function FlyAnimation:OnFlyFinishCallBack(info, target, flyItem)
    local target2 = ItemId.GetWidget(info.itemId, HUD_ICON_ENUM.HEAD)
    Runtime.InvokeCbk(target2.Refresh, target2, true, self.flyTime)
    WaitExtension.SetTimeout(
        function()
            Runtime.InvokeCbk(info.flyItemCallback, flyItem.gameObject)
            local target1 = ItemId.GetWidget(info.itemId, HUD_ICON_ENUM.ITEM)
            Runtime.InvokeCbk(target1.OnHit, target1)
            Runtime.InvokeCbk(target1.Refresh, target1, true)
            Runtime.InvokeCbk(target2.OnHit, target2)
            local flyCbk = function()
                if self.targetShowEnterAnim then
                    if target.inLayout then
                        target:ShowExitAnimInLayout(
                            function()
                                target:SetInteractable(true)
                            end
                        )
                    else
                        target:ShowExitAnim(
                            nil,
                            function()
                                target:SetInteractable(true)
                            end
                        )
                    end
                end
                if self.onFinish ~= nil then
                    WaitExtension.InvokeDelay(self.onFinish)
                end
            end
            if not target.SetTimeout then
                console.error("no settimeout", target)
                WaitExtension.SetTimeout(flyCbk, 1)
            else
                target:SetTimeout(nil, flyCbk, 1)
            end
        end,
        self.flyTime
    )
end

return FlyAnimation
