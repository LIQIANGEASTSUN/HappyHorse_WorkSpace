---@class BreedEvent
local BreedEvent = {
    Ready = "BreedEvent_Ready"
}

return BreedEvent