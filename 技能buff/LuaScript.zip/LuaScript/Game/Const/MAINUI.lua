---@class MAINUI 用于控制飞道具时需要显示的icon
local MAINUI = {
    LAYERS = {
        SCENE_UI = "SCENE_UI",
        SCENE_BG = "SCENE_BG",
        BASIC_UI = "BASIC_UI"
    },
    ICONS = {
        --  部分数值和 ItemTemplate widgetType 所匹配
        UserInfoWidget = 1, --左上角玩家经验值，设置按钮等
        PropsWidget = 2, --右上角玩家金币和材料预览
        DiamondIcon = 3, -- 钻石
        ---背包
        BagButton = 4,
        AnimalsButton = 5,
        MapButton = 6,
        CleanerButton = 7,
        ShopButton = 8,
        GMButton = 9,
        ---任务按钮
        TaskButton = 10,
        -- 出航按钮
        ShipButton = 11,
        -- 探索岛主界面显示出战队伍
        PetTeam = 12,
    }
}
return MAINUI
