return {
    --账号类型（关联账号）
    TYPE = {
        GUEST = 0,
        FACEBOOK = 1,
        LEDOU = 2,
        APPLE = 4
    }
}