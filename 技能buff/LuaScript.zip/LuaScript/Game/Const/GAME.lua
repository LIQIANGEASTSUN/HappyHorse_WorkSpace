---@class GAME
local GAME = {
    SCENE_NAMES = table.deserialize(AppServices.Meta:GetConfigMetaValue("SCENE_NAMES")),
    FACEBOOK_BIND_AWARD_ITEM_ID = "-99999",  -- facebook奖励条目id

    FRAME_RATE = 60,
    FRAME_INTERVAL       = 1 / 60,

    SceneTeleporterPosition = Vector3(-2.45, 0, 8.23),

    -- HEADIMAGE_FACEBOOK_AVATAR_NUM = 999,
    NpcAlias = {},

    --平台类型
    PlatType = {
        GUEST = 0,
        FACEBOOK = 1,
        LEDOU = 2,
        APPLE = 3
    }
}
return GAME
