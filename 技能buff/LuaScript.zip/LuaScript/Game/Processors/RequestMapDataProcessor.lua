---@class RequestMapDataProcessor
local RequestMapDataProcessor = {}

function RequestMapDataProcessor:Init()
    self:RegisterEvent()
end

function RequestMapDataProcessor:RegisterEvent()
    AppServices.NetWorkManager:addObserver(MsgMap.SCChangeScene, self.OnRevChangeScene, self)
end
function RequestMapDataProcessor:UnRegisterEvent()
    AppServices.NetWorkManager:removeObserver(MsgMap.SCChangeScene, self.OnRevChangeScene, self)
end

function RequestMapDataProcessor:OnRevChangeScene(response)
    local sceneInfo = response.scene
    local sceneName = tostring(sceneInfo.sn)

    local KeyEventProcessor = require("Game.Processors.KeyEventProcessor")
    local ChangeSceneAnimation = require "Game.Common.ChangeSceneAnimation"
    ChangeSceneAnimation.Instance():EnterCityIn(
        function()
            local function OnChangeSuccess()
                KeyEventProcessor.Enable = true
            end
            local processor = require "Game.Processors.ChangeSceneProcessor"
            processor.Change(sceneName, OnChangeSuccess, {msg = {sceneInfo = response}})
        end
    )
end

---请求地图数据并完成场景切换
function RequestMapDataProcessor:Start(name)
    local cfg = CONST.RULES.LoadSceneConfig(name)
    local sceneId = cfg.params.sceneId
    if not sceneId or sceneId == "0" then ---检查场景ID
        ErrorHandler.ShowErrorMessage(string.format("Request map data error,sceneId = %s", sceneId)) --@DEL
        return
    end
    AppServices.Net:Send(MsgMap.CSChangeScene, {scene = sceneId})
    local KeyEventProcessor = require("Game.Processors.KeyEventProcessor")
    KeyEventProcessor.Enable = false
    -- local function onSuccess(result)
    --     AppServices.PipeManager:ResponseSceneInfo(sceneId, result.pipeMsgs or {})
    --     extraParam.serverMapData = self:ConvertSuccessServerData(result, sceneId) or {}
    --     RuntimeContext.CACHES.SERVER_MAP = extraParam.serverMapData or {}
    --     if not extraParam.serverMapData then
    --         Runtime.InvokeCbk(onFailed)
    --         ErrorHandler.ShowErrorMessage("没有获取到地图数据")
    --     else
    --         local ChangeSceneAnimation = require "Game.Common.ChangeSceneAnimation"
    --         ChangeSceneAnimation.Instance():EnterCityIn(
    --             function()
    --                 local function OnChangeSuccess()
    --                     Runtime.InvokeCbk(onSuc)
    --                     KeyEventProcessor.Enable = true
    --                 end
    --                 local processor = require "Game.Processors.ChangeSceneProcessor"
    --                 processor.Change(name, OnChangeSuccess, extraParam, extraAssets)
    --             end
    --         )
    --     end
    --     AppServices.FarmManager:InitFromServer(result.farmlandMsgs, cfg)
    --     local starMsg = Net.Converter.ConvertSceneStarMsg(result.starMsg)
    --     AppServices.MapStarManager:InitTask(sceneId, starMsg)
    -- end

    -- local function onFail(eCode)
    --     extraParam.serverMapData = {}
    --     RuntimeContext.CACHES.SERVER_MAP = {}
    --     ErrorHandler.ShowErrorPanel(eCode)
    --     Runtime.InvokeCbk(onFailed)
    --     KeyEventProcessor.Enable = true
    -- end

    -- Net.Scenemodulemsg_25301_SceneInfo_Request({sceneId = cfg.params.sceneId}, onFail, onSuccess)
end

function RequestMapDataProcessor:Release()
    self:UnRegisterEvent()
end

return RequestMapDataProcessor
